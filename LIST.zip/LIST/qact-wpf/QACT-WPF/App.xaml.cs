﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Windows;
using System.IO;
using System.Net;
using System.Diagnostics; //SKD03102017

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    /// 
    public partial class App : Application, INotifyPropertyChanged
    {



        //List all Global static Variables
        #region Truely global Variables
        public static string Passphrase = "VIP_QA_PassPhrase";
        public static string AutomationFiles = @"\\fileshareocw\viptestmbrsupapp\TestTools&Automation\Automation_Files\";
        public static string QACTSwitchesFile = Path.Combine(AutomationFiles, "QACTSwitches.json");
        public static string SelfUpdateServer = @"\\fileshareocw\viptestmbrsupapp\TestTools&Automation\QACT_New\QACT.exe";//Saumen031517
        public static string TempFolder = Path.GetTempPath();
        public static string HelpURL = @"http://mysite/personal/anujana/Documents/QACT%20User%20Guide/QACT%20User%20Guide.html";
        public static string SliMSID = "vipqats";
        public static string SliMSPWD = "yoS8%R";
        public static Uri VMPasswordChangeURI = new Uri("https://vm3.visa.com/password/");
        #endregion
        #region iSetup Related Variables
        public static string LocalSetupStoreFolder = System.Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\Setups";
        #endregion
        #region TSU Related Variables
        public static string TSUFileServer = Path.Combine(AutomationFiles, "TestSystemUpdate.txt");

        #endregion
        #region S2S Related Variables
        public static string TestSystemStatusServer = Path.Combine(AutomationFiles, "Test System Status.txt");
        public static string S2SDatabaseServer = Path.Combine(AutomationFiles, "S2SDB.txt");
        public static string LocalSupervisionFolder = System.Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\Supervision";
        public static List<string> ALLQASYSTEMS = new List<string>() { "BASEZ11", "QAZ11", "QA1PZ11", "QA2PZ11", "QA3PZ11", "QA4PZ11", "QA5PZ11", "QA6PZ11", "QA7PZ11" };
        //Add QAZ11 to restricted-Requested by Kaushik:09/12/16
        public static List<string> RestrictedSystems =new List<string>() {/* "QAZ11"*/ };

        #endregion
        #region TSU Request Entry Related Variables
        public static string ExtraTSUCMDServer = Path.Combine(AutomationFiles, "TSU Request Entry.txt");
        public static string SharepointQAScriptFile = @"http://myteams/sites/vipqa/Shared%20Documents/QAScript.xlsx";
        public static string SharepointGlobalFile = @"http://mysite/personal/jmanto/Documents/Regression%20Globals.xlsx";
        #endregion
        #region Regression Related Variables
        public static InputFile InputObj = null;
        public static string CaptureDetailsServer = Path.Combine(AutomationFiles, "CaptureInfo");
        public static string RegressionResultServer = @"\\fileshareocw\viptestmbrsupapp\Regression_Results";
        public static string TestRegressionResultServer = @"\\fileshareocw\VIPTESTENGGFC\Regression_Results";   //GGIRDHAR030717 - Test Framework Enhancement
        public static string KnownDumpsServer = Path.Combine(AutomationFiles, "KnownDumps.txt");
        public static string RegressionErrorDBfile = Path.Combine(AutomationFiles, "RegressionErrorDatabase.csv");

        public static string[] ALLVIPS = { "A", "B", "C", "E", "F" }; //Use it to increase VIP
        public static string[] ALLGLOBALS = { "DCS", "BMX", "NWK", "CFG", "FXT" };
        public static string[] VALIDVTAPES = { "A0", "A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9" };
        public static string[] VALIDLOADS = { "Replace", "Activate", "Reload" };
        public static List<string> CMDLINEARGS;
        

        public static List<string> REGRESSIONTYPES = new List<string>() { "PRODD", "STIPD", "BADD","BADD+PCAS", "SOAP", "DRB", "LOAD_NIGHT", "UNBALANCED", "PCAS", "DURBIN", "TOKEN", "APF" };//removed , "ECIP"
        public static List<string> HSMUNITS = new List<string>() { "NA", "900-90F", "940-94F", "950-95F", "960-96F", "970-97F", "980-98F", "990-99F", "9A0-9AF" };//Saumen082616

        #endregion
        #region ARCHES Related Variables
        public static string CSV_TBF_File = Path.Combine(AutomationFiles, "All TBF items.csv");
        public static string SAFallbackFolder = Path.Combine(AutomationFiles, "SwitchActivatedFallback");
        public static string DUMPINITTAPE = "A00097";
        #endregion
        #region SYSUP Related Variables

        #endregion
        #region Issue Tracker Related Variables
        public static string IssueTrackerAPIPath = @"http://ww975dnp01/IssueTracker/api/Observations/";
        public static string IssueTrackerViewPath = @"http://ww975dnp01/IssueTracker/IssueView.html?id=";
        #endregion

        public static IDictionary<string, string> debuggingFilePaths = new Dictionary<string, string>();

        [Obsolete]
        public static string QAGlobalServer = @"\\fileshareocw\viptestmbrsupapp\TestTools&Automation\TSU\Globals.xlsx";

        [Obsolete]
        public static string QAScriptFile = Path.Combine(AutomationFiles, "QA_System_Script.xls");
        string exp_method;   //SKD03102017
        public ExceptionHandlingDriver exp;   //SKD03102017

        //

        #region Properties bind to UI
        int _Progress = 0;
        public int Progress { get { return _Progress; } set { this._Progress = value; NotifyPropertyChanged("Progress"); } }
        double _ProgOpacity = 0;
        public double ProgOpacity { get { return this._ProgOpacity; } set { this._ProgOpacity = value; NotifyPropertyChanged("ProgOpacity"); } }
        string _Status = "";
        public string Status { get { return this._Status; } set { this._Status = value; NotifyPropertyChanged("Status"); } }
        bool _Marque = false;
        public bool Marque { get { return this._Marque; } set { this._Marque = value; NotifyPropertyChanged("Marque"); } }

        private bool _IsVIPTESTENGMember = true;
        /// <summary>
        /// Set to true if user is in "VISA\QA - VIP Support" group or id is svc_vtss.
        /// Otherwise false
        /// </summary>
        public bool IsVIPTESTENGMember
        {
            get { return _IsVIPTESTENGMember; }
            set { _IsVIPTESTENGMember = value; NotifyPropertyChanged("IsQAMember"); }
        }

        public string AssemblyVersion
        {
            get
            {
                return "V-" + Assembly.GetEntryAssembly().GetName().Version;
            }
        }
        #endregion
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            IsVIPTESTENGMember = CheckVIPTESTENGMember();
            CMDLINEARGS = e.Args.Select(x => x.ToUpper()).ToList();
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            if (Environment.CurrentDirectory == SelfUpdateServer.Replace("\\QACT.exe", ""))
                Application.Current.Shutdown();
        }

        void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Exception ex = (Exception)e.ExceptionObject;
            exp_method = GetExecutingMethodName(ex); //SKD03102017
            string[] exp_method_arr = exp_method.Split('.');  //SKD03102017
            exp.newHandleError("Unhandled Error" + exp_method_arr[1], "New Conn During TPFSETUP", ErrorTypes.NotifyandAbort, ErrorGroup.UNHANDLED_ERROR);  //SKD03102017
            //MessageBox.Show("QACT is crashed.\nError:\n" + ex.Message);
            //Saumen012617 - removed stacktrace to get the whole exception information
            //System.IO.File.WriteAllText(System.IO.Directory.GetCurrentDirectory() + @"\QACT_crash_debug.dbg", ex.StackTrace);
            File.WriteAllText(Directory.GetCurrentDirectory() + @"\QACT_crash_debug.dbg", ex.ToString());
            //Saumen012617
            saveDebugFile();

        }
        bool CheckVIPTESTENGMember()
        {
            WindowsIdentity currentUser = WindowsIdentity.GetCurrent();
            //provide special permission to svc_vtss id
            if (currentUser.Name.Equals("VISA\\svc_vtss", StringComparison.InvariantCultureIgnoreCase))
                return true;
            foreach (var item in currentUser.Groups)
            {
                try
                {
                    if (item.Translate(typeof(NTAccount)).Value.Contains("VISA\\QA - VIP Support"))
                        return true;
                }
                catch { }
            }

            return false;
        }
        void saveDebugFile()
        {
            foreach (KeyValuePair<string, string> entry in debuggingFilePaths)
                System.IO.File.Copy(entry.Key, entry.Value, true);
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        private void Application_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {

            Exception ex = (Exception)e.Exception;
            //MessageBox.Show("QACT UI is crashed.\nError:\n" + ex.Message);
            //Saumen012617 - removed stacktrace to get the whole exception information
            //System.IO.File.WriteAllText(System.IO.Directory.GetCurrentDirectory() + @"\QACT_UI_crash_debug.dbg", ex.StackTrace);
            File.WriteAllText(Directory.GetCurrentDirectory() + @"\QACT_UI_crash_debug.dbg", ex.ToString());
            //Saumen012617
            saveDebugFile();

        }

        //Start SKD03102017
        private static string GetExecutingMethodName(Exception exception)       // New method to identify the method from where the exception occuered
        {
            StackTrace trace = new StackTrace(exception);
            var frame = trace.GetFrame(0);
            var method = frame.GetMethod();

            return string.Concat(method.DeclaringType.FullName, ".", method.Name);
        }

        //ENDSKD03102017

    }
}


// ***************************************************************************************
//                                  Change Log
// ***************************************************************************************
// Date       - Name            - Description                               - Label
// ***************************************************************************************
// 03/01/2017 - Gaurav Girdhar  - Introduce new variable for Test Framework - GGIRDHAR030717
// 08/26/2016 - Saumen Biswas   - Added HSM series 99* & 9A*                - Saumen082616
// ***************************************************************************************
