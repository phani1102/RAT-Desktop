﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace QACT_WPF
{
    public class HLLAPI
    {
        /// <summary>
        /// This is the main interfacing function
        /// </summary>
        /// <param name="Func"></param>
        /// <param name="Data"></param>
        /// <param name="Length"></param>
        /// <param name="RETC"></param>
        /// <returns></returns>
        [DllImport("EHLAPI32.dll")]
        static extern UInt32 hllapi(out int Func, StringBuilder Data, out int Length, out int RETC);
        public string screenshotfile;
        string screenseparator = "------------------------------------------------------------------------------------------------------------------------------";
        public string SessionShortName { get; set; }
        public bool IsLogRequired { get; set; }
        const int LOOPDELAY = 200;//in miliseconds
        //Saumen022317
        //Saumen012417
        //public int Loop_Counter = 0;
        //const int Screen_Capture_Interval = 5; //in minutes
        //Saumen012417
        DateTime previous_time = DateTime.Now;
        //Saumen022317
        DispatcherTimer Hotspot;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="shortname"></param>
        /// <param name="logrequired"></param>
        /// <param name="Purpose"></param>
        public HLLAPI(string shortname, bool logrequired, string Purpose)
        {
            SessionShortName = shortname;
            IsLogRequired = logrequired;
            if (IsLogRequired)
            {
                // Log = new ObservableCollection<string>();
                //   LogFileName = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\HLLAPILOG\" + logfile;
                if (!System.IO.Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\HLLAPILOG"))
                    System.IO.Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\HLLAPILOG");
                //   Log.CollectionChanged += Log_CollectionChanged;
                //   Log.Add("Requested Session shortname=" + SessionShortName);
                //////////////////////////////// Deleting log files older than 7 days ////////////////////////////////////////
                System.IO.Directory.GetFiles(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "HLLAPILOG"))
                                            .Select(file => new System.IO.FileInfo(file))
                                             .Where(fileInfo => fileInfo.LastAccessTime < DateTime.Now.AddDays(-7))
                                             .ToList()
                                             .ForEach(oldfile => oldfile.Delete());

                screenshotfile = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\HLLAPILOG\Screenshot_" + SessionShortName + '_' + Purpose + "_" + DateTime.Now.ToString(@"dd MMM yyyy HH mm ss") + ".txt";
                System.IO.File.WriteAllLines(screenshotfile, new string[] { "================= Screenshot of session " + SessionShortName + " " + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + " =================", "Using QACT V- " + System.Reflection.Assembly.GetEntryAssembly().GetName().Version });
            }
        }

        #region API Functions
        /// <summary>
        /// This function tries to catch memory access errors from hllapi and if the error occurs retry the function for 3 times
        /// </summary>
        /// <param name="Function"></param>
        /// <param name="Data"></param>
        /// <param name="Length"></param>
        /// <param name="RETC"></param>
        [System.Runtime.ExceptionServices.HandleProcessCorruptedStateExceptionsAttribute()]
        void tryhllapi(out int Function, StringBuilder Data, out int Length, out int RETC)
        {
            //Run it for max 3 times
            for (int i = 0; i < 3; i++)
            {
                try
                {
                    hllapi(out Function, Data, out Length, out RETC);
                    return;
                }
                catch (Exception)
                { }

            }
            // when all 3 retries get error this last will try and throw the error.
            try
            {
                //Now try to Disconnect and connect again (do not use the tryhllapi method)
                DisConnect();
                Connect();
                //
                hllapi(out Function, Data, out Length, out RETC);
            }
            catch (Exception)
            {
                throw new ExternalException("HLLAPI memory corruption Exception.Disconnect/Connect didn't work.");
            }
        }
        private int Connect()
        {
            int Function = 1; StringBuilder Data = new StringBuilder(SessionShortName); int Length = Data.Length; int RETC;
            hllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        private int DisConnect()
        {
            int Function = 2; StringBuilder Data = new StringBuilder(); int Length; int RETC;
            hllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Connect Presentation Space.
        /// ShortSessionName:A 1-character PS short name; must be a letter of the alphabet (A–Z).
        /// </summary>
        /// <param name="ShortSessionName"></param>
        public int ConnectSession()
        {
            int Function = 1; StringBuilder Data = new StringBuilder(SessionShortName); int Length = Data.Length; int RETC;
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Disconnect Presentation Space
        /// </summary>
        /// <param name="ShortSessionName"></param>
        /// <returns></returns>
        public int DisconnectSession()
        {
            int Function = 2; StringBuilder Data = new StringBuilder(); int Length; int RETC;
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Function 3: Send Key
        /// keytoenter:A string of maximum 255 characters (keystrokes) to be sent to the host PS. The string must end with an EOT character if STREOT is set in Function 9.
        /// </summary>
        /// <param name="keytoenter"></param>
        /// <returns></returns>
        public int SendText(string keytoenter, bool password = false, bool waitforActiveVM = true)
        {
            //Wait before sending Text
            int counter = 0;
            if (waitforActiveVM)
            {
                int WAITRC = Wait();
                while (WAITRC == 4 || WAITRC == 5)
                {
                    try
                    {
                        SendText(Keys3270.Reset, false, false);
                    }
                    catch { }
                    counter++;
                    if (counter == 5)
                    {
                        System.IO.File.AppendAllLines(screenshotfile, new List<string>() { DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + "==>Was trying to enter: " + keytoenter + ": For Debug:WAITRC=" + WAITRC });
                        throw new TimeoutException("VM is not accepting inputs.");
                    }
                    WAITRC = Wait();
                }
            }

            //
            int Function = 3; StringBuilder Data = new StringBuilder(keytoenter); int Length = Data.Length; int RETC;
            if (IsLogRequired)
            {
                //var screenlines = GetLines(50);
                var screenlines = GetLines(30);//Saumen022317
                var screen = new string[] { screenseparator }.Concat(screenlines).Concat(new string[] { screenseparator, DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + "==> Entering " + (password ? "********" : keytoenter) });
                if (string.Concat(screenlines).Replace("RUNNING   RSVM3", "").Trim() == "")
                    screen = new string[] { screenseparator }.Concat(new string[] { screenseparator, DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + "==> Entering " + (password ? "********" : keytoenter) });
                //if (keytoenter != Keys3270.Home)//Saumen022317
                    System.IO.File.AppendAllLines(screenshotfile, screen);
            }
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }

        private int Wait()
        {
            int Function = 4; StringBuilder Data = new StringBuilder(); int Length; int RETC;
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Search Presentation Space
        /// Function replaces the value of call parameter Data length with the PS position where specified text was found, or 0 if the text was not found.
        /// foundat: It will return PS position where specified text was found, or 0 if the text was not found.
        /// </summary>
        /// <param name="tofind"></param>
        /// <returns></returns>
        public int SearchString(string tofind, int startpoint)
        {
            int Function = 6; StringBuilder Data = new StringBuilder(tofind); int Length = Data.Length; int RETC = startpoint; int foundat = 0;
            tryhllapi(out Function, Data, out Length, out RETC);
            return foundat;
        }
        /// <summary>
        /// Query Cursor Location
        /// </summary>
        /// <param name="tofind"></param>
        /// <param name="startpoint"></param>
        /// <param name="Cursorat"></param>
        /// <returns></returns>
        public int QueryCursorLocation()
        {
            int Function = 7; StringBuilder Data = new StringBuilder(); int Length; int RETC; int Cursorat = 0;
            tryhllapi(out Function, Data, out Length, out RETC);
            return Cursorat;
        }
        /// <summary>
        /// Copy Presentation Space to String
        /// </summary>
        /// <param name="MaxLength"></param>
        /// <param name="screentext"></param>
        /// <returns></returns>
        string GetSessionScreenText(int MaxLength)
        {
            string screentext = "";
            int Function = 8; int Length = MaxLength; StringBuilder Data = new StringBuilder(Length); int RETC;
            tryhllapi(out Function, Data, out Length, out RETC);
            return screentext;
        }
        /// <summary>
        /// Returns a list of Open Sessions
        /// </summary>
        /// <returns></returns>
        public List<string> GetOpenSessions()
        {
            int Function = 10; int Length = 312; StringBuilder Data = new StringBuilder(312); int RETC;
            List<string> SessionNames = new List<string>();
            tryhllapi(out Function, Data, out Length, out RETC);
            return SessionNames;
        }
        /// <summary>
        /// Lock session so that keyboard inputs are not accepted
        /// </summary>
        /// <returns></returns>
        public int LockConnectedSession()
        {
            int Function = 11; StringBuilder Data = new StringBuilder(); int Length; int RETC;
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Unlock keyboard hold
        /// </summary>
        /// <returns></returns>
        public int UnlockConnectedSession()
        {
            int Function = 12; StringBuilder Data = new StringBuilder(); int Length; int RETC;
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Put a text to a particular location
        /// </summary>
        /// <param name="Text"></param>
        /// <param name="startposition"></param>
        /// <returns></returns>
        int TypeText(string Text, int startposition)
        {
            int Function = 15; StringBuilder Data = new StringBuilder(Text); int Length = Data.Length; int RETC = startposition;
            // if (IsLogRequired)
            //   Log.Add(DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + "==>Call TypeText(" + Text+","+startposition + ")");
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Pause for a provided number of seconds. 
        /// </summary>
        /// <param name="Seconds"></param>
        /// <returns></returns>
        public int Pause(int Seconds)
        {
            //
            DateTime endtime = DateTime.Now.AddSeconds(Seconds);
            do
            {
                System.Threading.Thread.Sleep(LOOPDELAY);
            } while (DateTime.Now < endtime);
            return 0;
        }
        /// <summary>
        /// Gets row & column for the current session
        /// </summary>
        /// <returns></returns>
        string GetRowColCount()
        {
            int row = 0; int col = 0;
            int Function = 22; int Length = 18; StringBuilder Data = new StringBuilder(18); int RETC; Data.Append(SessionShortName);
            tryhllapi(out Function, Data, out Length, out RETC);
            switch (RETC)
            {
                case 0:
                    row = Convert.ToInt16(Data[11]);
                    switch (row)
                    {
                        case 24:
                            col = 80;
                            break;
                        case 27:
                            col = 132;
                            break;
                        case 32:
                            col = 80;
                            break;
                        case 43:
                            col = 80;
                            break;
                        default:
                            break;
                    }
                    break;
            }
            return row + "," + col;
        }
        /// <summary>
        /// Search for a field with exact name
        /// </summary>
        /// <param name="FieldText"></param>
        /// <param name="startpoint"></param>
        /// <returns></returns>
        int SearchField(string FieldText, int startpoint)
        {
            int Function = 30; StringBuilder Data = new StringBuilder(FieldText); int Length = Data.Length; int RETC = startpoint; int foundat = 0;
            tryhllapi(out Function, Data, out Length, out RETC);
            switch (RETC)
            {
                case 0:
                    foundat = Length;
                    break;
            }
            return foundat;
        }
        /// <summary>
        /// FieldType format
        ///Content  Description
        ///^^ or T^ This field.
        ///N^       Next field (protected or unprotected).
        ///NP       Next protected field.
        ///NU       Next unprotected field.
        ///P^       Previous field (protected or unprotected)
        ///PP       Previous protected field.
        ///PU       Previous unprotected field.
        ///^ = a space
        /// </summary>
        /// <param name="FieldType"></param>
        /// <param name="startpoint"></param>
        /// <param name="foundat"></param>
        /// <returns></returns>
        int SearchFieldByType(string FieldType, int startpoint)
        {
            int Function = 31; StringBuilder Data = new StringBuilder(FieldType); int Length = Data.Length; int RETC = startpoint; int foundat = 0;
            tryhllapi(out Function, Data, out Length, out RETC);
            switch (RETC)
            {
                case 0:
                    foundat = Length;
                    break;
            }
            return foundat;
        }
        /// <summary>
        /// FieldType format
        ///Content  Description
        ///^^ or T^ This field.
        ///N^       Next field (protected or unprotected).
        ///NP       Next protected field.
        ///NU       Next unprotected field.
        ///P^       Previous field (protected or unprotected)
        ///PP       Previous protected field.
        ///PU       Previous unprotected field.
        ///^ = a space
        /// </summary>
        /// <param name="FieldType"></param>
        /// <param name="startpoint"></param>
        /// <param name="FieldLength"></param>
        /// <returns></returns>
        int GetFieldLengthByType(string FieldType, int startpoint)
        {
            int Function = 32; StringBuilder Data = new StringBuilder(FieldType); int Length = Data.Length; int RETC = startpoint; int FieldLength = 0;
            tryhllapi(out Function, Data, out Length, out RETC);
            switch (RETC)
            {
                case 0:
                    FieldLength = Length;
                    break;
            }
            return FieldLength;
        }
        /// <summary>
        /// Type text to a field
        /// </summary>
        /// <param name="Text"></param>
        /// <param name="fieldposition"></param>
        /// <returns></returns>
        int TypeTextToField(string Text, int fieldposition)
        {
            int Function = 33; StringBuilder Data = new StringBuilder(Text); int Length = Data.Length; int RETC = fieldposition;
            // if (IsLogRequired)
            //    Log.Add(DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + "==>Call TypeTextToField(" + Text+","+fieldposition + ")");
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Gets text from a field with particular position
        /// </summary>
        /// <param name="NumberOfCharacter"></param>
        /// <param name="fieldposition"></param>
        /// <returns></returns>
        string GetFieldText(int NumberOfCharacter, int fieldposition)
        {
            string FieldText = "";
            int Function = 34; StringBuilder Data = new StringBuilder(NumberOfCharacter); int Length = NumberOfCharacter; int RETC = fieldposition;
            tryhllapi(out Function, Data, out Length, out RETC);
            switch (RETC)
            {
                case 0:
                    FieldText = Data.ToString();
                    break;
            }
            return FieldText;
        }
        /// <summary>
        /// Set the cursor to the specified position
        /// </summary>
        /// <param name="CursorPosition"></param>
        /// <returns></returns>
        int SetCursor(int CursorPosition)
        {
            int Function = 40; StringBuilder Data = new StringBuilder(); int Length; int RETC = CursorPosition;
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Prevent accidental close by user
        /// </summary>
        /// <returns></returns>
        public int PreventClosing()
        {
            int Function = 41; StringBuilder Data = new StringBuilder(SessionShortName); int Length = Data.Length; int RETC;
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Allow to close window
        /// </summary>
        /// <returns></returns>
        public int AllowClosing()
        {
            int Function = 43; StringBuilder Data = new StringBuilder(SessionShortName); int Length = Data.Length; int RETC;
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Send a file to host
        /// </summary>
        /// <param name="PCFileName"></param>
        /// <param name="HostFileName"></param>
        /// <returns></returns>
        public string SendFile(string PCFileName, string HostFileName, int lrec = 130, bool append = false)
        {
            if (!System.IO.File.Exists(PCFileName))
                return String.Empty;

            /////////////////////////////////////////////// FILE SEGMENTATION FOR LARGER FILES ///////////////////////////////////////////////////////
            string[] PCfile = System.IO.File.ReadAllLines(PCFileName);
            int maxChunkSize = 11 * 1024 * 2;   // since Unicode, UTF-16 is 2 bytes long
            if (Encoding.Unicode.GetByteCount(String.Join("", PCfile)) > maxChunkSize)
            {// File is large than maxChunkSize

                List<string> chunkFile = new List<string>();

                // now divide the file along line boundaries into chunks
                for (int ln = 0; ln < PCfile.Length; )
                {
                    for (int chunkSize = ASCIIEncoding.Unicode.GetByteCount(PCfile[ln]); chunkSize <= maxChunkSize; chunkSize += ASCIIEncoding.Unicode.GetByteCount(PCfile[ln]))
                    {
                        chunkFile.Add(PCfile[ln]);
                        ++ln;
                        if (ln >= PCfile.Length)
                            break;
                    }

                    string tmpPath = System.IO.Path.GetTempPath() + System.IO.Path.GetFileName(PCFileName);
                    System.IO.File.WriteAllLines(tmpPath, chunkFile);
                    // send chunk files
                    SendFile(tmpPath, HostFileName, lrec, append);
                    append = true;

                    //System.IO.File.Delete(tmpPath);
                    chunkFile.Clear();
                }
                return String.Empty;
            }
            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            SendText(Keys3270.Clear);

            string transferstring = PCFileName + " " + SessionShortName.ToLower() + ": " + HostFileName.Replace(".", " ") + " (ASCII CRLF " + (append ? "APPEND " : String.Empty) + "LRECL " + lrec;//CRLF
            int Function = 90; StringBuilder Data = new StringBuilder(transferstring); int Length = Data.Length; int RETC;
            if (IsLogRequired)
            {
                //  Log.Add(DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + "==>Call SendFile(" + PCFileName + "," + HostFileName + ")");
                var screen = new string[] { screenseparator }.Concat(new string[] { screenseparator, DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + "==> Send file: " + PCFileName + "-->" + HostFileName });
                System.IO.File.AppendAllLines(screenshotfile, screen);
            }
            tryhllapi(out Function, Data, out Length, out RETC);

            string result = "";
            switch (RETC)
            {
                case 2:
                    result = "A parameter error occurred.";
                    break;
                case 3:
                    result = "The file was transferred.";
                    break;
                case 4:
                    result = "The file was transferred with records segmented.";
                    break;
                case 9:
                    result = "A system error occurred.";
                    break;
                case 27:
                    result = "The file transfer was terminated by CTRL C.";
                    break;
                case 301:
                    result = "Invalid function number.";
                    break;
                case 302:
                    result = "File not found.";
                    break;
                case 303:
                    result = "Path not found.";
                    break;
                case 305:
                    result = "Access denied.";
                    break;
                case 308:
                    result = "Insufficient memory.";
                    break;
                case 310:
                    result = "Invalid environment.";
                    break;
                case 311:
                    result = "Invalid format.";
                    break;
                default:
                    result = "Unknown return code:" + RETC;
                    break;
            }
            return result;
        }
        /// <summary>
        /// receive a file from HOST
        /// </summary>
        /// <param name="PCFileName"></param>
        /// <param name="HostFileName"></param>
        /// <returns></returns>
        public string ReceiveFile(string PCFileName, string HostFileName)
        {
            SendText(Keys3270.Clear);
            string transferstring = PCFileName + " " + SessionShortName.ToLower() + ": " + HostFileName.Replace(".", " ") + " (ASCII CRLF";
            int Function = 91; StringBuilder Data = new StringBuilder(transferstring); int Length = Data.Length; int RETC;
            if (IsLogRequired)
            {
                var screen = new string[] { screenseparator }.Concat(new string[] { screenseparator, DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + "==> Receive file: " + PCFileName + "<--" + HostFileName });
                System.IO.File.AppendAllLines(screenshotfile, screen);
            }
            tryhllapi(out Function, Data, out Length, out RETC);
            string result = "";
            switch (RETC)
            {
                case 2:
                    result = "A parameter error occurred.";
                    break;
                case 3:
                    result = "The file was transferred.";
                    break;
                case 4:
                    result = "The file was transferred with records segmented.";
                    break;
                case 9:
                    result = "A system error occurred.";
                    break;
                case 27:
                    result = "The file transfer was terminated by CTRL C.";
                    break;
                case 301:
                    result = "Invalid function number.";
                    break;
                case 302:
                    result = "File not found.";
                    break;
                case 303:
                    result = "Path not found.";
                    break;
                case 305:
                    result = "Access denied.";
                    break;
                case 308:
                    result = "Insufficient memory.";
                    break;
                case 310:
                    result = "Invalid environment.";
                    break;
                case 311:
                    result = "Invalid format.";
                    break;
                default:
                    result = "Unknown return code:" + RETC;
                    break;
            }
            return result;
        }
        /// <summary>
        /// Convert specified row col to PS position
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        int ConvertRowColToPosition(int row, int col)
        {
            int Function = 99; StringBuilder Data = new StringBuilder(SessionShortName + "R"); int Length = row; int RETC = col;
            tryhllapi(out Function, Data, out Length, out RETC);
            int position = 0;
            switch (RETC)
            {
                case 0:
                case 9998:
                case 9999:
                    break;
                default:
                    position = RETC;
                    break;
            }
            return position;
        }
        /// <summary>
        /// Convert specified position to row col
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        string ConvertPositionToRowCol(int position)
        {
            int Function = 99; StringBuilder Data = new StringBuilder(SessionShortName + "P"); int Length; int RETC = position;
            tryhllapi(out Function, Data, out Length, out RETC);
            int row = 0; int col = 0;
            switch (RETC)
            {
                case 0:
                case 9998:
                case 9999:
                    break;
                default:
                    row = Length; col = RETC;
                    break;
            }
            return row + "," + col;
        }
        /// <summary>
        /// connect to window services
        /// </summary>
        /// <returns></returns>
        public int ConnectWindowService()
        {
            int Function = 101; StringBuilder Data = new StringBuilder(SessionShortName); int Length = Data.Length; int RETC;
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Disconnect window services
        /// </summary>
        /// <returns></returns>
        int DisconnectWindowService()
        {
            int Function = 102; StringBuilder Data = new StringBuilder(SessionShortName); int Length = Data.Length; int RETC;
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Set window visibility
        /// </summary>
        /// <param name="visibility"></param>
        /// <returns></returns>
        int SetWindowStatus(bool visibility)
        {
            int Function = 104; Byte[] x = { (byte)((int)SessionShortName[0]), 1 };

            if (visibility)
                x = x.Concat(new byte[] { 0, 8 }).ToArray();
            else
                x = x.Concat(new byte[] { 16, 0 }).ToArray();
            int Length = x.Length; int RETC = 0;
            StringBuilder Data = new StringBuilder(string.Concat(x.Select(d => Convert.ToChar(d))));
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        #endregion



        #region User functions
        /// <summary>
        /// Type Text starting from particular row and col, Return Code 0 & 6(truncated) are success results.
        /// </summary>
        /// <param name="Text"></param>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        public int TypeText(string Text, int row, int col)
        {
            // if (IsLogRequired)
            //   Log.Add(DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + "==>Call TypeText(" + Text + "," + row + "," + col + ")");
            int Function = 15; StringBuilder Data = new StringBuilder(Text); int Length = Data.Length; int RETC;
            RETC = ConvertRowColToPosition(row, col);
            tryhllapi(out Function, Data, out Length, out RETC);
            return RETC;
        }
        /// <summary>
        /// Get text of the whole screen
        /// </summary>
        /// <returns></returns>
        public string GetSessionScreenText()
        {
            string screentext = "";
            int row, col;
            string rowcol = GetRowColCount();
            row = Convert.ToInt16(rowcol.Split(',')[0]); col = Convert.ToInt16(rowcol.Split(',')[1]);
            int Function = 8; int Length = row * col; StringBuilder Data = new StringBuilder(Length); int RETC = 1;
            tryhllapi(out Function, Data, out Length, out RETC);
            switch (RETC)
            {
                case 0:
                    screentext = Data.ToString();//;.Substring(0, Length);
                    break;
            }
            return screentext;
        }
        /// <summary>
        /// Search a particular string in the screen. ignorecase is on by default. Returns the non-zero position where the text was found.
        /// If nothing found 0 is returned.
        /// </summary>
        /// <param name="tofind"></param>
        /// <param name="ignorecase"></param>
        /// <returns></returns>
        public int SearchString(string tofind, bool ignorecase = true)
        {
            string screentext; int foundat = 0;
            screentext = GetSessionScreenText();
            if (ignorecase)
            {
                tofind = tofind.ToUpper(); screentext = screentext.ToUpper();
            }
            if (screentext.Contains(tofind))
            {
                foundat = screentext.IndexOf(tofind) + 1;
            }
            return foundat;
        }
        /// <summary>
        /// Set the cursor to particular row and col. If row(or col)>max row(or col) then last row(or col) is selected.
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        public void SetCursor(int row, int col)
        {

            int sessrow, sesscol;
            string sessrowcol = GetRowColCount();
            sessrow = Convert.ToInt16(sessrowcol.Split(',')[0]); sesscol = Convert.ToInt16(sessrowcol.Split(',')[1]);
            if (sessrow < row)
                row = sessrow;
            if (sesscol < col)
                col = sesscol;
            int result = SetCursor(row * sesscol + col);

        }
        /// <summary>
        /// Tries to match the regex against the  VM screen and throws an exception in case if it fails to match in the specified amount of time
        /// </summary>
        /// <param name="regexToCheck"></param>
        /// <param name="timeout"></param>
        /// <param name="hotspot"></param>
        /// <returns></returns>
        public Match WaitForRegexEx(Regex regexToCheck, int timeout = 1, bool hotspot = true)
        {
            DateTime endtime = DateTime.Now + TimeSpan.FromSeconds(timeout);

            List<string> screen = new List<string>();

            do
            {
                screen.Clear();
                screen.AddRange(GetLines(99));
                string lastline = screen.Count > 0 ? screen.LastOrDefault().ToUpper() : "";

                if (regexToCheck.Options.HasFlag(RegexOptions.Multiline))
                { // multiline
                    if (regexToCheck.IsMatch(String.Join(Environment.NewLine, screen)))
                        return regexToCheck.Match(String.Join(Environment.NewLine, screen));
                }
                else
                {// single line 
                    foreach (string ln in screen)
                    {
                        if (regexToCheck.IsMatch(ln))
                            return regexToCheck.Match(ln);
                    }
                }

                //Turn on HotSpot
                if ((lastline.Contains("HOLDING") || lastline.Contains("MORE")) && hotspot)
                    SendText(Keys3270.Clear);

                System.Threading.Thread.Sleep(LOOPDELAY);

            } while (DateTime.Now < endtime);

            throw new RegexMatchTimeoutException("Unable to match regex: " + regexToCheck.ToString() + Environment.NewLine + "Timeout: " + timeout);

        }

        public Match WaitForRegex(Regex regexToCheck, int timeout, bool hotspot = true)
        {
            DateTime endtime = DateTime.Now + TimeSpan.FromSeconds(timeout);
            List<string> screen = new List<string>();
            try
            {
                do
                {
                    screen.Clear();
                    screen.AddRange(GetLines(99));
                    string lastline = screen.Count > 0 ? screen.LastOrDefault().ToUpper() : "";

                    if (regexToCheck.Options.HasFlag(RegexOptions.Multiline))
                    { // multiline
                        if (regexToCheck.IsMatch(String.Join(Environment.NewLine, screen)))
                            return regexToCheck.Match(String.Join(Environment.NewLine, screen));
                    }
                    else
                    {// single line 
                        foreach (string ln in screen)
                        {
                            if (regexToCheck.IsMatch(ln))
                                return regexToCheck.Match(ln);
                        }
                    }

                    //Turn on HotSpot
                    if ((lastline.Contains("HOLDING") || lastline.Contains("MORE")) && hotspot)
                        SendText(Keys3270.Clear);

                    System.Threading.Thread.Sleep(LOOPDELAY);

                }
                while (DateTime.Now < endtime);
            }
            catch (Exception)
            {

            }
            return Match.Empty;
        }

        /// <summary>
        /// Wait for a particular waitstring to appear at the screen for max timeout seconds. It checks the screen at 200 ms Interval, ignorecase is on by default.
        /// Non zero return denotes the text was found.
        /// </summary>
        /// <param name="waitstring"></param>
        /// <param name="timeout"></param>
        /// <param name="ignorecase"></param>
        /// <returns></returns>
        public int WaitforString(string waitstring, int timeout, bool ignorecase = true, bool hotspot = true)
        {
            DateTime endtime = DateTime.Now + TimeSpan.FromSeconds(timeout);
            int foundat;
            //Loop_Counter = 0; //Saumen012417//Saumen022317
            do
            {
                var lines = GetLines(50);
                string lastline = lines.Count > 0 ? lines.LastOrDefault().ToUpper() : "";
                foundat = SearchString(waitstring, ignorecase);
                if (foundat > 0)
                    break;
                //Turn on HotSpot
                if ((lastline.Contains("HOLDING") || lastline.Contains("MORE")) && hotspot)
                    SendText(Keys3270.Clear);
                System.Threading.Thread.Sleep(LOOPDELAY);
                //Saumen012417
                //Saumen022317
                //Loop_Counter++;
                //if (((LOOPDELAY * Loop_Counter) / (Screen_Capture_Interval * 60 * 1000)) % 1 == 0)
                if (DateTime.Now.Subtract(previous_time).TotalMinutes >= 5)//Saumen022317
                {
                    SendText(Keys3270.Home);
                    previous_time = DateTime.Now;//Saumen022317
                }
                //Saumen012417
            } while (foundat == 0 && DateTime.Now < endtime);
            return foundat;
        }
        /// <summary>
        /// Returns 0 if waitstring found, 1 if nothing found/some error, enc_error will be the error what was encountered.
        /// </summary>
        /// <param name="waitstring"></param>
        /// <param name="timeout"></param>
        /// <param name="ErrorsList"></param>
        /// <param name="ignorecase"></param>
        /// <returns></returns>
        public int WaitforString(string waitstring, int timeout, List<string> ErrorsList, out string enc_error, int linenumber = 0, bool ignorecase = true, bool hotspot = true)
        {
            DateTime endtime = DateTime.Now + TimeSpan.FromSeconds(timeout);
            int result = 1;
            enc_error = "";
            //Loop_Counter = 0; //Saumen012417//Saumen022317
            do
            {
                var lines = GetLines(50);
                string lastline = lines.Count > 0 ? lines.LastOrDefault().ToUpper() : "";
                if (linenumber != 0)
                    try
                    {
                        lines = lines.GetRange(linenumber - 1, 1);
                    }
                    catch (Exception)
                    {
                        lines = new List<string>();
                    }

                if (!lines.Any(l => ignorecase ? l.ToUpper().Contains(waitstring.ToUpper()) : l.Contains(waitstring)))
                {
                    var xx = ErrorsList.FirstOrDefault(e => lines.Any(l => l.ToUpper().Contains(e.ToUpper())));
                    if (xx != null)
                    {
                        enc_error = xx;
                        break;
                    }
                }
                else
                {
                    result = 0;
                    break;
                }

                if ((lastline.Contains("HOLDING") || lastline.Contains("MORE")) && hotspot)
                    SendText(Keys3270.Clear);

                System.Threading.Thread.Sleep(LOOPDELAY);
                //Saumen012417
                //Saumen022317
                //Loop_Counter++;
                //if (((LOOPDELAY * Loop_Counter) / (Screen_Capture_Interval * 60 * 1000)) % 1 == 0)
                if (DateTime.Now.Subtract(previous_time).TotalMinutes >= 5)//Saumen022317
                {
                    SendText(Keys3270.Home);
                    previous_time = DateTime.Now;//Saumen022317
                }
                //Saumen012417

            } while ((result == 1 || enc_error == "") && DateTime.Now < endtime);
            return result;
        }

        public int WaitForStringEx(string waitstring, int timeout, List<string> ErrorsList, out string enc_error, int linenumber = 0, bool ignorecase = true, bool hotspot = true)
        {
            int result = WaitforString(waitstring, timeout, ErrorsList, out enc_error, linenumber, ignorecase, hotspot);

            if (result != 0 && String.IsNullOrWhiteSpace(enc_error))
                throw new System.TimeoutException("Time out for waitstring " + waitstring + ", timeOut : " + timeout);

            return result;
        }

        /// <summary>
        /// Returns 0 if any Response found, 1 if no response found, response will be the response what was found.
        /// </summary>
        /// <param name="Responses"></param>
        /// <param name="timeout"></param>
        /// <param name="response"></param>
        /// <param name="ignorecase"></param>
        /// <param name="hotspot"></param>
        /// <returns></returns>
        /// SYSUP SPECIAL
        public int WaitforString(List<string> Responses, int timeout, out string response, bool ignorecase = true, bool hotspot = true)
        {
            DateTime endtime = DateTime.Now + TimeSpan.FromSeconds(timeout);
            int result = 1;
            response = null;
            Responses = Responses.Where(w => w != null && w != "").ToList();
            const int LOOPDELAY = 200;//in miliseconds
            do
            {
                var lines = GetLines(50);
                string lastline = lines.Count > 0 ? lines.LastOrDefault().ToUpper() : "";
                response = Responses.FirstOrDefault(r => lines.Any(l => l.ToUpper().Contains(r.ToUpper())));
                if (response != null)
                {
                    result = 0;
                    break;
                }
                if ((lastline.Contains("HOLDING") || lastline.Contains("MORE")) && hotspot)
                    SendText(Keys3270.Clear);
                System.Threading.Thread.Sleep(LOOPDELAY);
            } while ((result == 1 || response == null) && DateTime.Now < endtime);
            if (Responses.Count == 0)
                result = 0;
            return result;
        }
        /// <summary>
        /// Get all Lines from thse screen including the status line
        /// </summary>
        /// <returns></returns>
        public List<string> GetAllLines()
        {
            return GetLines(100);
        }
        /// <summary>
        /// Get a predefined number of lines from th screen. Start line is by default 1.
        /// </summary>
        /// <param name="endrow"></param>
        /// <param name="startrow"></param>
        /// <returns></returns>
        public List<string> GetLines(int endrow, int startrow = 1)
        {
            List<string> Lines = new List<string>();
            if (endrow < startrow)
                return Lines;
            string screentext = GetSessionScreenText();
            int row, col;
            string rowcol = GetRowColCount();
            row = Convert.ToInt16(rowcol.Split(',')[0]); col = Convert.ToInt16(rowcol.Split(',')[1]);
            if (row < endrow)
                endrow = row;
            try
            {
                for (int i = 0; i < 100; i++)
                {
                    if (screentext.Length > col)
                    {
                        Lines.Add(screentext.Substring(0, col));
                        screentext = screentext.Remove(0, col);
                        continue;
                    }
                    else
                    {
                        Lines.Add(screentext); break;
                    }
                }
                return Lines.GetRange(startrow - 1, endrow <= Lines.Count ? endrow - startrow + 1 : Lines.Count);
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllLines(screenshotfile, new List<string>() { "Error from GETLINES():row " + row + " col " + col + " " + ex.Message });
                return Lines;
            }


        }
        /// <summary>
        /// Set the TextToSet to next unprotectedfield after the field with text FieldText
        /// </summary>
        /// <param name="Field"></param>
        /// <param name="TextToSet"></param>
        /// <returns></returns>
        public int SetFieldValue(string FieldText, string TextToSet, bool ignorecase = true)
        {

            int RC = 24;
            int foundat = SearchString(FieldText, ignorecase);
            if (foundat > 0)
            {
                int nextunprotectedat = SearchFieldByType("NU", foundat);
                if (nextunprotectedat > 0)
                {
                    int nextunprotectedlength = GetFieldLengthByType("T ", nextunprotectedat);
                    if (nextunprotectedlength > 0)
                    {
                        if (TextToSet.Length > nextunprotectedlength)
                            TextToSet = TextToSet.Substring(0, nextunprotectedlength);
                        RC = TypeTextToField(TextToSet, nextunprotectedat);
                    }
                }
            }
            return RC;
        }
        /// <summary>
        /// Show/Hide Attachmate Window
        /// </summary>
        /// <param name="visibility"></param>
        public void ShowWindow(bool visibility)
        {
            if (visibility)
                PreventClosing();
            else
                AllowClosing();
            int RC = SetWindowStatus(visibility);

        }
        /// <summary>
        /// Enter a particular command provided by user and wait for specified wait time. Clears screen by default before entering the command.
        /// </summary>
        /// <param name="command"></param>
        /// <param name="wait"></param>
        /// <param name="clearbeforeenter"></param>
        public void EnterCommand(string command, int wait = 1, bool clearbeforeenter = true, bool password = false)
        {
            if (clearbeforeenter)
                SendText(Keys3270.Clear);
            SendText(Keys3270.Home);
            SendText(command + Keys3270.Enter, password);
            Pause(wait);
        }
        public List<string> RunExec(string execName, TimeSpan waitTime)
        {
            List<string> screen = new List<string>();
            DateTime endTime = DateTime.UtcNow.Add(waitTime);

            EnterCommand(execName);
            do
            {
                screen.AddRange(GetLines(99));
                SendText(Keys3270.Clear);
            } while (!screen.Contains("Ready") && endTime >= DateTime.UtcNow);

            ////////////// On ready Not found /////////////////////
            // Attempt 1 
            if (!screen.Contains("Ready"))
            {
                EnterCommand("b");
                screen.AddRange(GetLines(99));
                SendText(Keys3270.Clear);
            }

            // throw an exception
            if(!screen.Contains("Ready;"))
            {
                ExecTimeOutException execTimeout = new ExecTimeOutException("Exec \"" + execName + "\" time out : " + waitTime.ToString());
                execTimeout.TN3270Screen = screen;
                throw execTimeout;
            }

            return screen;
        }

        void SetHotSpot(bool IsHotspotOn)
        {
            if (IsHotspotOn)
            {
                if (Hotspot == null)
                    Hotspot = new DispatcherTimer();
                Hotspot.Interval = new TimeSpan(0, 0, 0, 0, 200);
                Hotspot.Tick += Hotspot_Tick;
                Hotspot.Start();
            }
            else
                if (Hotspot != null && Hotspot.IsEnabled)
                    Hotspot.Stop();
        }

        void Hotspot_Tick(object sender, EventArgs e)
        {
            string lastline = GetLines(50).Last().ToUpper();
            if (lastline.Contains("HOLDING") || lastline.Contains("MORE"))
                SendText(Keys3270.Clear);

        }
        #endregion


    }

    public class ExecTimeOutException : System.TimeoutException
    {
        public List<string> TN3270Screen = new List<string>();

        public ExecTimeOutException()
            : base()
        { }
        public ExecTimeOutException(string message)
            : base(message)
        { }
        public ExecTimeOutException(string message, Exception innerException)
            : base(message, innerException)
        { }

    }

    public class Keys3270
    {
        public static string AT = "@@";
        public static string Alternate_Cursor = "@$";
        public static string Attention = "@A@Q";
        public static string Backspace = "@<";
        public static string Backtab = "@B";
        public static string Blue = "@A@h";
        public static string Caps_Lock = "@Y";
        public static string Clear = "@C";
        public static string Cursor_Down = "@V";
        public static string Cursor_Left = "@L";
        public static string Cursor_Left_Double = "@A@L";
        public static string Cursor_Right = "@Z";
        public static string Cursor_Right_Double = "@A@Z";
        public static string Cursor_Select = "@A@J";
        public static string Cursor_Up = "@U";
        public static string Delete = "@D";
        public static string Delete_Word = "@A@D";
        public static string Device_Cancel = "@A@R";
        public static string DUP = "@S@x";
        public static string End = "@q";
        public static string Enter = "@E";
        public static string Erase_to_EOF = "@F";
        public static string Erase_Input = "@A@F";
        public static string Reset_Reverse_Video = "@A@c";
        public static string Field_Mark = "@S@y";
        public static string Green = "@A@f";
        public static string Reset_Host_Colors = "@A@l";
        public static string Reverse_Video_On = "@A@9";
        public static string Screen_Lock = "@s";
        public static string System_Request = "@A@H";
        public static string Tab = "@T";
        public static string Test = "@A@C";
        public static string Turquoise = "@A@i";
        public static string Underscore = "@A@b";
        public static string White = "@A@j";
        public static string Word_Tab_Back = "@A@z";
        public static string Word_Tab_Forward = "@A@y";
        public static string Yellow = "@A@g";
        public static string Reset = "@R";
        public static string Home = "@0";
        public static string Insert = "@I";
        public static string Jump = "@J";
        public static string New_Line = "@N";
        public static string Num_Lock = "@t";
        public static string Page_Down = "@v";
        public static string Page_Up = "@u";
        public static string PA1 = "@x";
        public static string PA2 = "@y";
        public static string PA3 = "@z";
        public static string PF1 = "@1";
        public static string PF2 = "@2";
        public static string PF3 = "@3";
        public static string PF4 = "@4";
        public static string PF5 = "@5";
        public static string PF6 = "@6";
        public static string PF7 = "@7";
        public static string PF8 = "@8";
        public static string PF9 = "@9";
        public static string PF10 = "@a";
        public static string PF11 = "@b";
        public static string PF12 = "@c";
        public static string SPF1 = "@d";
        public static string SPF2 = "@e";
        public static string SPF3 = "@f";
        public static string SPF4 = "@g";
        public static string SPF5 = "@h";
        public static string SPF6 = "@i";
        public static string SPF7 = "@j";
        public static string SPF8 = "@k";
        public static string SPF9 = "@l";
        public static string SPF10 = "@m";
        public static string SPF11 = "@n";
        public static string SPF12 = "@o";
        public static string Pink = "@A@e";
        public static string Print_PS = "@A@T";
        public static string Print_Screen = "@P";
        public static string Queue_Overrun = "@/";
        public static string Red = "@A@d";
    }
}
