﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using Excel = Microsoft.Office.Interop.Excel;

namespace QACT_WPF
{
    public static partial class CommonClass
    {
        public static bool UploadFiletoVM(string sourcefilepath, string destfilename, string id, string pwd, out string error)
        {
            error = ""; bool IsSuccess = false;
            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(@"ftp://vm3.visa.com/" + destfilename);
            try
            {
                request.Method = WebRequestMethods.Ftp.UploadFile;
                request.Credentials = new NetworkCredential(id, pwd);
                request.UseBinary = false;
                request.KeepAlive = false;
                using (StreamReader sourceStream = new StreamReader(sourcefilepath))
                {
                    byte[] fileContents = Encoding.Default.GetBytes(sourceStream.ReadToEnd());
                    request.ContentLength = fileContents.Length;
                    using (Stream requestStream = request.GetRequestStream())
                    {
                        try
                        {
                            requestStream.Write(fileContents, 0, fileContents.Length);
                        }
                        catch (Exception ex)
                        {
                            //Close the stream so that the file is not locked.
                            sourceStream.Close();
                            sourceStream.Dispose();
                            throw ex;
                        }

                    }
                }
                IsSuccess = true;
            }
            catch (WebException we)
            {
                error = "Error in transferring file. FTP error: " + ((FtpWebResponse)we.Response).StatusDescription;
            }
            catch (Exception ex)
            {
                error = "Error in transferring file." + ex.Message;
            }
            finally
            {
                request = null;
            }
            return IsSuccess;

        }

        public static void ChangeStatus(string status, int progress, double Opacity, bool marque)
        {
            (Application.Current as App).Status = status;
            (Application.Current as App).Progress = progress;
            (Application.Current as App).ProgOpacity = Opacity;
            (Application.Current as App).Marque = marque;
        }

        public static string GetQAGlobalFromSharepoint()
        {

            try
            {
                //comment out next lineafter Sharepoint integration of globals
                //System.IO.File.Copy(App.QAGlobalServer, App.TempFolder + "temp_global.xlsx", true);
                //Enable the following after Sharepoint integration of globals
                string globalFilePath = System.IO.Path.GetTempFileName();
                using (WebClient wc = new WebClient())
                {
                    wc.Proxy.Credentials = System.Net.CredentialCache.DefaultCredentials;
                    wc.UseDefaultCredentials = true;
                    //System.IO.File.Delete(App.TempFolder + "temp_global.xlsx");
                    //wc.DownloadFile(App.SharepointGlobalFile, App.TempFolder + "temp_global.xlsx");
                    wc.DownloadFile(App.SharepointGlobalFile, globalFilePath);
                }
                //return App.TempFolder + "temp_global.xlsx";
                return globalFilePath;
            }
            catch (Exception)
            {

            }
            return null;
        }
        public static void StoreAsJsonFile(this object obj, string jsonPath)
        {
            JavaScriptSerializer serialize = new JavaScriptSerializer();
            try
            {
                System.IO.File.WriteAllText(jsonPath, FormatJson(serialize.Serialize(obj)));
            }
            catch (Exception ex) { throw ex; }
        }
        private static string FormatJson(string json, string INDENT_STRING = "\t")
        {
            int indentation = 0;
            int quoteCount = 0;
            var result =
                from ch in json
                let quotes = ch == '"' ? quoteCount++ : quoteCount
                let lineBreak = ch == ',' && quotes % 2 == 0 ? ch + Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, indentation)) : null
                let openChar = ch == '{' || ch == '[' ? ch + Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, ++indentation)) : ch.ToString()
                let closeChar = ch == '}' || ch == ']' ? Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, --indentation)) + ch : ch.ToString()
                select lineBreak == null
                            ? openChar.Length > 1
                                ? openChar
                                : closeChar
                            : lineBreak;

            return String.Concat(result);
        }
        public static T LoadFromJSONFile<T>(string JsonFilePath)
        {
            T DataObj;

            JavaScriptSerializer serialize = new JavaScriptSerializer();

            try
            {
                DataObj = (T)serialize.Deserialize(System.IO.File.ReadAllText(JsonFilePath), typeof(T));
            }
            catch (Exception ex)
            { throw ex; }

            return DataObj;
        }
        /// <summary>
        /// Changes the VM password using the web interface of VM3, throws AuthenticationException on failure
        /// </summary>
        /// <param name="VMId">VM user id to change password of</param>
        /// <param name="newPassword">new password ti set</param>
        /// <param name="currentPassword">current password that has to be changed</param>
        /// <returns>returns the new changed password</returns>
        public static string ChangeVMPassword(string VMId, string newPassword, string currentPassword)
        {

            using (System.Net.WebClient webclient = new System.Net.WebClient())
            {
                webclient.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
                var VMPasswordChangeData = new System.Collections.Specialized.NameValueCollection
                        {
                            { "userid", VMId},
                            { "password", currentPassword },
                            {"newpassword", newPassword},
                            {"newpw2", newPassword}
                        };

                var resp = webclient.UploadValues(App.VMPasswordChangeURI, "POST", VMPasswordChangeData);
                string ResponseStringJSON = System.Text.Encoding.UTF8.GetString(resp);
                //{"server":"ZWEB05S","rc":0,"text":"Password change complete for PSATPUT3"}
                //{"server":"ZWEB05S","rc":8,"focus":"password","text":"Incorrect userid/password"}
                var respData = (new System.Web.Script.Serialization.JavaScriptSerializer()).Deserialize<Dictionary<string, string>>(ResponseStringJSON);
                if (int.Parse(respData["rc"]) == 0)
                {
                    return newPassword;
                }
                else
                {
                    throw new System.Security.Authentication.AuthenticationException("Password change failed for " + VMId + ": " + ResponseStringJSON);
                }
            }
        }

    }

    /// <summary>
    /// This Webclient extension works with cookie
    /// </summary>
    [System.ComponentModel.DesignerCategory("Code")]
    public class WebClientEx : WebClient
    {
        private int _TimeOut = 100 * 1000;

        public int TimeOut
        {
            get { return _TimeOut; }
            set { _TimeOut = value; }
        }

        private CookieContainer _cookieContainer = new CookieContainer();

        protected override WebRequest GetWebRequest(Uri address)
        {
            WebRequest request = base.GetWebRequest(address);
            request.Timeout = TimeOut;
            if (request is HttpWebRequest)
            {
                (request as HttpWebRequest).CookieContainer = _cookieContainer;
            }
            return request;
        }

    }
}
