﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QACT_WPF
{
    public static partial class CommonClass
    {
        /// <summary>
        /// Log of user visible changes
        /// </summary>
        public static readonly string UpdateLog =
@"Date          Change
05/04/17    -Add logic to Upload REG LOG to server.
11/03/16    -Script file preparation for future system update module.(-Krishnendu) 
10/06/16    -Add ZKSET APSC7F after first ZRIPL.
            -Script textbox in S2S is now ReadOnly. 
09/28/16    -Make all systems avaliable to S2S due to frequent requests of blocking.
09/23/16    -Issue Tracker is now disabled as the server machine is down.
            -TSU Request entry UI fix.
            -ARCHES will not call issue tracker as the server is down.
09/19/16    -S2S is now capable of parsing TSU section.
            -Automated system build script preparation will now parse TSU for old changes.
            -No popup for ZUODF DIR ALL during system update, just INIT database before closing.
            -System update UI changes to show exact which command is applied.
            -Throw exception when SLiMS Webapp login is not successful during TSU generation.
09/13/16    -Add QAZ11X to restricted systems list. Requested by Kaushik. 
             DDR to QAZ11X is not possible from S2S until restriction is removed.
            -'Processing completed with Errors' is changed to NotifyOnly.
            -Populate Globals from server only when there is at least one blank global in UI.
09/09/16    -When setup need to be created with both DCS and BMX globals use QAT in all 5 VIPs.
09/08/16    -From now onwards keypoint movement is checked by default.
            -New tool under QACT->Add fields to JIRA (VIP Project).
09/01/16    -Abort run in case of no access to VM3:TESTCASE.VIPQAAUTOMATION.
08/30/16    -New module under Tools: Intersect Report (to find intersect of any WE).
            -Improved intersect search logic. 
08/26/16    -ARCHES: Ability to Analyze SA runs with different SA ZBURZ for different install.
08/25/16    -System Update: Save the system update screenshot to Supervision folder with SystemName_Log.txt name.
            -Remove local files from HLLAPI folder after upload to specific location.
            -Prevent closing of QACT when System upate is running.
08/24/16    -System Update: Special Case When TLD LOAD Is waiting for RTA Tape mount.
            -NotifyandAbort for Tape cutting failure in Scheduler Analysis.
08/22/16    -Fix RADVICE Error.
08/19/16    -Added Step Erase Old files.
            -Added button Reset Settings.
            -Uncheck Erase old files and Create steup steps when read settings used.
08/18/16    -TSU failure in auto mode will now send emails instead of popup.
            -TSU server file is changed to Test System Status.txt
            -CUTXXXS timeout is now increased to 45 minutes.
            -Classify errors more correctly.
            -Append REXX error log to server file.
08/17/16    -Upload REXX errorlog file to server.
            -Move run rumbers with name BASERUN or RUNxx.
08/16/16    -Introduce Switch controls.
            -Restrict few write commands to QA.
            -Disable email sending from system update.
            -Get loaddates in background in TSU.
08/12/16    -V 3.16.8.12
            -Added Authentication checking.
            -Compare only DTD,RSI and CSI Tapes.
            -Make the status list for ARCHES short.
08/11/16    -TSU will now take Install dates from Test System Status server file(if dates are blank). 
08/10/16    -REXX error handling part included.
            -GET TESTCASE before calling UNIDUMP.
08/04/16    -Display stage of dump occurance.
08/01/16    -Auto clean extra commands server file when the command was expired 1 week back.
07/29/16    -Add new columns in Error Database.
            -Collect errors from Analysis also.
            -Save created setups during analysis to server.
07/25/16    -Energency fix for TSU.Fallback status was written something different in script.
07/15/16    -Bypass Pop ups in Scheduler run.
            -Use Static Load from and Store as methods.
            -Comment out REXX error handling and activate older methods.
07/11/16    -ZKSET STIPON logic removed.
            -REXX Errors handling.
06/29/16    -Logoff VIPs/CMS ID in case of critical error and Regression can't be continued.
            -Fix problem of saving baserun files in parent folder.
            -Erase old files before checking space when Checkspace step is selected.
            -Auto correct switch errors during System update.
            -TSU fix in 07/17 install infinite loop in Intersect finding of WE014906. 
            -Another fix in TSU where Fallenback WE was not applied because only the status was changed.
06/27/16    -Fix in TSU.
06/23/16    -Activate input from Sharepoint Globals.
06/21/16    -Get a QAT during analysis for coderun setup.
            -Save Screenshot file to server after Regression/Analysis complete also.
            -Build background for Sharepoint Globals.
06/17/16    -Scheduler Indicator
            -SAVETRAN time increased to 3 Hours
            -FTPCDB/CUPLOAD during analysis
            -Build ErrorDB from QACT itself during regression
06/14/16    -Fix in TSU (where a single WE is appearing multiple times)
06/13/16    -ECOM/COF provisioning and authorization added for Token regression
            -CDB and TTAG sync check in Preliminary Analysis
            -Resolutions added in Preliminary Analysis
            -Updated Load Night
06/09/16    -HLLAPI Update
            -Load night updates
            -REGP5VIP timeout increased to 1 min
05/30/16    -ANALYSIS RECREATE timeout increased to 10 minutes
05/27/16    -New file fetch during ARCHES
            -TRAN TABLE in ARCHES
            -Catch memory access violation in ARCHES
            -Increase delay in PARSEM message screen appear
            -Add server path in error mails
            -Clear vitalsigns files during system update
05/18/16    -Primary version Changed to 3.
            -SOAP regression will now use 5 VIP by default.
            -Removed 1VIP options.

            -Compare new dump files to get DUMPS_UNIQUE.txt.
            -HLLAPI.cs updated to upload files more than 12 KB. Split them in 12 KB chunks.
            -TSU Update-Moveout WEs will be first deleted then again applied.
            -Switch ON/OFF during fallback.
05/10/16    -iSetup will now have a server button, Clicking this will fetch latest server TSU.
            -HLLAPI updated to check VM hang before sending any text. We'll check for max 5 minutes.
            -S2S module is now equipped with uploading of Script file to sharepoint in XLSX format.
             Once this is in process we'll update the Sharepoint file rather sending it to Testsystem support.
05/09/16    -Manual fallback script option in ARCHES.
05/05/16    -Better error Handling for MMIDNTFR
            -max timeout for MMIDNTFR increased to 1hr and 15 mins
            -doHX() added on MMIDNTFR failure
            -CSV Output file Updates for Scheduler
            -Load Night testing error handling updated
            -Better Regex usage in HLLAPI, LOAD_NIGHT and REGRESSION
            -In HLLAPI added waitForRegexEx(), throws an exception on failure to match the regex
";
    }
}
