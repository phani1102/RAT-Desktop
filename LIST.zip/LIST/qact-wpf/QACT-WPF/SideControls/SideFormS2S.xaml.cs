﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for SideFormS2S.xaml
    /// </summary>
    public partial class SideFormS2S : Window
    {
        private bool IsSystemInNorm; private bool IsAddedtoDB = false;
        public ObservableCollection<VIP> OBSAllVIP { get; set; }
        public SideFormS2S(string zcommand, string worktodo)
        {
            InitializeComponent();
            txtcmd.Text = zcommand;
            SelectWork(worktodo);  
        }
        public SideFormS2S(bool currentstate, string worktodo)
        {
            InitializeComponent();
            IsSystemInNorm = currentstate;
            SelectWork(worktodo);
        }

        private void SelectWork(string worktodo)
        {
            this.Title = worktodo;
            switch (worktodo)
            {
                case "Replace WE":
                case "Load and Activate WE":
                    grdLoadAndAct.Visibility = Visibility.Visible;
                    break;
                case "Load Global":
                    comboGlobal.ItemsSource = new string[] { "DCS", "BMX", "NWK", "CFG", "FXT" };
                    grdGlobal.Visibility = Visibility.Visible;
                    break;
                case "Z-Commands or Section From TSU":
                    grdZcmd.Visibility = Visibility.Visible;
                    btnAdd.Visibility = Visibility.Collapsed;
                    btnAddE.IsDefault = true;
                    break;
                case "Add Z-Command to database":
                    grdAddCmd.Visibility = Visibility.Visible;
                    foreach (var item in S2S.DataBaseItems)
                        lstCMDs.Items.Add(item);
                    break;
                case "TLD Settings":
                    grdTLD.Visibility = Visibility.Visible;
                    btnAdd.Visibility = Visibility.Collapsed;
                    btnAddE.IsDefault = true;
                    break;
                default:
                    break;
            }
        }

        private void btnAddE_Click(object sender, RoutedEventArgs e)
        {
            btnAdd_Click(null, null);
            if (txtError.Text == null || txtError.Text=="")
            this.Close();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            ObservableCollection<string> _Script;
            if (this.Title.Contains("WE"))
            {
                _Script = (ObservableCollection<string>)this.DataContext;
                string WeNo = txtWENumber.Text.Trim(), Vtape = txtWEVtape.Text.Trim();
                bool requiredstate = comboState.SelectedIndex == 0 ? true : false;
                if (WeNo == "")
                {
                    txtWENumber.Focus(); txtError.Text = "WE Number can not be blank"; return;
                }
                if (Vtape == "")
                {
                    txtWEVtape.Focus(); txtError.Text = "Vtape Number can not be blank"; return;
                }
                if (this.Title == "Replace WE")
                    _Script.Add("*--------- Replace " + WeNo + " with " + Vtape + " ---------*");
                else
                    _Script.Add("*--------- Load and Activate " + WeNo + " with " + Vtape + " ---------*");
                AddZCommandsFromDB(txtBeforeAct.Text.Split(new string[]{Environment.NewLine},StringSplitOptions.RemoveEmptyEntries).ToList(), ref IsSystemInNorm, ref _Script);
                S2S.ChangeState(ref IsSystemInNorm, requiredstate, ref _Script);
                if (this.Title == "Replace WE")
                {
                    _Script.Add("ZOLDR DISP L " + WeNo + "||10||ACTIVATED ON CPUID X||DOES NOT EXIST");
                    _Script.Add("ZOLDR DEACT " + WeNo + "||10||COMPLETE||DEACTIVATE LOADSET " + WeNo+"||DOES NOT EXIST");
                    _Script.Add("ZOLDR DEL " + WeNo + "||10||DELETED||LOADSET " + WeNo + " RENAMED TO||DOES NOT EXIST");
                }
                _Script.Add("ZOLDR DISP L " + WeNo + "||10||" + WeNo + "  DOES NOT EXIST");
                _Script.Add("ZTOFF OLD||10||TAPE OLD NOT MOUNTED");
                _Script.Add("ZCP VTRUN 34C||10||034C is not ready||unloaded from 034C");
                _Script.Add("ZCP VTM 34C " + Vtape + "||10||" + Vtape + " mounted on 034C Ldisk");
                _Script.Add("ZTMNT OLD 34C AI BP||10||TAPE OLD MOUNTED ON DEVICE 034C");
                _Script.Add("ZOLDR LOAD OLD NODEBUG||10|| Updating OLD Tape History for tape " + Vtape + " removed from 34C");
                _Script.Add("ZCP VTRUN 34C||10||unloaded from 034C||034C is not ready");
                _Script.Add("ZOLDR DISP L " + WeNo + "||10||INACTIVE");
                _Script.Add("ZOLDR ACT " + WeNo + "||10||ACTIVATE OF LOADSET " + WeNo + " COMPLETED ");
                _Script.Add("ZOLDR DISP L " + WeNo + "||10||ACTIVATED ON CPUID X");
                AddZCommandsFromDB(txtAfterAct.Text.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries).ToList(), ref IsSystemInNorm, ref _Script);
                txtBeforeAct.Clear(); txtAfterAct.Clear(); txtWENumber.Clear(); txtWEVtape.Clear(); txtError.Text=null; 
            }
            else if (this.Title.Contains("Global"))
            {
                _Script = (ObservableCollection<string>)this.DataContext;
                if (comboGlobal.SelectedItem == null)
                {
                    comboGlobal.Focus(); txtError.Text = "Select a Global Type"; return;
                }
                if (txtGlVtape.Text.Trim()=="")
                {
                    txtGlVtape.Focus(); txtError.Text = "Vtape Number can not be blank"; return;
                }
                _Script.Add("*--------- Load " + comboGlobal.SelectedItem.ToString() + " Global: " + txtGlVtape.Text.Trim() + " ---------*");
                switch (comboGlobal.SelectedItem.ToString())
                {
                    case "DCS":
                    case "BMX":
                    case "NWK":
                    case "CFG":
                        S2S.ChangeState(ref IsSystemInNorm, false, ref _Script);
                        _Script.Add("ZTOFF SDF||10||BSS    TAPE SDF NOT MOUNTED");
                        _Script.Add("ZCP VTRUN 347||10||0347 is not ready||unloaded from 0347");
                        _Script.Add("ZCP VTM 347 " + txtGlVtape.Text.Trim() + "||10||" + txtGlVtape.Text.Trim() + " mounted on 0347 Ldisk");
                        _Script.Add("ZTMNT SDF 347 AI BP||10||TAPE SDF MOUNTED ON DEVICE 0347");
                        _Script.Add("ZQTBL " + comboGlobal.SelectedItem.ToString() + " LOAD BPALL||180||Updating SDF Tape History for tape " + txtGlVtape.Text.Trim() + " removed from 347");
                        _Script.Add("ZCP VTRUN 347||10||unloaded from 0347||0347 is not ready");
                        break;
                    case "FXT":
                        S2S.ChangeState(ref IsSystemInNorm, true, ref _Script);
                        _Script.Add("ZCP VTRUN 347||10||0347 is not ready||unloaded from 0347");
                        _Script.Add("ZDECB IN||10");
                        _Script.Add("ZCP VTM 347 " + txtGlVtape.Text.Trim() + "||10||" + txtGlVtape.Text.Trim() + " mounted on 0347 Ldisk");
                        _Script.Add("ZTMNT FXT 347 AI BP||10||TAPE FXT MOUNTED ON DEVICE 0347");
                        _Script.Add("ZKFXT LOAD BPALL||60||Updating FXT Tape History for tape " + txtGlVtape.Text.Trim() + " removed from 347");
                        _Script.Add("ZCP VTRUN 347||10||unloaded from 0347||0347 is not ready");
                        break;
                    default:
                        break;
                }
                comboGlobal.SelectedItem = null; txtGlVtape.Clear(); comboGlobal.Focus(); txtError.Text = null; 
            }
            else if (this.Title == "Z-Commands or Section From TSU")
            {
                _Script = (ObservableCollection<string>)this.DataContext;
               //List<string> AllLines = txtZCommand.Text.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries).ToList();
                List<string> AllLines =SystemMaster.BuildScriptFromTSUSection(txtZCommand.Text.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries).ToList());
               _Script.Add("*--------- Apply Following Z-Commands ---------*");
                AddZCommandsFromDB(AllLines,ref IsSystemInNorm,ref _Script);
            }
            else if (this.Title == "Add Z-Command to database")
            {
                
                if (txtcmd.Text.Trim()=="" || txtcmd.Text.Trim().ToUpper().ToCharArray()[0]!='Z')
                {
                    txtcmd.Clear(); txtcmd.Focus(); txtError.Text = "Z-Command starts with Z"; return;
                }
                try
                {
                    int tim=Convert.ToInt16(txttime.Text);
                    if (tim <= 0)
                        throw new ArgumentException();
                }
                catch (Exception)
                {
                    txttime.Clear(); txttime.Focus(); txtError.Text = "Time should be an Integer"; return;
                }
                DataItem tmpdata = new DataItem() { CMD = txtcmd.Text.Trim(), Response_1 = txtresp1.Text.Trim(), ResponseTime = Convert.ToInt16(txttime.Text), Response_2 = txtresp2.Text.Trim(), Response_3 = txtresp3.Text.Trim() };
                if (S2S.DataBaseItems.Count != 0 && !S2S.DataBaseItems.Any(d => d.CMD.ToUpper() == tmpdata.CMD.ToUpper()))
                {
                    S2S.DataBaseItems.Add(tmpdata);
                    if (S2S.AddNewline)
                    {
                        System.IO.File.AppendAllLines(App.S2SDatabaseServer, new string[] { "\n" });
                        S2S.AddNewline = false;
                    }
                    System.IO.File.AppendAllLines(App.S2SDatabaseServer, new string[] { (tmpdata.CMD + "||" + tmpdata.ResponseTime + "||" + tmpdata.Response_1 + "||" + tmpdata.Response_2 + "||" + tmpdata.Response_3).TrimEnd('|') });
                    IsAddedtoDB = true;
                    txtcmd.Clear(); txtresp1.Clear(); txtresp2.Clear(); txtresp3.Clear(); txtcmd.Focus();
                    lstCMDs.Items.Add(tmpdata);
                    lstCMDs.ScrollIntoView(tmpdata);
                    CommonClass.ChangeStatus("Added to database.", 0, 0, false);
                }
            }
            else if (this.Title=="TLD Settings")
            {
                _Script = (ObservableCollection<string>)this.DataContext;
                var firsterror = OBSAllVIP.FirstOrDefault(v => v.IsEnabled && v.ZBURZ.Trim() == "");
                if (firsterror != null)
                {
                    //Get the ItemContainer from the errornious item
                    DependencyObject firsterrorvip = lstTLD.ItemContainerGenerator.ContainerFromItem(firsterror);
                    //Get the Border Object=>Get Content Presenter=>Get The StackPanel Inside It
                    StackPanel sp = (StackPanel)VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(firsterrorvip, 0), 0), 0);
                    //Stack Panel=>=>Children[2] TLD Tape txtbox
                    (sp.Children[2]  as TextBox).Focus();
                    txtError.Text = "TLD Tape can not be blank"; return;
                }
                S2S.ChangeState(ref IsSystemInNorm, false, ref _Script);
                _Script.Add("*--------- Apply TLD Tape QATLDTAPE ---------*");
                _Script.Add("ZULDR ACC " + DateTime.Now.ToString("MMddyy") + "||1200||NO MORE LOADSETS EXIST TO BE ACCEPTED");
                _Script.Add("ZOLDR DISP ALL||10||NO LOADSETS EXIST");
                _Script.Add("ZOLDR RECLAIM||10||RECLAIM COMPLETED");
                _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
                _Script.Add("ZIMAG DISP ALL||5||END OF ZIMAG DISPLAY");
                _Script.Add("ZUMAG IMAG TPF0X TPF0Y||300||ZUMAG processing completed");
                _Script.Add("ZDSYS||300||COPY FROM TPF0X TO TPF0Y COMPLETE");
                _Script.Add("ZDECB IN||10||END OF DISPLAY");
                _Script.Add("ZCP VTRUN 348||10||0348 is not ready||unloaded from 0348");
                _Script.Add("ZCP VTM 348 QATLDTAPE||10||mounted on 0348");
                _Script.Add("ZTMNT TLD 348 AI||10||ADDING TLD TAPE HISTORY ITEM");
                _Script.Add("ZTPLD TPF0Y TLD NODEBUG||1800||LOAD COMPLETE");
                _Script.Add("ZIMAG ENA TPF0Y||10||IMAGE TPF0Y ENABLED");
                if ((bool)chkKEYPT.IsChecked)
                {
                    _Script.Add("ZIMAG KEYPT DELETE KPT ALL CPU ALL||15||KEYPOINTS REMOVED FROM THE BACKUP AREA");
                    _Script.Add("ZIMAG KEYPT MOVE TPF0Y KPT ALL CPU ALL||10||ZIMAG KEYPT CONTINUE - OR - ZIMAG KEYPT ABORT");
                    _Script.Add("ZIMAG K C||40||THE FOLLOWING PROCESSORS MUST BE IPLED");
                }

                _Script.Add("ZCP I 4000 CL||10||SELECT IMAGE+");
                _Script.Add("I||10||SPECIFY IMAGE NAME+");
                _Script.Add("TPF0Y||180||RESTART COMPLETED- 1052 STATE||TRST BSS    MOUNT RTA TAPE");
                txtError.Text = null;
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            this.DialogResult = IsSystemInNorm;
            if (this.Title == "Add Z-Command to database")
                this.DialogResult = IsAddedtoDB;
        }

        public static void AddZCommandsFromDB(List<string> ZCommands,ref bool IsSystemInNorm ,ref ObservableCollection<string> _Script)
        {
            ZCommands = ZCommands.Where(l =>l!="" && l.ToCharArray()[0] != '*' && l.Trim()!="").Select(z=>z.Trim()).ToList();
            foreach (var Zcmd in ZCommands)
            {
                if (Zcmd.ToUpper()=="ZCYCL NORM")
                {
                    S2S.ChangeState(ref IsSystemInNorm, true, ref _Script); continue; 
                }
                else if (Zcmd.ToUpper()=="ZCYCL 1052")
                {
                    S2S.ChangeState(ref IsSystemInNorm, false, ref _Script); continue; 
                }
                else if (Zcmd.ToUpper().Contains("ZCP I 4000"))
                {
                    _Script.Add("ZCP I 4000 CL||300||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized"); IsSystemInNorm = false; continue;
                }
                else if (Zcmd.ToUpper() == "ZRIPL")
                {
                    _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
                    continue;
                }
                else
                {
                    DataItem matchedcommand = S2S.DataBaseItems.FirstOrDefault(dbitm =>
                        dbitm.CMD.ToUpper().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).All(s =>
                            Zcmd.ToUpper().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).Any(z => z.Trim() == s.Trim())));
                    if (matchedcommand != null)
                        _Script.Add((Zcmd + "||" + matchedcommand.ResponseTime + "||" + matchedcommand.Response_1 + "||" + matchedcommand.Response_2 + "||" + matchedcommand.Response_3).Trim('|'));
                    else
                    {
                        if ((bool)new SideFormS2S(Zcmd, "Add Z-Command to database") { DataContext=S2S.DataBaseItems }.ShowDialog().Value)
                            AddZCommandsFromDB(new List<string> { Zcmd }, ref IsSystemInNorm, ref _Script);
                        else
                        {
                            S2S.DataBaseItems.Add(new DataItem() { CMD = Zcmd, ResponseTime = 5 });
                            _Script.Add(Zcmd + "||5");
                        }

                    }

                }
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (this.Title == "TLD Settings")
                lstTLD.ItemsSource = OBSAllVIP;
        }

    }
}
