﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for EditBox.xaml
    /// </summary>
    public partial class EditBox : Window
    {
        public EditBox()
        {
            InitializeComponent();
        }
        public List<string> WholeTSU { get; set; }
        public string CurrentItem { get; set; }
        public List<string> AllSystems { get; set; }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            comboAllsystems.ItemsSource = AllSystems;
            if (CurrentItem != null)//Balanced
            {
                stacksystem.Visibility = Visibility.Collapsed;
                comboAllsystems.SelectedItem = CurrentItem;
            }
            else
                ((VIP)this.DataContext).ThisInstall = null;
            //if (!IsSystemSelectionEnabled)
            //{

            //    GetThisInstall(CurrentItem);
            //}
            //else
            //{
            //    ((VIP)this.DataContext).ThisInstall = null;
            //    comboAllsystems.ItemsSource = AllSystems;
            //}

        }
        private void GetThisInstall(string currentsystem)
        {
            ((VIP)this.DataContext).ThisInstall = null;
            int startindex = WholeTSU.IndexOf(currentsystem);
            int finishindex = WholeTSU.Count;
            try
            {
                finishindex = WholeTSU.IndexOf(WholeTSU.Where(l =>
                    WholeTSU.IndexOf(l) > startindex && l.ToUpper().Contains("Z11X") && l.ToUpper().Contains("A/B/C") && l.ToUpper().Contains("INSTALL")).First());
            }
            catch { }

            foreach (var item in WholeTSU.GetRange(startindex, finishindex - startindex))
            {
                ((VIP)this.DataContext).ThisInstall += item + Environment.NewLine;
            }
        }

        private void btndone_Click(object sender, RoutedEventArgs e)
        {
            if (txtedit.GetLineText(0).Replace("\r\n", "") == comboAllsystems.SelectedItem.ToString())
                this.Close();
        }

        private void comboAllsystems_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comboAllsystems.SelectedItem != null)
            {
                GetThisInstall(comboAllsystems.SelectedItem.ToString());
            }
        }
    }
}
