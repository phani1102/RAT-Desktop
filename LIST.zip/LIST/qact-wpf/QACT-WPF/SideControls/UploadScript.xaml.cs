﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Net;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for UploadScript.xaml
    /// </summary>
    public partial class UploadScript : Window
    {
        public UploadScript()
        {
            InitializeComponent();
        }

        private void btnbrowse_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog xlsopenfiledlg = new OpenFileDialog() { Filter = "Excel Files|*.xlsx", Multiselect = false, Title = "Browse for QA Script File" };
            xlsopenfiledlg.ShowDialog();
            txtpath.Text = xlsopenfiledlg.FileName;
        }

        private void btnUpload_Click(object sender, RoutedEventArgs e)
        {
            if (System.IO.File.Exists(txtpath.Text))
            {
                try
                {
                    using (WebClient wc = new WebClient())
                    {
                        wc.UseDefaultCredentials = true;
                        wc.Proxy = null;
                        wc.UploadFile(txtserver.Text, "PUT", txtpath.Text);
                        this.Close();
                    }
                }
                catch (Exception ex)
                {
                    txtexc.Text = ex.Message;
                }

            }
            else
                txtexc.Text = "Local file does not exist";
        }

        private void btncancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
