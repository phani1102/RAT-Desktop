﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public static iSetup oldisetup;
        public static SwitchCompare oldswitchcompare;
        public static S2S olds2s;
        public static TSU oldTSU;
        public static RegSettings RegressionA, RegressionB, RegressionC, RegressionD, RegressionE, RegressionF, RegressionG, RegressionH, RegressionI, RegressionJ;//Saumen030617
        public static ARCHES ARCHESA, ARCHESB, ARCHESC, ARCHESD, ARCHESE, ARCHESF, ARCHESG, ARCHESH, ARCHESI, ARCHESJ;//Saumen030617
        public static TSURequestEntry oldtsureq;
        public static IssueTracker ITrack;
        public static SystemMaster sysmaster;
        public static SystemUpdate sysupa, sysupb, sysupc, sysupe, sysupf;
        public static IntersectPage intersectpage;
        public static VRAPage vrapage;
        public static MainPages.JiraIntegrate JI; //BMOLYNEA011917
        private void treTools_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            try
            {
                //Border=>TextBlock
                string oldselection = e.OldValue != null ? ((TreeViewItem)e.OldValue).Header.ToString() : null;
                switch (oldselection)
                {
                    case "iSetup":
                        oldisetup = (iSetup)frameTool.Content;
                        break;
                    case "S2S":
                        olds2s = (S2S)frameTool.Content;
                        break;
                    case "TSU":
                        oldTSU = (TSU)frameTool.Content;
                        break;
                    case "Switch Compare":
                        oldswitchcompare = (SwitchCompare)frameTool.Content;
                        break;
                    case "TSU Entry Request":
                        oldtsureq = (TSURequestEntry)frameTool.Content;
                        break;
                    case "REG-A":
                        RegressionA = (RegSettings)frameTool.Content;
                        break;
                    case "REG-B":
                        RegressionB = (RegSettings)frameTool.Content;
                        break;
                    case "REG-C":
                        RegressionC = (RegSettings)frameTool.Content;
                        break;
                    case "REG-D":
                        RegressionD = (RegSettings)frameTool.Content;
                        break;
                    case "REG-E":
                        RegressionE = (RegSettings)frameTool.Content;
                        break;
                    //Saumen030617
                    case "REG-F":
                        RegressionF = (RegSettings)frameTool.Content;
                        break;
                    case "REG-G":
                        RegressionG = (RegSettings)frameTool.Content;
                        break;
                    case "REG-H":
                        RegressionH = (RegSettings)frameTool.Content;
                        break;
                    case "REG-I":
                        RegressionI = (RegSettings)frameTool.Content;
                        break;
                    case "REG-J":
                        RegressionJ = (RegSettings)frameTool.Content;
                        break;
                    //Saumen030617
                    case "ARCHES-A":
                        ARCHESA = (ARCHES)frameTool.Content;
                        break;
                    case "ARCHES-B":
                        ARCHESB = (ARCHES)frameTool.Content;
                        break;
                    case "ARCHES-C":
                        ARCHESC = (ARCHES)frameTool.Content;
                        break;
                    case "ARCHES-D":
                        ARCHESD = (ARCHES)frameTool.Content;
                        break;
                    case "ARCHES-E":
                        ARCHESE = (ARCHES)frameTool.Content;
                        break;
                    //Saumen030617
                    case "ARCHES-F":
                        ARCHESF = (ARCHES)frameTool.Content;
                        break;
                    case "ARCHES-G":
                        ARCHESG = (ARCHES)frameTool.Content;
                        break;
                    case "ARCHES-H":
                        ARCHESH = (ARCHES)frameTool.Content;
                        break;
                    case "ARCHES-I":
                        ARCHESI = (ARCHES)frameTool.Content;
                        break;
                    case "ARCHES-J":
                        ARCHESJ = (ARCHES)frameTool.Content;
                        break;
                    //Saumen030617
                    case "SYSUP-A":
                        sysupa = (SystemUpdate)frameTool.Content;
                        break;
                    case "SYSUP-B":
                        sysupb = (SystemUpdate)frameTool.Content;
                        break;
                    case "SYSUP-C":
                        sysupc = (SystemUpdate)frameTool.Content;
                        break;
                    case "SYSUP-E":
                        sysupe = (SystemUpdate)frameTool.Content;
                        break;
                    case "SYSUP-F":
                        sysupf = (SystemUpdate)frameTool.Content;
                        break;
                    case "System Update":
                        sysmaster = (SystemMaster)frameTool.Content;
                        break;
                    case "Issue Tracker":
                        ITrack = (IssueTracker)frameTool.Content;
                        break;
                    case "Intersect Report":
                        intersectpage = (IntersectPage)frameTool.Content;
                        break;
                    case "VIP Remote Access":
                        vrapage = (VRAPage)frameTool.Content;
                        break;
                    case "Jira Integration"://BMOLYNEA011917
                        JI = (QACT_WPF.MainPages.JiraIntegrate)frameTool.Content;
                        break;
                    default:
                        break;
                }
                string selectedtool = ((TreeViewItem)e.NewValue).Header.ToString();
                switch (selectedtool)
                {
                    case "iSetup":
                        if (oldisetup == null)
                            oldisetup = new iSetup() { Height = 450, Width = 600 };
                        frameTool.Navigate(oldisetup);
                        break;
                    case "S2S":
                        if (olds2s == null)
                            olds2s = new S2S() { Height = 550, Width = 900 };
                        frameTool.Navigate(olds2s);
                        break;
                    case "TSU":
                        if (oldTSU == null)
                            oldTSU = new TSU() { Height = 550, Width = 700 };
                        frameTool.Navigate(oldTSU);
                        break;
                    case "Switch Compare":
                        if (oldswitchcompare == null)
                            oldswitchcompare = new SwitchCompare() { Height = 550, Width = 900 };
                        frameTool.Navigate(oldswitchcompare);
                        break;
                    case "REG-A":
                        if (RegressionA == null)
                            RegressionA = new RegSettings("A") { Width = 1010, Height = 600 };
                        frameTool.Navigate(RegressionA);
                        break;
                    case "REG-B":
                        if (RegressionB == null)
                            RegressionB = new RegSettings("B") { Width = 1010, Height = 600 };
                        frameTool.Navigate(RegressionB);
                        break;
                    case "REG-C":
                        if (RegressionC == null)
                            RegressionC = new RegSettings("C") { Width = 1010, Height = 600 };
                        frameTool.Navigate(RegressionC);
                        break;
                    case "REG-D":
                        if (RegressionD == null)
                            RegressionD = new RegSettings("D") { Width = 1010, Height = 600 };
                        frameTool.Navigate(RegressionD);
                        break;
                    case "REG-E":
                        if (RegressionE == null)
                            RegressionE = new RegSettings("E") { Width = 1010, Height = 600 };
                        frameTool.Navigate(RegressionE);
                        break;
                    //Saumen030617
                    case "REG-F":
                        if (RegressionF == null)
                            RegressionF = new RegSettings("F") { Width = 1010, Height = 600 };
                        frameTool.Navigate(RegressionF);
                        break;
                    case "REG-G":
                        if (RegressionG == null)
                            RegressionG = new RegSettings("G") { Width = 1010, Height = 600 };
                        frameTool.Navigate(RegressionG);
                        break;
                    case "REG-H":
                        if (RegressionH == null)
                            RegressionH = new RegSettings("H") { Width = 1010, Height = 600 };
                        frameTool.Navigate(RegressionH);
                        break;
                    case "REG-I":
                        if (RegressionI == null)
                            RegressionI = new RegSettings("I") { Width = 1010, Height = 600 };
                        frameTool.Navigate(RegressionI);
                        break;
                    case "REG-J":
                        if (RegressionJ == null)
                            RegressionJ = new RegSettings("J") { Width = 1010, Height = 600 };
                        frameTool.Navigate(RegressionJ);
                        break;
                    //Saumen030617
                    case "TSU Entry Request":
                        if (oldtsureq == null)
                            oldtsureq = new TSURequestEntry() { Height = 540, Width = 500 };
                        frameTool.Navigate(oldtsureq);
                        break;
                    case "Update Log":
                        frameTool.Navigate(new UpdateLog() { Height = 550, Width = 900 });
                        break;
                    case "ARCHES-A":
                        if (ARCHESA == null)
                            ARCHESA = new ARCHES("A") { Width = 970, Height = 600 };
                        frameTool.Navigate(ARCHESA);
                        break;
                    case "ARCHES-B":
                        if (ARCHESB == null)
                            ARCHESB = new ARCHES("B") { Width = 970, Height = 600 };
                        frameTool.Navigate(ARCHESB);
                        break;
                    case "ARCHES-C":
                        if (ARCHESC == null)
                            ARCHESC = new ARCHES("C") { Width = 970, Height = 600 };
                        frameTool.Navigate(ARCHESC);
                        break;
                    case "ARCHES-D":
                        if (ARCHESD == null)
                            ARCHESD = new ARCHES("D") { Width = 970, Height = 600 };
                        frameTool.Navigate(ARCHESD);
                        break;
                    case "ARCHES-E":
                        if (ARCHESE == null)
                            ARCHESE = new ARCHES("E") { Width = 970, Height = 600 };
                        frameTool.Navigate(ARCHESE);
                        break;
                    //Saumen030617
                    case "ARCHES-F":
                        if (ARCHESF == null)
                            ARCHESF = new ARCHES("F") { Width = 970, Height = 600 };
                        frameTool.Navigate(ARCHESF);
                        break;
                    case "ARCHES-G":
                        if (ARCHESG == null)
                            ARCHESG = new ARCHES("G") { Width = 970, Height = 600 };
                        frameTool.Navigate(ARCHESG);
                        break;
                    case "ARCHES-H":
                        if (ARCHESH == null)
                            ARCHESH = new ARCHES("H") { Width = 970, Height = 600 };
                        frameTool.Navigate(ARCHESH);
                        break;
                    case "ARCHES-I":
                        if (ARCHESI == null)
                            ARCHESI = new ARCHES("I") { Width = 970, Height = 600 };
                        frameTool.Navigate(ARCHESI);
                        break;
                    case "ARCHES-J":
                        if (ARCHESJ == null)
                            ARCHESJ = new ARCHES("J") { Width = 970, Height = 600 };
                        frameTool.Navigate(ARCHESJ);
                        break;
                    //Saumen030617
                    case "Issue Tracker":
                        if (ITrack == null)
                            ITrack = new IssueTracker() { Height = 600, Width = 930 };
                        frameTool.Navigate(ITrack);
                        break;
                    case "Help":
                        System.Diagnostics.Process.Start(App.HelpURL);
                        break;
                    case "SYSUP-A":
                        if (sysupa == null)
                            sysupa = new SystemUpdate("A") { Width = 970, Height = 600 };
                        frameTool.Navigate(sysupa);
                        break;
                    case "SYSUP-B":
                        if (sysupb == null)
                            sysupb = new SystemUpdate("B") { Width = 970, Height = 600 };
                        frameTool.Navigate(sysupb);
                        break;
                    case "SYSUP-C":
                        if (sysupc == null)
                            sysupc = new SystemUpdate("C") { Width = 970, Height = 600 };
                        frameTool.Navigate(sysupc);
                        break;
                    case "SYSUP-E":
                        if (sysupe == null)
                            sysupe = new SystemUpdate("E") { Width = 970, Height = 600 };
                        frameTool.Navigate(sysupe);
                        break;
                    case "SYSUP-F":
                        if (sysupf == null)
                            sysupf = new SystemUpdate("F") { Width = 970, Height = 600 };
                        frameTool.Navigate(sysupf);
                        break;
                    case "System Update":
                        if (sysmaster == null)
                            sysmaster = new SystemMaster() { Width = 800, Height = 600 };
                        frameTool.Navigate(sysmaster);
                        break;
                    case "Intersect Report":
                        if (intersectpage == null)
                            intersectpage = new IntersectPage() { Width = 600, Height = 600 };
                        frameTool.Navigate(intersectpage);
                        break;
                    case "VIP Remote Access":
                        if (vrapage == null)
                            vrapage = new VRAPage() { Width = 900, Height = 700 };
                        frameTool.Navigate(vrapage);
                        break;
                    case "Add Fields to JIRA (VIP Project)":
                        frameTool.Navigate(new AddtoJIRA() { Width=500, Height=400 });
                        break;
                    case "Jira Integration"://BMOLYNEA011917
                        if (JI == null)
                            JI = new MainPages.JiraIntegrate() { Height = 345.646, Width = 755.017 };
                        frameTool.Navigate(JI);
                        break;
                    default:
                        break;
                }
            }
            catch (Exception)
            {

                // throw;
            }
        }

        private void frameTool_Navigated(object sender, NavigationEventArgs e)
        {
            frameTool.Width = ((Page)e.Content).Width;
            frameTool.Height = ((Page)e.Content).Height;
            this.Width = treTools.Width + frameTool.Width + 15;
            this.Height = frameTool.Height + stStatusBar.Height + 40;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if ((RegressionA != null && !RegressionA.IsIdle) || (RegressionB != null && !RegressionB.IsIdle) || (RegressionC != null && !RegressionC.IsIdle) || (RegressionD != null && !RegressionD.IsIdle) || (RegressionE != null && !RegressionE.IsIdle))
            {
                if (MessageBox.Show("Some regression is still running...\n Minimize window?", "Minimize window", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    this.WindowState = WindowState.Minimized;
                e.Cancel = true;
            }
            if ((ARCHESA != null && !ARCHESA.IsIdle) || (ARCHESB != null && !ARCHESB.IsIdle) || (ARCHESC != null && !ARCHESC.IsIdle) || (ARCHESD != null && !ARCHESD.IsIdle) || (ARCHESE != null && !ARCHESE.IsIdle))
            {
                if (MessageBox.Show("Some analysis is still running...\n Minimize window?", "Minimize window", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    this.WindowState = WindowState.Minimized;
                e.Cancel = true;
            }
            if ((sysupa != null && !sysupa.IsIdle) || (sysupb != null && !sysupb.IsIdle) || (sysupc != null && !sysupc.IsIdle) || (sysupe != null && !sysupe.IsIdle) || (sysupf != null && !sysupf.IsIdle))
            {
                if (MessageBox.Show("Some system is still being updated...\n Minimize window?", "Minimize window", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    this.WindowState = WindowState.Minimized;
                e.Cancel = true;
            }
            if (vrapage!=null && vrapage.VRAClient.IsConnected)
            {
                vrapage.VRAClient.Dispose();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            BackgroundWorker bwupdate = new BackgroundWorker();
            bwupdate.DoWork += bwupdate_DoWork;
            bwupdate.RunWorkerCompleted += bwupdate_RunWorkerCompleted;
            CommonClass.ChangeStatus("Checking for update...", 0, 1, true);
            bwupdate.RunWorkerAsync();
            bwupdate.Dispose();

            Microsoft.Win32.SystemEvents.SessionEnding += SessionEndingEvtHandler;

        }
        private static void SessionEndingEvtHandler(object sender, Microsoft.Win32.SessionEndingEventArgs e) // cancels System shutdown
        {
            try
            {
                System.Diagnostics.Process.Start("shutdown /a");
            }
            catch { }
        }
        void bwupdate_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            CommonClass.ChangeStatus(e.Result.ToString(), 0, 0, false);
            if (e.Result.ToString().Contains("QACT is updated"))
            {
                System.Diagnostics.Process.Start("QACT.exe", String.Join(" ", String.Join(" ", App.CMDLINEARGS)));
                this.Close();
            }
            HandleCommandLineArguments();
        }

        void bwupdate_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                new RunSettings();
                System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
                System.Diagnostics.FileVersionInfo fvi = System.Diagnostics.FileVersionInfo.GetVersionInfo(assembly.Location);
                string thisversion = fvi.FileVersion;
                fvi = System.Diagnostics.FileVersionInfo.GetVersionInfo(App.SelfUpdateServer);
                string servversion = fvi.FileVersion;
                if (Convert.ToInt32(servversion.Replace(".", "")) > Convert.ToInt32(thisversion.Replace(".", "")))
                {
                    var assemblyfolder = System.IO.Path.GetDirectoryName(assembly.Location);
                    if ((App.CMDLINEARGS.Count() == 0 && MessageBox.Show("Latest version of QACT is V-" + servversion + "\nDownload update and restart QACT?", "New version (V-" + servversion + ") available!", MessageBoxButton.YesNo) == MessageBoxResult.Yes) || App.CMDLINEARGS.Count() > 0)
                    {
                        if (System.IO.File.Exists(System.IO.Path.Combine(assemblyfolder, "QACT.exe.OLD")))
                        {
                            System.IO.File.Delete(System.IO.Path.Combine(assemblyfolder, "QACT.exe.OLD"));
                        }
                        System.IO.File.Move(assembly.Location, System.IO.Path.Combine(assemblyfolder, "QACT.exe.OLD"));
                        System.IO.File.Copy(App.SelfUpdateServer, System.IO.Path.Combine(assemblyfolder, "QACT.exe"), true);
                        e.Result = "QACT is updated.Restart app to use updated version.";
                    }
                    else
                        e.Result = "Update cancelled.";
                }
                else
                    e.Result = "Already upto date.";
            }
            catch (Exception ex)
            {
                e.Result = "Error in updating QACT.Error-" + ex.Message;
            }
        }


        private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            Hyperlink thisLink = (Hyperlink)sender;
            string navigateUri = thisLink.NavigateUri.ToString() + @"&Subject=QACT Feedback/Issue";
            Process.Start(new ProcessStartInfo(navigateUri));
            e.Handled = true;
        }

        #region CommandLine Arguments
        /// <summary>
        /// Handles CommmandLine arguments for the latest file version
        /// </summary>
        public void HandleCommandLineArguments()
        {
            string[] args = Environment.GetCommandLineArgs();
            if (args.Length < 2)
                return;
            else if (args[1].Contains("FROM_FILE="))
            {
                App.InputObj = new InputFile(args[1].Split('=')[1]);
                LoadFromFile();
                return;
            }
            else if (args[1].Equals("ISETUP", StringComparison.CurrentCultureIgnoreCase))
            {
                ((TreeViewItem)treTools.Items[0]).IsExpanded = true;
                ((TreeViewItem)((TreeViewItem)treTools.Items[0]).Items[0]).IsSelected = true;

            }
            else if (args[1].Equals("TSU", StringComparison.CurrentCultureIgnoreCase))
            {
                this.WindowState = System.Windows.WindowState.Minimized;
                ((TreeViewItem)treTools.Items[0]).IsExpanded = true;
                ((TreeViewItem)((TreeViewItem)treTools.Items[0]).Items[1]).IsSelected = true;
            }
            else if (args[1].Equals("S2S", StringComparison.CurrentCultureIgnoreCase))
            {
                ((TreeViewItem)treTools.Items[0]).IsExpanded = true;
                ((TreeViewItem)((TreeViewItem)treTools.Items[0]).Items[2]).IsSelected = true;
            }
            //////////////////////////// IF REGRESSION ////////////////////////////////
            else if (args[1].Equals("REG", StringComparison.CurrentCultureIgnoreCase))
            {
                ((TreeViewItem)treTools.Items[1]).IsExpanded = true;    // open regression panel

                switch (args[2].Trim().ToUpper())                       // open regression window
                {
                    case "A":
                        ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[0]).IsSelected = true;

                        break;
                    case "B":
                        ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[1]).IsSelected = true;

                        break;
                    case "C":
                        ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[2]).IsSelected = true;

                        break;
                    case "D":
                        ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[3]).IsSelected = true;

                        break;
                    default:
                        break;
                }
            }
            /////////////////////////////////////// ARCHES //////////////////////////////////////////
            else if (args[1].Equals("ARCHES", StringComparison.CurrentCultureIgnoreCase))
            {
                ((TreeViewItem)treTools.Items[2]).IsExpanded = true;

                switch (args[2].Trim().ToUpper())
                {
                    case "A":
                        ((TreeViewItem)((TreeViewItem)treTools.Items[2]).Items[0]).IsSelected = true;
                        break;
                    case "B":
                        ((TreeViewItem)((TreeViewItem)treTools.Items[2]).Items[1]).IsSelected = true;

                        break;
                    case "C":
                        ((TreeViewItem)((TreeViewItem)treTools.Items[2]).Items[2]).IsSelected = true;

                        break;
                    case "D":
                        ((TreeViewItem)((TreeViewItem)treTools.Items[2]).Items[3]).IsSelected = true;

                        break;
                }

            }
            //////////// MULTISYS /////
            else if (args[1].Equals("MULTISYS", StringComparison.CurrentCultureIgnoreCase))
            {
                ((TreeViewItem)((TreeViewItem)treTools.Items[3])).IsSelected = true;
            }
        }
        /// <summary>
        /// Loads this App using the configuration mentioned in the input json file
        /// </summary>
        /// <param name="fileName">configuration file in json</param>
        private void LoadFromFile()
        {
            if (App.InputObj == null)
                return;

            ((TreeViewItem)treTools.Items[1]).IsExpanded = true;    // open regression panel

            switch (App.InputObj.RegWindow)                       // open regression window
            {
                case "A":
                    ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[0]).IsSelected = true;
                    break;
                case "B":
                    ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[1]).IsSelected = true;
                    break;
                case "C":
                    ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[2]).IsSelected = true;
                    break;
                case "D":
                    ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[3]).IsSelected = true;
                    break;
                case "E":
                    ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[4]).IsSelected = true;               //Saumen082216
                    break;
                //Saumen030617
                case "F":
                    ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[5]).IsSelected = true;
                    break;
                case "G":
                    ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[6]).IsSelected = true;
                    break;
                case "H":
                    ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[7]).IsSelected = true;
                    break;
                case "I":
                    ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[8]).IsSelected = true;
                    break;
                case "J":
                    ((TreeViewItem)((TreeViewItem)treTools.Items[1]).Items[9]).IsSelected = true;
                    break;
                //Saumen030617
                default:
                    break;
            }
        }
        #endregion

        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.F1)
                System.Diagnostics.Process.Start(App.HelpURL);
        }
    }

}


// ***************************************************************************************
//                                  Change Log
// ***************************************************************************************
// Date       - Name            - Description                               - Label
// ***************************************************************************************
// 01/19/2017 - Brandon         - Added Jira Integration Tab to the page    - BMOLYNEA011917
//              Molyneaux
// 08/22/2016 - Saumen Biswas   - Fixed the reference for RegWindow E       - Saumen082216
// ***************************************************************************************
