﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using Excel = Microsoft.Office.Interop.Excel;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for S2S.xaml
    /// </summary>
    public partial class S2S : Page,INotifyPropertyChanged
    {
        public static bool AddNewline = false;
        public ObservableCollection<VIP> ObsAllVIP { get { return this._ObsAllVIP; } set { _ObsAllVIP = value; NotifyPropertyChanged("OBSALLVIP"); } }
        ObservableCollection<VIP> _ObsAllVIP = new ObservableCollection<VIP>();
        
        
        
        
        bool IsSysteminNorm=false;
        public string SystemtoUpdate = "";
        string PZTLDTAPE, Excelfilename;
        public static List<DataItem> DataBaseItems=new List<DataItem>();
        List<Global> GlobalsFromSheet = new List<Global>();
        bool IsAcceptEnabled;
        ObservableCollection<string> _Script = new ObservableCollection<string>();
        public ObservableCollection<string> Script { get { return this._Script; } set { this._Script = value; NotifyPropertyChanged("Script"); } }
        public S2S()
        {
            InitializeComponent();
            _Script.CollectionChanged += _Script_CollectionChanged;
            comboAction.ItemsSource = new string[]{
              //  "Supervision Installation Script from SLiMS - .xls file",
                "Supervision Installation Script from SLiMS - .txt file",
              //  "Add Lines from TSU",
                "Load and Activate WE",
                "Replace WE",
                "Load Global",
                "Z-Commands or Section From TSU",
                "Apply Normal QA TLD",
                "Finish Normal QA TLD Load",
                "HARD IPL",
                "ZCYCL NORM",
                "ZCYCL 1052",
                "ZRIPL",
                "ZUODF DIR ALL",
                "WAIT"
            };
            
            PrePopulateSettings();
        }

        void _Script_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            Script = _Script;
        }
        void PrePopulateSettings()
        {
            //Populate VIPs
            Reset();
            PopulateVIPs("QA");
            //foreach (var vicid in App.ALLVIPS)
            //{
            //    VIP tempvip = new VIP() { VIPNAME = "VIP-" + vicid, IsEnabled = vicid == "D" ? false : true };
            //    _ObsAllVIP.Add(tempvip);
            //}
            PopulateLoadDates();
        }

        private void PopulateVIPs(string type)
        {
            SystemtoUpdate = type;
            _ObsAllVIP.Clear();
            foreach (var vicid in App.ALLVIPS)
            {
                VIP tempvip = new VIP() { VIPNAME = "VIP" + vicid};
                if (type.ToUpper() == "BASEZ")
                {
                    tempvip.VPARS = "BB41" + vicid;
                    tempvip.IsEnabled = true;
                }
                else if (type.ToUpper() == "NATV")
                {
                    tempvip.VPARS = (vicid == "A" || vicid == "C") ? "NN41" + vicid : "";
                    tempvip.IsEnabled = (vicid == "A" || vicid == "C") ? true : false;
                }
                else if (type.ToUpper() == "PZ")
                {
                    tempvip.VPARS = "PP41" + vicid;
                    tempvip.IsEnabled = true;
                }
                else
                {
                    tempvip.VPARS = "QAP0" + (App.ALLVIPS.ToList().IndexOf(vicid)+1);
                    tempvip.IsEnabled = true;
                }
                _ObsAllVIP.Add(tempvip);
            }
           // throw new NotImplementedException();
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            BackgroundWorker bwdb = new BackgroundWorker();
            bwdb.DoWork += bwdb_DoWork;
            bwdb.RunWorkerCompleted += bwdb_RunWorkerCompleted;
            CommonClass.ChangeStatus("Getting Database from server...", 0, 1, true);
            bwdb.RunWorkerAsync();
            comboDDRFrom.ItemsSource=App.ALLQASYSTEMS;
        }

        void bwdb_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Result.ToString()=="Database retrieved successfully.")
                menuMenu.BorderBrush = new SolidColorBrush(Colors.Green);
            else
                menuMenu.BorderBrush = new SolidColorBrush(Colors.Red);
            CommonClass.ChangeStatus(e.Result.ToString(), 0, 0, false);
        }

        void bwdb_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                DataBaseItems.Clear();
                string[] AllText = System.IO.File.ReadAllText(App.S2SDatabaseServer).Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
                if (AllText[AllText.Length - 1] != "")
                    AddNewline = true;
                foreach (var item in AllText.Where(t => t != ""))
                {
                    DataItem tmpdata = new DataItem() { ResponseTime = 5 };
                    string[] splitted = item.Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries);
                    tmpdata.CMD = splitted[0].Trim();
                    tmpdata.ResponseTime = Convert.ToInt16(splitted[1]);
                    tmpdata.Response_1 = splitted.Count() > 2 ? splitted[2].Trim() : "";
                    tmpdata.Response_2 = splitted.Count() > 3 ? splitted[3].Trim() : "";
                    tmpdata.Response_3 = splitted.Count() > 4 ? splitted[4].Trim() : "";
                    DataBaseItems.Add(tmpdata);
                }
                e.Result = "Database retrieved successfully.";
            }
            catch (Exception ex)
            {
                DataBaseItems.Clear();
                e.Result = "Couldn't get Database properly." + ex.Message;
            }
        }

        private void PopulateLoadDates()
        {
            List<string> sundays = new List<string>();
            for (int i = -30; i < 90; i++)
            {
                var x = DateTime.Today.AddDays(i);
                if (x.DayOfWeek == DayOfWeek.Sunday)
                {
                    sundays.Add(x.ToString("MM/dd/yy"));
                }
            }
            comboLoadDate.ItemsSource = sundays;
            comboLoadDate.SelectedItem=DateTime.Today.AddDays
                (7 - (int)DateTime.Today.DayOfWeek).ToString("MM/dd/yy");
        }
        private void comboDDRFrom_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comboDDRFrom.SelectedItem == null)
                return;
            comboDDRTo.IsEnabled = true;
            comboDDRTo.ItemsSource = App.ALLQASYSTEMS.Where(v=>v!="BASEZ11" && v!=comboDDRFrom.SelectedItem.ToString() && !App.RestrictedSystems.Any(q=>v.Contains(q)));
            if (comboDDRTo.SelectedItem == null)
                comboLoadDate.IsEnabled = false;
        }
        private void comboDDRTo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            if (comboDDRTo.SelectedItem != null)
            {
                comboLoadDate.IsEnabled = true;
                grpGlobal.IsEnabled = true;
                listVIP.IsEnabled = true;
                btnAccept.IsEnabled = true;
                Bringup_Rename_Rta(comboDDRFrom.SelectedItem.ToString(), comboDDRTo.SelectedItem.ToString());
            }
            else
            {
                comboLoadDate.IsEnabled = false;
                grpGlobal.IsEnabled = false;
                listVIP.IsEnabled = false;
                btnAccept.IsEnabled = false;
                _Script.Clear();
            }
        }
        private void Bringup_Rename_Rta(string source, string dest)
        {
            _Script.Clear();
            _Script.Add("*--------- Bringup, Rename and Mount RTA ---------*");
            if (source == "BASEZ11")
            {
                source = "VIPXT";
            }
            string zafil = (EBCEDIC(dest) + "EEEE" + "4040404040404040404040").Substring(0, 18);
            _Script.Add("VPSETUP " + dest + "X VDB QATnn||120||To clear your VDB and continue, enter Clear,||To exit VPSETUP, enter Quit,");
            _Script.Add("CLEAR||30||VPSETUP completed successfully.");
            _Script.Add("CP IPL 4000||600||OSA-OSA1PRIV ACTIVATED");

            if (dest != "PZ11" && dest != "BASEZ11" && dest != "NATV")
            {
                _Script.Add("ZDFIL 4C00000E 604||10||" + source);
                _Script.Add("ZAFIL 4C00000E 604 " + zafil + "||10||" + dest + "X");
                _Script.Add("ZDFIL 4C00000E 604||10||" + dest + "X");
                _Script.Add("ZDSYS||10||" + source);
                _Script.Add("ZDSID||10||" + dest + "X");
               // _Script.Add("ZUODF DIR ALL||10||TOT=    0");
                _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
            }
            _Script.Add("ZCP VTM 34F SCR||10||mounted on 034F");
            _Script.Add("ZTMNT RTA 34F SO||10||TMNT BSS    TAPE RTA MOUNTED ON DEVICE 034F");
            _Script.Add("ZTPSW RTA||10||Updating RTA Tape History for tape");
            _Script.Add("ZUKP4 CONS A||10|| Selected option active");
            //Script = _Script;
        }
        private void btnAccept_Click(object sender, RoutedEventArgs e)
        {
            if (ObsAllVIP.Where(v => v.IsEnabled).Count() == 0)
            {
                txtError.Text = "Select at least 1 VIP";
                return;
            }
            comboDDRFrom.IsEnabled = false;
            comboDDRTo.IsEnabled = false;
            comboLoadDate.IsEnabled = false;
            listVIP.IsEnabled = false;
            grpGlobal.IsEnabled = false;
            btnAccept.IsEnabled = false;
            comboAction.IsEnabled = true;
            btnGenFiles.IsEnabled = true;
            txtPrimCMS.IsEnabled = txtPrimPWd.IsEnabled = txtNTID.IsEnabled = true;
            txtError.Text = "";
        }
        private void comboAction_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (comboAction.SelectedItem as string)
            {
                case "Supervision Installation Script from SLiMS - .xls file":
                    OpenFileDialog xlsopenfiledlg = new OpenFileDialog() { Filter = "Excel Files|*.xlsx;*.xls", Multiselect = false, Title = "Open SLiMS generated .xls file" };
                    List<string> xlscmdarraycpy = new List<string>();
                    xlsopenfiledlg.ShowDialog();
                    if (xlsopenfiledlg.FileName != "")
                    {
                        Excelfilename = xlsopenfiledlg.FileName;
                        _Script.Add("*--------- Commands from SLiMS generated .xls file ---------*");
                        SideFormS2S.AddZCommandsFromDB(GetCommandsFromXLSScript(Excelfilename), ref IsSysteminNorm, ref _Script);
                    }
                    break;
                case "Supervision Installation Script from SLiMS - .txt file":
                    OpenFileDialog txtopenfiledlg = new OpenFileDialog() { Filter = "Text Files|*.txt", Multiselect = false, Title = "Open SLiMS generated .txt file" };
                    List<string> cmdarraycpy = new List<string>();
                    txtopenfiledlg.ShowDialog();
                    try
                    {
                        cmdarraycpy = System.IO.File.ReadAllLines(txtopenfiledlg.FileName).ToList();
                        _Script.Add("*--------- Commands from SLiMS generated .txt file ---------*");
                        SideFormS2S.AddZCommandsFromDB(System.IO.File.ReadAllLines(txtopenfiledlg.FileName).ToList(), ref IsSysteminNorm, ref _Script);
                    }
                    catch (Exception ex)
                    {
                        txtError.Text = "Error:" + ex.Message;
                    }
                    
                    break;
                case "Load and Activate WE":
                    IsSysteminNorm = (bool)new SideFormS2S(IsSysteminNorm, "Load and Activate WE") { DataContext = _Script}.ShowDialog().Value;
                    break;
                case "Load Global":
                    IsSysteminNorm = (bool)new SideFormS2S(IsSysteminNorm, "Load Global") { DataContext = _Script }.ShowDialog().Value;
                    break;
                case "Replace WE":
                    IsSysteminNorm = (bool)new SideFormS2S(IsSysteminNorm, "Replace WE") { DataContext = _Script}.ShowDialog().Value;
                    break;
                case "ZUODF DIR ALL":
                    _Script.Add("ZUODF DIR ALL||10||TOT=    0");
                    break;
                case "ZCYCL NORM":
                    ChangeState(ref IsSysteminNorm, true, ref _Script);
                    break;
                case "ZCYCL 1052":
                    ChangeState(ref IsSysteminNorm, false, ref _Script);
                    break;
                case "ZRIPL":
                    _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
                    break;
                case "HARD IPL":
                    _Script.Add("ZCP I 4000 CL||300||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
                    IsSysteminNorm = false;
                    break;
                case "Z-Commands or Section From TSU":
                    IsSysteminNorm = (bool)new SideFormS2S(IsSysteminNorm, "Z-Commands or Section From TSU") { DataContext = _Script }.ShowDialog().Value;
                    break;
                case "Apply Misc. commands and finish script":
                    //ApplyMiscCommands();
                    //break;
                case "WAIT":
                    _Script.Add("WAIT||2||XXXXXXXXXX");
                    break;
                case "Apply Normal QA TLD":
                    IsSysteminNorm = (bool)new SideFormS2S(IsSysteminNorm, "TLD Settings") { DataContext = _Script, OBSAllVIP=ObsAllVIP }.ShowDialog().Value;
                    //"TLD Settings"
                    //new TLDSettings(VIPA.Checked, VIPB.Checked, VIPC.Checked, VIPD.Checked, VIPE.Checked, VIPF.Checked).ShowDialog();
                    //AddLinestoScript(TLDSettings.CommandsToLoad.ToArray());
                    //tlda = TLDSettings.tlda; tldb = TLDSettings.tldb; tldc = TLDSettings.tldc;
                    //tldd = TLDSettings.tldd; tlde = TLDSettings.tlde; tldf = TLDSettings.tldf;
                    break;
                case "Finish Normal QA TLD Load":
                    FinishNormalQATLD();
                    break;
                default:
                    break;
            }
            txtScript.ScrollToEnd();
            comboAction.SelectedItem = null;
        }

        /// <summary>
        /// 1052=false, NORM=true
        /// </summary>
        /// <param name="currentstate"></param>
        /// <param name="requiredstate"></param>
        /// <returns></returns>
        public static void ChangeState(ref bool currentstate, bool requiredstate, ref ObservableCollection<string> _Script)
        {
            if (currentstate == requiredstate)
                return;
            else
            {
                currentstate = requiredstate;
                if (requiredstate == true)
                {
                    _Script.Add("ZCYCL NORM||90"); _Script.Add("ZDSYS||10||THE SYSTEM IS IN NORM STATE"); _Script.Add("ZUDIS @SPAUS||5||000  00");
                }
                else
                {
                    _Script.Add("ZCYCL 1052||60"); _Script.Add("ZDSYS||10||THE SYSTEM IS IN 1052 STATE"); _Script.Add("ZUDIS @SPAUS||5||000  01");
                }
            }
        }
        private string EBCEDIC(string dest)
        {
            return string.Concat(System.Text.Encoding.GetEncoding("IBM037").GetBytes(dest).Select(b => b.ToString("X2")).ToArray());
        }
   
        private void newQAScript_Click(object sender, RoutedEventArgs e)
        {
            Reset();
            PopulateVIPs("QA");
        }

        private void newBASEZScript_Click(object sender, RoutedEventArgs e)
        {
            Reset();
            comboDDRFrom.SelectedItem = null;
            comboDDRFrom.IsEnabled = false;
            comboLoadDate.IsEnabled = true;
            grpGlobal.IsEnabled = true;
            listVIP.IsEnabled = true;
            PopulateVIPs("BASEZ");
            Bringup_Rename_Rta("BASEZ11", "BASEZ11");
            _Script.Add("ZULDR ACC " + DateTime.Now.ToString("MMddyy") + "||1200||NO MORE LOADSETS EXIST TO BE ACCEPTED");
            _Script.Add("ZOLDR DISP ALL||10||NO LOADSETS EXIST");
            _Script.Add("ZOLDR RECLAIM||10||RECLAIM COMPLETED");
            _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
            btnAccept.IsEnabled = true;
            listVIP.IsEnabled = true;
        }

        private void newPZScript_Click(object sender, RoutedEventArgs e)
        {
            Reset();
            comboDDRFrom.SelectedItem = null;
            comboDDRFrom.IsEnabled = false;
            comboLoadDate.IsEnabled = true;
            grpGlobal.IsEnabled = true;
            listVIP.IsEnabled = true;
            PopulateVIPs("PZ");
            Bringup_Rename_Rta("BASEZ11", "PZ11");
            PZTLDTAPE = Interaction.InputBox("Enter the PZ11X TLD Tape Number.", "PZ TLD Tape?", "");
            string temptld = Interaction.InputBox("Confirm the PZ11X TLD Tape Number.", "Confirm!", "");
            if (PZTLDTAPE.Trim() == "" || PZTLDTAPE != temptld)
            {
                MessageBox.Show("TLD tape couldn't be verified.", "Improper TLD", MessageBoxButton.OK, MessageBoxImage.Information);
                Reset();
                return;
            }
            ChangeState(ref IsSysteminNorm, false, ref _Script);
            _Script.Add("ZULDR ACC " + DateTime.Now.ToString("MMddyy") + "||1200||NO MORE LOADSETS EXIST TO BE ACCEPTED");
            _Script.Add("ZOLDR DISP ALL||10||NO LOADSETS EXIST");
            _Script.Add("ZOLDR RECLAIM||10||RECLAIM COMPLETED");
            _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
            _Script.Add("ZIMAG DISP ALL||5||END OF ZIMAG DISPLAY");
            _Script.Add("ZUMAG IMAG TPF0X TPF0Y||300||ZUMAG processing completed");
            _Script.Add("ZDSYS||300||COPY FROM TPF0X TO TPF0Y COMPLETE");
            _Script.Add("ZDECB IN||10||END OF DISPLAY");
            _Script.Add("ZCP VTRUN 348||10||0348 is not ready||unloaded from 0348");
            _Script.Add("ZCP VTM 348 " + PZTLDTAPE + "||10||mounted on 0348");
            _Script.Add("ZTMNT TLD 348 AI BP||10||ADDING TLD TAPE HISTORY ITEM");
            _Script.Add("ZPOOL 1052 UP||10||TO2 CYCLED UP");
            _Script.Add("ZTPLD TPF0Y TLD||1800||LOAD COMPLETE");
            _Script.Add("ZIMAG ENA TPF0Y||10||IMAGE TPF0Y ENABLED");
            _Script.Add("ZCP I 4000 CL||10||SELECT IMAGE+");
            _Script.Add("I||10||SPECIFY IMAGE NAME+");
            _Script.Add("TPF0Y||180||RESTART COMPLETED- 1052 STATE||TRST BSS    MOUNT RTA TAPE");
            _Script.Add("ZIMAG PRI TPF0Y||10||TPF0Y HAS BEEN DEFINED AS THE PRIMARY IMAGE");
            _Script.Add("ZIMAG DISA TPF0X||10||IMAGE TPF0X DISABLED");
            _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
            btnAccept.IsEnabled = true;
            listVIP.IsEnabled = true;
            
        }

        private void newNATV_Click(object sender, RoutedEventArgs e)
        {
            Reset();
            comboDDRFrom.SelectedItem = null;
            comboDDRFrom.IsEnabled = false;
            comboLoadDate.IsEnabled = true;
            grpGlobal.IsEnabled = true;
            listVIP.IsEnabled = true;
            PopulateVIPs("NATV");
            Bringup_Rename_Rta("NATV", "NATV");
            _Script.Add("ZULDR ACC " + DateTime.Now.ToString("MMddyy") + "||1200||NO MORE LOADSETS EXIST TO BE ACCEPTED");
            _Script.Add("ZOLDR DISP ALL||10||NO LOADSETS EXIST");
            _Script.Add("ZOLDR RECLAIM||10||RECLAIM COMPLETED");
            _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
            btnAccept.IsEnabled = true;
            listVIP.IsEnabled = true;
        }

        private void ZCmdManage_Click(object sender, RoutedEventArgs e)
        {
            new SideFormS2S("", "Add Z-Command to database") {}.ShowDialog();
        }

        private void FinishNormalQATLD()
        {
            ChangeState(ref IsSysteminNorm,false,ref _Script);
            _Script.Add("ZIMAG PRI TPF0Y||10||TPF0Y HAS BEEN DEFINED AS THE PRIMARY IMAGE");
            _Script.Add("ZIMAG DISA TPF0X||10||IMAGE TPF0X DISABLED");
            _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
            if (SystemtoUpdate=="NATV")
            {
                _Script.Add("ZDKAT KPA||5||KEYPT A  FILE ADDRESS");
                _Script.Add("ZAFIL xxxxxxxx 37 60 V-00||5");
                _Script.Add("ZCTKA ALTER USERSW-1000||5");
                _Script.Add("ZUKP4 IUCV A||5");
                _Script.Add("ZUKP4 NATIVE A||5");
                _Script.Add("ZUKP4 TLM A||5");
                _Script.Add("ZUKP4 TMS I||5");
                _Script.Add("ZUPMR CONT OFF||5");
                _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
                ChangeState(ref IsSysteminNorm, true, ref _Script);
                _Script.Add("ZMEAS SET CSDMAX-680||5");
            }
        }

        private void ApplyMiscCommands()
        {
            _Script.Add("*--------- Apply miscellaneous commands and unmount RTA ---------*");
            ChangeState(ref IsSysteminNorm, true, ref _Script);
            if (SystemtoUpdate!="NATV")
            {
                if (SystemtoUpdate == "QA" || SystemtoUpdate=="BASEZ")
                {
                    _Script.Add("ZRPDU CREATE NOSWITCH||10||END DISPLAY||PDU CA RELEASE ITEMS ALL PROCESSED");
                    _Script.Add("ZDUPD S||10|| ZDUPD A - TO ABORT");
                    _Script.Add("ZDUPD C||10||END OF DISPLAY");
                    _Script.Add("ZMQSC START QMGR||10||MANAGER ALREADY STARTED");
                    _Script.Add("ZURTD SET SERVICE-OFF||10||Service control switch now OFF");
                    _Script.Add("ZUMQD ALTER SYSLOG-OFF||10||SysLog Logging deactivated");
                    _Script.Add("ZINET ALTER SERVER-DBUG ACT-OPER||10||END OF DISPLAY");
                    _Script.Add("ZUAAA SET RUNMODE-VCMS||10||VCMS scoring run mode already set");
                    _Script.Add("ZKVLS SET AVM-OFF PFM-OFF MDM-OFF NAPEAK-OFF EOD-OFF KEYP-ON GL-ON||10|| Successful - PFM SET to OFF, was OFF");
                    _Script.Add("ZQTTM ECHO OFF||10||AUTO ECHO OFF");
                    _Script.Add("zfile cd /usr/vitalsigns/||2");
                    _Script.Add("zfile rm *.0||5");
                }
                _Script.Add("ZKENC MAXTRACE 9999||10||UPDATES ARE COMPLETE");
                _Script.Add("ZPSTC STA 808801 SIGN ON||10||SIGN-ON BIT ALREADY ON");
                _Script.Add("ZQSTC STA 808801 SIGN ON||10||SIGN-ON BIT ALREADY ON");
                _Script.Add("ZKTIM 06.00.00 04/10/81||10||TIME IS NOW  06.00.00 04/10/81");
                _Script.Add("ZQADP ADVC MAX||10||Advice-count parameter set in ZQADP File||TMS pending list empty||Auto TMS pending processing begun");
                _Script.Add("ZQADP START||600||ZQADP process is ended||-------------------------------------");
            }
            ChangeState(ref IsSysteminNorm, false, ref _Script);
            _Script.Add("ZCP IPL 4000 CL||300||RESTART COMPLETED- 1052 STATE");
            //_Script.Add("ZUODF DIR ALL||10||TOT=    0");
            _Script.Add("ZUODF INIT||10||ODF data base initialization complete");
            _Script.Add("ZQEOD||10||SMS audit successfully closed on CPC");
            //_Script.Add("ZUODF DIR ALL||10||TOT=    0");
            _Script.Add("ZUKP4 CONS I||10||Selected option inactive");
            if (SystemtoUpdate=="NATV")
            {
                _Script.Add("ZCP VTM 340 DUMMY||5");
            }
            _Script.Add("ZTMNT RTA 340 SO");
            _Script.Add("ZTPSW RTA");
            _Script.Add("ZCP VTRUN 34F||10||unloaded from 034F||034F is not ready");
            if (SystemtoUpdate != "NATV")
            {
                _Script.Add("ZTTCP INACT ALL||10||COMPLETED");
                _Script.Add("ZOSAE DELETE OSA-OSA1PRIV||10||DELETED");
            }
            else {
                /*
                 zttcp inact locips
    zttcp change defip-10.203.223.190
    zttcp change defip-10.203.223.189
    zosae delete osa-osa1priv

                 */
                _Script.Add("zttcp inact locips||5");
                _Script.Add("zttcp change defip-10.203.223.190||5");
                _Script.Add("zttcp change defip-10.203.223.189||5");
                _Script.Add("zosae delete osa-osa1priv||5");
            }
            _Script.Add(".END");
        }

        private void PopulateGlobals(string fname)
        {
            GlobalsFromSheet.Clear();
            BackgroundWorker bw_globals = new BackgroundWorker();
            bw_globals.DoWork += bw_globals_DoWork;
            CommonClass.ChangeStatus("Getting Globals from Excel sheet...", 0, 1, true);
            grpGlobal.IsEnabled = false;
            IsAcceptEnabled = btnAccept.IsEnabled;
            btnAccept.IsEnabled = false;
            bw_globals.RunWorkerCompleted += bw_globals_RunWorkerCompleted;
            bw_globals.RunWorkerAsync(fname + "|" + comboLoadDate.SelectedItem.ToString());
            bw_globals.Dispose();
        }
        
        void bw_globals_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            comboGlobal.Items.Clear();
            foreach (var item in GlobalsFromSheet)
            {
                comboGlobal.Items.Add(item.Capture);
            }
            btnAccept.IsEnabled = IsAcceptEnabled;
            grpGlobal.IsEnabled = true;
            CommonClass.ChangeStatus("Ready", 0, 0, false);

        }

        void bw_globals_DoWork(object sender, DoWorkEventArgs e)
        {
            Excel.Application xlapp = null;
            try
            {
                //System.IO.File.Copy(e.Argument.ToString().Split('|')[0], App.TempFolder + "temp_global.xlsx", true);
                string filename = e.Argument.ToString().Split('|')[0];
                xlapp = new Excel.Application();
                xlapp.DisplayAlerts = false;
                Excel.Workbook xlworkbook = xlapp.Workbooks.Open(filename, Type.Missing, true, true);
                Excel.Worksheet xlsheet = xlworkbook.Worksheets[1]; ///Check the first Sheet
                int row = 1;
                int loaddatecol = 0;
                DateTime loaddate = DateTime.Parse(e.Argument.ToString().Split('|')[1]);
                while (true)
                {
                    if (((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Contains("PROD DATA"))
                    {
                        //Find the column of install date from next line
                        //Form the new Global class;
                        Global tempglobal = new Global() { Capture = ((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Trim().Replace("PROD DATA", "CAPTURE") };
                        //Check first 20 columns for Load date
                        for (int col = 1; col <= 20; col++)
                        {
                            string celltext = ((xlsheet.Cells[row + 1, col] as Excel.Range).Text as string).ToUpper();
                            if (celltext == "" || celltext == null || celltext.Contains("DATA"))
                                continue;
                            else if (celltext.Contains("BASELINE"))
                            {
                                loaddatecol = col;
                                continue;
                            }
                            else
                            {
                                int mnthdiff = loaddate.Month - Convert.ToInt16(celltext.Split('/')[0]);
                                int yr = loaddate.Year;
                                if (mnthdiff <= -6)
                                    yr = yr - 1;

                                if ((DateTime.ParseExact(celltext + "/" + yr, "MM/dd/yyyy", null) <= loaddate))
                                {
                                    loaddatecol = col;
                                }
                                else
                                    break;
                            }
                            //if (celltext.Contains(DateTime.Parse(e.Argument.ToString().Split('|')[1]).ToString("MM/dd")))
                            //{
                            //    loaddatecol = col;
                            //    break;
                            //}
                        }
                        row++;
                        if (loaddatecol == 0)
                            continue;
                        do
                        {
                            row++;
                            string celltext = ((xlsheet.Cells[row, 1] as Excel.Range).Text as string).ToUpper();
                            if (celltext.Contains("DCS"))
                            {
                                //check all columns from 2nd column
                                for (int i = loaddatecol; i >= 2; i--)
                                {
                                    if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                    {
                                        tempglobal.DCS = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                        break;
                                    }
                                }
                            }
                            else if (celltext.Contains("BMX"))
                            {
                                for (int i = loaddatecol; i >= 2; i--)
                                {
                                    if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                    {
                                        tempglobal.BMX = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                        break;
                                    }
                                }
                            }
                            else if (celltext.Contains("NWK"))
                            {
                                for (int i = loaddatecol; i >= 2; i--)
                                {
                                    if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                    {
                                        tempglobal.NWK = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                        break;
                                    }
                                }
                            }
                            else if (celltext.Contains("CFG"))
                            {
                                for (int i = loaddatecol; i >= 2; i--)
                                {
                                    if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                    {
                                        tempglobal.CFG = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                        break;
                                    }
                                }
                            }
                            else if (celltext.Contains("FXT"))
                            {
                                for (int i = loaddatecol; i >= 2; i--)
                                {
                                    if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                    {
                                        tempglobal.FXT = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                        break;
                                    }
                                }
                            }
                            else if (celltext.Contains("CONFIG"))
                            {
                                for (int i = loaddatecol; i >= 2; i--)
                                {
                                    if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                    {
                                        tempglobal.Config = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                        break;
                                    }
                                }
                            }
                            else if (celltext.Contains("RSI"))
                            {
                                for (int i = loaddatecol; i >= 2; i--)
                                {
                                    if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                    {
                                        tempglobal.RSIPilot = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                        break;
                                    }
                                }
                            }
                            else if (celltext.Contains("SUBSCRIBER"))
                            {
                                for (int i = loaddatecol; i >= 2; i--)
                                {
                                    if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                    {
                                        tempglobal.Subscriber = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                        break;
                                    }
                                }
                            }
                            else if (celltext.Contains("MVV"))
                            {
                                for (int i = loaddatecol; i >= 2; i--)
                                {
                                    if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                    {
                                        tempglobal.MVV = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                        break;
                                    }
                                }
                                GlobalsFromSheet.Add(tempglobal);
                                loaddatecol = 0;
                            }
                        } while (!((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Contains("MVV"));
                    }
                    row++;
                    if (GlobalsFromSheet.Count == 2 || row >= 30)//Cehck maximum 30 lines
                    {

                        break;
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "File Read Error!", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            finally
            {

                if (xlapp != null)
                {
                    xlapp.Quit();
                }
            }
        }

        private void Global_none_Checked(object sender, RoutedEventArgs e)
        {
            if (comboGlobal == null)
                return;
            comboGlobal.Items.Clear();
        }

        private void Global_server_Checked(object sender, RoutedEventArgs e)
        {
            PopulateGlobals(CommonClass.GetQAGlobalFromSharepoint());
        }

        private void Global_manual_Checked(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openfiledlg = new OpenFileDialog() { Filter = "Excel Files|*.xlsx;*.xls", Multiselect = false, Title = "Open Globals .xls file" };
            openfiledlg.ShowDialog();
            if (openfiledlg.FileName != "")
                PopulateGlobals(openfiledlg.FileName);
        }
        private List<string> GetCommandsFromXLSScript(string xlsfilename)
        {
            CommonClass.ChangeStatus("Getting Commands from Excel sheet...", 0, 1, true);
            comboAction.IsEnabled = false;
            List<string> cmdarray = new List<string>();
            const int WEnumberCol = 1, LoadStateCol = 7, VtapeCol = 10, CommandsCol = 12, WEStartRow = 6, LoaddateCol = 3;
            Excel.Application xlapp = new Excel.Application();
            xlapp.DisplayAlerts = false;
            try
            {
                Excel.Workbook xlworkbook = xlapp.Workbooks.Open(xlsfilename, Type.Missing, true, true);
                Excel.Worksheet xlsheet = xlworkbook.Worksheets["SCRIPT"];
                int Index = 0;
                bool IsPreviouswas1052 = true;
                while (!(xlsheet.Cells[WEStartRow + Index, WEnumberCol] as Excel.Range).Text.Contains("CODE Level"))
                {
                    if (!(xlsheet.Cells[WEStartRow + Index, WEnumberCol] as Excel.Range).Text.Contains("WE"))
                    {
                        Index++;
                        continue;
                    }
                    string WEnumber = (xlsheet.Cells[WEStartRow + Index, WEnumberCol] as Excel.Range).Text;
                    string Loadstate = (xlsheet.Cells[WEStartRow + Index, LoadStateCol] as Excel.Range).Text;
                    string vtape = (xlsheet.Cells[WEStartRow + Index, VtapeCol] as Excel.Range).Text;
                    string x = (xlsheet.Cells[WEStartRow + Index, LoaddateCol] as Excel.Range).Text;
                    DateTime loaddate = DateTime.Parse(x.Substring(0, x.IndexOf(' ')));
                    bool IsPreviousloaddate = loaddate < DateTime.Parse(comboLoadDate.SelectedItem.ToString()) ? true : false;
                    string[] commands = ((xlsheet.Cells[WEStartRow + Index, CommandsCol] as Excel.Range).Text as string)
                        .Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);
                    Index++;
                    if (Loadstate.ToUpper().Contains("1052") && !IsPreviouswas1052)
                    {
                        cmdarray.Add("ZCYCL 1052");
                        IsPreviouswas1052 = true;
                    }
                    else if (Loadstate.ToUpper().Contains("NORM") && IsPreviouswas1052)
                    {
                        cmdarray.Add("ZCYCL NORM");
                        IsPreviouswas1052 = false;
                    }
                    if (IsPreviousloaddate)
                    {
                        cmdarray.Add("ZOLDR DEACT " + WEnumber.Trim());
                        cmdarray.Add("ZOLDR DEL " + WEnumber.Trim());
                    }
                    if (vtape.Trim() != "" && vtape.Trim() != @"n/a")
                    {
                        cmdarray.Add("ZCP VTRUN 34C");
                        cmdarray.Add("ZCP VTM 34C " + vtape.Trim());
                        cmdarray.Add("ZTMNT OLD 34C AI BP");
                        cmdarray.Add("ZOLDR LOAD OLD NODEBUG");
                        cmdarray.Add("ZCP VTRUN 34C");
                    }
                    foreach (var cmd in commands)
                    {
                        if (cmd.Trim() == "")
                            continue;
                        if (cmd.Trim() == "ZCYCL 1052" && IsPreviouswas1052)
                            continue;
                        if (cmd.Trim() == "ZCYCL NORM" && !IsPreviouswas1052)
                            continue;
                        cmdarray.Add(cmd.Trim());
                    }
                }
                cmdarray.Add("ZCYCL 1052");
                cmdarray.Add("ZRIPL");
                cmdarray.Add("ZCYCL NORM");
            }
            catch (Exception ex)
            {
                txtError.Text = "Error:" + ex.Message;
                MessageBox.Show(ex.Message, "File Read Error!", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            finally
            {
                if (xlapp != null)
                {
                    xlapp.Quit();
                }
            }

            if (cmdarray.Count < 3)
                Excelfilename = null;
            comboAction.IsEnabled = true;

            CommonClass.ChangeStatus("Ready", 0, 0, false);
            return cmdarray;
        }

        private void SendMailFromVTSS()
        {
            CommonClass.ChangeStatus("Sending Email to GDL - VPARS", 0, 1, true);

            string subject = "", body = "";
            string commonbody = @"


Regards,
VIP Test System Support


Please note:
For all test system related questions/concerns please email to VIP Test System Support at VIPTestSystemSupp@visa.com
Application and System development is requested to notify this mailbox of any change that needs to be implemented on test systems.

Navigate to the VTSS website at http://vip/qatools/vipsys.cgi. You will be required to authenticate yourself with a valid VM3 user id/password. You may be prompted to authenticate twice.";

            //Create Subject and Body.
            if (SystemtoUpdate=="NATV")
            {
                subject = "NATVA/NATVC System update :: Build " + comboLoadDate.SelectedItem.ToString() + " Install System";
                body = "NATVA/NATVC systems will be updated soon to create " + comboLoadDate.SelectedItem.ToString() +
                        " Install production image. Anybody using the NATVA/NATVC systems is requested to log off from them, otherwise you might get experience unexpected behaviour." + commonbody;
            }
            else if (SystemtoUpdate == "BASEZ")
            {
                subject = "BASEZ11x System update :: Build " + comboLoadDate.SelectedItem.ToString() + " Install System";
                body = "BASEZ11x systems will be updated soon to create " + comboLoadDate.SelectedItem.ToString() +
                        " Install production image. Anybody using the BASEZ11x systems is requested to log off from them, otherwise you might get experience unexpected behaviour." + commonbody;
            }
            else if (SystemtoUpdate == "PZ")
            {
                subject = "DDR from BASEZ11x  to PZ11x :: Build " + comboLoadDate.SelectedItem.ToString() + " Install System";
                body = "A DDR will be applied soon from the current BASEZ11x  systems to the PZ11x  systems to create " + comboLoadDate.SelectedItem.ToString() +
                    " Install production image. Anybody using the PZ11x systems is requested to log off from them, otherwise you might get experience unexpected behaviour." +
                    commonbody;
            }
            else
            {
                subject = "DDR from " + comboDDRFrom.SelectedItem.ToString() + "x to " +
                    comboDDRTo.SelectedItem.ToString() + "x :: Build " + comboLoadDate.SelectedItem.ToString() + " Install System";
                body = "A DDR will be applied soon from the current " + comboDDRFrom.SelectedItem.ToString()
                    + "x systems to the " + comboDDRTo.SelectedItem.ToString()
                    + "x systems to create " + comboLoadDate.SelectedItem.ToString() +
                    " Install production image. Anybody using the " + comboDDRTo.SelectedItem.ToString()
                    + "x systems is requested to log off from them, otherwise you might get experience unexpected behaviour." +
                    commonbody;
            }
            Outlook.Application oApp; Outlook.MailItem oMsg; Outlook.Recipient oRecip;
            try
            {
                oApp = new Outlook.Application();
                oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                oRecip = (Outlook.Recipient)oMsg.Recipients.Add("VPARS@visa.com");
                oMsg.Subject = subject; oMsg.Body = body;
                oMsg.SentOnBehalfOfName = "VIPTestSystemSupp@visa.com";
                ((Outlook._MailItem)oMsg).Send();
                MessageBox.Show("Mail successfully sent to GDL-VPARS.");
            }
            catch (Exception)
            {
                MessageBox.Show("Error in sending Email.");
            }
            finally { oRecip = null; oMsg = null; oApp = null; }
            CommonClass.ChangeStatus("Ready", 0, 1, false);
        }

        private void UpdateStatusPage(string ddrfrom, string ddrto)
        {
            CommonClass.ChangeStatus("Updating Status Page...", 0, 1, true);
            try
            {
                var OldStatus = System.IO.File.ReadAllLines(App.TestSystemStatusServer);
                List<string> newstatus = new List<string>();
                string ThisSystem = ddrto + "," + comboLoadDate.SelectedItem.ToString() + "," + DateTime.UtcNow.ToString("MM/dd/yy hh:mm:ss") + "," + ddrfrom + ",,,,,,";
                if (comboGlobal.SelectedItem != null)
                {
                    Global g = GlobalsFromSheet.First(p => p.Capture == comboGlobal.SelectedItem.ToString());
                    ThisSystem = ThisSystem.TrimEnd(',') + "," + comboGlobal.SelectedItem.ToString() + "," + g.DCS + "," + g.BMX + "," +
                        g.NWK + "," + g.CFG + "," + g.FXT;
                }
                else
                {
                    var oldsys = OldStatus.First(l => l.Substring(0, l.IndexOf(',')) == ddrfrom);
                    var splitted = oldsys.Split(',');
                    ThisSystem = ThisSystem.TrimEnd(',') + "," + splitted[4] + "," + splitted[5] + "," + splitted[6] + "," +
                        splitted[7] + "," + splitted[8] + "," + splitted[9];
                }
                foreach (var line in OldStatus)
                {
                    if (line.Substring(0, line.IndexOf(',')) == ddrto)
                    {
                        newstatus.Add(ThisSystem);
                    }
                    else
                        newstatus.Add(line);
                }
                System.IO.File.WriteAllLines(App.TestSystemStatusServer, newstatus.ToArray());
                //xlworkbook.Close(true);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in Status update", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            CommonClass.ChangeStatus("Ready", 0, 0, false);

        }

        private void GenerateXLScripts(string xlsfilename)
        {
            CommonClass.ChangeStatus("Generating Excel Scripts...", 0, 1, true);
            Excel.Application xlapp = new Excel.Application();
            xlapp.DisplayAlerts = false;
            try
            {
                Excel.Workbook xlworkbook = xlapp.Workbooks.Open(xlsfilename, Type.Missing, true);
                Excel.Worksheet xlsheet = xlworkbook.Worksheets["SCRIPT"];
                //Format the Excel in our Way
                (xlsheet.Rows["1:6"] as Excel.Range).Insert();
                (xlsheet.Rows["1:10"] as Excel.Range).Clear();
                xlsheet.Range["A1:B9"].Font.Bold = true;
                xlsheet.Range["A1:B9"].HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
                xlsheet.Range["A1:B9"].Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                xlsheet.Range["A1:B1"].Interior.ColorIndex = 46;
                xlsheet.Range["A1:B1"].Merge();
                xlsheet.Range["A2:B3"].Interior.ColorIndex = 45;
                xlsheet.Range["A4:B4"].Interior.ColorIndex = 38;
                xlsheet.Range["A5:B9"].Interior.ColorIndex = 36;
                (xlsheet.Columns["B"] as Excel.Range).EntireColumn.ColumnWidth = 20;

                (xlsheet.Cells[1, 1] as Excel.Range).Value = comboDDRTo.SelectedItem.ToString() + "x System (" + DateTime.Parse(comboLoadDate.SelectedItem.ToString()).ToString("MM/dd/yyyy") + " INSTALL)";
                (xlsheet.Cells[2, 1] as Excel.Range).Value = "DDR From:";
                (xlsheet.Cells[2, 2] as Excel.Range).Value = comboDDRFrom.SelectedItem.ToString() + "x";
                (xlsheet.Cells[3, 1] as Excel.Range).Value = "Updated On:";
                (xlsheet.Cells[3, 2] as Excel.Range).Value = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm");
                (xlsheet.Cells[4, 1] as Excel.Range).Value = "VIPs";
                (xlsheet.Cells[4, 2] as Excel.Range).Value = "RTA";
                (xlsheet.Cells[5, 1] as Excel.Range).Value = "VIPA";
                (xlsheet.Cells[6, 1] as Excel.Range).Value = "VIPB";
                (xlsheet.Cells[7, 1] as Excel.Range).Value = "VIPC";
                (xlsheet.Cells[8, 1] as Excel.Range).Value = "VIPE";
                (xlsheet.Cells[9, 1] as Excel.Range).Value = "VIPF";

                Excel.Range endlevel = xlsheet.Cells.Find("CODE level", Type.Missing, Excel.XlFindLookIn.xlFormulas,
                   Excel.XlLookAt.xlPart, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext, false, Type.Missing, Type.Missing) as Excel.Range;
                if (endlevel != null)
                {
                    if (comboGlobal.SelectedItem != null)
                    {
                        Global tmpglobal = GlobalsFromSheet.Where(g => g.Capture == comboGlobal.SelectedItem.ToString()).First();
                        (xlsheet.Cells[endlevel.Row + 3, 1] as Excel.Range).EntireRow.Clear();
                        (xlsheet.Cells[endlevel.Row + 3, 1] as Excel.Range).EntireRow.Font.Bold = true;
                        (xlsheet.Cells[endlevel.Row + 3, 1] as Excel.Range).Value = "Globals: " + tmpglobal.Capture;
                        (xlsheet.Cells[endlevel.Row + 4, 1] as Excel.Range).Value = "DCS";
                        (xlsheet.Cells[endlevel.Row + 4, 2] as Excel.Range).Value = tmpglobal.DCS;
                        (xlsheet.Cells[endlevel.Row + 5, 1] as Excel.Range).Value = "BMX";
                        (xlsheet.Cells[endlevel.Row + 5, 2] as Excel.Range).Value = tmpglobal.BMX;
                        (xlsheet.Cells[endlevel.Row + 6, 1] as Excel.Range).Value = "NWK";
                        (xlsheet.Cells[endlevel.Row + 6, 2] as Excel.Range).Value = tmpglobal.NWK;
                        (xlsheet.Cells[endlevel.Row + 7, 1] as Excel.Range).Value = "CFG";
                        (xlsheet.Cells[endlevel.Row + 7, 2] as Excel.Range).Value = tmpglobal.CFG;
                        (xlsheet.Cells[endlevel.Row + 8, 1] as Excel.Range).Value = "FXT";
                        (xlsheet.Cells[endlevel.Row + 8, 2] as Excel.Range).Value = tmpglobal.FXT;
                        (xlsheet.Cells[endlevel.Row + 10, 1] as Excel.Range).EntireRow.Interior.Color = Excel.XlRgbColor.rgbDarkGreen;
                    }

                }
                xlsheet.SaveAs(App.LocalSupervisionFolder+"\\" + comboDDRTo.SelectedItem.ToString() + "x.xlsx");
                xlworkbook.PublishObjects.Add(Excel.XlSourceType.xlSourceSheet,
                    App.LocalSupervisionFolder + "\\" + comboDDRTo.SelectedItem.ToString() + "x.htm", "SCRIPT", "",
                    Excel.XlHtmlType.xlHtmlStatic, comboDDRTo.SelectedItem.ToString(),
                    comboDDRTo.SelectedItem.ToString() + "x  " + comboLoadDate.SelectedItem.ToString() + " Install").Publish(true);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in Excel Report creation!", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            finally
            {
                if (xlapp != null)
                {
                    xlapp.Quit();
                }
            }
            CommonClass.ChangeStatus("Ready", 0, 0, false);
        }
        private string getHexString(string asciisrc)
        {
            return string.Concat(System.Text.Encoding.ASCII.GetBytes(asciisrc).Select(b => b.ToString("X2")).ToArray());
        }

        private void CreateFile(VIP vip)
        {
            string filepath;
            string ddrfrom = "";
            List<string> AllLinestoWrite = new List<string>();
            if (SystemtoUpdate == "NATV")
            {
                filepath = App.LocalSupervisionFolder+"\\" + "NATV" + vip.VIPNAME.Replace("VIP", "") + ".txt";
                ddrfrom = "NATV" + vip.VIPNAME.Replace("VIP", "");
            }
            else if (SystemtoUpdate=="PZ")
            {
                filepath = App.LocalSupervisionFolder + "\\" + "PZ11" + vip.VIPNAME.Replace("VIP", "") + ".txt";
                ddrfrom = "BASEZ11" + vip.VIPNAME.Replace("VIP", "");
            }
            else if (SystemtoUpdate=="BASEZ")
            {
                filepath = App.LocalSupervisionFolder + "\\" + "BASEZ11" + vip.VIPNAME.Replace("VIP", "") + ".txt";
                ddrfrom = "BASEZ11" + vip.VIPNAME.Replace("VIP", "");
            }
            else
            {
                filepath = App.LocalSupervisionFolder + "\\" + comboDDRTo.SelectedItem.ToString() + vip.VIPNAME.Replace("VIP", "") + ".txt";
                ddrfrom = comboDDRFrom.SelectedItem.ToString() + vip.VIPNAME.Replace("VIP", "");
            }
            if (!System.IO.Directory.Exists(App.LocalSupervisionFolder))
            {
                System.IO.Directory.CreateDirectory(App.LocalSupervisionFolder);
            }
            if (System.IO.File.Exists(filepath))
            {
                System.IO.File.Delete(filepath);
            }

            string firstline = ddrfrom + "||" + vip.VPARS + "||" + txtPrimCMS.Text.ToUpper() + "||" + getHexString(txtPrimPWd.Password.ToUpper()) + "||" + comboLoadDate.SelectedItem.ToString() + "||" + (txtNTID.Text.Trim() != "" ? txtNTID.Text.Trim() + "@visa.com" : "");

            //System.IO.File.AppendAllLines(filepath, new string[] { firstline });
            AllLinestoWrite.Add(firstline);
            bool HFDLOAD=_Script.Where(s=>s.ToUpper().Contains("ZUHFD RECEIVE")||s.ToUpper().Contains("ZUHFD INSTALL")).Count()>0?true:false;
            foreach (var line in _Script)
            {
                string tmpline = line.Replace("VIPXT", "VIP" + vip.VIPNAME.Replace("VIP", "") + "T").Replace("11X", "11" + vip.VIPNAME.Replace("VIP", "")).Replace("NATVX", "NATV" + vip.VIPNAME.Replace("VIP", "")).Replace("CPUID X", "CPUID " + vip.VIPNAME.Replace("VIP", ""));
                if (!HFDLOAD)
                {
                    if (SystemtoUpdate=="NATV")
                        tmpline = tmpline.Replace("QATnn", "QATnn IPADDR NONE");
                    tmpline = tmpline.Replace("OSA-OSA1PRIV ACTIVATED", "RESTART COMPLETED- 1052 STATE");
                }
                tmpline = tmpline.Replace("QATnn", ((vip.QAT == "" || vip.QAT == null) ? "24" : vip.QAT)).Replace("EEEE", EBCEDIC(vip.VIPNAME.Replace("VIP",""))).Replace("QATLDTAPE", vip.ZBURZ);//zburz name holds TLD value
                if (SystemtoUpdate=="NATV")
                {
                    if (vip.VIPNAME.Replace("VIP", "") == "A")
                    {
                        tmpline = tmpline.Replace("CP IPL 4000", "CP IPL D000").Replace("CP I 4000", "CP I D000");
                    }
                    else if (vip.VIPNAME.Replace("VIP", "") == "C")
                    {
                        tmpline = tmpline.Replace("CP IPL 4000", "CP IPL D100").Replace("CP I 4000", "CP I D100");
                    }
                }
                if (tmpline != "")
                {
                    AllLinestoWrite.Add(tmpline);
                   // System.IO.File.AppendAllLines(filepath, new string[] { tmpline });
                }
            }
            if (_Script[Script.Count - 1] != ".END")
            {
                AllLinestoWrite.Add(".END");
               // System.IO.File.AppendAllLines(filepath, new string[] { ".END" });
            }
            System.IO.File.WriteAllLines(filepath, AllLinestoWrite);

        }
        private void Reset()
        {
            IsSysteminNorm = false;
            _Script.Clear();
            Excelfilename = null;
            comboDDRFrom.SelectedItem = null;
            comboDDRFrom.IsEnabled = true;
            comboDDRTo.SelectedItem = null;
            comboDDRTo.IsEnabled = false;
            comboLoadDate.IsEnabled = false;
            Global_none.IsChecked = true;
            grpGlobal.IsEnabled = false;
            txtPrimCMS.IsEnabled = txtPrimPWd.IsEnabled = txtNTID.IsEnabled= listVIP.IsEnabled = false;
        }

        private void btnGenFiles_Click(object sender, RoutedEventArgs e)
        {
            if (txtPrimCMS.Text.Trim() == "")
            {
                MessageBox.Show("Enter your primary CMS ID", "Error!", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                txtPrimCMS.Focus();
                return;
            }
            if (txtPrimPWd.Password.Trim() == "")
            {
                MessageBox.Show("Enter primary CMS Password", "Error!", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                txtPrimPWd.Focus();
                return;
            }
            #region DDRFROMTO
            string ddrto;
            string ddrfrom;
            if (SystemtoUpdate=="BASEZ")
            {
                ddrto = ddrfrom = "BASEZ11X";
            }
            else if (SystemtoUpdate=="PZ")
            {
                ddrto = "PZ11X";
                ddrfrom = "BASEZ11X";
            }
            else if (SystemtoUpdate=="NATV")
            {
                ddrto = ddrfrom = "NATV";
            }
            else
            {
                ddrto = comboDDRTo.SelectedItem.ToString() + "X";
                ddrfrom = comboDDRFrom.SelectedItem.ToString() + "X";
            }
            #endregion
            //apply Globals
            if (comboGlobal.SelectedItem != null)
            {
                if (comboGlobal.SelectedItem != null)
                {
                    //appliedglobal
                    var xxx = System.IO.File.ReadAllLines(App.TestSystemStatusServer);
                    var oldsys = xxx.First(l => l.Substring(0, l.IndexOf(',')) == ddrfrom);
                    var splitted = oldsys.Split(',');
                    Global g = GlobalsFromSheet.First(p => p.Capture == comboGlobal.SelectedItem.ToString());
                    if (g.DCS != "" && splitted[5] != g.DCS)
                        ApplyGlobal("DCS", g.DCS);
                    if (g.BMX != "" && splitted[6] != g.BMX)
                        ApplyGlobal("BMX", g.BMX);
                    if (g.NWK != "" && splitted[7] != g.NWK)
                        ApplyGlobal("NWK", g.NWK);
                    if (g.CFG != "" && splitted[8] != g.CFG)
                        ApplyGlobal("CFG", g.CFG);
                    if (g.FXT != "" && splitted[9] != g.FXT)
                        ApplyGlobal("FXT", g.FXT);
                }
            }
            ApplyMiscCommands();
            try
            {
                //We can do this operation in parallel. Why use sequential?
                //Parallel.ForEach(ObsAllVIP.Where(v => v.IsEnabled), (vip) => CreateFile(vip));
                // Parallel operation is causing the InvalidOperationException in UI

                ObsAllVIP.Where(VIP => VIP.IsEnabled)
                            .ToList()
                            .ForEach(vip => CreateFile(vip));

                if (Excelfilename != null && Excelfilename != "")
                    GenerateXLScripts(Excelfilename);

                if (MessageBox.Show("Scripts are saved to Supervision Folder on your desktop.\nNotify GDL-VPARS users?", "Send email...", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    SendMailFromVTSS();
                if (MessageBox.Show("Update Status Excel sheet?", "Status Update...", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    UpdateStatusPage(ddrfrom, ddrto);
                comboAction.IsEnabled = false;
                btnGenFiles.IsEnabled = false;
                listVIP.IsEnabled = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in creating scripts"+ex.Message, "Error!");
            }
            
        }

        private void ApplyGlobal(string glbtype, string vtape)
        {
            _Script.Add("*--------- Load "+glbtype+" Global with "+vtape+" ---------*");
            switch (glbtype)
            {
                    case "DCS":
                    case "BMX":
                    case "NWK":
                    case "CFG":
                        ChangeState(ref IsSysteminNorm, false, ref _Script);
                        _Script.Add("ZTOFF SDF||10||BSS    TAPE SDF NOT MOUNTED");
                        _Script.Add("ZCP VTRUN 347||10||0347 is not ready||unloaded from 0347");
                        _Script.Add("ZCP VTM 347 " + vtape + "||10||" + vtape + " mounted on 0347 Ldisk");
                        _Script.Add("ZTMNT SDF 347 AI BP||10||TAPE SDF MOUNTED ON DEVICE 0347");
                        _Script.Add("ZQTBL " + glbtype + " LOAD BPALL||180||Updating SDF Tape History for tape " + vtape + " removed from 347");
                        _Script.Add("ZCP VTRUN 347||10||unloaded from 0347||0347 is not ready");
                        break;
                    case "FXT":
                        ChangeState(ref IsSysteminNorm, true, ref _Script);
                        _Script.Add("ZCP VTRUN 347||10||0347 is not ready||unloaded from 0347");
                        _Script.Add("ZDECB IN||10");
                        _Script.Add("ZCP VTM 347 " + vtape + "||10||" + vtape + " mounted on 0347 Ldisk");
                        _Script.Add("ZTMNT FXT 347 AI BP||10||TAPE FXT MOUNTED ON DEVICE 0347");
                        _Script.Add("ZKFXT LOAD BPALL||60||Updating FXT Tape History for tape " + vtape + " removed from 347");
                        _Script.Add("ZCP VTRUN 347||10||unloaded from 0347||0347 is not ready");
                        break;
                    default:
                        break;
            }
        }

        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        private void uploadScript_Click(object sender, RoutedEventArgs e)
        {
            new UploadScript().ShowDialog();
        }

    }
    public class DataItem
    {
        public string CMD { get; set; }
        public int ResponseTime { get; set; }
        public string Response_1 { get; set; }
        public string Response_2 { get; set; }
        public string Response_3 { get; set; }

    }
    public class Global
    {
        public string Capture { get; set; }
        public string DCS { get; set; }
        public string BMX { get; set; }
        public string NWK { get; set; }
        public string CFG { get; set; }
        public string FXT { get; set; }
        public string Config { get; set; }
        public string RSIPilot { get; set; }
        public string Subscriber { get; set; }
        public string MVV { get; set; }
    }
}
