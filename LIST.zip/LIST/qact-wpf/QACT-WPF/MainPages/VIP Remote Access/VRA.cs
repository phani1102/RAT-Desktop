﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace QACT_WPF.VIPRemoteAccess
{
    public class VRA:IDisposable,INotifyPropertyChanged
    {
        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        public delegate void ReturnDataHandler(string tpfreturndata);
        public event ReturnDataHandler DataReturnedFromHost;

        #region Private Members
        Socket tpfsocket;
        NetworkStream tpfstream;
        SslStream tpfsslstream;
        Thread ReceiverThread;
        bool IsReceiving;
        #endregion

        #region Properties
        private string _RemoteIP;

        public string RemoteIP
        {
            get { return _RemoteIP; }
            set { _RemoteIP = value; }
        }

        private bool _IsAutoZpage=true;

        public bool IsAutoZPAGE
        {
            get { return _IsAutoZpage; }
            set { _IsAutoZpage = value; }
        }

        int RemotePort = 59102;
        private bool _IsConnected;

        public bool IsConnected
        {
            get { return _IsConnected; }
        }
        private bool _IsSSLConnection;

        public bool IsSSLConnection
        {
            get { return _IsSSLConnection; }
        }
        private bool _IsLoggedIn;

        public bool IsLoggedin
        {
            get { return _IsLoggedIn; }
        }
        private string _SystemName="Unknown";
        public string SystemName
        {
            get { return _SystemName; }
            set { _SystemName = value; }
        }
        
        #endregion
        #region Constructors
        public VRA()
        {
            RemotePort = 51902;
            _IsSSLConnection = false;
        }
        public VRA(string ip)
            : this()
        {
            RemoteIP = ip;
            Connect();
        }
        #endregion
        #region Private Functions
        void ReceiveTextFromStream(out string data)
        {

            if (!_IsConnected)
                throw new InvalidOperationException("Please connect to the remote host first");
            tpfstream.ReadTimeout = 1;
            if (tpfsslstream != null)
            {
                tpfsslstream.ReadTimeout = 1;
            }
            byte[] buffer = new byte[8192];
            int read = 0;
            string s = null;
            try
            {
                if (tpfstream.DataAvailable || read == 0 || read == buffer.Length)
                {
                    if (_IsSSLConnection)
                    {
                        read = tpfsslstream.Read(buffer, 0, buffer.Length);
                        tpfsslstream.Flush();
                    }
                    else
                    {
                        read = tpfstream.Read(buffer, 0, buffer.Length);
                        tpfstream.Flush();
                    }
                    if (read == -1)
                    {
                        _IsConnected = false;
                        throw new InvalidOperationException("Host connection is not available.");
                    }
                    s = Encoding.ASCII.GetString(buffer, 0, read).Replace("\0", null).Replace("\n",Environment.NewLine);
                    if (s.Length > 5)
                    {
                        OnDataReturnedFromHost(s);
                        if (s.Contains("MORE DATA AVAILABLE, ENTER ZPAGE TO CONTINUE") && IsAutoZPAGE)
                        {
                            WriteCMD("ZPAGE");
                        }
                    }
                }

            }
            catch (Exception)
            {

            }
            data = s;
        }
        private void InfiniteReceive()
        {
            try
            {
                string xx;
                while (IsReceiving)
                    ReceiveTextFromStream(out xx);
            }
            catch (Exception)
            {
                IsReceiving = false;
            }
        }
        protected void OnDataReturnedFromHost(string tpfreturndata)
        {
            if (DataReturnedFromHost != null)
            {
                DataReturnedFromHost(tpfreturndata);
            }
        }
        private bool ValidateCert(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            _IsSSLConnection = true;
            return true;
        }
        void StartReceivingText()
        {
            if (ReceiverThread == null)
                ReceiverThread = new Thread(InfiniteReceive);
            try
            {
                if (!IsReceiving)
                {
                    IsReceiving = true;
                    if (ReceiverThread.ThreadState != ThreadState.Running)
                        ReceiverThread.Start();
                }
            }
            catch (Exception)
            {
                IsReceiving = false;
            }

        }
        #endregion

        #region Publicly Accessable Functions
        public void Connect()
        {
            if (string.IsNullOrWhiteSpace(RemoteIP))
                throw new ArgumentException("Remote IP is not valid.", "RemoteIP");
            RemoteIP = Regex.Replace(RemoteIP, "0*([0-9]+)", "${1}");
            if (_IsConnected)
            {
                Disconnect();
            }
            try
            {
                tpfsocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                tpfsocket.Connect(RemoteIP, RemotePort);
                tpfstream = new NetworkStream(tpfsocket);
                _IsConnected = true;
                SystemName = RemoteIP;
            }
            catch (Exception ex)
            {
                _IsConnected = false;
                //Dispose the objects
                Dispose();
                throw ex;
            }
        }
        public void Login()
        {
            if (_IsConnected)
            {

                string cmd = "ZCP VPQ";
                string resp;
                //

                //
                for (int i = 0; i < 8; i++)
                {
                    WriteCMD(cmd);
                    ReceiveTextFromStream(out resp);
                    if (resp == null)
                        continue;
                    if (resp.Contains("SSII0007E")) //SSL Required
                    {
                        cmd = "START SSL";
                    }
                    else if (resp.Contains("SSII0008I"))  // SSL Ready
                    {
                        //Now onwards SSL Stream will be used
                        try
                        {
                            tpfsslstream = new SslStream(tpfstream, false, new RemoteCertificateValidationCallback(ValidateCert),null);
                            tpfsslstream.AuthenticateAsClient(RemoteIP);
                            cmd = "ZCP VPQ";
                        }
                        catch(Exception ex) { }
                    }
                    else if (resp.Contains("SSII0002E"))  // SSII0002E 12.17.38 Not logged on to application.  Cpu Id: B
                    {
                        var vipid = new Regex(@"Cpu Id:\s*(?<VIPID>\w)").Match(resp).Groups["VIPID"];
                        cmd = "LOGI SMP" + vipid;
                    }
                    else if (resp.Contains("SSII0004I"))  // Login Complete
                    {
                        _IsLoggedIn = true;
                        StartReceivingText();
                        break;
                    }
                }
            }
        }
        public void Disconnect()
        {
            IsReceiving = false;
            _IsConnected = false;
            if (tpfsslstream != null)
            {
                tpfsslstream.Flush();
                tpfsslstream.Close();
            }
            if (tpfstream != null)
            {
                tpfstream.Flush();
                tpfstream.Close();
            }
            if (tpfsocket != null)
            {
                // tpfsocket.Shutdown(SocketShutdown.Both);
                if (tpfsocket.Connected)
                    tpfsocket.Disconnect(true);
                tpfsocket.Close();
            }
            try
            {
                ReceiverThread.Abort();
            }
            catch (Exception)
            {
            }
            finally { ReceiverThread = null; }

        }
        public void Dispose()
        {
            Disconnect();
            if (tpfsslstream != null)
                tpfsslstream.Dispose();
            tpfsslstream = null;
            if (tpfstream != null)
                tpfstream.Dispose();
            tpfstream = null;
            if (tpfsocket != null)
                tpfsocket.Dispose();
            tpfsocket = null;
        }
        public void WriteCMD(string Command)
        {
            if (string.IsNullOrEmpty(Command))
                return;
            if (!_IsConnected)
                throw new InvalidOperationException("Please connect to the remote host first");
            //Console MSG -PORT 51902
            String vmlh = Command.Length.ToString("X2");
            vmlh = "00000000" + vmlh + "0000";// For Console msg
            vmlh = vmlh.Substring(vmlh.Length - 8);
            var databytes = HexStringToByteArray(vmlh);
            //For Console MSG
            databytes = databytes.Concat(Encoding.ASCII.GetBytes(Command)).ToArray();
            if (_IsSSLConnection)
            {
                tpfsslstream.Write(databytes, 0, databytes.Length);
                tpfsslstream.Flush();
            }
            else
            {
                tpfstream.Write(databytes, 0, databytes.Length);
                tpfstream.Flush();
            }
        }
        public static byte[] HexStringToByteArray(string hex)
        {
            return Enumerable.Range(0, hex.Length)
                             .Where(x => x % 2 == 0)
                             .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
                             .ToArray();
        }
        #endregion
    }
}
