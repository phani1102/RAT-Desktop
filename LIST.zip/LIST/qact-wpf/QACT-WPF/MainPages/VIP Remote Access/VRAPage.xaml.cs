﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using QACT_WPF.VIPRemoteAccess;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for VRAPage.xaml
    /// </summary>
    public partial class VRAPage : Page
    {
        public VRA VRAClient;
        public VRAPage()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (btnConnect.Content.ToString() == "Disconnect")
                {
                    VRAClient.Dispose();
                    btnConnect.IsDefault = true; ;
                    btnConnect.Background = new SolidColorBrush(Colors.CadetBlue);
                    btnSend.IsDefault = false;
                    grpSend.IsEnabled = false;
                    btnConnect.Content = "Connect";
                    return;
                }
                VRAClient = new VRA(txtServerIP.Text);
                VRAClient.Login();

                if (VRAClient.IsLoggedin)
                {
                    btnConnect.Content = "Disconnect";
                    btnConnect.Background= new SolidColorBrush(Colors.Red);
                    btnSend.Background = new SolidColorBrush(Colors.Green);
                    VRAClient.DataReturnedFromHost += VRAClient_DataReturnedFromHost;
                    btnConnect.IsDefault = false;
                    btnSend.IsDefault = true;
                    grpSend.IsEnabled = true;
                }
                else
                {
                    btnSend.Background = new SolidColorBrush(Colors.Red);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error in logging in.\nCheck the VPARS is nin NORM.\n" + ex.Message);
            }
            
        }

        void VRAClient_DataReturnedFromHost(string tpfreturndata)
        {
            this.Dispatcher.BeginInvoke((Action)(() =>
            {
                txtResponse.Text += tpfreturndata;
                txtResponse.ScrollToEnd();
            }));
        }

        private void btnSend_Click(object sender, RoutedEventArgs e)
        {
            var cmd = txtCommand.Text.Trim();
            if (!string.IsNullOrWhiteSpace(cmd))
            {
                txtResponse.Text += new string('_',80)+Environment.NewLine+ cmd+ Environment.NewLine + new string('_',80)+Environment.NewLine;
                VRAClient.WriteCMD(cmd);
                txtCommand.Text = null;
                txtResponse.ScrollToEnd();
            }
        }
    }
}
