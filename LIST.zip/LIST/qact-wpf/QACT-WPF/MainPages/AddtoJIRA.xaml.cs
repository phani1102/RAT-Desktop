﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for AddtoJIRA.xaml
    /// </summary>
    public partial class AddtoJIRA : Page
    {
        public AddtoJIRA()
        {
            InitializeComponent();
        }

        private void addtojira_Click(object sender, RoutedEventArgs e)
        {
            if (txtWE.Text.Length != 8)
            {
                statusWE.Content = "Invalid format";
            }
            else
            {
                statusWE.Content = AddFieldToJIRA("Work Effort", txtWE.Text);
            }
            if (txtRTN.Text.Length != 6)
            {
                statusRTN.Content = "Invalid format";
            }
            else
            {
                statusRTN.Content = AddFieldToJIRA("RTN", txtRTN.Text);
            }
            if (dtpckr.SelectedDate==null || dtpckr.SelectedDate.Value.DayOfWeek!= DayOfWeek.Sunday)
            {
                statusRTN.Content = "Invalid format";
            }
            else
            {
                statusDate.Content = AddFieldToJIRA("Install Date", dtpckr.SelectedDate.Value.ToString("MM/dd/yyyy"));
            }
        }
        private string AddFieldToJIRA(string field, string toadd)
        {
            string status = null;
            string url = @"https://issues/rest/api/latest/issue";
            var mergedCredentials = string.Format("{0}:{1}", "svcvipqa", "3#Zt'!eSND");
            var byteCredentials = Encoding.UTF8.GetBytes(mergedCredentials);
            var encodedCredentials = Convert.ToBase64String(byteCredentials);
            DR newdr = new DR();
            newdr.fields.Add("project", new Field() { key = "VIP" });
            newdr.fields.Add("issuetype", new Field() { name = "Value Addition Request" });//Value Addition Request
            newdr.fields.Add("customfield_17218", new Field() { value = field });
            newdr.fields.Add("customfield_17219", toadd);
            newdr.fields.Add("description", "Add " + toadd + " to available " + field);
            newdr.fields.Add("summary", "Add " + toadd + " to available " + field);
            JavaScriptSerializer serialize = new JavaScriptSerializer();
            var drtext = serialize.Serialize(newdr);

            try
            {
                using (WebClient webClient = new WebClient())
                {
                    webClient.Headers.Set("Authorization", "Basic " + encodedCredentials);
                    webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
                    var xx = webClient.UploadString(url, drtext);
                    //now get the url of created DR
                    string transitionurl = url + "/" + xx.Replace("\"", "").Split(',')[1].Replace("key:", "") + "/transitions";
                    //now do the assign
                    //https://issues.trusted.visa.com/rest/api/latest/issue/VIP-1964/transitions
                    // Resolve : ID 11
                    string assigntext = "{\"transition\": {\"id\": \"11\"}}";
                    webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
                    webClient.UploadString(transitionurl, assigntext);
                    status = "Successful";
                    //{"update": {"comment": [{"add": {"body": "Comment added when Assigning issue"}}]},"transition": {"id": "21"}}
                    //
                }
            }
            catch (Exception)
            {
                status = "Failed";
            }
            return status;

        }
        class DR
        {
            public Dictionary<string, dynamic> fields { get; set; }
            public DR()
            {
                fields = new Dictionary<string, dynamic>();
            }
        }
        class Field
        {
            public string id { get; set; }
            public string key { get; set; }
            public string value { get; set; }
            public string name { get; set; }
        }

        private void btnreset_Click(object sender, RoutedEventArgs e)
        {
            txtWE.Clear();
            txtRTN.Clear();
            dtpckr.SelectedDate = null;
        }
    }
}
