﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for TSURequestEntry.xaml
    /// </summary>
    public partial class TSURequestEntry : Page
    {
        
        public TSURequestEntry()
        {
            InitializeComponent(); 
            
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            if (txtCMD.Text.Trim() == string.Empty)
            {
                //txterror.Text = "What to apply can not be left blank.";
                MessageBox.Show("What to apply can not be left blank.","TSU Request Entry");
                txtCMD.Focus();
                return;
            }
            if (dtStartInstall.SelectedDate==null)
            {
                MessageBox.Show("Select start date.", "TSU Request Entry");
               // txterror.Text = "Select start date.";
                dtStartInstall.Focus();
                return;   
            }
            if (dtEndInstall.SelectedDate == null && !(bool)chkNotDecided.IsChecked)
            {
                MessageBox.Show("Select end date.", "TSU Request Entry");
                //txterror.Text = "Select end date.";
                dtEndInstall.Focus();
                return;
            }
            List<string>commands=new List<string>();
            var chkvips = chkVIP.Items.Cast<CheckBox>().Where(c => (bool)c.IsChecked);
            var chktypes = chkType.Items.Cast<CheckBox>().Where(c => (bool)c.IsChecked);
            foreach (var line in txtCMD.Text.Split(new string[]{ Environment.NewLine},StringSplitOptions.RemoveEmptyEntries))
            {
                string command = "";
                command += line.Trim() + "   [";
                //var chkvips = chkVIP.Items.Cast<CheckBox>().Where(c => (bool)c.IsChecked);
                if (chkvips.Count()>0)
                {
                    //command += "IN-";
                    //foreach (var item in chkvips)
                    command +="IN-"+string.Concat(chkvips.Select(i=>i.Content+","));// item.Content.ToString() + ",";
                    command = command.TrimEnd(',') + ";";
                }
            //var chktypes = chkType.Items.Cast<CheckBox>().Where(c => (bool)c.IsChecked);
                if (chktypes.Count()>0)
                {
                    //command += "During-";
                   // foreach (var item in chktypes)
                    command +="During-"+string.Concat(chktypes.Select(i=>i.Content+","));
                    command = command.TrimEnd(',') + ";";
                }
                command += "Requested by-" + (txtreqby.Text.Trim() == "" ? Environment.UserName : txtreqby.Text.Trim());
                if (txtComment.Text.Trim() != string.Empty)
                    command += ";Comment-" + txtComment.Text.Trim();
                command += "]||" + dtStartInstall.SelectedDate.Value.ToString("MM/dd/yyyy") + "||" + ((bool)chkNotDecided.IsChecked ? "01/01/2099" : dtEndInstall.SelectedDate.Value.ToString("MM/dd/yyyy")) + "||" + DateTime.UtcNow.ToString("MM/dd/yy HH:mm:ss") + " GMT";
                commands.Add(command);
            }
            try
            {
                //Auto Clean command database
                //Remove commands that are not valid now because their final load date was 7 days before today
                //Read Old commands
                var Extracommands = System.IO.File.ReadAllLines(App.ExtraTSUCMDServer).ToList();
                for (int i = 0; i < Extracommands.Count; i++)
                {
                    try
                    {
                        if (DateTime.ParseExact(Extracommands[i].Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries)[2], "MM/dd/yyyy", null).AddDays(7) <=DateTime.Now)
                        {
                            //nullify those commands which were needed to be applied till last week
                            Extracommands[i] = null;
                        }
                    }
                    catch{}
                }
                //Remove nulls and write rest of the lines with concating new commands
                System.IO.File.WriteAllLines(App.ExtraTSUCMDServer, Extracommands.Where(c => c != null).Concat(commands));
                //System.IO.File.AppendAllLines(App.ExtraTSUCMDServer,commands);
                MessageBox.Show("Your request is accepted! Create TSU to validate changes.", "TSU Request Entry");
                txtCMD.Clear();
                txtCMD.Focus();
                txtreqby.Clear();
                //txterror.Text = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sorry! Error:"+ex.Message, "TSU Request Entry");
                // MessageBox.Show("Sorry! Some error occured. Contact DEV.");
                // txterror.Text = ex.Message;
            }
            
        }

        private void hypmanage_Click(object sender, RoutedEventArgs e)
        {
            txtAll.Text = System.IO.File.ReadAllText(App.ExtraTSUCMDServer);
            grdEdit.Visibility = Visibility.Visible;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            grdEdit.Visibility = Visibility.Collapsed;
            System.IO.File.WriteAllText(App.ExtraTSUCMDServer,txtAll.Text);
        }
    }
}
