﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QACT_WPF
{
    public class RegressionErrors
    {
        public static readonly List<string> LogonErrors = new List<string>()
            {
                "LOGON unsuccessful--incorrect password",
                "not in CP directory",
                "Already logged on LDEV",
                "RECONNECTED AT",
                "expired",
                "news"
            };
        public static readonly List<string> TPFSETUPErrors = new List<string>()
            {
                "<Enter> for list of retrievable jobfiles, or type new JOB name",
                "Not logged off",
                "Unauthorised VPARS id",
                "Invalid file",
                "Invalid",
                "Fill in your USERID and PASSWORD and press ENTER"
            };
        public static readonly List<string> TPFJOBSErrors = new List<string>()
            {
                "END TPFPROC: NEWCONN RC=-43",
                "Job ended rc=0 *",
                "Job ended rc=-",
                "RC=-",
                "Fill in your USERID and PASSWORD and press ENTER"
            };
        public static readonly List<string> ParsemErrors = new List<string>()
            {
                "Incomplete fileid specified",
                "Invalid option",
                "Fill in your USERID and PASSWORD and press ENTER"
            };
        public static readonly List<string> BucketRunErrors = new List<string>()
            {
                "Message sending cancelled via keyboard interrupt",
                "Disk A is full...",
                "Disk Z is full...",
                "Insufficient storage",
                "FTP GET or other error",
                "Disk A(191) is full",
                "Disk A(291) is full",
                "Fill in your USERID and PASSWORD and press ENTER"

            };
        public static readonly List<string> TapecuttingErrors = new List<string>()
            {
                "End of TPF Procedure:  RC=-11",
                "End of TPF Procedure:  RC=-",
                "Disk A is full...",
                "Disk Z is full...",
                "Disk A(191) is full",
                "Disk A(291) is full",
                "Ready(",
                "NOTHING TO DUMP",
                "Fill in your USERID and PASSWORD and press ENTER"

            };
        public static readonly List<string> CompareErrors = new List<string>()
        {
            "Mismatched tapes",
            "ERROR unable to define temporary working disk space",
            "scratch volume",
            "Request was canceled by attention interrupt",
            "No records to compare!",
            //"Ready;",
            "PARSEM news and status",
            "Disk A(191) is full",
            "Disk A(291) is full",
            "Disk A is full",
            "Disk Z is full",
            "Fill in your USERID and PASSWORD and press ENTER",
            "Ready("
        };
        public static readonly List<string> FallbackErrors = new List<string>()
        {
            "Global Fallback Completed",
            "Switch status changed",
            "File \"FLBK SCRIPT A1\" does not exist",
            "Not found in FLBK SCRIPT A1",
            "Processing completed with Errors.",
            "Ready(",
            "Fill in your USERID and PASSWORD and press ENTER"
        };
        public static readonly List<string> ANALYSIS_RECREATE_ERRORS = new List<string>()
        {
            "Interesting Case",
           // "No mismatches recreated",
            "Ready(",
            "No dumps recreated",
            "Fill in your USERID and PASSWORD and press ENTER"
        };
        public static readonly List<string> AUTOSAVE_ERRORS = new List<string>()
        {
                "Disk A is full...",
                "Disk Z is full...",
                "NO TEST CASE(S) FOUND",
                "Processing completed with Errors.",
                "NO SAVETAPE TEXT A1 FOUND.. EXITING NOW...",
                "Ready(",
                "Fill in your USERID and PASSWORD and press ENTER"
        };
        public static readonly List<string> CHKMODE_ERRORS = new List<string>()
        {
                "Disk A is full...",
                "Disk Z is full...",
                "Processing completed with Errors.",
                "Ready(",
                "Fill in your USERID and PASSWORD and press ENTER"
        };
        public static readonly List<string> USING_ERRORS = new List<string>()
        {
            "Required No.Of VPARS Not available",
            "Required No.Of QAT Not available",
            "Required No.Of LQAT Not available",
            "Ready(",
            "Fill in your USERID and PASSWORD and press ENTER"
        };

        //public static readonly List<ExecError> MMIDNTFR_ERRORS = new List<ExecError>()
        //{
        //    new ExecError{
        //        ErrorString = "Processing completed; Error in Comparison",                                     //(when input % comparison below 50%): QACT should log error and continue,
        //        ErrorType = ErrorTypes.LogOnly
        //    },
        //    new ExecError{
        //        ErrorString = "Processing completed with Errors",					                            //QACT should log error and continue,
        //        ErrorType = ErrorTypes.LogOnly
        //    },
        //    new ExecError{
        //        ErrorString = "Ready(",                                                             			// MMIDNTFR unsuccessful
        //        ErrorType = ErrorTypes.NotifyandWait
        //    }
        //};
        public static readonly Dictionary<string, ErrorTypes> INTERNALREXXERRORS = new Dictionary<string, ErrorTypes>()
        {
            //{"Processing completed successfully", ErrorTypes.Nothing},//This is the main 
            {"Processing completed with Errors", ErrorTypes.LogOnly},
            {"ABORT QACT", ErrorTypes.NotifyandAbort},
            //{"Ready(", ErrorTypes.LogOnly},
            {"Ready(", ErrorTypes.NotifyandAbort},//Saumen020617
            {"Fill in your USERID and PASSWORD and press ENTER",ErrorTypes.NotifyandAbort}
        };

    }
    public struct ExecError
    {
        public string ErrorString;
        public ErrorTypes ErrorType;
    }
    /// <summary>
    /// Regression Errors are being dividen in different Groups
    /// </summary>
    public enum ErrorGroup
    {
        USER_ERROR,
        VM_ERROR,
        DISK_SPACE_ERROR,
        FTP_ERROR,
        PARSEM_ERROR,
        VM_TOOLS_ERROR,
        UNHANDLED_ERROR,
        BUCKET_EXECUTION_TIMEOUT,
        BUCKET_EXECUTION_ERROR,
        CUPLOAD_ERROR,
        COM_ERROR,
        MANUAL_INTERVENSION,
        MMIDNTFR_ERROR,
        NO_FREE_HSM,
        OSA_ERROR_AFTER_RETRY,
        OUT_OF_PRODDQAT_ID,
        SYSTEM_PROBLEM,
        TAPE_COMPARISON_ERROR,
        TAPE_CUTTING_ERROR,
        TPFSETUP_ERROR,
        SETUP_CREATION_ERROR,
        NOT_CLASSIFIED_ERROR,
        ANALYSIS_EXECS_ERROR,
        ETC_ERROR,
        UNIDUMPS_ERROR,
        OTHER_INTERNAL_EXEC_ERROR,
        NO_ERROR
    }
}
