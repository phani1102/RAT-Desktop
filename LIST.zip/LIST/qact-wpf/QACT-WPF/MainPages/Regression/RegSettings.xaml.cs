﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Threading;
using System.Collections.ObjectModel;
using Microsoft.Win32;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.InteropServices;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for RegSettings.xaml
    /// </summary>
    public partial class RegSettings : Page, INotifyPropertyChanged
    {
        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        #region Members & Properties
        const int VMCommandTimeOut = 1;
        // public static List<string> CaptureDetailsFromServer;
        public Thread RegressionThread { get; set; }
        public Thread TimerThread { get; set; }
        HLLAPI reg;
        List<string> ErrorsInRun = new List<string>();
        public ObservableCollection<VIP> ObsAllVIP { get { return this._ObsAllVIP; } set { _ObsAllVIP = value; NotifyPropertyChanged("OBSALLVIP"); } }
        ObservableCollection<VIP> _ObsAllVIP = new ObservableCollection<VIP>();
        public ObservableCollection<RegStage> RegStages { get { return this._RegStages; } set { _RegStages = value; NotifyPropertyChanged("RegStages"); } }
        ObservableCollection<RegStage> _RegStages = new ObservableCollection<RegStage>();
        GlobalSet _globalset = new GlobalSet();
        public GlobalSet GLOBALS { get { return this._globalset; } set { _globalset = value; NotifyPropertyChanged("GLOBALS"); } }
        private Steps _stepstoperform = new Steps();
        public Steps StepstoPerform { get { return this._stepstoperform; } set { _stepstoperform = value; NotifyPropertyChanged("StepstoPerform"); } }
        bool _regressionSuccessful = false;
        public bool RegressionSuccessful { get { return _regressionSuccessful; } set { _regressionSuccessful = value; NotifyPropertyChanged("RegressionSuccessful"); } }
        bool _isIdle = true;
        public bool IsIdle { get { return _isIdle; } set { _isIdle = value; NotifyPropertyChanged("IsIdle"); } }

        bool _IsControlEnabled = true;
        public bool IsControlEnabled { get { return _IsControlEnabled; } set { _IsControlEnabled = value; NotifyPropertyChanged("IsControlEnabled"); } }

        public string SessionName { get; set; }
        string _buttoncontent = "Start";
        public string ButtonContent { get { return _buttoncontent; } set { _buttoncontent = value; NotifyPropertyChanged("ButtonContent"); } }
        int _elapsedSeconds;
        public int ElapsedSeconds { get { return _elapsedSeconds; } set { _elapsedSeconds = value; NotifyPropertyChanged("ElapsedSeconds"); } }
        RunSettings _Runsettings = new RunSettings();
        public RunSettings Runsettings { get { return _Runsettings; } set { _Runsettings = value; NotifyPropertyChanged("Runsettings"); } }
        //public RunSettings Runsettings = null;
        public event EventHandler RegressionCompleted;
        public bool finished = false;
        bool IsLoggedon = false;
        //bool IsJsonReadused = false;

        #endregion

        #region Get Settings and Manage UI and Threads
        public RegSettings(string sessionname)
        {
            InitializeComponent();
            comboType.ItemsSource = App.REGRESSIONTYPES;
            comboHSM.ItemsSource = App.HSMUNITS;
            SessionName = sessionname;
            this.Title = "Regression Window " + sessionname.ToUpper();
            ButtonContent = "Start";
            reg = new HLLAPI(SessionName, true, "REGRESSION");
            foreach (var vicid in App.ALLVIPS)
            {
                VIP tempvip = new VIP() { VIPNAME = "VIP" + vicid };
                _ObsAllVIP.Add(tempvip);
            }
            comboRun.ItemsSource = new string[] { "RUN1", "RUN2", "RUN3", "RUN4", "RUN5", "RUN6", "RUN7", "RUN8", "RUN9", "RUN10", "RUN11", "RUN12", "RUN13", "RUN14", "RUN15", "RUN16", "RUN17", "RUN18", "RUN19", "RUN20" };//Saumen013117
            List<string> swtactinfo = new List<string>();
            swtactinfo.Add("N/A");
            if (DateTime.Now.Month <= 4)
                swtactinfo.Add(DateTime.ParseExact("0401", "MMdd", null).ToString("MMMyy").ToUpper());
            if (DateTime.Now.Month > 4 && DateTime.Now.Month <= 10)//Saumen030317
                swtactinfo.Add(DateTime.ParseExact("1001", "MMdd", null).ToString("MMMyy").ToUpper());
            comboswitch.ItemsSource = swtactinfo;
            //IsJsonReadused = false;

            if (App.InputObj != null)
                this.Loaded += RegSettings_Loaded_File;
        }

        /// <summary>
        /// RegSettings.xaml page event Handler.
        /// This handler programmatically clicks the Start button on the loaded RegSettings Page, only if the Inputfile object is not null.
        /// It also adds "StartArchesFile" event handler to the RegressionCompleted event
        /// </summary>
        /// <param name="sender">the RegSettings page object</param>
        /// <param name="e">event object</param>
        void RegSettings_Loaded_File(object sender, RoutedEventArgs e)
        {
            if (!((App)App.Current).IsVIPTESTENGMember)
            {
                MessageBox.Show("You are not authorized to use this exclusive feature.", "UnAuthorizedException");
                App.InputObj = null;
                return;
            }
            if (App.InputObj.State >= InputFile.Status.REGRESSION_RUNNING)
                return;

            this.RegressionCompleted += StartArchesFile;

            ////////////////////////// Click the Start Button ////////////////////////////////
            this.btnSTART.RaiseEvent(new RoutedEventArgs(System.Windows.Controls.Primitives.ButtonBase.ClickEvent));
            App.InputObj.State = InputFile.Status.REGRESSION_RUNNING;

        }
        /// <summary>
        /// Event Handler for Regression Commpleted Event. 
        /// This event handler is responsible for starting Arches, or exiting the application in case there is no comparison in Regression
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartArchesFile(object sender, EventArgs e)
        {
            RegSettings RegPage = (RegSettings)sender;
            RegPage.IsIdle = true;

            VIP BaseVIP = RegPage.Runsettings.VIPS.LastOrDefault(v => !String.IsNullOrWhiteSpace(v.VPARS));
            App.InputObj.BaseRunVPARS = BaseVIP == null ? null : BaseVIP.VPARS;

            VIP CodeVIP = RegPage.Runsettings.VIPS
                                                .LastOrDefault(
                                                v => !String.IsNullOrWhiteSpace(v.VPARS)
                                                    && !v.VPARS.Equals(App.InputObj.BaseRunVPARS, StringComparison.CurrentCultureIgnoreCase));
            App.InputObj.CodeRunVPARS = CodeVIP == null ? null : CodeVIP.VPARS;

            // Assign CoderunVpars for Arches
            if (App.InputObj.CodeRunVPARS == null)
            {
                // fetch another VPARS for ARCHES 
                RegPage.reg.EnterCommand("USING 1VPARS", 2);
                //Parse PRODD Ids here from the screen
                var response = reg.GetLines(10).Where(l => l.Trim() != "" && !l.Contains("Ready;") && !l.Contains("AVAILABLE") && !l.Contains("Not available"));
                var proddline = response.FirstOrDefault(l => l.Contains("PRODD"));
                if (proddline != null)
                {// VPARS found 
                    App.InputObj.CodeRunVPARS = proddline.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0].Trim();
                    //Send Email
                    string emailSubject = "I will be using " + App.InputObj.CodeRunVPARS + " for " + RegPage.Runsettings.RegType + " Analysis, of " + RegPage.Runsettings.InstallDate + " install (" + RegPage.Runsettings.RunNumber + ")";
                    HandleError(emailSubject, ErrorTypes.NotifyOnly, ErrorGroup.NO_ERROR, emailSubject, "QA-VIP-Support", false);
                }
                else
                {// No VPARS found
                    string emailSubject = "No VPARS available to IPL CODERUN, for " + RegPage.Runsettings.RegType + " Analysis, of " + RegPage.Runsettings.InstallDate + " install (" + RegPage.Runsettings.RunNumber + ")";
                    HandleError(emailSubject, ErrorTypes.NotifyandAbort, ErrorGroup.OUT_OF_PRODDQAT_ID);
                    RegPage.LogOffCMS();
                    return;
                }

            }

            if (App.InputObj.RegType.Equals("TOKEN") || RegPage.Runsettings.IsComparisonRequired == false)
            {///////////////////////////////// Do only a standalone Run ///////////////////////////////////////////

                RegPage.LogOffAllVPARS(RegPage.Runsettings.VIPS.Where(v => !String.IsNullOrWhiteSpace(v.VPARS)).ToList());
                if (HSM_PRODD77 == "DETACHED")                                                                      //Saumen090116
                {
                    ReserveHSM("9", "ATTACH");                                                                      //Saumen082916
                }
                RegPage.LogOffCMS();                                  // Log off CMS
                RegPage.reg.DisconnectSession();

                App.InputObj.State = InputFile.Status.REGRESSION_COMPLETED;
                InputFile.UpdateStatus(App.InputObj, "Run Completed");                                              //Saumen082416
                // Close QACT
                if (Application.Current != null)
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        try
                        {
                            Application.Current.Shutdown(-1);
                            IsIdle = true;
                        }
                        catch
                        {
                            Environment.Exit(-1);
                        }

                    });
                return;
            }
            else
            {///////////////////////////////// Do a complete run with analysis /////////////////////////////////////////// 
                // log off all vics except Baserun and Coderun VPARS used in Analysis
                RegPage.LogOffAllVPARS(RegPage.Runsettings.VIPS.Where(v =>
                                                                        !String.IsNullOrWhiteSpace(v.VPARS)                // is not empty, in case of SOAP
                                                                        && !v.VPARS.Equals(App.InputObj.BaseRunVPARS)      // not baserun VPARS
                                                                        && !v.VPARS.Equals(App.InputObj.CodeRunVPARS)      // not coderun VPARS
                                                                        ).ToList());
                if (HSM_PRODD77 == "DETACHED")                                                                  //Saumen090116
                {
                    //Saumen082916
                    if (Runsettings.RegType != "DRB")
                    {
                        //Saumen030317
                        //if (Runsettings.RegType == "DURBIN" || Runsettings.RegType == "ECIP" || Runsettings.RegType == "UNBALANCED" || Runsettings.RegType == "PRODD" || Runsettings.RegType == "TOKEN")
                        //{
                        //Saumen030317
                        ReserveHSM("9", "ATTACH");
                        //Saumen030317
                        //}
                        //else
                        //{
                        //    ReserveHSM("5", "ATTACH");
                        //}
                        //Saumen030317
                    }
                    //Saumen082916
                }
            }
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            // Log off CMS
            RegPage.LogOffCMS();

            App.InputObj.State = InputFile.Status.REGRESSION_COMPLETED;

            // Invoke Arches by navigating to the Arches Page
            if (Application.Current != null)
                Application.Current.Dispatcher.Invoke((Action)(() =>
                {
                    QACT_WPF.MainWindow mainWindow = (QACT_WPF.MainWindow)Application.Current.MainWindow;
                    ((TreeViewItem)mainWindow.treTools.Items[2]).IsExpanded = true;
                    switch (App.InputObj.RegWindow)
                    {
                        case "A":
                            ((TreeViewItem)((TreeViewItem)mainWindow.treTools.Items[2]).Items[0]).IsSelected = true; ;
                            break;
                        case "B":
                            ((TreeViewItem)((TreeViewItem)mainWindow.treTools.Items[2]).Items[1]).IsSelected = true;
                            break;
                        case "C":
                            ((TreeViewItem)((TreeViewItem)mainWindow.treTools.Items[2]).Items[2]).IsSelected = true;
                            break;
                        case "D":
                            ((TreeViewItem)((TreeViewItem)mainWindow.treTools.Items[2]).Items[3]).IsSelected = true;
                            break;
                        case "E":
                            ((TreeViewItem)((TreeViewItem)mainWindow.treTools.Items[2]).Items[4]).IsSelected = true;
                            break;
                        //Saumen030617
                        case "F":
                            ((TreeViewItem)((TreeViewItem)mainWindow.treTools.Items[2]).Items[5]).IsSelected = true; ;
                            break;
                        case "G":
                            ((TreeViewItem)((TreeViewItem)mainWindow.treTools.Items[2]).Items[6]).IsSelected = true;
                            break;
                        case "H":
                            ((TreeViewItem)((TreeViewItem)mainWindow.treTools.Items[2]).Items[7]).IsSelected = true;
                            break;
                        case "I":
                            ((TreeViewItem)((TreeViewItem)mainWindow.treTools.Items[2]).Items[8]).IsSelected = true;
                            break;
                        case "J":
                            ((TreeViewItem)((TreeViewItem)mainWindow.treTools.Items[2]).Items[9]).IsSelected = true;
                            break;
                        //Saumen030617
                    }
                }));
        }

        /// <summary>
        /// event Handler for the Start button in RegSettings.xaml page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSTART_Click(object sender, RoutedEventArgs e)
        {

            if (ButtonContent == "Start")
            {
                ErrorsInRun.Clear();
                _RegStages.Clear();
                BackgroundWorker fetchsettings = new BackgroundWorker();
                //fetchsettings.DoWork += fetchsettings_DoWork;
                fetchsettings.DoWork +=
                    (object workSender, DoWorkEventArgs doWorkArg) =>
                    {
                        IsControlEnabled = false;
                        IsIdle = false;
                        doWorkArg.Result = PopulateSettings();
                    };

                fetchsettings.RunWorkerCompleted += fetchsettings_RunWorkerCompleted;
                fetchsettings.RunWorkerAsync();
            }
            else if (ButtonContent == "Pause")
            {
                RegressionThread.Suspend();
                TimerThread.Suspend();
                ButtonContent = "Resume";
            }
            else if (ButtonContent == "Resume")
            {
                RegressionThread.Resume();
                TimerThread.Resume();
                ButtonContent = "Pause";
            }

        }

        void fetchsettings_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            IsControlEnabled = true;
            if ((bool)e.Result == false)
            {
                CommonClass.ChangeStatus("Populating and validating Regression Settings:Failed.", 0, 0, false);
                IsIdle = true;
                return;
            }
            CommonClass.ChangeStatus("Ready;", 0, 0, false);
            if (Runsettings.RegType.Equals("LOAD_NIGHT", StringComparison.InvariantCultureIgnoreCase))
            { // IN CASE OF LOAD NIGHT TESTING, START a different THREAD

                if (string.IsNullOrWhiteSpace(_globalset.DCS) || string.IsNullOrWhiteSpace(_globalset.BMX) || string.IsNullOrWhiteSpace(_globalset.NWK) || string.IsNullOrWhiteSpace(_globalset.CFG) || string.IsNullOrWhiteSpace(_globalset.FXT))
                {
                    PopulateGlobals();
                }
                Runsettings.IsComparisonRequired = false;
                //LoadNightTesting.LoadNightProcess LDProc = new LoadNightTesting.LoadNightProcess(this.reg, this.Runsettings, DateTime.Parse(Runsettings.InstallDate).AddDays(-7));
                LoadNightTesting.LoadNightProcess LDProc = new LoadNightTesting.LoadNightProcess(this.reg, this.Runsettings, DateTime.Parse(Runsettings.BaserunInstallDate));//Saumen041717

                LDProc.OnError += (string errorTag, string errorDesc, ErrorTypes errType) => { return HandleError(errorTag + '\t' + errorDesc, errType); };
                LDProc.OnStageUpdate += (string stage, string desc, bool isNewStage) => { AddOrUpdateStageLog(stage, desc, isNewStage); };
                LDProc.OnCompletion +=
                    (object runSender, EventArgs runEventArgs) =>
                    {
                        Runsettings.IsComparisonRequired = false;
                        OnRegressionCompleted();
                    };

                RegressionThread = new Thread(
                    () =>
                    {
                        try
                        {
                            LDProc.Run();
                        }
                        catch (Exception ex)
                        {
                            System.IO.File.WriteAllText(System.IO.Path.Combine(LDProc.runSett.CoderunServer, ex.GetHashCode() + ".Exception"), ex.ToString());
                        }
                    });
            }
            else
                RegressionThread = new Thread(PerformRegression);

            //RegressionThread.SetApartmentState(ApartmentState.STA);
            TimerThread = new Thread(IncreaseTime);
            //TimerThread.SetApartmentState(ApartmentState.STA);
            ElapsedSeconds = 0;
            RegressionThread.Start();
            TimerThread.Start();
            IsIdle = false;
            ButtonContent = "Pause";
        }

        //void fetchsettings_DoWork(object sender, DoWorkEventArgs e)
        //{
        //    IsControlEnabled = false;
        //    IsIdle = false;
        //    e.Result = PopulateSettings();
        //}

        void IncreaseTime()
        {
            while (true)
            {
                Thread.Sleep(1000);
                ElapsedSeconds++;
            }
        }
        /// <summary>
        /// Event Handler for "Stop/Pause/Resume" button in RegSettings.xaml pages
        /// All actions of pausing, stopping or resuming are performed on the RegressionThread
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            Runsettings.IsSchedulerRun = false;
            if (RegressionThread == null)
                return;
            if (MessageBox.Show("Do you really want to stop ongoing regression?", "Stop Regression", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No) == MessageBoxResult.No)
                return;
            if (RegressionThread.ThreadState == System.Threading.ThreadState.Suspended)
            {
                RegressionThread.Resume();
                TimerThread.Resume();
            }
            RegressionThread.Abort();
            //Finishing Regression
            IsIdle = true;
            try
            {
                TimerThread.Abort();
                App.InputObj.State = InputFile.Status.REGRESSION_STOPPED;
                AddOrUpdateStageLog("Regression", "Manually Aborted", true);
            }
            catch (Exception)
            {

            }

            _RegStages.Insert(0, new RegStage() { Stage = "Regression Ended.", Status = "Stopped via STOP button", StartAt = DateTime.Now.ToString("MM/dd/yy HH:mm:ss"), EndAt = DateTime.Now.ToString("MM/dd/yy HH:mm:ss") });
            UpdateStagestofile();
            RegressionThread = null;
            TimerThread = null;
            ButtonContent = "Start";

        }
        /// <summary>
        /// event handler for "Show/Hide Attachmate window" button in RegSettings.xaml page
        /// shows or hides the Attachmate Window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnShowHide_Click(object sender, RoutedEventArgs e)
        {
            if (btnShowHide.Content.ToString().Contains("Show"))
            {
                reg.ShowWindow(true);
                btnShowHide.Content = "Hide Attachmate Window";
            }
            else
            {
                reg.ShowWindow(false);
                btnShowHide.Content = "Show Attachmate Window";
            }
        }
        /// <summary>
        /// Event Handler for "Read JSON settings" button in RegSettings.xaml page"
        /// Opens a file dialog box to select and read the "Runsettings.json" file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnbrowse_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog() { Multiselect = false, ReadOnlyChecked = true, Title = "Select the file containing Run settings", Filter = "JSON files|*.json" };
            openfile.ShowDialog();
            if (openfile.FileName != "")
            {
                var tmp = CommonClass.LoadFromJSONFile<RunSettings>(openfile.FileName);
                if (tmp == null || tmp.RegType == null || tmp.InstallDate == null)
                {
                    MessageBox.Show("Invalid settings file.", "Regression Window - " + reg.SessionShortName);
                    return;
                }
                tmp.VMPWD = Crypto.Decrypt(tmp.VMPWD, App.Passphrase);
                Runsettings = tmp;
                pwdPassword.Password = Runsettings.VMPWD;
                if (Runsettings.Globals != null)
                {
                    _globalset.DCS = Runsettings.Globals["DCS"];
                    _globalset.BMX = Runsettings.Globals["BMX"];
                    _globalset.NWK = Runsettings.Globals["NWK"];
                    _globalset.CFG = Runsettings.Globals["CFG"];
                    _globalset.FXT = Runsettings.Globals["FXT"];
                }
                StepstoPerform.EraseOldFiles = false;
                StepstoPerform.SetupCreate = false;
            }
        }
        private void Expander_Expanded(object sender, RoutedEventArgs e)
        {
            borderSteps.Visibility = Visibility.Visible;
        }
        private void Expander_Collapsed(object sender, RoutedEventArgs e)
        {
            borderSteps.Visibility = Visibility.Collapsed;
        }
        private void btnregcompletedialog_Click(object sender, RoutedEventArgs e)
        {
            RegressionSuccessful = false;
        }

        void GetRunNumber()
        {
            if (txtCodeServer.Text != null && txtCodeServer.Text != "" && !txtCodeServer.Text.Contains("Error in format"))
            {
                if (!System.IO.Directory.Exists(txtCodeServer.Text))
                    System.IO.Directory.CreateDirectory(txtCodeServer.Text);
                var lastsuccessfulrunnumber = System.IO.Directory.GetDirectories(txtCodeServer.Text).Select(d => d.Replace(txtCodeServer.Text, "")).Where(d => d.ToUpper().Contains("S-")).Select(d => d.ToUpper().Replace("S-RUN", "")).Max();
                if (!(bool)chkCompare.IsChecked)
                {
                    txtCodeServer.Text += "S-RUN0";
                }
                else
                {
                    if (lastsuccessfulrunnumber != null)
                        txtCodeServer.Text += "S-RUN" + (Convert.ToInt16(lastsuccessfulrunnumber) + 1);
                    else
                        txtCodeServer.Text += "S-RUN1";
                }
                System.IO.Directory.CreateDirectory(txtCodeServer.Text);
            }
        }
        /// <summary>
        /// Populates the Runsettings Object with valid Regression run parameters, issues appropriate popups for invalid values
        /// </summary>
        /// <returns></returns>
        bool PopulateSettings()
        {
            CommonClass.ChangeStatus("Populating and validating Regression Settings...", 50, 1, true);
            //////////////////////////// Scheduler run //////////////////////////////
            if (App.InputObj != null)
            {
                try
                {
                    App.InputObj.CalculatePaths();
                    Runsettings = new RunSettings(App.InputObj);
                    if (!finished)
                    {
                        Runsettings.IsSchedulerRun = true;
                        StepstoPerform.SetupCreate = true;
                        StepstoPerform.LogOffAllVics = false;
                    }
                    else
                        Runsettings.IsSchedulerRun = false;

                    return true;
                }
                catch (Exception ex)
                {
                    HandleError("Error in populating run settings for scheduler : " + ex.Message, ErrorTypes.NotifyandAbort, ErrorGroup.NOT_CLASSIFIED_ERROR);
                    return false;
                }
            }

            /////////////// UI Initiated Run ///////////////////////////
            bool result = false;
            if (Application.Current != null)
                Application.Current.Dispatcher.Invoke(() =>
                {
                    #region UI Validation
                    if (Runsettings.InstallDate == null)
                    {
                        MessageBox.Show("Invalid Install Date", " Regression window " + reg.SessionShortName);
                        dateInstall.Focus();
                        result = false;
                        return false;
                    }
                    //Runsettings.InstallDate = dateInstall.SelectedDate.Value.ToString("MM/dd/yyyy");
                    //Check Run Type
                    if (Runsettings.RegType == null)
                    {
                        MessageBox.Show("Please select a Run Type", " Regression window " + reg.SessionShortName);
                        comboType.Focus();
                        result = false;
                        return false;
                    }
                    // Runsettings.RegType = comboType.SelectedItem.ToString();
                    //Check Capture
                    //Runsettings.RegCapture = txtCapture.Text.Trim().ToUpper();
                    if (String.IsNullOrWhiteSpace(Runsettings.RegCapture))
                    {
                        MessageBox.Show("Invalid Regression Capture", " Regression window " + reg.SessionShortName);
                        txtCapture.Focus();
                        result = false;
                        return false;
                    }
                    //Runsettings.RegCapture = Runsettings.RegCapture.ToUpper();
                    //Check Bucket

                    if (String.IsNullOrWhiteSpace(Runsettings.Bucket))
                    {
                        MessageBox.Show("Invalid Regression Bucket", " Regression window " + reg.SessionShortName);
                        txtBucket.Focus();
                        result = false;
                        return false;
                    }
                    //Runsettings.Bucket = Runsettings.Bucket.ToUpper();
                    //Check System date
                    if (Runsettings.SystemDate == null)
                    {
                        MessageBox.Show("Invalid system date", " Regression window " + reg.SessionShortName);
                        dateSystem.Focus();
                        result = false;
                        return false;
                    }
                    else if (dateSystem.SelectedDate.Value.Date < DateTime.Now.Date)
                    {
                        MessageBox.Show("System date can't be less than today's date.", " Regression window " + reg.SessionShortName);
                        dateSystem.Focus();
                        result = false;
                        return false;
                    }
                    else if (dateSystem.SelectedDate.Value.Date < dateInstall.SelectedDate.Value.Date)
                    {
                        MessageBox.Show("System date can't be less than install date.", " Regression window " + reg.SessionShortName);
                        dateSystem.Focus();
                        result = false;
                        return false;
                    }
                    if (String.IsNullOrWhiteSpace(Runsettings.VMID))
                    {
                        MessageBox.Show("Invalid VM ID", " Regression window " + reg.SessionShortName);
                        txtVMID.Focus();
                        result = false;
                        return false;
                    }
                    //Check PASSWORD
                    Runsettings.VMPWD = pwdPassword.Password.Trim().ToUpper();
                    if (String.IsNullOrWhiteSpace(Runsettings.VMPWD))
                    {
                        MessageBox.Show("Invalid Password", " Regression window " + reg.SessionShortName);
                        pwdPassword.Focus();
                        result = false;
                        return false;
                    }
                    //check setup

                    if (String.IsNullOrWhiteSpace(Runsettings.SetupFile))
                    {
                        MessageBox.Show("Invalid Setup file name", " Regression window " + reg.SessionShortName);
                        txtSetupFile.Focus();
                        result = false;
                        return false;
                    }
                    //check servers

                    try
                    {
                        if (Runsettings.CoderunServer != null)
                            Runsettings.CoderunServer = Runsettings.CoderunServer.Trim().TrimEnd('\\');
                        if (!System.IO.Directory.Exists(Runsettings.CoderunServer))
                            System.IO.Directory.CreateDirectory(Runsettings.CoderunServer);
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Invalid coderun Server address", " Regression window " + reg.SessionShortName);
                        txtCodeServer.Focus();
                        result = false;
                        return false;
                    }

                    //Runsettings.IsComparisonRequired = (bool)chkCompare.IsChecked;
                    if (Runsettings.BaserunServer != null)
                        Runsettings.BaserunServer = Runsettings.BaserunServer.Trim().TrimEnd(new char[] { '\\' });
                    if (!System.IO.Directory.Exists(Runsettings.BaserunServer) && Runsettings.IsComparisonRequired)
                    {
                        MessageBox.Show("Invalid baserun server address", " Regression window " + reg.SessionShortName);
                        txtBaseserver.Focus();
                        result = false;
                        return false;
                    }
                    Runsettings.TapeRetentionPeriod = Convert.ToInt16(txtretension.Text);
                    result = true;
                    return true;
                    #endregion
                });

            return result;
        }
        /// <summary>
        /// A utility function which writes the RegStages list to Status.txt file in the Regression folder
        /// </summary>
        void UpdateStagestofile()
        {
            try
            {
                System.IO.File.WriteAllLines(Runsettings.CoderunServer + @"\Status.txt", _RegStages.Select(s => s.Stage.PadRight(50) + s.StartAt.PadRight(20) + s.Status.PadRight(50) + s.EndAt.PadRight(20) + s.TimeTaken.PadRight(10)));
            }
            catch { }
        }
        /// <summary>
        /// A utility function that updates the Regression Stages and also reflects them in the UI and Status.txt file  
        /// </summary>
        /// <param name="Stage">Name of the regression stage</param>
        /// <param name="Status"> Status of the Stage</param>
        /// <param name="addnew">When false it will update the record at the top.
        /// When true it will insert a new stage.</param>
        private void AddOrUpdateStageLog(string Stage, string Status, bool newStage, bool updateScheduler = true)
        {
            try
            {

                if (newStage)
                {
                    Application.Current.Dispatcher.Invoke(
                            () => _RegStages.Insert(0, new RegStage() { Stage = Stage, StartAt = DateTime.Now.ToString("MM/dd/yy HH:mm:ss"), Status = Status })
                        );
                }
                else
                {
                    Application.Current.Dispatcher.Invoke(() => _RegStages.First().EndAt = DateTime.Now.ToString("MM/dd/yy HH:mm:ss"));
                }

                // Stage Status Update
                Application.Current.Dispatcher.Invoke(() => _RegStages.First().Status = Status);

            }
            catch (Exception ex)
            {
                System.IO.File.WriteAllText(System.IO.Path.Combine(Runsettings.CoderunServer, ex.GetHashCode() + ".Exception"), ex.ToString());
            }
            finally
            {// Updates to flat file

                if (updateScheduler)
                { //update new stage to RegressionOutputFile
                    new Thread(() => InputFile.UpdateStatus(App.InputObj, _RegStages.First().Stage + '\t' + _RegStages.First().Status)).Start();
                }
                // logs in RunStatus.txt
                new Thread(() => UpdateStagestofile()).Start();
            }
        }
        #endregion

        /// <summary>
        /// The Main driver function for all the regression steps. This funtion is called separately in a thread named as RegressionThread, which is started on clicking the start button
        /// This RegressionThread in turn uses the utility functions in RegSettings.xaml page to update the UI, store status on file and Handle errors
        /// </summary>
        /// 
        [System.Runtime.ExceptionServices.HandleProcessCorruptedStateExceptionsAttribute()]
        void PerformRegression()
        {

            #region Regression Thread Work
            try
            {
                AddOrUpdateStageLog("Regression", "Started...", true);

                string BaserunInstallDate = null;
                string BaserunSystemDate = null;

                if (Runsettings.IsComparisonRequired)
                    if (!ValidateBaserun(out BaserunInstallDate, out BaserunSystemDate))
                        goto FINISH;
                if (string.IsNullOrWhiteSpace(_globalset.DCS) || string.IsNullOrWhiteSpace(_globalset.BMX) || string.IsNullOrWhiteSpace(_globalset.NWK) || string.IsNullOrWhiteSpace(_globalset.CFG) || string.IsNullOrWhiteSpace(_globalset.FXT))
                {
                    PopulateGlobals();
                }
                //PopulateGlobals();
                //Saumen031017
                if (Runsettings.RegType.Contains("UNBALANCED") || Runsettings.RegType.Contains("LOAD_NIGHT"))
                {
                    if (Runsettings.IsSchedulerRun == false)
                    {
                        Runsettings.BaserunInstallDate = DateTime.ParseExact(Runsettings.InstallDate, @"MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture).AddDays(-7).ToString(@"MM/dd/yyyy");
                    }
                }
                else
                {
                    Runsettings.BaserunInstallDate = BaserunInstallDate;
                }
                //Saumen031017
                Runsettings.BaserunSystemDate = BaserunSystemDate;
                var tmp = Runsettings.VMPWD;
                Runsettings.VMPWD = Crypto.Encrypt(Runsettings.VMPWD, App.Passphrase);
                Runsettings.StoreAsJsonFile(System.IO.Path.Combine(Runsettings.CoderunServer, "RunSettings.json"));
                Runsettings.VMPWD = tmp;
                AddOrUpdateStageLog("Connect to session " + reg.SessionShortName, "Running...", true);
                reg.ShowWindow(true);

                if (reg.ConnectSession() == 0)
                {
                    AddOrUpdateStageLog(null, "Successful.", false);
                    // Save log files
                    App.debuggingFilePaths[reg.screenshotfile] = System.IO.Path.Combine(Runsettings.CoderunServer, System.IO.Path.GetFileName(reg.screenshotfile));

                    if (StepstoPerform.Logon)
                    {
                        ///////////////////// LOGIN to VM /////////////////////////////
                        try
                        {// try logging in 
                            AddOrUpdateStageLog("Login and Get Temp Disks", "Started...", true);
                            Runsettings.VMID = Login(Runsettings.VMID, Runsettings.VMPWD);
                            IsLoggedon = true;
                            GetTempDisks();
                            //UpdateUsingFile();
                            AddOrUpdateStageLog("Login", "Successful", false);
                        }
                        catch (System.Security.Authentication.InvalidCredentialException ex)
                        {
                            AddOrUpdateStageLog("Login", ex.Message, false);

                            if (Runsettings.IsSchedulerRun && Runsettings.VMID.ToUpper().Split(new String[] { " BY " }, StringSplitOptions.RemoveEmptyEntries).Length > 1)
                            {   /// change password here only for scheduler runs
                                try
                                {
                                    AddOrUpdateStageLog("Login", "Changing password for " + Runsettings.VMID, false);

                                    // change password using web interface
                                    string logonById = Runsettings.VMID.ToUpper().Split(new String[] { " BY " }, StringSplitOptions.RemoveEmptyEntries).Last();
                                    Runsettings.VMPWD = CommonClass.ChangeVMPassword(logonById, Using.getCurrentPassword(logonById), Using.getPreviousPassword(logonById));

                                    // try one login after password change
                                    Login(logonById, Runsettings.VMPWD);
                                    LogOffCMS();

                                    AddOrUpdateStageLog("Login", "Password changed for " + Runsettings.VMID, false);
                                }
                                catch (Exception changePasswordEx)
                                {
                                    AddOrUpdateStageLog("Login", "Password change failed for " + Runsettings.VMID, false);
                                    throw changePasswordEx;
                                }

                                /// and then retry 
                                Runsettings.VMID = Login(Runsettings.VMID, Runsettings.VMPWD);
                                IsLoggedon = true;
                                GetTempDisks();
                                //UpdateUsingFile();
                                AddOrUpdateStageLog("Login", "Successful", true);
                            }
                            else
                            {
                                IsLoggedon = false;
                                HandleError(ex.Message, ErrorTypes.NotifyandAbort, ErrorGroup.USER_ERROR);
                                //throw ex;
                                goto FINISH;
                            }
                        }
                        catch (System.Security.Authentication.AuthenticationException ex)
                        {/// handle failed logins here
                            AddOrUpdateStageLog("Login", "Unsuccessful", false);
                            IsLoggedon = false;
                            HandleError(ex.Message, ErrorTypes.NotifyandAbort, ErrorGroup.USER_ERROR);
                            //throw ex;
                            goto FINISH;
                        }
                        catch (MemberAccessException ex)
                        {
                            AddOrUpdateStageLog("Login", ex.Message, false);
                            HandleError(ex.Message, ErrorTypes.NotifyandAbort, ErrorGroup.USER_ERROR);
                            //throw ex;
                            goto FINISH;
                        }
                    }
                    if (StepstoPerform.EraseOldFiles)
                    {
                        EraseOldFiles();
                    }
                    ///////////////////////// Checks A disk Space and erase old files ///////////////////////////////
                    if (StepstoPerform.CheckSpace)
                        if (!CheckSpace())
                            goto FINISH;
                    UpdateUsingFile();
                    ///////////////////////// Creates a TPFSETUP file using Isetup based on the regression type
                    if (StepstoPerform.SetupCreate)
                    {
                        Runsettings.VIPS = ObsAllVIP.ToList();
                        AddOrUpdateStageLog("Create Setup", "Running...", true);
                        string error = CreateandTransferSetup(Runsettings, reg);
                        if (String.IsNullOrEmpty(error))
                        { //////////// Setup creation and transfer successful ////////////
                            AddOrUpdateStageLog(null, "Successful.", false);
                            //Send an Email
                            string emailsubject = "I will be using " + string.Concat(Runsettings.VIPS.Where(v => v.VPARS != "").Select(v => v.VPARS + ",")).TrimEnd(',')
                                + " " + string.Concat(Runsettings.VIPS.Where(v => v.QAT != "").Select(q => q.QAT + ",")).TrimEnd(',') + " for " + Runsettings.InstallDate + " install " + Runsettings.RegType + " Regression(" + Runsettings.RunNumber + ").";

                            HandleError(emailsubject, ErrorTypes.NotifyOnly, ErrorGroup.NO_ERROR, emailsubject, "QA-VIP-Support", false);
                        }
                        else
                        { ////////////// setup creation failed ////////////////
                            AddOrUpdateStageLog(null, "Unsuccessful.", false);
                            if (HandleError("Setup was not created properly." + error, ErrorTypes.NotifyandAbort, ErrorGroup.SETUP_CREATION_ERROR) == false)
                                goto FINISH;
                        }
                    }

                    if (!OverWriteVPARSNames())
                        goto FINISH;

                    if (StepstoPerform.SubmitSetup && !Runsettings.IsSkipSetup)
                        if (!SubmitAndTrackSetup(Runsettings))
                            goto FINISH;

                    if (StepstoPerform.EnvSetup)
                    {
                        if (!EnvironmentSetup())
                            goto FINISH;
                        GetTempDisks();
                    }

                    if (StepstoPerform.BucketRun)
                    {
                        if (Runsettings.RegType != "UNBALANCED")
                            ParsemSetup(Runsettings.RegType);

                        foreach (var item in Runsettings.Bucket.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                        {
                            if (Runsettings.RegType == "UNBALANCED")
                            {
                                if (item.Contains("MINI"))
                                {
                                    ParsemSetup("STIPD");
                                    //Comment out ZKSET STIPON
                                    //foreach (var vip in ObsAllVIP.Where(v => v.VPARS != "" && v.VPARS != null))
                                    //{
                                    //    reg.EnterCommand("PIPE LITERAL  " + vip.VPARS + " ==>ZKSET STIPON |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                                    //    reg.EnterCommand("PIPE CMS TPFOPR " + vip.VPARS + " ZKSET STIPON |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                                    //}
                                }
                                else if (item.Contains("BADD"))
                                    ParsemSetup("BADD");
                                else if (item.Contains("NCC"))
                                    ParsemSetup("ECIP");
                                else if (item.Contains("PROD"))
                                    ParsemSetup("PRODD");
                            }

                            if (Runsettings.RegType == "TOKEN")
                            {
                                if (!RunToken())
                                    goto FINISH;
                                else
                                    break;
                            }

                            //////////// TURN ON THE SWITCH BEFORE NCC BUCKET IN UNBALANCED REGRESSION /////////
                            if (item.Contains("NCC") && Runsettings.RegType.Equals("UNBALANCED", StringComparison.InvariantCultureIgnoreCase))
                            {
                                //Use ZUREP in 1st VIP
                                var vpars = Runsettings.VIPS.FirstOrDefault(v => !String.IsNullOrWhiteSpace(v.VPARS)).VPARS;
                                reg.EnterCommand("TPFOPR " + vpars + " ZUREP ZKSWT 03 MOD RTN-820521 P-NOW", 1);
                                reg.WaitforString("Ready", 5);
                                reg.EnterCommand("TPFOPR " + vpars + " ZUREP ZKSWT 03 ON RTN-820521", 1);
                                reg.WaitforString("Ready", 5);

                                //foreach (string vpars in Runsettings.VIPS.Where(v => !String.IsNullOrWhiteSpace(v.VPARS))
                                //                                                .Select(v => v.VPARS))
                                //{
                                //    //ZKSWT 03 MOD RTN-820521 P-NOW
                                //    //ZKSWT 03 ON RTN-820521
                                //    reg.EnterCommand("TPFOPR " + vpars + " ZKSWT 03 MOD RTN-820521 P-NOW", 1);
                                //    reg.WaitforString("Ready", 5);
                                //    reg.EnterCommand("TPFOPR " + vpars + " ZKSWT 03 ON RTN-820521", 1);
                                //    reg.WaitforString("Ready", 5);
                                //}
                            }

                            if (!RunBucket(item))
                                goto FINISH;//need to discuss 
                            //Remove ZKSET STIPON logic
                            //Do ZKSET STIPOFF after MINI bucket processing
                            //if (Runsettings.RegType == "UNBALANCED")
                            //{
                            //    if (item.Contains("MINI"))
                            //    {
                            //        foreach (var vip in ObsAllVIP.Where(v => v.VPARS != "" && v.VPARS != null))
                            //        {
                            //            reg.EnterCommand("PIPE LITERAL  " + vip.VPARS + " ==>ZKSET STIPOFF |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                            //            reg.EnterCommand("PIPE CMS TPFOPR " + vip.VPARS + " ZKSET STIPOFF |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                            //        }
                            //    }
                            //}
                        }
                        //Do ZKSET STIPOFF for STIPD after all bucket complete
                        //ZKSET STIPON logic removed
                        //if (Runsettings.RegType == "STIPD")
                        //{
                        //    foreach (var vip in ObsAllVIP.Where(v => v.VPARS != "" && v.VPARS != null))
                        //    {
                        //        reg.EnterCommand("PIPE LITERAL  " + vip.VPARS + " ==>ZKSET STIPOFF |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                        //        reg.EnterCommand("PIPE CMS TPFOPR " + vip.VPARS + " ZKSET STIPOFF |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                        //    }
                        //}
                    }
                    if (StepstoPerform.Aprod)
                        RunAPROD();

                    if (StepstoPerform.Advice)
                        if (!AdviceRetrieval())
                            goto FINISH;

                    if (StepstoPerform.TapeCut)
                        CutTapesForAllVIP(GetTapestoCut(Runsettings.RegType));

                    if (StepstoPerform.Compare)
                    {
                        if (Runsettings.RegType == "TOKEN")
                        {
                            reg.EnterCommand("PIPE < USERXML ECIP *|> USERXML ECIP A1");
                            if (!CompareResult("USERXML ECIP RECID (IR OS WR WO)"))
                                goto FINISH;
                        }
                        if (!CompareResult())
                            goto FINISH;
                    }
                    if (StepstoPerform.FileTransfer)
                        TransferFiles();
                    //Do Priliminary analysis before Preparing email
                    if (StepstoPerform.Prelim)
                        PerformPreliminaryAnalysis();

                    // remove the log file
                    if (App.debuggingFilePaths.ContainsKey(reg.screenshotfile))
                        App.debuggingFilePaths.Remove(reg.screenshotfile);

                    if (StepstoPerform.Mail)
                        MailGenerate();

                    if (StepstoPerform.LogOffAllVics)
                        LogOffAllVPARS(Runsettings.VIPS);

                    if (HSM_PRODD77 == "DETACHED")                                                                  //Saumen090116
                    {
                        //Saumen082916
                        if (Runsettings.RegType != "DRB")
                        {
                            //Saumen030317
                            //if (Runsettings.RegType == "DURBIN" || Runsettings.RegType == "ECIP" || Runsettings.RegType == "UNBALANCED" || Runsettings.RegType == "PRODD" || Runsettings.RegType == "TOKEN")
                            //{
                            //Saumen030317
                            ReserveHSM("9", "ATTACH");
                            //Saumen030317
                            //}
                            //else
                            //{
                            //    ReserveHSM("5", "ATTACH");
                            //}
                            //Saumen030317
                        }
                        //Saumen082916
                    }

                    //This is special case where we are not taking the current datetime for starttime
                    if (Application.Current != null)
                        Application.Current.Dispatcher.Invoke((Action)(() =>
                        {
                            _RegStages.Insert(0, new RegStage() { Stage = "Regression Completed", StartAt = _RegStages.Last().StartAt });
                            _RegStages.First().EndAt = DateTime.Now.ToString("MM/dd/yy HH:mm:ss");
                            UpdateStagestofile();
                        }));

                    RegressionSuccessful = true;
                    AddOrUpdateStageLog(null, "Done.", false);

                    ////////////////////// Log off and fire the Regression Completed Event //////////////////////
                    OnRegressionCompleted();
                }
                else
                {
                    HandleError("Cannot connect to session " + reg.SessionShortName, ErrorTypes.NotifyandAbort, ErrorGroup.SYSTEM_PROBLEM);
                    AddOrUpdateStageLog(null, "Unsuccessful.", false);
                }

            FINISH:
                IsIdle = true;
                finished = true;
            }
            catch (ThreadAbortException)
            {
                // System.IO.File.WriteAllText(Runsettings.CoderunServer + @"\unherr.stk", ex.StackTrace);
                //Save Whatever data you want to save. 
            }

            catch (Exception ex)
            {
                //Saumen012617 - removed stacktrace to get the whole exception information
                //System.IO.File.WriteAllText(Runsettings.CoderunServer + @"\unherr.dbg", ex.StackTrace);
                File.WriteAllText(Runsettings.CoderunServer + @"\unherr.dbg", ex.ToString());
                //Saumen012617
                HandleError("Unhandled error:" + ex.Message, ErrorTypes.NotifyandAbort, ErrorGroup.UNHANDLED_ERROR);
                if (!Runsettings.IsSchedulerRun)
                    MessageBox.Show("This is an unhandled error during regression.\n" + ex.Message, "Regression window-" + reg.SessionShortName);
            }
            finally
            {
                try
                {
                    // Store the screenshot file into coderun server
                    System.IO.File.Copy(reg.screenshotfile, System.IO.Path.Combine(Runsettings.CoderunServer, System.IO.Path.GetFileName(reg.screenshotfile)), true);
                    //System.IO.File.Delete(reg.screenshotfile);
                }
                catch (Exception) { }
                //Finishing Regression
                IsIdle = true;
                try
                {
                    TimerThread.Abort();
                }
                catch (Exception)
                {

                }
                RegressionThread = null;
                TimerThread = null;
                ButtonContent = "Start";

            }
            #endregion

        }
        /// <summary>
        /// specialized function for running token bucket
        /// </summary>
        private bool RunToken()
        {
            string[] Buck = Runsettings.Bucket.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            //reg.EnterCommand("ACCESS VM3:TESTCASE.VIPQAAUTOMATION X ( FORCERW", VMCommandTimeOut);
            reg.EnterCommand("ACCESS VM3:VIPQAAUT.VIPQAAUTOMATION X ( FORCERW", VMCommandTimeOut);//Saumen021417
            if (reg.WaitforString("Ready;", 5) == 0)
            {
                //return HandleError("No access to VM3:TESTCASE.VIPQAAUTOMATION.", ErrorTypes.NotifyandAbort, ErrorGroup.USER_ERROR);
                return HandleError("No access to VM3:VIPQAAUT.VIPQAAUTOMATION.", ErrorTypes.NotifyandAbort, ErrorGroup.USER_ERROR);//Saumen021417
            }
            ParsemSetup("ECIP");
            RunBucket("NCC  CASES X1");
            reg.EnterCommand("PIPE CMS EXEC NCCLOG NCC OUTPUT Z1", VMCommandTimeOut);
            ParsemSetup("TOKEN");
            RunBucket("CBPP  CASES Z1");
            reg.WaitforString("Ready", 600);
            reg.EnterCommand("PIPE < NCC ERRLOG Z1 |> " + Buck[0] + " ERRLOG Z1", VMCommandTimeOut);
            reg.EnterCommand("PIPE < CBPP ERRLOG Z1 |>> " + Buck[0] + " ERRLOG Z1", VMCommandTimeOut);
            String VICA = " ";
            String VICF = " ";
            foreach (VIP vip in Runsettings.VIPS)
            {
                if (vip.VIPNAME.Contains("A"))
                {
                    VICA = vip.VPARS;
                    reg.EnterCommand("ETC 6 " + vip.VPARS + " (" + Buck[0] + " (" + Buck[1], VMCommandTimeOut);
                    reg.WaitforString("Ready", 1000);
                    reg.EnterCommand("PIPE < TOKEN DATA Z1 |> PAN_TKN TABLE Z1", VMCommandTimeOut);
                    AddOrUpdateStageLog("Creating LCM Data File", "Running...", true);
                    reg.EnterCommand("ETC 4 " + vip.VPARS + " (" + Buck[0] + " (" + Buck[1], VMCommandTimeOut);
                    reg.WaitforString("Ready", 600);
                    AddOrUpdateStageLog(null, "Successful.", false);
                    AddOrUpdateStageLog("Creating LCM CASES File", "Running...", true);
                    reg.EnterCommand("ETC 5 " + vip.VPARS + " (" + Buck[0] + " (" + Buck[1], VMCommandTimeOut);
                    reg.WaitforString("Ready", 600);
                    AddOrUpdateStageLog(null, "Successful.", false);
                }
                if (vip.VIPNAME.Contains("F"))
                    VICF = vip.VPARS;
            }
            AddOrUpdateStageLog("Bulk File Processing", "Running...", true);
            // Bulk Token Update
            reg.EnterCommand("PIPE LITERAL FTPVIP Started with BLKTKNU STAGE Z1 |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            reg.EnterCommand("PIPE CMS FTPVIP " + VICF + " BLKTKNU STAGE Z1|>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            if (reg.WaitforString("Ready;", 40) > 0)
                reg.EnterCommand("PIPE LITERAL FTPVIP Successful. |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            else
                reg.EnterCommand("PIPE LITERAL FTPVIP Unsuccessful. |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            reg.Pause(100);
            reg.EnterCommand("SENDCMD " + VICF + " ZUBTU BULK STATUS (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
            if (reg.WaitforString("Total Updates:      0", 10) > 0)
                HandleError("FTPVIP - BLKTKNU is unsuccessful.", ErrorTypes.NotifyAndLog, ErrorGroup.FTP_ERROR);
            else
                AddOrUpdateStageLog(null, "FTPVIP - BLKTKNU Done.", false);
            // Bulk CardArt Metadata Update
            reg.EnterCommand("PIPE LITERAL FTPVIP Started with CRDART STAGE Z1 |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            reg.EnterCommand("PIPE CMS FTPVIP " + VICF + " CRDART STAGE Z1|>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            if (reg.WaitforString("Ready;", 40) > 0)
                reg.EnterCommand("PIPE LITERAL FTPVIP Successful. |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            else
                reg.EnterCommand("PIPE LITERAL FTPVIP Unsuccessful. |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            reg.Pause(100);
            reg.EnterCommand("SENDCMD " + VICF + " ZUBTU CART STATUS (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
            if (reg.WaitforString("Total Updates:      0", 10) > 0)
                HandleError("FTPVIP - CRDART is unsuccessful.", ErrorTypes.NotifyAndLog, ErrorGroup.FTP_ERROR);
            else
                AddOrUpdateStageLog(null, "FTPVIP - CRDART Done.", false);
            // Bulk PAN Replacement & Pan Expiry Update
            reg.EnterCommand("PIPE LITERAL FTPVIP Started with BULKPUPD STAGE Z1 |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            reg.EnterCommand("PIPE CMS FTPVIP " + VICF + " BULKPUPD STAGE Z1|>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            if (reg.WaitforString("Ready;", 40) > 0)
                reg.EnterCommand("PIPE LITERAL FTPVIP Successful. |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            else
                reg.EnterCommand("PIPE LITERAL FTPVIP Unsuccessful. |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            reg.Pause(100);
            reg.EnterCommand("SENDCMD " + VICF + " ZUBTU PUPD STATUS (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
            if (reg.WaitforString("Total Updates:      0", 10) > 0)
                HandleError("FTPVIP - BULKPUPD is unsuccessful.", ErrorTypes.NotifyAndLog, ErrorGroup.FTP_ERROR);
            else
                AddOrUpdateStageLog(null, "FTPVIP - BULKPUPD Done.", false);
            ///////////// CHECK DUMPS using UNIDUMPS//////////////////
            UNIDUMPS(String.Join(" ", Runsettings.VIPS
                                                    .Where(vic => !String.IsNullOrWhiteSpace(vic.VPARS))
                                                    .Select(vic => vic.VPARS).ToList()), "After PAN/CARDART/TOKEN BULK update"
                    );
            AddOrUpdateStageLog("Token Vault Alteration", "Running...", true);
            reg.EnterCommand("SENDVLC " + VICA + " CHGSTATE ZBURZ Z1", VMCommandTimeOut);
            reg.WaitforString("Ready", 600);
            foreach (VIP vip in Runsettings.VIPS)
            {
                reg.EnterCommand("TPFZMS " + vip.VPARS + " CHGVAULT " + vip.VPARS + " Z1(NODISPLAY", VMCommandTimeOut);
                reg.WaitforString("Ready", 180);
            }
            AddOrUpdateStageLog(null, "Done.", false);
            ParsemSetup("ECIP");
            RunBucket("LCM  CASES Z1");
            reg.EnterCommand("PIPE CMS EXEC NCCLOG LCM OUTPUT Z1", VMCommandTimeOut);
            reg.WaitforString("Ready", 600);
            reg.EnterCommand("PIPE Literal ------- LCM REPORT -------|>> NCC REPORT A1", VMCommandTimeOut);
            reg.EnterCommand("PIPE < LCM REPORT A1 |>> NCC REPORT A1", VMCommandTimeOut);
            reg.WaitforString("Ready", 5);
            reg.EnterCommand("PIPE Literal --------- LCM STATLOG ---------|>> NCC STATLOG Z1", VMCommandTimeOut);
            reg.EnterCommand("PIPE < LCM STATLOG Z1 |>> NCC STATLOG Z1", VMCommandTimeOut);
            reg.WaitforString("Ready", 5);
            CutTapesForAllVIP(GetTapestoCut("PRODD"));
            reg.EnterCommand("PIPE < TAPE LOG A1|> PRTAPE LOG A1", VMCommandTimeOut);
            AddOrUpdateStageLog("ACTXXXX ZBURZ", "Running...", true);
            reg.EnterCommand("SENDVLC " + VICA + " ACTXXXX ZBURZ Z1", VMCommandTimeOut);
            reg.WaitforString("Ready", 900);
            AddOrUpdateStageLog(null, "Successful.", false);
            ParsemSetup("PRODD");                                               // Changed to PRODD from PROD
            RunBucket("TKNREG AUTH X1");
            reg.EnterCommand("PIPE Literal --------- TOKEN AUTH REPORT ---------|>> NCC REPORT A1", VMCommandTimeOut);
            reg.EnterCommand("PIPE < TKNREG REPORT A1 |>> NCC REPORT A1", VMCommandTimeOut);
            reg.WaitforString("Ready", 5);
            reg.EnterCommand("PIPE Literal ----------- TOKEN AUTH STATLOG -----------|>> NCC STATLOG Z1", VMCommandTimeOut);
            reg.EnterCommand("PIPE < TKNREG STATLOG Z1 |>> NCC STATLOG Z1", VMCommandTimeOut);
            reg.WaitforString("Ready", 5);

            ///////////// For CBPP Authorization /////////////////////
            AddOrUpdateStageLog("CBPP Autorization", "Running...", true);
            reg.EnterCommand("ETC 2 " + VICA + " (" + Buck[0] + " (" + Buck[1], VMCommandTimeOut);
            if (reg.WaitforString("Ready", 60 * 60 * 3) == 0)
            {
                if (!HandleError("CBPP Authorization Still Running/Ready Not found -" + "ETC 2 " + VICA + " (" + Buck[0] + " (" + Buck[1], Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.ETC_ERROR))
                    return false;
            }
            AddOrUpdateStageLog(null, "Successful.", false);
            ///////////// CHECK DUMPS using UNIDUMPS//////////////////
            UNIDUMPS(String.Join(" ", Runsettings.VIPS
                                                    .Where(vic => !String.IsNullOrWhiteSpace(vic.VPARS))
                                                    .Select(vic => vic.VPARS).ToList()), "After HCE Authorization processing"
                    );

            ///////////// For COF/ECOM Authorization //////////////////
            AddOrUpdateStageLog("COF/ECOM Autorization", "Running...", true);
            ParsemSetup("TOKEN_AUTH");                                               
            RunBucket("TPWAUTH CASES X1");
            reg.EnterCommand("PIPE Literal --------- COF/ECOM AUTH REPORT ---------|>> NCC REPORT A1", VMCommandTimeOut);
            reg.EnterCommand("PIPE < TPWAUTH REPORT A1 |>> NCC REPORT A1", VMCommandTimeOut);
            reg.WaitforString("Ready", 5);
            reg.EnterCommand("PIPE Literal ----------- COF/ECOM STATLOG -----------|>> NCC STATLOG Z1", VMCommandTimeOut);
            reg.EnterCommand("PIPE < TPWAUTH STATLOG Z1 |>> NCC STATLOG Z1", VMCommandTimeOut);
            AddOrUpdateStageLog(null, "Successful.", false);

            ///////////// For QRC Authorization ///////////////////////
            AddOrUpdateStageLog("QRC Autorization", "Running...", true);
            reg.EnterCommand("ETC 8 " + VICA + " (" + Buck[0] + " (" + Buck[1], VMCommandTimeOut);
            if (reg.WaitforString("Ready", 60 * 60 * 3) == 0)
            {
                if (!HandleError("QRC Authorization Still Running/Ready Not found -" + "ETC 8 " + VICA + " (" + Buck[0] + " (" + Buck[1], Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.ETC_ERROR))
                    return false;
            }
            AddOrUpdateStageLog(null, "Successful.", false);
            ///////////// CHECK DUMPS using UNIDUMPS//////////////////
            UNIDUMPS(String.Join(" ", Runsettings.VIPS
                                                    .Where(vic => !String.IsNullOrWhiteSpace(vic.VPARS))
                                                    .Select(vic => vic.VPARS).ToList()), "After COF/ECOM/QRC Authorization processing"
                    );

            //string file_type = Runsettings.InstallDate.Replace("/", "").Substring(0, 4) + Runsettings.RegType.Substring(0, 2) + Runsettings.RunNumber.Replace("BASERUN", "BR").Replace("RUN", (Runsettings.SwitchActivationInfo != "N/A" && Runsettings.SwitchActivationInfo != null ? "S" : null));
            string file_type = Runsettings.InstallDate.Replace("/", "").Substring(0, 4) + Runsettings.RegType.Substring(0, 2) + Runsettings.RunNumber.Replace("RUN", null);//Saumen031317

            reg.EnterCommand("PIPE < NCC REPORT A1 |>> " + Buck[0] + " REPORT A1", VMCommandTimeOut);           // Accumulating all Report
            reg.EnterCommand("PIPE < NCC STATLOG Z1 |>> " + Buck[0] + " STATLOG Z1", VMCommandTimeOut);         // Accumulating all statlog
            /////////////  Renaming Token Files in SFS Directory ////////////
            reg.EnterCommand("RENAME BULKPUPD STAGE X1 BULKPUPD " + file_type + " X1", VMCommandTimeOut);
            reg.WaitforString("Ready", 30);
            reg.EnterCommand("RENAME CRDART STAGE X1 CRDART " + file_type + " X1", VMCommandTimeOut);
            reg.WaitforString("Ready", 30);
            reg.EnterCommand("RENAME BLKTKNU STAGE X1 BLKTKNU " + file_type + " X1", VMCommandTimeOut);
            reg.WaitforString("Ready", 30);
            reg.EnterCommand("RENAME QRCAUTH CASES X1 QRCAUTH " + file_type + " X1", VMCommandTimeOut);
            reg.WaitforString("Ready", 30);
            reg.EnterCommand("RENAME CALLIN HCE X1 CALLIN " + file_type + " X1", VMCommandTimeOut);
            reg.WaitforString("Ready", 30);
            reg.EnterCommand("RENAME CBPPAUTH CASES X1 CBPPAUTH " + file_type + " X1", VMCommandTimeOut);
            reg.WaitforString("Ready", 30);
            reg.EnterCommand("RENAME LCM CASES X1 LCM " + file_type + " X1", VMCommandTimeOut);
            reg.WaitforString("Ready", 30);

            return true;
        }

        /// <summary>
        /// Updates the Using.json file at "\\fileshareocw\viptestmbrsupapp\TestTools&Automation\Automation_Files\Using.json".
        /// This file contains the usage of all Prodd ids, QATs and Autoreg ids. 
        /// </summary>
        private void UpdateUsingFile()
        {
            if (!((App)App.Current).IsVIPTESTENGMember)
                return;
            //reg.EnterCommand("GET TESTCASE", 1);
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                reg.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            reg.EnterCommand("GET VIPQAAUT", 1);//Saumen021417
            reg.EnterCommand("USING AUTOREG", 1);
            //Ready; T=0.04/0.05 11:54:45
            reg.WaitForRegex(new Regex("Ready"), 20);

            string tmpFilePath = System.IO.Path.GetTempFileName();
            reg.ReceiveFile(tmpFilePath, "USAGE TEXT A1");

            Using UsingObj = new Using(tmpFilePath);
            UsingObj.StoreAsJSON();

            System.IO.File.Delete(tmpFilePath);
        }
        /// <summary>
        /// Gets a temporary Z disk, testcase id , TDATA and RBARIK6
        /// </summary>
        private void GetTempDisks()
        {
            //reg.EnterCommand("REIPL 96M", VMCommandTimeOut);
            reg.EnterCommand("DEF STOR 1T");
            reg.WaitforString("Ready", 5);
            Regex maxsizeregex = new Regex(@"maximum\s+\((?<MAX>\w+)\)");
            var max = reg.GetLines(5).FirstOrDefault(l => maxsizeregex.IsMatch(l));
            reg.EnterCommand("REIPL " + (max == null ? "96M" : maxsizeregex.Match(max).Groups["MAX"].Value), 1);
            reg.WaitforString("Ready;", 60);
            //reg.EnterCommand("GET RBARIK6", VMCommandTimeOut);  //added Rakesh. Will be Removed
            //reg.EnterCommand("GET TESTCASE", VMCommandTimeOut);
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                reg.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            reg.EnterCommand("GET VIPQAAUT", VMCommandTimeOut);//Saumen021417
            //if (Runsettings.RegType == "ECIP" || Runsettings.RegType == "UNBALANCED" || Runsettings.RegType == "TOKEN")//Saumen022717
                reg.EnterCommand("GETD TEMP 1080CYL Z", 2);
            //else//Saumen022717
            //    reg.EnterCommand("GETD TEMP 540CYL Z", 2);//Saumen022717
            reg.WaitforString("Ready;", 120);
            //reg.EnterCommand("ACCESS VM3:TESTCASE.VIPQAAUTOMATION X ( FORCERW", VMCommandTimeOut);
            //reg.EnterCommand("ACCESS VM3:TESTCASE.VIPQAAUTOMATION X ( FORCERO", VMCommandTimeOut);//Saumen020617 : added back commit 5f79cc2022a
            reg.EnterCommand("ACCESS VM3:VIPQAAUT.VIPQAAUTOMATION X ( FORCERO", VMCommandTimeOut);//Saumen021417
            if (reg.WaitforString("Ready;", 5) == 0 && ((App)App.Current).IsVIPTESTENGMember && Runsettings.IsRegularServerPath)
            {
                //throw new MemberAccessException("Required read access to VM3:TESTCASE.VIPQAAUTOMATION in not available.");
                throw new MemberAccessException("Required read access to VM3:VIPQAAUT.VIPQAAUTOMATION in not available.");//Saumen021417
            }
            reg.EnterCommand("VMLINK TDATA 291", 2);
            reg.EnterCommand("VMLINK TDATA 292", 2);
        }
        /// <summary>
        /// Fires the RegressionCompleted Event
        /// </summary>
        protected void OnRegressionCompleted()
        {
            if (this.RegressionCompleted != null)
                this.RegressionCompleted(this, EventArgs.Empty);
        }
        /// <summary>
        /// Logs of the logged in CMS by enetering "LOG"
        /// </summary>
        public void LogOffCMS()
        {
            // LOGGING OFF
            //reg.EnterCommand("LOGOFF", 3);                                                                          //Saumen082316
            //reg.WaitforString("z/VM ONLINE", 15);
            UpdateUsingFile();//Saumen020917
            reg.EnterCommand("LOGOFF", 1);
            reg.WaitforString("z/VM ONLINE", 30, false);
            reg.DisconnectSession();//Saumen020917
        }
        /// <summary>
        /// Logs of all the given VICs by using "TPFOPR <VPARS> ZCP LOG"
        /// </summary>
        /// <param name="VICs">List of all the VICs to log off</param>
        public void LogOffAllVPARS(IList<QACT_WPF.VIP> VICs)
        {
            AddOrUpdateStageLog("Log Off VICs", "Runnning...", true);

            foreach (VIP vic in VICs.Where(v => !String.IsNullOrWhiteSpace(v.VPARS)))
            {
                //Saumen031017
                reg.EnterCommand("TPFOPR " + vic.VPARS + " ZCYCL 1052", 2);
                reg.EnterCommand("TPFOPR " + vic.VPARS + " ZDSYS", 2);
                int max_try = 0;
                while (reg.WaitforString("IN 1052", 60) == 0 && max_try <= 5)
                {
                    reg.EnterCommand("TPFOPR " + vic.VPARS + " ZDSYS", 2);
                    max_try++;
                }
                //Saumen031017
                reg.EnterCommand("TPFOPR " + vic.VPARS + " ZCP LOG", 2);
                reg.WaitforString("not open (no longer open)", 20);
                reg.WaitforString("Ready", 60);
            }

            AddOrUpdateStageLog("Log Off VICs", "Successful.", false);
        }

        #region Regression Related Tasks
        /// <summary>
        /// Gets the VPARS details (i.e VICs and their corresponding VPARS) from the Setup File
        /// </summary>
        /// <returns>true indicates success and false indicates failure</returns>
        private bool OverWriteVPARSNames()
        {
            //Here Parse the Vpars names from the setup file itself.. we'll remove VPARS UI Later
            AddOrUpdateStageLog("Overwrite UI with VPARS IDs from setup file", "Running...", true);
            reg.EnterCommand("PIPE < " + Runsettings.SetupFile + " $TTVDATA A1 | XLATE UPPER | LOCATE /.USERIDS/ | NLOCATE /*H./ | CONSOLE ", 5);
            List<string> userids = new List<string>();
            userids = reg.GetLines(10).Where(l => l.Contains(".USERIDS ") && !l.Contains("PIPE"))
                .Select(l => "VIP" + l.Substring(l.IndexOf(".USERID") - 1).Replace(".USERIDS", "")).ToList();
            foreach (VIP vip in ObsAllVIP)
            {
                string vparsfromsetup = userids.FirstOrDefault(u => u.Contains(vip.VIPNAME));
                if (vparsfromsetup != null)
                {
                    //if (vip.VPARS.ToUpper().Trim() != vparsfromsetup.Substring(4).ToUpper().Trim())
                    //    HandleError("We have changed " + vip.VIPNAME + " VPARS to " + vparsfromsetup.Substring(4).ToUpper().Trim(), ErrorTypes.LogOnly);
                    vip.VPARS = vparsfromsetup.Substring(4).ToUpper().Trim();
                }
                else
                    vip.VPARS = String.Empty;
            }
            if (userids.Count() == 0)
            {
                HandleError("Please check the setup file.\nNo VPARS found from it.", ErrorTypes.NotifyandAbort, ErrorGroup.USER_ERROR);
                AddOrUpdateStageLog(null, "Unsuccessful.", false);
                return false;
            }
            //overwrite the settings file also.
            Runsettings.VIPS = ObsAllVIP.ToList();
            var tmp = Runsettings.VMPWD;
            Runsettings.VMPWD = Crypto.Encrypt(Runsettings.VMPWD, App.Passphrase);
            Runsettings.StoreAsJsonFile(Runsettings.CoderunServer + @"\RunSettings.json");
            Runsettings.VMPWD = tmp;
            AddOrUpdateStageLog(null, "Successful.", false);
            return true;

        }
        /// <summary>
        /// Reads the globals excel sheet and stores the global information in the RunSettings object. Global value for a particular global type is populated only when is is empty
        /// </summary>
        private void PopulateGlobals()
        {
            Excel.Application xlapp = null; Excel.Workbook xlworkbook; Excel.Worksheet xlsheet;
            try
            {
                AddOrUpdateStageLog("Populate globals from server", "Running...", true);
                xlapp = new Excel.Application();
                xlapp.DisplayAlerts = false;
                xlworkbook = xlapp.Workbooks.Open(CommonClass.GetQAGlobalFromSharepoint(), Type.Missing, true, true);
                xlsheet = xlworkbook.Worksheets[1]; ///Check the first Sheet
                int maxrow = xlsheet.UsedRange.Rows.Count;//Saumen020617 : added back commit c0145d16aac
                int row = 1;
                int loaddatecol = 0;
                //Saumen020617 : added back commit c0145d16aac
                //DateTime loaddate = DateTime.ParseExact(Runsettings.InstallDate, "MM/dd/yyyy", null);
                //string capturedate = DateTime.ParseExact(Runsettings.RegCapture, "MMdd", null).ToString("MM/dd");
                //while (row < 35 && !((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Contains(capturedate))
                DateTime loaddate = DateTime.Parse(Runsettings.InstallDate);
                var capturedate = DateTime.ParseExact(Runsettings.RegCapture, "MMdd", null);
                if (capturedate > DateTime.Now)
                {
                    capturedate = capturedate.AddYears(-1);
                }
                // string capturedate = DateTime.ParseExact(Runsettings.RegCapture, "MMdd", null).ToString("MM/dd");
                while (row < maxrow && !((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Contains(capturedate.ToString("MM/dd")))
                //Saumen020617
                row++;
                //if (row != 35)
                if (row != maxrow)//Saumen020617 : added back commit c0145d16aac
                {
                    for (int i = row + 1; i < row + 10; i++)
                    {
                        if (loaddatecol == 0)
                        {
                            //for (int col = 1; col < 20; col++)
                            for (int col = 1; col <= 20; col++)//Saumen020617 : added back commit c0145d16aac
                            {
                                //Saumen020617 : added back commit c0145d16aac
                                //string celltext = ((xlsheet.Cells[i, col] as Excel.Range).Text as string).ToUpper().Trim();
                                DateTime celldate;
                                string celltext = ((xlsheet.Cells[row + 1, col] as Excel.Range).Text as string).ToUpper();
                                //Saumen020617
                                if (celltext == "" || celltext == null || celltext.Contains("DATA"))
                                    continue;
                                //Saumen020617 : added back commit c0145d16aac
                                //else if (celltext.Contains("BASELINE"))
                                //{
                                //    loaddatecol = col;
                                //    continue;
                                //}
                                //Saumen020617
                                else
                                {
                                    //Saumen020617 : added back commit c0145d16aac
                                    //int mnthdiff = loaddate.Month - Convert.ToInt16(celltext.Split('/')[0]);
                                    //int yr = loaddate.Year;
                                    //if (mnthdiff <= -6)
                                    //    yr = yr - 1;

                                    //if ((DateTime.ParseExact(celltext + "/" + yr, "MM/dd/yyyy", null) <= loaddate))
                                    if (celltext.Contains("BASELINE"))
                                    {
                                        celldate = capturedate;
                                    }
                                    else
                                        celldate = (DateTime.ParseExact(celltext + "/" + capturedate.Year, "MM/dd/yyyy", null));
                                    if (celldate < capturedate)
                                    {
                                        celldate = celldate.AddYears(1);
                                    }
                                    if (celldate <= loaddate)
                                    //Saumen020617
                                    {
                                        loaddatecol = col;
                                    }
                                    else
                                        break;
                                }
                            }
                        }
                        if (loaddatecol == 0)
                            continue;
                        else
                        {

                            string celltext = ((xlsheet.Cells[i, 1] as Excel.Range).Text as string).ToUpper().Trim();
                            //if (celltext.Contains("FILES") || celltext.Contains("CONFIG"))
                            if (celltext.Contains("CONFIG") || celltext.Contains("RSI") || celltext.Contains("SUBSCRIBER") || celltext.Contains("MVV"))//Saumen020617 : added back commit c0145d16aac
                                break;
                            else if (celltext.Contains("GLOBALS") || celltext == "")
                                continue;
                            for (int col = loaddatecol; col >= 2; col--)
                            {
                                string celltext2 = ((xlsheet.Cells[i, col] as Excel.Range).Text as string).ToUpper().Trim();
                                if (celltext2 != "")
                                {
                                    switch (celltext)
                                    {
                                        case "DCS":
                                            if (_globalset.DCS == null || _globalset.DCS.Trim() == "")
                                                _globalset.DCS = celltext2;
                                            break;
                                        case "BMX":
                                            if (_globalset.BMX == null || _globalset.BMX.Trim() == "")
                                                _globalset.BMX = celltext2;
                                            break;
                                        case "NWK":
                                            if (_globalset.NWK == null || _globalset.NWK.Trim() == "")
                                                _globalset.NWK = celltext2;
                                            break;
                                        case "CFG":
                                            if (_globalset.CFG == null || _globalset.CFG.Trim() == "")
                                                _globalset.CFG = celltext2;
                                            break;
                                        case "FXT":
                                            if (_globalset.FXT == null || _globalset.FXT.Trim() == "")
                                                _globalset.FXT = celltext2;
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    AddOrUpdateStageLog(null, "Successful.", false);

                }
                else
                    throw new IndexOutOfRangeException();

            }
            catch (Exception)
            {
                AddOrUpdateStageLog(null, "Unsuccessful.", false);
                // throw;
            }
            finally
            {
                xlsheet = null;
                xlworkbook = null;
                if (xlapp != null)
                {
                    xlapp.Quit();
                    xlapp = null;
                }
            }
            Runsettings.Globals = new Dictionary<string, string>();
            Runsettings.Globals.Add("DCS", _globalset.DCS);
            Runsettings.Globals.Add("BMX", _globalset.BMX);
            Runsettings.Globals.Add("NWK", _globalset.NWK);
            Runsettings.Globals.Add("CFG", _globalset.CFG);
            Runsettings.Globals.Add("FXT", _globalset.FXT);
        }
        /// <summary>
        /// Validates the Baserun settings by De-serializing the RunSettings object in the Baserun folder
        /// </summary>
        /// <param name="BaserunInstallDate">A valid Baserun Install date from the De-serialized RunSettings object</param>
        /// <param name="BaserunSystemDate">A valid Baserun System date from the De-serialized RunSettings object</param>
        /// <returns></returns>
        private bool ValidateBaserun(out string BaserunInstallDate, out string BaserunSystemDate)
        {
            AddOrUpdateStageLog("Validating baserun compatibility.", "Running...", true);
            bool Result = true;
            BaserunInstallDate = null;
            BaserunSystemDate = null;
            RunSettings baserunsettings = CommonClass.LoadFromJSONFile<RunSettings>(Runsettings.BaserunServer + @"\RunSettings.json");
            baserunsettings.VMPWD = Crypto.Decrypt(baserunsettings.VMPWD, App.Passphrase);
            if (baserunsettings == null || baserunsettings.RegType == null || baserunsettings.InstallDate == null)
            {
                Result = HandleError("Invalid BaseRun settings.\n(We can still try to compare.)", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.USER_ERROR);
                if (Runsettings.IsSchedulerRun)
                    Runsettings.IsComparisonRequired = false;
            }
            else
            {
                BaserunInstallDate = baserunsettings.InstallDate;
                BaserunSystemDate = baserunsettings.SystemDate;
                if (baserunsettings.RegType != Runsettings.RegType)
                {
                    Result = HandleError("Two different types of runs are being compared.\r\n(We suggest to abort the run.)", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.USER_ERROR);
                    if (Runsettings.IsSchedulerRun)
                        Runsettings.IsComparisonRequired = false;
                }
                if (baserunsettings.RegCapture != Runsettings.RegCapture && Result)
                {
                    Result = HandleError("Two different captures are being compared.\r\n(We suggest to abort the run.)", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.USER_ERROR);
                    if (Runsettings.IsSchedulerRun)
                        Runsettings.IsComparisonRequired = false;
                }
//GGIRDHAR031717 - HotFix                if (baserunsettings.RunDate.AddDays(baserunsettings.TapeRetentionPeriod) <= Runsettings.RunDate && Result)
                if (baserunsettings.RunDate.AddDays(baserunsettings.TapeRetentionPeriod) < Runsettings.RunDate && Result)
                {
                    Result = HandleError("Baserun tapes may expire. Please Check.\r\n(We suggest to abort the run.)", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.USER_ERROR);
                    if (Runsettings.IsSchedulerRun)
                        Runsettings.IsComparisonRequired = false;
                }
                if (baserunsettings.SystemDate != Runsettings.SystemDate && Result && Runsettings.SwitchActivationInfo == "N/A")
                {
                    Result = HandleError("Two different system dates are being compared.\r\n(We can still try to compare.)", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.USER_ERROR);
                    if (Runsettings.IsSchedulerRun)
                        Runsettings.IsComparisonRequired = false;
                }

            }
            AddOrUpdateStageLog(null, "Done.", false);
            if (!Runsettings.IsComparisonRequired)
            {
                Runsettings.BaserunServer = "";
                HandleError("Performing a standalone run due to incompatible baserun.", ErrorTypes.NotifyAndLog, ErrorGroup.USER_ERROR);//Saumen021417
            }
            return Result;
        }
        #endregion

        #region Basic Regression Functions
        private bool Logon()
        {
            bool Result = false;
            string error = "";
            AddOrUpdateStageLog("Logon to " + Runsettings.VMID.ToUpper(), "Running...", true);

            if (reg.WaitforString("USERID   ===>", 30) == 0)
            {
                Result = HandleError("Login Error:Session is not in Logon Screen.", ErrorTypes.NotifyandAbort, ErrorGroup.USER_ERROR);
            }
            else
                if (reg.SetFieldValue("USERID   ===>", Runsettings.VMID) == 0 && reg.SetFieldValue("PASSWORD ===>", Runsettings.VMPWD) == 0)
            {
                reg.SendText(Keys3270.Enter);

                if (reg.WaitforString("Ready;", 30, RegressionErrors.LogonErrors, out error) == 1)
                {
                    if (error == "RECONNECTED AT")
                    {
                        reg.SendText(Keys3270.PA1);
                        reg.SendText("I CMS" + Keys3270.Enter);
                        reg.Pause(3);
                        reg.SendText(Keys3270.Enter);
                        if (reg.WaitforString("Ready;", 10) != 0)
                            Result = true;
                    }
                    else if (error == "news")
                    {
                        reg.SendText(Keys3270.PF3);
                        if (reg.WaitforString("Ready;", 10) != 0)
                            Result = true;
                    }
                    else
                        Result = HandleError("Login Error:" + error, ErrorTypes.NotifyandAbort, ErrorGroup.USER_ERROR);
                }
                else
                    Result = true;
            }
            if (Result)
                AddOrUpdateStageLog(null, "Successful.", false);
            else
                AddOrUpdateStageLog(null, "Unsuccessful.", false);
            return Result;

        }

        /// <summary>
        /// Logs in by using the specified string in VMid and also updates the login string aptly
        /// </summary>
        /// <param name="VMId">Logon String</param>
        /// <param name="password">Password</param>
        /// <returns>true on Success and false on failure</returns>
        private string Login(string VMId, string password)
        {
            ////////////////////////////////////////////////////////////////////////////////////////////////////
            ///////////////////// Step 1. ENTER credentials ////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////
            if (reg.WaitforString("COMMAND  ===>", 30) == 0)
            {
                reg.DisconnectSession();
                reg.ConnectSession();
            }

            reg.EnterCommand("LOGON " + VMId);
            //reg.SendText(Keys3270.Enter);
            reg.EnterCommand(password, 1, false, true); // do not save password

            ///////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////// Step 2. Check the screen for successful login //////////////////////////
            ///////////////////////////////////////////////////////////////////////////////////////////////
            Match loginMatch = reg.WaitForRegex(new Regex(@"(?<LoginSuccess>(\bReady\b)|(\bLOGON\s+AT\s+\b))|(?<Reconnected>\bRECONNECTED\s+AT\b)|(?<IncorrectPassword>\bLOGON\s+unsuccessful--incorrect\s+password\b)"), 60);

            if (loginMatch.Groups["LoginSuccess"].Success)
            {////////////// Login Success ///////////////

                reg.EnterCommand("ID", 1);
                return VMId.ToUpper().Split(new String[] { " BY " }, StringSplitOptions.RemoveEmptyEntries).First();

            }
            else if (loginMatch.Groups["Reconnected"].Success)
            {/////////////// RECONNECTED AT //////////////////

                // reg.SendText(Keys3270.PA1); I CMS is causing problems
                reg.SendText("b" + Keys3270.Enter);
                reg.Pause(3);
                reg.SendText("b" + Keys3270.Enter);

                if (reg.WaitforString("Ready;", 20) == 0)
                    throw new System.Security.Authentication.AuthenticationException("VM reconnected but Ready; screen not found : Login for " + VMId);
                else
                    return VMId.ToUpper().Split(new String[] { " BY " }, StringSplitOptions.RemoveEmptyEntries).First();
            }
            else if (loginMatch.Groups["IncorrectPassword"].Success)
            {///////////// Incorrect Password //////////////

                throw new System.Security.Authentication.InvalidCredentialException("Incorrect password for " + VMId + " : " + loginMatch.Groups["IncorrectPassword"].Value);
            }
            else
            {///////////// Login failed /////////////////////
                throw new System.Security.Authentication.AuthenticationException("Login failed for " + VMId + " : " + loginMatch.Groups[0].Value);
            }
        }

        /// <summary>
        /// Create a TPFSETUP file according to the Regression type and Installdate.
        /// Required resources (PRODD ids and QATs) are obtained from GetPRODDandQAT() 
        /// This function internally calls ISetup.
        /// </summary>
        /// <returns>null on success or an error string on failure</returns>
        public static string CreateandTransferSetup(RunSettings runSett, HLLAPI reg)
        {
            //reg.EnterCommand("GET TESTCASE", VMCommandTimeOut);
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                reg.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            reg.EnterCommand("GET VIPQAAUT", VMCommandTimeOut);//Saumen021417
            string error = null;
            var oldcmdlineargs = App.CMDLINEARGS;
            string prodqat = GetPRODDandQAT(runSett, reg);
            if (!RegressionErrors.USING_ERRORS.Any(e => e == prodqat))
            {
                //Saumen031317
                string cmdlineargs = null;
                if (runSett.BaserunInstallDate != null)
                {
                    cmdlineargs =
                        "ISETUP USESERV NOCLICK NOEDIT CMS=" + runSett.VMID + " PWD=" + runSett.VMPWD +
                        " SYS=" + runSett.InstallDate.Substring(0, 5) + " RUN=" + runSett.RegType + (runSett.SwitchActivationInfo != "N/A" && runSett.SwitchActivationInfo != null ? ",SA" : null) +
                        " FILE=" + runSett.SetupFile + " GLB=" + DateTime.ParseExact(runSett.RegCapture, "MMdd", null).ToString("MM/dd")
                        + prodqat + " BASESYS=" + runSett.BaserunInstallDate.Substring(0, 5);//Saumen030917
                }
                else
                {
                    cmdlineargs =
                        "ISETUP USESERV NOCLICK NOEDIT CMS=" + runSett.VMID + " PWD=" + runSett.VMPWD +
                        " SYS=" + runSett.InstallDate.Substring(0, 5) + " RUN=" + runSett.RegType + (runSett.SwitchActivationInfo != "N/A" && runSett.SwitchActivationInfo != null ? ",SA" : null) +
                        " FILE=" + runSett.SetupFile + " GLB=" + DateTime.ParseExact(runSett.RegCapture, "MMdd", null).ToString("MM/dd")
                        + prodqat;//Saumen030917
                }
                //Saumen031317
                App.CMDLINEARGS = cmdlineargs.Split(' ').ToList();//("ISETUP SYS=BASEZ USESERV NOCLICK GLB=10/27 NOEDIT VIPB=PRODD2X,,PROD FILE=TESTFILE RUN=PRODD " + "CMS=" + runSett.VMID + " PWD=" + runSett.VMPWD).Split(' ');
                iSetup isetup = null;
                //Copy the TSU from server to regression folder
                System.IO.File.Copy(App.TSUFileServer, System.IO.Path.Combine(runSett.CoderunServer, "TSU_Regression.txt"), true);
                if (Application.Current != null)
                    Application.Current.Dispatcher.Invoke((Action)(() =>
                    {
                        isetup = new iSetup(getlist: true);
                    }));
                for (int i = 0; i < 10; i++)
                {
                    Thread.Sleep(500);
                    if ((Application.Current as App).Status.Contains("File List returned to caller.") || (isetup.CurrentError != null))
                        break;
                    if (i == 4)
                    {
                        isetup.CurrentError = "Timed out.";
                    }
                }
                (Application.Current as App).Status = "Ready";
                if (!string.IsNullOrWhiteSpace(isetup.CurrentError))
                    error = isetup.CurrentError;
                else
                {
                    foreach (var item in isetup.FilestoTransfer)
                    {
                        reg.EnterCommand("ERASE " + item.Replace(".", " ") + " A1", 1);
                        reg.SendFile(App.LocalSetupStoreFolder + "\\" + item, item.Replace(".", " "));
                        // Store the setup files in Regression folder
                        System.IO.File.Copy(System.IO.Path.Combine(App.LocalSetupStoreFolder, item), System.IO.Path.Combine(runSett.CoderunServer, item), true);
                    }
                    ////Send Email
                    //string emailsubject = "I will be using " + string.Concat(runSett.VIPS.Where(v => v.VPARS != "").Select(v => v.VPARS + ",")).TrimEnd(',')
                    //    + " " + string.Concat(runSett.VIPS.Where(v => v.QAT != "").Select(q => q.QAT + ",")).TrimEnd(',') + " for " + runSett.InstallDate + " install " + runSett.RegType + " Regression(" + runSett.RunNumber + ").";
                    //HandleError(emailsubject, ErrorTypes.NotifyOnly, emailsubject, "QA-VIP-Support", false);
                }
                App.CMDLINEARGS = oldcmdlineargs;
                isetup = null;
            }
            else
            {
                error = RegressionErrors.USING_ERRORS.First(e => e == prodqat);
            }
            //if (!Result)
            //{
            //    AddOrUpdateStageLog(null, "Unsuccessful.", false);
            //    Result = HandleError("Setup was not created properly.\n"+error, ErrorTypes.NotifyandWait);
            //}
            //else
            //    AddOrUpdateStageLog(null, "Successful.", false);
            return error;
        }
        /// <summary>
        /// Gets the available and required resources (PRODD ids and QATs) based on the Regression type for setup file creation. 
        /// </summary>
        /// <returns> A string with VICs and their assigned resources (e.g. VIPA=PRODD11,01,PROD0804 VIPB=PRODD12,02,PROD0804 VIPC=PRODD13,03,PROD0804  etc). This string is comapatible with Isetup's command line args</returns>
        public static string GetPRODDandQAT(RunSettings runSett, HLLAPI reg)
        {
            //Saumen021417 - stopped using QAT for regressions
            //bool IsWithDCSandBMX = false;
            //try
            //{
            //    //First read the TSU and determine is there are Both DCS and BMX globals to load
            //    var tsu = File.ReadAllLines(App.TSUFileServer);
            //    var thissystemTSU = tsu.Select(l => l.ToUpper()).SkipWhile
            //        (l => !(l.Contains(runSett.InstallDate.Substring(0, 5)) && l.ToUpper().Contains("Z11X") && l.ToUpper().Contains("A/B/C") && l.ToUpper().Contains("INSTALL")))
            //        .TakeWhile(l => !l.Contains("ENTER ZKSET APSD1F"));
            //    if (thissystemTSU.Where(t => (t.Contains("APPLY DCS:") || t.Contains("APPLY BMX:")) && t.Replace("/", null).Contains(runSett.RegCapture + " CAPTURE")).Count() >= 2)
            //    {
            //        IsWithDCSandBMX = true;
            //    }

            //}
            //catch (Exception)
            //{
            //}
            //Saumen021417


            //
            string Result = null, zburzs = null;
            List<string> response = new List<string>();

            //Saumen021417
            //if (runSett.RegType.Equals("LOAD_NIGHT", StringComparison.InvariantCultureIgnoreCase))
            //{// create a 5 VIP setup with 5 large QATs only

            //    reg.EnterCommand("USING 5VPARS", 2);    // get VPARS
            //    response.AddRange(
            //            reg.GetLines(20)
            //                    .Where(l => !String.IsNullOrWhiteSpace(l) && !l.Contains("Ready;") && !l.Contains("AVAILABLE") && !l.Contains("Not available"))
            //                    .ToList()
            //        );

            //    reg.EnterCommand("USING 5LQAT", 2);    // now get LQATS
            //    response.AddRange(
            //            reg.GetLines(20)
            //                    .Where(l => !String.IsNullOrWhiteSpace(l) && !l.Contains("Ready;") && !l.Contains("AVAILABLE") && !l.Contains("Not available"))
            //                    .ToList()
            //        );
            //}
            //else if (runSett.RegType.Equals("UNBALANCED", StringComparison.InvariantCultureIgnoreCase))
            //{
            //    throw new NotImplementedException("Automated setup for Unbalanced run is not supported yet!");
            //}
            ////use 5 QATs when There are both DCS and BMX globals to load
            //else if (IsWithDCSandBMX)
            //{
            //    reg.EnterCommand("USING 5VPARS 5QAT", 2);
            //    response = reg.GetLines(10).Where(l => l.Trim() != "" && !l.Contains("Ready;") && !l.Contains("AVAILABLE") && !l.Contains("Not available")).ToList();
            //}
            //else if (runSett.RegType == "DRB" || runSett.RegType.Equals("PRODD", StringComparison.InvariantCultureIgnoreCase))  // Attach QAT in VIC B for PRODD runs also
            //{
            //    reg.EnterCommand("USING 5VPARS 1QAT", 2);
            //    response = reg.GetLines(10).Where(l => l.Trim() != "" && !l.Contains("Ready;") && !l.Contains("AVAILABLE") && !l.Contains("Not available")).ToList();
            //}
            //else if (runSett.RegType == "ECIP" || runSett.RegType.Equals("TOKEN", StringComparison.InvariantCultureIgnoreCase))
            //{
            //    reg.EnterCommand("USING 5VPARS 4QAT", 2);
            //    response = reg.GetLines(10).Where(l => l.Trim() != "" && !l.Contains("Ready;") && !l.Contains("AVAILABLE") && !l.Contains("Not available")).ToList();
            //}
            //else
            //{
            reg.EnterCommand("USING 5VPARS", 2);
            if (reg.WaitforString("Ready;", 10) != 0)//Saumen030717
            {
                response = reg.GetLines(10).Where(l => l.Trim() != "" && !l.Contains("Ready;") && !l.Contains("AVAILABLE") && !l.Contains("Not available")).ToList();
            }
            //}
            //Saumen021417

            string error = "";
            if (reg.WaitforString("Waiting for errors...", 5, RegressionErrors.USING_ERRORS, out error) == 1)
            {
                if (error != "")
                {
                    return error;
                }

            }
            //Parse PRODD Ids here from the screen
            //var response = reg.GetLines(10).Where(l => l.Trim() != "" && !l.Contains("Ready;") && !l.Contains("AVAILABLE") && !l.Contains("Not available"));
            var proddline = response.FirstOrDefault(l => l.Contains("PRODD"));
            if (proddline != null)
            {
                var proddlist = proddline.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                if (proddlist.Count() == 1)
                {
                    runSett.VIPS.First(v => v.VIPNAME.Contains("B")).VPARS = proddlist[0];
                }
                else if (proddlist.Count() == 5)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        runSett.VIPS[i].VPARS = proddlist[i];
                    }
                }
            }
            var qatline = response.FirstOrDefault(l => l.Contains("QAT"));
            List<string> qatlist = new List<string>();
            if (qatline != null)
            {
                qatlist = qatline.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).ToList();
                if (qatlist.Count() == 1)
                {
                    runSett.VIPS.First(v => v.VIPNAME.Contains("B")).QAT = qatlist[0];
                }
                else if (qatlist.Count() == 4)
                {
                    qatlist.Insert(3, ""); //Insert a blank QAT for VIP E
                    for (int i = 0; i < 5; i++)
                    {
                        runSett.VIPS[i].QAT = qatlist[i];

                    }
                }
                else if (qatlist.Count() == 5)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        runSett.VIPS[i].QAT = qatlist[i];
                    }
                }
            }

            //var x = runSett.Bucket.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(b => b.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[0] + ",");
            zburzs = string.Concat(
                runSett.Bucket.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(b => b.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[0].Replace("1VIP", "SOAP") + ",").Distinct())
                .TrimEnd(',');
            foreach (var vip in runSett.VIPS.Where(v => !String.IsNullOrWhiteSpace(v.VPARS)))
            {
                string qat = "";
                if (qatlist.Count == 1)
                    qat = vip.VIPNAME.Contains("B") ? qatlist[0] : "";
                else if (qatlist.Count == 5)
                    qat = qatlist[runSett.VIPS.IndexOf(vip)];

                //if (vip.VPARS != "")
                Result += " " + vip.VIPNAME + "=" + vip.VPARS + "," + qat.Replace("QAT", "") + "," + zburzs + ",PCR9371I";
            }

            return Result;
        }

        /// <summary>
        /// Submits a TPFSETUP file and tracks the progress of the submitted job
        /// </summary>
        /// <param name="sett">RunSettings object</param>
        /// <param name="forcefully_Logoff">on true forecefully logs off the VPARS in the setup file</param>
        /// <param name="jobSchedulingAttempts">number of times to check for job id in tpf jobs screen</param>
        /// <param name="jobCompletionTime">minutes to wait for IPLing to complete</param>
        /// <returns>true on success else false on failure</returns>
        private bool SubmitAndTrackSetup(RunSettings sett, bool forcefully_Logoff = false, int jobSchedulingAttempts = 15, int jobCompletionTime = 2 * 60 * 60)
        {
            if (sett.IsSkipSetup)
                return true;

            string regexForDateTime = @"[0-1][0-9][./][0-3][0-9][./][0-9]{2}\s[0-2][0-9]\:[0-5][0-9]\:[0-5][0-9]";

            string regexForJobId = @"JOB[0-9]+";

            string regexForVMId = @"\w{3,9}";

            AddOrUpdateStageLog("Submit Setup:" + sett.SetupFile.ToUpper() + " $TTVDATA", "Running...", true);      //Saumen082516

            Regex logonByRegex = new Regex(@"\s*(?<AutoregId>\b\w+\b)(\s+BY\s+)?(?<LoginId>\b\w+\b)?\s*", RegexOptions.IgnoreCase);
            sett.VMID = logonByRegex.Match(sett.VMID).Groups["AutoregId"].Value;
            //reg.EnterCommand("CP SET MSG OFF", 1);//Saumen031517
            //////////////////////////// Try Submitting the setup //////////////////////////////
            List<string> screen = new List<string>();
            bool Retry = false;
            DateTime ScheduledJobDateTime = new DateTime();
            do
            {
                /////////////////////////////////////// SET VTOD DATE ////////////////////////////////////
                reg.EnterCommand("SET VTOD DATE " + sett.SystemDate + " TIME 10:52:00", VMCommandTimeOut);
                reg.EnterCommand("I CMS", VMCommandTimeOut);
                reg.SendText(Keys3270.Enter);
                reg.WaitforString("Ready;", 2);
                //reg.EnterCommand("GET TESTCASE", VMCommandTimeOut);
                //GGIRDHAR030717 - Test Framework Enhancement
                if (InputFile.TestRun)
                {
                    reg.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
                }
                //GGIRDHAR030717 - Test Framework Enhancement
                reg.EnterCommand("GET VIPQAAUT", VMCommandTimeOut);//Saumen021417
                reg.EnterCommand("ERASE TESTKEYS CONTROL A1", VMCommandTimeOut);
                //////////////////////// Submit setup ////////////////////////
                reg.WaitforString("Ready", 2);
                //Saumen032817
                reg.EnterCommand("TPFSETUP " + sett.SetupFile + " $TTVDATA A1 ( SUBMIT", 2);
                int loopcount = 0;
                while (reg.WaitforString("Ready", 10 * 60) == 0)//Saumen032917
                {
                    loopcount++;
                    reg.EnterCommand("B", 2);
                    if (loopcount >= 300)
                    {
                        HandleError("Job file NOT submitted properly", ErrorTypes.NotifyandAbort, ErrorGroup.TPFSETUP_ERROR);//Saumen031517
                    }
                }
                loopcount = 0;
                //following line is creating problems when the setup file contains too many zburz to fit in one single page.
                //reg.WaitforString("Ready", 60);
                //// Now check the screen /////
                //screen.Clear();
                //int loopcount = 0;
                //do
                //{
                //    loopcount++;
                //    reg.Pause(1);
                screen.AddRange(reg.GetLines(99));//Saumen032917
                //    reg.SendText(Keys3270.Clear);
                //    if (loopcount == 100)
                //    {
                //        throw new InternalBufferOverflowException("Possible infinite looping..Contact developer immediately");
                //    }
                //} while (!screen.Any(ln => ln.Contains("Ready")));
                //loopcount = 0;
                //Saumen032817
                screen.RemoveAll(ln => ln.Contains("* MSG FROM") || ln.Contains("RDR FILE") || ln.Contains("MORE...") || ln.Contains("HOLDING") || string.IsNullOrWhiteSpace(ln.Trim()));          // remove improper lines

                // Job file submitted                                                   
                // OR PRODD18 PRODD48 PRODD51 Not logged off
                string lineOfInterest = screen[(screen.LastIndexOf(screen.Last(ln => !String.IsNullOrWhiteSpace(ln) && ln.Contains("Ready"))/*index of the last line with Ready*/ ) - 1)];

                if (lineOfInterest.Contains("Job file submitted"))
                {
                    AddOrUpdateStageLog(null, lineOfInterest.Trim(), false);                                        //Saumen082516

                    /*File TTECH VPARSREQ A1 sent to TTECHTSM at RSVM3 on 03/24/16 10:47:22*/
                    string lineOfJob = screen[(screen.LastIndexOf(screen.Last(ln => !String.IsNullOrWhiteSpace(ln) && ln.Contains("Ready"))/*index of the last line with Ready*/ ) - 2)];

                    Regex regexForJobLine = new Regex("\bFile\b[w ]+\bsent\bto\b[wd ]+\bon\b" + regexForDateTime, RegexOptions.IgnoreCase);

                    //string lineOfJob = screen.SingleOrDefault(ln => regexForJobLine.IsMatch(ln));

                    if (lineOfJob != null && Regex.Match(lineOfJob, regexForDateTime).Success)
                    {
                        ScheduledJobDateTime = DateTime.ParseExact(Regex.Match(lineOfJob, regexForDateTime).Value, @"MM/dd/yy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                        Retry = false;
                    }
                    else
                        Retry = true;
                }
                else if (lineOfInterest.Contains("Not logged off") && forcefully_Logoff)
                {
                    // log off vpars
                    AddOrUpdateStageLog(null, "Logging of " + lineOfInterest.Replace("Not logged off", ""), false);

                    foreach (string vpars in lineOfInterest.Replace("Not logged off", "").Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        //Saumen031017
                        reg.EnterCommand("TPFOPR " + vpars + " ZCYCL 1052", 2);
                        reg.EnterCommand("TPFOPR " + vpars + " ZDSYS", 2);
                        int max_try = 0;
                        while (reg.WaitforString("IN 1052", 60) == 0 && max_try <= 5)
                        {
                            reg.EnterCommand("TPFOPR " + vpars + " ZDSYS", 2);
                            max_try++;
                        }
                        //Saumen031017
                        reg.EnterCommand("TPFOPR " + vpars + " ZCP LOG", 1);
                        reg.WaitforString("not open (no longer open)", 60);
                        reg.WaitforString("Ready", 60);
                    }
                    Retry = true;
                }
                else
                {
                    AddOrUpdateStageLog(null, lineOfInterest.Trim(), false);                                        //Saumen082516
                    //Retry = HandleError(lineOfInterest.Trim() + "\nYou can fix it and retry by pressing yes", ErrorTypes.NotifyandWait, ErrorGroup.TPFSETUP_ERROR);
                    Retry = HandleError(lineOfInterest.Trim() + "\nYou can fix it and retry by pressing yes", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.TPFSETUP_ERROR);
                    if (Retry == false)
                        return false;
                }

            } while (Retry);

            ///////////////////////////////////////// Get JOB ID ///////////////////////////////////////////////////
            string job_id = null; // to find
            //reg.EnterCommand("TPFJOBS", 1);
            //reg.WaitforString("TPFJOBS: Jobs scheduled on", 20);
            //// try with an interval of 60 seconds
            for (int i = 0; i < jobSchedulingAttempts && String.IsNullOrWhiteSpace(job_id); i++)
            {
                screen.Clear();

                //////////////////// Method 1 ////////////////////
                //Saumen032817
                reg.EnterCommand("pipe CMS TPFJOBS ( TYPE | LOCATE /" + sett.VMID + "/ | CONSOLE ", 2);
                int loopcount = 0;
                while (reg.WaitforString("Ready", 10 * 60) == 0)//Saumen032917
                {
                    loopcount++;
                    reg.EnterCommand("pipe CMS TPFJOBS ( TYPE | LOCATE /" + sett.VMID + "/ | CONSOLE ", 2);
                    if (loopcount >= 300)
                    {
                        HandleError("Unable to get JOb id from TPFJOBS", ErrorTypes.NotifyandAbort, ErrorGroup.TPFSETUP_ERROR);//Saumen031517
                    }
                }
                loopcount = 0;
                //int loopcount = 0;
                //do
                //{
                //    loopcount++;
                //    reg.Pause(1);
                screen.AddRange(reg.GetLines(99));//Saumen032917
                //    reg.SendText(Keys3270.Clear);
                //    if (loopcount == 100)
                //    {
                //        //throw new InternalBufferOverflowException("Possible infinite looping..Contact developer immediately");
                //        HandleError("Unable to get JOb id from TPFJOBS", ErrorTypes.NotifyandAbort, ErrorGroup.TPFSETUP_ERROR);//Saumen031517
                //    }
                //}
                //while (!screen.Any(ln => !String.IsNullOrWhiteSpace(ln) && ln.Contains("Ready")));
                //Saumen032817
                //////////////////////////////////////////////////

                ////////////////////// Method 2 ////////////////////
                //reg.SendText(Keys3270.Enter);
                //reg.WaitforString("TPFJOBS: Jobs scheduled on", 20);
                //screen.AddRange(reg.GetLines(99));
                ////////////////////////////////////////////////////

                string regexForJobLine = "\\s*" + regexForDateTime + "\\s" + regexForJobId + "\\s" + regexForVMId + "\\s";

                string jobLine = screen.Where(ln => Regex.Match(ln, regexForJobLine, RegexOptions.IgnoreCase).Success)
                                           .Select(ln => Regex.Match(ln, regexForJobLine, RegexOptions.IgnoreCase).Value)
                                           .SingleOrDefault(jobInfo => jobInfo.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[3].Equals(sett.VMID, StringComparison.InvariantCultureIgnoreCase)           // SAME vm ID
                                                             && DateTime.ParseExact(Regex.Match(jobInfo, regexForDateTime, RegexOptions.IgnoreCase).Value.Replace('.', '/'), @"MM/dd/yy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) >= ScheduledJobDateTime);    // job after the scheduled datetime

                job_id = jobLine != null ? Regex.Match(jobLine, regexForJobId, RegexOptions.IgnoreCase).Value : null;

                /// Take approx Date time in case of failure
                if (String.IsNullOrWhiteSpace(job_id) && i > 3)
                {
                    string approxJobLine = screen
                                                .Where(ln => Regex.Match(ln, regexForJobLine, RegexOptions.IgnoreCase).Success)
                                                .Select(ln => Regex.Match(ln, regexForJobLine, RegexOptions.IgnoreCase).Value)
                                                .OrderByDescending(jobInfo => DateTime.ParseExact(Regex.Match(jobInfo, regexForDateTime, RegexOptions.IgnoreCase).Value.Replace('.', '/'), @"MM/dd/yy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture))
                                                .FirstOrDefault(jobInfo => jobInfo.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[3].Equals(sett.VMID, StringComparison.InvariantCultureIgnoreCase)           // SAME vm ID
                                                                 && (DateTime.ParseExact(Regex.Match(jobInfo, regexForDateTime, RegexOptions.IgnoreCase).Value.Replace('.', '/'), @"MM/dd/yy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) - ScheduledJobDateTime).TotalSeconds <= 5.0d);

                    job_id = approxJobLine != null ? Regex.Match(approxJobLine, regexForJobId, RegexOptions.IgnoreCase).Value : null;
                }

                reg.Pause(60);
            }

            // Everything to get the job id has failed here
            if (String.IsNullOrWhiteSpace(job_id))
            {
                AddOrUpdateStageLog(null, "Unable to get Job id", false);

                return HandleError("Unable to get JOb id from TPFJOBS", ErrorTypes.NotifyandAbort, ErrorGroup.TPFSETUP_ERROR);// jobSchedulingAttempts == 0 ? false : SubmitAndTrackSetup(sett, forcefully_Logoff, jobSchedulingAttempts / 2, jobCompletionTime);
            }

            //reg.SendText(Keys3270.PF3);
            //reg.WaitforString("Ready", 20);
            //////////////////////// keep querying the job id //////////////////////
            IDictionary<string, string> tpfJobsData = new Dictionary<string, string>();
            for (int i = 0; i < jobCompletionTime / 60; i++)
            {
                screen.Clear();
                reg.EnterCommand("TPFJOBS * " + job_id + " " + sett.VMID + " ( JOBSTAT", VMCommandTimeOut);
                reg.WaitforString("Ready", 5);
                screen.AddRange(reg.GetLines(99));

                screen.RemoveAll(ln => ln.Contains("* MSG FROM") || ln.Contains("RDR FILE") || ln.Contains("Ready") || ln.Contains("TPFJOBS"));          // remove improper lines

                tpfJobsData.Clear();
                tpfJobsData = screen.Where(ln => !String.IsNullOrWhiteSpace(ln) && ln.Split(':').Length > 1)
                                                                 .ToDictionary(
                                                                 ln => ln.Split(new char[] { ':' }, 2, StringSplitOptions.RemoveEmptyEntries)[0].Trim().ToUpper(),
                                                                 ln => ln.Split(new char[] { ':' }, 2, StringSplitOptions.RemoveEmptyEntries)[1].Trim());

                if (tpfJobsData.ContainsKey("STATUS"))
                    AddOrUpdateStageLog(null, tpfJobsData["STATUS"], false, updateScheduler: false);
                //Start SKD03102017
                if (tpfJobsData.ContainsKey("STATUS") && tpfJobsData["STATUS"].Contains("Done NEWCONN rc=-43"))
                {
                    ExceptionHandlingDriver exptionhandlingdriver = new ExceptionHandlingDriver(this.reg, this.Runsettings);
                    TPFSetup_NewConn tpfsetup_newConn = new TPFSetup_NewConn(reg, _Runsettings);

                    if (!exptionhandlingdriver.HandleErrorwithAutoCorrect("Doing Auto Correct in NEWCONN Module", "NotifyandAbort", "ErrGrp", tpfsetup_newConn))
                        return false;
                }
                //END SKD03102017

                if (tpfJobsData.ContainsKey("STATUS") && tpfJobsData["STATUS"].Contains("Job ended rc"))
                    break;

                reg.Pause(60);              //  A normal wait time
            }

            if (tpfJobsData.ContainsKey("STATUS") && (tpfJobsData["STATUS"].Contains("*") || tpfJobsData["STATUS"].Contains("-")))
            {
                AddOrUpdateStageLog(null, tpfJobsData["STATUS"], false);
                return HandleError("TPFSETUP STATUS : " + String.Join(";", tpfJobsData), Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.TPFSETUP_ERROR);
                //return HandleError("TPFSETUP STATUS : " + tpfJobsData["STATUS"], ErrorTypes.NotifyandWait, ErrorGroup.TPFSETUP_ERROR);
                // error handling
            }

            reg.WaitforString("Ready;", 10);
            reg.EnterCommand("SET VTOD SYSTEM", VMCommandTimeOut);
            reg.EnterCommand("I CMS", VMCommandTimeOut);
            reg.SendText(Keys3270.Clear);

            AddOrUpdateStageLog(null, "Successful.", false);

            return true;
        }
        /// <summary>
        /// Runs messages from the given bucket file using PARSEM ( FTPDRB for DRB run )
        /// </summary>
        /// <param name="bucket">Name of the bucket file to run</param>
        /// <param name="MaxHours">Max hours to wait for completion of bucket run, after which the bucket run is programmatically stopped by double entering</param>
        /// <returns>true on success and false on failure</returns>
        private bool RunBucket(string bucket, int MaxHours = 5)
        {
            if (bucket == "")
                return true;
            bool Result = false;
            AddOrUpdateStageLog("Run Bucket " + bucket, "Running...", true);
            string error = "";
            if (bucket.ToUpper().Contains("DRB") && Runsettings.RegType == "DRB")
            {
                var vipb = Runsettings.VIPS.Where(v => v.VPARS != "" && v.VIPNAME.Contains("B")).FirstOrDefault();
                if (vipb == null)
                    vipb = Runsettings.VIPS.Where(v => v.VPARS != "").FirstOrDefault();
                if (vipb != null)
                {
                    //If bucket is like BDR0105 OPTCASES =>add * after it. 
                    reg.EnterCommand("PIPE CMS FTPDRB " + vipb.VPARS + " " + (bucket.Split(' ').Count() == 2 ? bucket + " *" : bucket) + " |>> PRODREGG SUMMARY A1", 1);
                    if (reg.WaitforString("Ready;", 120) > 0)
                    {
                        for (int i = 0; i < 15; i++)
                        {
                            reg.EnterCommand("SENDCMD " + vipb.VPARS + " ZKIJM DI CCR DETAIL", 1);
                            if (reg.WaitforString("ADVICE CREATION COMPLETED", 59) > 0)
                            {
                                Result = true;
                                break;
                            }
                            else
                                if (i == 14)
                                Result = HandleError("FTPDRB is not showing proper results(in 15 minutes).", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.FTP_ERROR);
                            //Result = HandleError("FTPDRB is not showing proper results(in 15 minutes).", ErrorTypes.NotifyandWait, ErrorGroup.FTP_ERROR);
                            //Critical_Error  FTPDRB ERROR
                        }
                        if (Result)
                        {
                            reg.EnterCommand("SENDCMD " + vipb.VPARS + " ZKIJM DI CCR (L=999 KEEP DEST=PRODREGG SUMMARY A1", 1);
                            reg.WaitforString("Ready;", 5);
                            reg.EnterCommand("SENDCMD " + vipb.VPARS + " ZKIJM DI CCR DETAIL (L=999 KEEP DEST=PRODREGG SUMMARY A1", 1);
                            reg.WaitforString("Ready;", 5);
                            reg.EnterCommand("SENDCMD " + vipb.VPARS + " ZKIJM DI CCR ITEM-001 (L=999 KEEP DEST=PRODREGG SUMMARY A1", 1);

                        }
                    }
                    else
                        Result = HandleError("FTPDRB is not Successful.", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.FTP_ERROR);
                    //Result = HandleError("FTPDRB is not Successful.", ErrorTypes.NotifyandWait, ErrorGroup.FTP_ERROR);
                }
            }
            else
            {
                DateTime bucketstart = DateTime.Now;
                reg.EnterCommand("PARSNEW " + bucket + " (REPLAY", 5);
                if (reg.WaitforString("PARSEM Message Sending Options", 10 * 60, RegressionErrors.ParsemErrors, out error) == 0)
                {
                    reg.SetFieldValue("ZDSID=", "Z");
                    reg.SendText(Keys3270.Enter);
                    //reg.SetFieldValue("ZDSID=", "Z");
                    reg.SendText(Keys3270.PF5);
                    //do
                    //{
                    if (reg.WaitforString("End of file, rc 0", MaxHours * 60 * 60, RegressionErrors.BucketRunErrors, out error) == 1)
                    {
                        Result = false;
                        MaxHours = 1;//
                        //programmetically exit the run.
                        if (error == "")
                        {
                            //Double eneter
                            reg.SendText(Keys3270.Enter);
                            reg.SendText(Keys3270.Enter);
                            reg.WaitforString("twice again to abort final message sets", 60);
                            reg.SendText(Keys3270.Enter);
                            reg.SendText(Keys3270.Enter);
                            reg.WaitforString("Message sending cancelled via keyboard interrupt", 60);
                            reg.WaitforString("Ready;", 120);
                            Result = HandleError("Bucket " + bucket + " was ended programmetically after 5 Hours.", ErrorTypes.NotifyAndLog, ErrorGroup.BUCKET_EXECUTION_TIMEOUT);
                        }
                        //end of programmetically exit the run.
                        else if (error == "Message sending cancelled via keyboard interrupt")
                        {
                            reg.WaitforString("Ready;", 120);
                            Result = HandleError("Bucket " + bucket + " was manually stopped.", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.MANUAL_INTERVENSION);
                            //Result = HandleError("Bucket " + bucket + " was manually stopped.",ErrorTypes.NotifyandWait, ErrorGroup.MANUAL_INTERVENSION);
                            // break;
                        }
                        else if (error == "Fill in your USERID and PASSWORD and press ENTER")
                        {
                            if (!HandleError("Bucket " + bucket + " was failed.Reason:VM was reconnected", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.VM_ERROR))
                                //if (!HandleError("Bucket " + bucket + " was failed.Reason:VM was reconnected", ErrorTypes.NotifyandWait, ErrorGroup.VM_ERROR))
                                Result = false;
                        }
                        else if (error != "")                                                                       //Saumen082316
                        {
                            //if (!HandleError("Bucket " + bucket + " was failed.Reason:" + error, ErrorTypes.NotifyandWait, ErrorGroup.BUCKET_EXECUTION_ERROR))
                            if (!HandleError("Bucket " + bucket + " was failed.Reason:" + error, Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.BUCKET_EXECUTION_ERROR))
                                Result = false;
                            //  break;
                        }                                                                                           //Saumen082316

                    }
                    else
                    {
                        reg.WaitforString("Ready;", 120);
                        Result = true;
                        //  break;
                    }
                    //    HandleError(bucket + " Bucket is running for last " + (DateTime.Now - bucketstart).ToString() + " hours\nPopup window is waiting for your response.", ErrorTypes.NotifyOnly);
                    //} while (MessageBox.Show(bucket + " Bucket is running...\nWait another 1 hour(max)?", "Wait more?", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes && error == "");
                }
                else
                    Result = HandleError("Parsem message sending screen didn't appear.\nRun bucket manually and after completion press Yes.", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.PARSEM_ERROR);
                //Result = HandleError("Parsem message sending screen didn't appear.\nRun bucket manually and after completion press Yes.", ErrorTypes.NotifyandWait, ErrorGroup.PARSEM_ERROR);
                if (Result)
                {
                    //Report Creation done here
                    // reg.EnterCommand("EMAIL " + bucket.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0].Trim() + " ERRLOG Z1 " + Runsettings.email + " at visa.com", 10);
                    var onlybucket = bucket.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0].Trim();
                    reg.EnterCommand("COPY " + onlybucket + " STATLOG Z1 " + onlybucket + " STATLOG A1 (REP", 2);
                    reg.EnterCommand("PARSNEW " + onlybucket + " OUTPUT Z1 (REPORT", VMCommandTimeOut);
                    if (reg.WaitforString("REPORT A created...", 20 * 60) == 0)
                        Result = HandleError("Report for " + bucket + " was not generated in 20 minutes.", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.PARSEM_ERROR);
                    //Result = HandleError("Report for " + bucket + " was not generated in 20 minutes.", ErrorTypes.NotifyandWait, ErrorGroup.PARSEM_ERROR);

                }

            }
            if (Result)
            {
                ///////////// CHECK DUMPS using UNIDUMPS//////////////////
                UNIDUMPS(String.Join(" ", Runsettings.VIPS
                                                        .Where(vic => !String.IsNullOrWhiteSpace(vic.VPARS))
                                                        .Select(vic => vic.VPARS).ToList()), "After running bucket " + bucket
                        );
                reg.EnterCommand("PIPE LITERAL DUMPS AFTER REGRESSION RUN :" + bucket + " |>> PRODREGG DUMPS A1", VMCommandTimeOut);
                foreach (VIP vip in Runsettings.VIPS.Where(v => v.VPARS != "" && v.VPARS != null))
                {
                    //reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUODF DIR ALL (L=999 KEEP DEST=PRODREGG DUMPS A1 NODISP", VMCommandTimeOut);
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUODF DIR (L=999 KEEP DEST=PRODREGG DUMPS A1 NODISP", VMCommandTimeOut);//Saumen031317
                    reg.WaitforString("Ready;", 60);
                }
            }
            if (Result)
                AddOrUpdateStageLog(null, "Successful.", false);
            else
                AddOrUpdateStageLog(null, "Unsuccessful. Error: " + error, false);
            return Result;
        }

        string HSM_PRODD77 = null;                                                                                  //Saumen090116

        /// <summary>
        /// Attaches a single HSM to the given VPARS from the provided HSM series and logs the putput in PRODREGG SUMMARY A1.
        /// </summary>
        /// <param name="VPARS">VPARS to attach HSM to</param>
        /// <param name="hsmunit">HSM series to attach from (e.g. 900-90F/NA). HSM is not attached if it is "NA"</param>
        /// <returns>true on Success else false on failure</returns>
        private bool AttachHSM(string VPARS, string hsmunit)
        {
            if (hsmunit == "NA")
                return true;
            bool Result = false;
            ReserveHSM("1", "DETACH");                                                                              //Saumen082916
            HSM_PRODD77 = "DETACHED";                                                                               //Saumen090116
            reg.EnterCommand("SENDCMD " + VPARS + " ZCP Q " + string.Join(" ", App.HSMUNITS.Where(h => h != "NA")), VMCommandTimeOut);
            if (reg.WaitforString("FREE", 10) > 0)
            {

                var freehsmline = reg.GetLines(50).FirstOrDefault(l => l.Contains("FREE"));
                reg.WaitforString("Ready;", 10);
                if (freehsmline != null)
                {
                    string hsmtoattach = freehsmline.Substring(freehsmline.IndexOf("FREE") - 5, 4).Substring(1);
                    reg.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZCP ATT " + hsmtoattach + " * |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                    reg.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZUVSM ON " + hsmtoattach + " |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                    reg.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZQCSM STOP |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                    reg.EnterCommand("PIPE CMS TPFOPR " + VPARS + " ZUVSM SETQ 99 |>> PRODREGG SUMMARY A1", 1);
                    Result = true;
                }
                else
                {
                    Result = false;
                    reg.EnterCommand("PIPE LITERAL No Free HSM found |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                }
                reg.WaitforString("Ready;", 10);
            }
            return Result;
        }
        /// <summary>
        /// Extends tape life of the given tape numbers 
        /// by searching if they belong to the given vpars
        /// </summary>
        /// <param name="tapeList">
        /// string array of tape numbers
        /// </param>
        protected void ExtendTapeLife(string[] tapeList)
        {

            foreach (string tape in tapeList)
            {
                /////////////////////////////// Check if the tape belong to VPARS //////////////////////////////               
                reg.EnterCommand("VTQ LI " + tape, VMCommandTimeOut);
                string vpars = "";
                if (reg.WaitforString("xxxxxxxxxxx", 3, Runsettings.VIPS.Where(v => v.VPARS != "").Select(v => v.VPARS).ToList(), out vpars) == 1 && vpars != "")
                {
                    reg.EnterCommand("TPFOPR " + vpars + " ZCP VTSET " + tape.Trim() + " KEEP " + Runsettings.TapeRetentionPeriod, VMCommandTimeOut);
                    reg.WaitforString("Ready;", VMCommandTimeOut * 4);
                }
            }
        }
        /// <summary>
        /// Valid tapes are DTD RSI CSI ETPDB CSIETP ICX ICB ICW TKN separated by space
        /// </summary>
        /// <param name="tapestocut">A space separated string of tape types to cut</param>
        /// <returns></returns>
        private bool CutTapesForAllVIP(string tapestocut) /// 
        {
            reg.EnterCommand("ERASE TAPE LOG A1", VMCommandTimeOut);
            string FirstVPARS = Runsettings.VIPS.First(v => v.VPARS != "" && v.VPARS != null).VPARS;
            bool Result = true;
            AddOrUpdateStageLog("Cutting Tapes", "Running ...", true);
            string error = "";
            foreach (var tape in tapestocut.ToUpper().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries))
            {

                AddOrUpdateStageLog(null, "Running TPFPROC CUT" + tape + "S...", false);
                reg.EnterCommand("TPFPROC CUT" + tape + "S " + FirstVPARS + " (NODISPLAY", 10);
                //Maximum 90 minutes. Should be sufficient for DTD RSI CSI ETP
                if (reg.WaitforString("Ready;", 45 * 60, RegressionErrors.TapecuttingErrors, out error) != 0)
                {
                    if (error == "")
                        error = "Timed-out(45 minutes)";
                    if (HandleError("TPFPROC CUT" + tape + "S is not Successful.Error:" + getexacterrorfromscreen(error) + Environment.NewLine + "Edit the CUTXXXS file properly before continuing.", Runsettings.IsSchedulerRun ? ((tape == "DTD" || tape == "RSI" || tape == "CSI") ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyAndLog) : ErrorTypes.NotifyandWait, ErrorGroup.TAPE_CUTTING_ERROR) == false)
                    {
                        AddOrUpdateStageLog(null, "Unsuccessful. Error: " + error, false);
                        return false;
                    }
                }
                switch (tape)
                {
                    case "DTD":
                    case "RSI":
                    case "CSI":
                    case "ICX":
                        reg.EnterCommand("PIPE < CUT" + tape + "S  TPFPLOG  A1|locate /All " + tape + " Tapenumbers/ |TAKE 1|strip|specs w4-* 1|preface literal " + tape + ":|join|XLATE 1-* 40 ,|>> TAPE LOG A1", VMCommandTimeOut);
                        break;
                    case "TKN":
                        reg.EnterCommand("PIPE < CUT" + tape + "S  TPFPLOG  A1|locate /All " + tape + " Tapenumbers/ |TAKE 1|strip|specs w4-* 1|preface literal " + tape + ":|join|XLATE 1-* 40 ,|>> TAPE LOG A1", VMCommandTimeOut);
                        reg.EnterCommand("PIPE Literal " + FirstVPARS + "==>ZDGBL _Capcnt 0.100 C-C |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                        reg.EnterCommand("PIPE CMS TPFOPR " + FirstVPARS + " ZDGBL _Capcnt 0.100 C-C |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                        break;
                    case "ETPD":
                        reg.EnterCommand("PIPE < CUTETPDS TPFPLOG  A1|locate /All SMS DET tapes/ |TAKE 1|strip|specs w5-* 1|preface literal ETPDB:|join|XLATE 1-* 40 ,|>> TAPE LOG A1", VMCommandTimeOut);
                        break;
                    case "ICB":
                    case "ICW":
                        reg.EnterCommand("PIPE < CUT" + tape + "S  TPFPLOG  A1|locate /All Base1 " + tape + " tapes/ |TAKE 1|strip|specs w5-* 1|preface literal " + tape + ":|join|XLATE 1-* 40 ,|>> TAPE LOG A1", VMCommandTimeOut);
                        break;
                    default:
                        break;
                }
            }
            // goto SKIP;
            //AddOrUpdateStageLog("Cutting Tapes", "Running CUTALL...", true);
            //reg.EnterCommand("CUTALL " + FirstVPARS + " (" +
            //    tapestocut.Replace("ETPDB", "ETP").Replace("CSIETP", "").Replace("ICB", "").Replace("ICW", "").Replace("ICX", "").Replace("TKN", ""), 10);
            ////Handle Tape cutting errors here
            //string error = "";
            ////Maximum 90 minutes. Should be sufficient for DTD RSI CSI ETP
            //if (reg.WaitforString("Ready;", 90 * 60, RegressionErrors.TapecuttingErrors, out error) == 1)
            //{

            //    //if (HandleError("CUTALL is not working properly." + Environment.NewLine + " Edit the \"TAPE LOG A1\" file aptly", ErrorTypes.NotifyandWait, ErrorGroup.TAPE_CUTTING_ERROR) == false)
            //    if (HandleError("CUTALL is not working properly." + Environment.NewLine + " Edit the \"TAPE LOG A1\" file aptly", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.TAPE_CUTTING_ERROR) == false)
            //        return false;
            //    // exit cut tapes
            //}
            //else
            //{
            //    // CUTALL Scucessful for DTD RSI CSI and ETPDB
            //    ///////////////////////////////////// Maintain the Sequence of Tape numbers RSI -- CSI -- DTD 
            //    reg.EnterCommand("PIPE < CUTRSIS  TPFPLOG  A1|locate /All RSI Tapenumbers/ |TAKE 1|strip|specs w4-* 1|preface literal RSI:|join|XLATE 1-* 40 ,|>> TAPE LOG A1", VMCommandTimeOut);
            //    reg.EnterCommand("PIPE < CUTCSIS  TPFPLOG  A1|locate /All CSI Tapenumbers/ |TAKE 1|strip|specs w4-* 1|preface literal CSI:|join|XLATE 1-* 40 ,|>> TAPE LOG A1", VMCommandTimeOut);
            //    reg.EnterCommand("PIPE < CUTDTDS  TPFPLOG  A1|locate /All DTD Tapenumbers/ |TAKE 1|strip|specs w4-* 1|preface literal DTD:|join|XLATE 1-* 40 ,|>> TAPE LOG A1", VMCommandTimeOut);
            //    reg.EnterCommand("PIPE < CUTETPDS TPFPLOG  A1|locate /All SMS DET tapes/ |TAKE 1|strip|specs w5-* 1|preface literal ETPDB:|join|XLATE 1-* 40 ,|>> TAPE LOG A1", VMCommandTimeOut);
            //}
            //if (tapestocut.Contains("CSIETP"))
            //{
            //    //Enter CSIETP cutting commands here
            //    // reg.EnterCommand("TPFPROC CUTCSIS " + FirstVPARS, VMCommandTimeOut);
            //}

            //if (tapestocut.Contains("ICB"))
            //{
            //    AddOrUpdateStageLog(null, "Running TPFPROC CUTICBS...", false);

            //    reg.EnterCommand("TPFPROC CUTICBS " + FirstVPARS, VMCommandTimeOut);
            //    if (reg.WaitforString("Ready;", 20 * 60, RegressionErrors.TapecuttingErrors, out error) == 1)
            //        HandleError("CUTICBS is not working properly.", ErrorTypes.NotifyAndLog, ErrorGroup.TAPE_CUTTING_ERROR);
            //}

            //if (tapestocut.Contains("ICX"))
            //{
            //    AddOrUpdateStageLog(null, "Running TPFPROC CUTICXS...", false);

            //    reg.EnterCommand("TPFPROC CUTICXS " + FirstVPARS, VMCommandTimeOut);
            //    if (reg.WaitforString("Ready;", 20 * 60, RegressionErrors.TapecuttingErrors, out error) == 1)
            //        HandleError("CUTICXS is not working properly.", ErrorTypes.NotifyAndLog, ErrorGroup.TAPE_CUTTING_ERROR);
            //}
            //if (tapestocut.Contains("ICW"))
            //{
            //    AddOrUpdateStageLog(null, "Running TPFPROC CUTICWS...", false);

            //    reg.EnterCommand("TPFPROC CUTICWS " + FirstVPARS, VMCommandTimeOut);
            //    if (reg.WaitforString("Ready;", 20 * 60, RegressionErrors.TapecuttingErrors, out error) == 1)
            //        HandleError("CUTICWS is not working properly.", ErrorTypes.NotifyAndLog, ErrorGroup.TAPE_CUTTING_ERROR);
            //}
            //if (tapestocut.Contains("TKN"))
            //{
            //    AddOrUpdateStageLog(null, "Running TPFPROC CUTTKNS...", false);
            //    reg.EnterCommand("TPFPROC CUTTKNS " + FirstVPARS, VMCommandTimeOut);
            //    if (reg.WaitforString("Ready;", 20 * 60, RegressionErrors.TapecuttingErrors, out error) == 1)
            //        HandleError("CUTTKNS is not working properly.", ErrorTypes.NotifyAndLog, ErrorGroup.TAPE_CUTTING_ERROR);
            //    // Add Token display after cuttkn
            //    //foreach (VIP vip in ObsAllVIP.Where(v=>v.VPARS!="" && v.VPARS!=null))
            //    //{
            //    reg.EnterCommand("PIPE Literal " + FirstVPARS + "==>ZDGBL _Capcnt 0.100 C-C |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            //    reg.EnterCommand("PIPE CMS TPFOPR " + FirstVPARS + " ZDGBL _Capcnt 0.100 C-C |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            //    //}
            //}
            //AddOrUpdateStageLog(null, "Collecting Tapes to TAPE LOG...", false);

            ///////////////////////////////////////////// add to tap log file /////////////////////////////////////////////
            //reg.EnterCommand("PIPE < CUTICBS  TPFPLOG  A1|locate /All Base1 ICB tapes/ |TAKE 1|strip|specs w5-* 1|preface literal ICB:|join|XLATE 1-* 40 ,|>> TAPE LOG A1", VMCommandTimeOut);
            //reg.EnterCommand("PIPE < CUTICWS  TPFPLOG  A1|locate /All Base1 ICW tapes/ |TAKE 1|strip|specs w5-* 1|preface literal ICW:|join|XLATE 1-* 40 ,|>> TAPE LOG A1", VMCommandTimeOut);
            //reg.EnterCommand("PIPE < CUTICXS  TPFPLOG  A1|locate /All ICX Tapenumbers/ |TAKE 1|strip|specs w4-* 1|preface literal ICX:|join|XLATE 1-* 40 ,|>> TAPE LOG A1", VMCommandTimeOut);
            //reg.EnterCommand("PIPE < CUTTKNS  TPFPLOG  A1|locate /All TKN Tapenumbers/ |TAKE 1|strip|specs w4-* 1|preface literal TKN:|join|XLATE 1-* 40 ,|>> TAPE LOG A1", VMCommandTimeOut);
            //reg.EnterCommand("PIPE LITERAL DUMPS AFTER TAPE CUTTING: |>> PRODREGG DUMPS A1", VMCommandTimeOut);
            AddOrUpdateStageLog(null, "Taking DUMPS after tape cutting...", false);
            foreach (VIP vip in Runsettings.VIPS.Where(v => v.VPARS != "" && v.VPARS != null))
            {
                //reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUODF DIR ALL (L=999 KEEP DEST=PRODREGG DUMPS A1 NODISP", VMCommandTimeOut);
                reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUODF DIR (L=999 KEEP DEST=PRODREGG DUMPS A1 NODISP", VMCommandTimeOut);//Saumen031317
                reg.WaitforString("Ready;", 60);
            }
            ///////////// CHECK DUMPS using UNIDUMPS//////////////////
            UNIDUMPS(String.Join(" ", Runsettings.VIPS
                                                    .Where(vic => !String.IsNullOrWhiteSpace(vic.VPARS))
                                                    .Select(vic => vic.VPARS).ToList()), "After cutting tapes");

            ////////////////////////////////////////////// EXTRACT CODE RUN TAPES AND EXTEND LIFE /////////////////////////////////////////////
            AddOrUpdateStageLog(null, "Extending tape life...", false);
            reg.EnterCommand("PIPE < TAPE LOG A1 | CONSOLE", VMCommandTimeOut);
            List<string> CodeRunLogTapesFile = reg.GetLines(50);
            foreach (String line in CodeRunLogTapesFile)
            {
                if (!String.IsNullOrWhiteSpace(line) && !line.Contains("PIPE") && !line.Contains("Ready") && line.Contains(":"))
                {
                    String tape_numbers = line.Split(':')[1].Replace(",Error,", ",").Trim();
                    ExtendTapeLife(tape_numbers.Split(','));
                }
            }
            if (Result)
                AddOrUpdateStageLog(null, "Successful.", false);
            else
                AddOrUpdateStageLog(null, "Unsuccessful. Error: " + error, false);
            return Result;
        }
        /// <summary>
        /// checks for unique dumps on all vparses and then stores them in UNIDUMPS TXT A1
        /// </summary>
        /// <param name="Vparses">space separated string of vparse to check dumps in</param>
        private void UNIDUMPS(string Vparses, string stage = null)
        {
            try
            {
                if (stage != null)
                {
                    reg.EnterCommand("PIPE LITERAL Stage-" + stage + " |>> UNIDUMPS TXT A1", 1);
                    reg.EnterCommand("PIPE LITERAL ---------------------------------- |>> UNIDUMPS TXT A1", 1);
                }
                reg.EnterCommand("UNIDUMP " + Vparses);
                Match unidumps_out = reg.WaitForRegexEx(new Regex(@"(?'completed'successfully;)|(?'error'Ready\()", RegexOptions.IgnoreCase), 20 * 60);

                if (unidumps_out.Groups["completed"].Success)
                    return;

                else if (unidumps_out.Groups["error"].Success)
                {
                    HandleError("UNIDUMPS " + Vparses + ": Execution failed", ErrorTypes.LogOnly, ErrorGroup.UNIDUMPS_ERROR);
                    return;
                }
            }
            catch (RegexMatchTimeoutException)
            {
                //doHX();
                HandleError("UNIDUMPS " + Vparses + ": Execution timeout, did HX", ErrorTypes.LogOnly, ErrorGroup.UNIDUMPS_ERROR);
                return;
            }
            catch (Exception)
            {
                HandleError("UNIDUMPS " + Vparses + ": EXEC timeout, and HX failure", ErrorTypes.LogOnly, ErrorGroup.UNIDUMPS_ERROR);
            }
        }
        /// <summary>
        /// Compares baserun and coderun tapes by reading the tape numbers from the respective files 
        /// </summary>
        /// <param name="user_mask">xml mask file to mask fields during compare</param>
        /// <returns>true on success and false on failure</returns>
        private bool CompareResult(String user_mask = null)
        {
            bool Result = true;
            string error = "";

            if (!Runsettings.IsComparisonRequired)
                return true;
            if (Runsettings.RegType == "ECIP" || Runsettings.RegType == "UNBALANCED") // SKIP Compare for ECIP and Unbalanced even if the checkbox is checked
                return true;

            try
            {
                var BaseRunLogs = System.IO.File.ReadAllLines(Runsettings.BaserunServer + (user_mask == null ? "\\log" : "\\provisioning_") + "tapes-coderun.txt").Where(l => l.Contains(":")).Select(l => l.Trim());
                if (Runsettings.RegType == "TOKEN")    /* Added by Rakesh - TKN Compare Bypass */
                    reg.EnterCommand("PIPE < " + (user_mask == null ? null : "PR") + "TAPE LOG A1 | NLOCATE /TKN/ | NLOCATE /ICX/ | CONSOLE", 2);  /* Nlocating TKN Tape */
                else
                    reg.EnterCommand("PIPE < TAPE LOG A1 | CONSOLE", 2);    /* else compare every tape */
                var CodeRunLogs = reg.GetLines(20).Where(l => l.Contains(':') && !l.Contains("Ready")).Select(l => l.Trim());

                foreach (var log in BaseRunLogs)
                {
                    string tapetype = log.Substring(0, log.IndexOf(':'));
                    //Compare only DTD/RSI/CSI Tapes
                    if (!tapetype.Equals("DTD", StringComparison.InvariantCultureIgnoreCase) && !tapetype.Equals("RSI", StringComparison.InvariantCultureIgnoreCase) && !tapetype.Equals("CSI", StringComparison.InvariantCultureIgnoreCase))
                    {
                        continue;
                    }
                    string basetapes = log.Substring(log.IndexOf(':') + 1).Replace("Time-out", "").Replace("Error", "").Trim(new char[] { ',' });
                    string codetapes = CodeRunLogs.FirstOrDefault(l => l.Contains(tapetype + ":"));
                    if (codetapes != null)
                        codetapes = codetapes.Substring(codetapes.IndexOf(':') + 1).Replace("Time-out", "").Replace("Error", "").Trim(new char[] { ',' });
                    if (basetapes != null && basetapes != "" && codetapes != null && codetapes != "")
                    {
                        AddOrUpdateStageLog("Compare " + tapetype + " Tapes", "Running...", true);
                        if (tapetype == "DTD" && user_mask == null)
                        {
                            AddOrUpdateStageLog(null, "Running H14 Compare", false);
                            //Increase H14DEF/F39DEF time to 1 hour
                            reg.EnterCommand("H14" + (Runsettings.RegType.Contains("SOAP") ? "SOAP " : "DEF ") + basetapes + " " + codetapes, VMCommandTimeOut);
                            if (reg.WaitforString("Ready;", 60 * 60, RegressionErrors.CompareErrors, out error) != 0)
                            {
                                if (error == "")
                                    //if (!HandleError("H14" + (Runsettings.RegType.Contains("SOAP") ? "SOAP " : "DEF ") + " is not completed properly in 1 hour.", ErrorTypes.NotifyandWait, ErrorGroup.VM_TOOLS_ERROR))
                                    if (!HandleError("H14" + (Runsettings.RegType.Contains("SOAP") ? "SOAP " : "DEF ") + " is not completed properly in 1 hour.", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.VM_TOOLS_ERROR))
                                        return false;
                                    else if (error == "Disk A(191) is full" || error == "Disk A is full" || error == "Disk Z is full")
                                        //if (!HandleError("Disk A(191) is full", ErrorTypes.NotifyandWait, ErrorGroup.SYSTEM_PROBLEM))
                                        if (!HandleError(error, Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.SYSTEM_PROBLEM))
                                            return false;
                            }
                        }
                        AddOrUpdateStageLog(null, "Running COMPNEW", false);

                        reg.EnterCommand("COMPNEW " + basetapes + " " + codetapes + " (" + user_mask + " QTP", VMCommandTimeOut);
                        if (reg.WaitforString("MsgNo Format  Dest   Srce  MTI", 60 * 60, RegressionErrors.CompareErrors, out error) == 1)
                        {
                            if (error == "PARSEM news and status")
                            {
                                reg.SendText(Keys3270.PF3);
                                if (reg.WaitforString("MsgNo Format  Dest   Srce  MTI", 2 * 60, RegressionErrors.CompareErrors, out error) == 0)
                                    AfterSuccessfulCompare(tapetype, user_mask);
                            }
                            else if (error == "")
                            {
                                //if (!HandleError(tapetype + " tape is not compared properly in 1 hour.", ErrorTypes.NotifyandWait, ErrorGroup.TAPE_COMPARISON_ERROR))
                                if (!HandleError(tapetype + " tape is not compared properly in 1 hour.", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.TAPE_COMPARISON_ERROR))
                                    return false;
                            }
                            else if (tapetype.Equals("DTD", StringComparison.InvariantCultureIgnoreCase)
                                    || tapetype.Equals("RSI", StringComparison.InvariantCultureIgnoreCase)
                                    || tapetype.Equals("CSI", StringComparison.InvariantCultureIgnoreCase))
                            {

                                //if (!HandleError("Error in comparing " + tapetype + " tapes. Error:" + error, ErrorTypes.NotifyandWait, ErrorGroup.TAPE_COMPARISON_ERROR))
                                if (!HandleError("Error in comparing " + tapetype + " tapes. Error:" + error, Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.TAPE_COMPARISON_ERROR))
                                    return false;
                            }
                            else
                            {
                                HandleError("Error in comparing " + tapetype + " tapes. Error:" + error, Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.TAPE_COMPARISON_ERROR);
                                //HandleError("Error in comparing " + tapetype + " tapes. Error:" + error, ErrorTypes.NotifyAndLog, ErrorGroup.TAPE_COMPARISON_ERROR);
                            }

                        }
                        else
                            AfterSuccessfulCompare(tapetype, user_mask);
                    }
                }

            }
            catch (Exception ex)
            {
                error = ex.Message;
                Result = false;
            }
            //if (Result)
            //    AddOrUpdateStageLog(null, "Successful.", false);
            //else
            //    AddOrUpdateStageLog(null, "Unsuccessful. Error: " + error, false);

            return Result;
        }
        /// <summary>
        /// This function is called after completion of compare for every tape type. This executes the MMIDNTFR exec
        /// </summary>
        /// <param name="tapetype">tape type compared (e.g. DTD,RSI,CSI etc)</param>
        /// <param name="user_mask">an XML file to mask fields during compare</param>
        private void AfterSuccessfulCompare(string tapetype, string user_mask = null)
        {
            reg.Pause(2);
            reg.SendText(Keys3270.PF3);
            reg.Pause(2);
            reg.WaitforString("Ready;", 60);
            reg.EnterCommand("ERASE " + tapetype + "MM TXT A1", 1);
            reg.EnterCommand("ERASE " + "P" + tapetype + "MM TXT A1", 1);

            //	Install followed by first two char of Regression type, followed by Run #. E.g. 0214PR1, 0228ST2, 0228SO10 etc.
            //string MM_FLTYP = Runsettings.InstallDate.Replace("/", "").Substring(0, 4) + Runsettings.RegType.Substring(0, 2) + Runsettings.RunNumber.Replace("BASERUN", "BR").Replace("RUN", (Runsettings.SwitchActivationInfo != "N/A" && Runsettings.SwitchActivationInfo != null ? "S" : null));
            string MM_FLTYP = Runsettings.InstallDate.Replace("/", "").Substring(0, 4) + Runsettings.RegType.Substring(0, 2) + Runsettings.RunNumber.Replace("RUN", null);//Saumen031317

            if (!Runsettings.RegType.Equals("TOKEN", StringComparison.InvariantCultureIgnoreCase)
               && (tapetype.Equals("RSI", StringComparison.CurrentCultureIgnoreCase) || tapetype.Equals("CSI", StringComparison.CurrentCultureIgnoreCase) || tapetype.Equals("DTD", StringComparison.CurrentCultureIgnoreCase)))
            {
                MMIDNTFR(tapetype, MM_FLTYP);
            }

            reg.EnterCommand("RENAME COMPARE SUMMARY A1 " + (user_mask == null ? null : "P") + tapetype + "MM TXT A1", 1);
            //if (Runsettings.IsSpoolRequired)
            //{
            reg.EnterCommand("REGP5VIP 11", VMCommandTimeOut);
            //NEW Change
            reg.SendText(tapetype + "MM " + MM_FLTYP + Keys3270.Enter);
            //NEW Change    
            reg.WaitforString("Ready;", 5 * 60);
            AddOrUpdateStageLog(null, "Done.", false);
        }

        private void MMIDNTFR(string tapetype, string MM_FLTYP)
        {
            ////////////////////////////////////////////////// RUN MMIDNTFR /////////////////////////////////////////////////////////////
            string installDateMMDD = Runsettings.InstallDate.Replace("/", "").Substring(0, 4);

            // AddOrUpdateStageLog("MMIDNTFR", "MMIDNTFR " + MM_FLTYP + " " + tapetype + " " + installDateMMDD + " Started", true);

            //reg.EnterCommand("GET TESTCASE", 1);
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                reg.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            reg.EnterCommand("GET VIPQAAUT", 1);//Saumen021417
            reg.WaitforString("Ready;", 3);

            int MMIDNTFR_wait = (int)(60 * 60 * 1.25);
            string MMIDNTFR_cmd = "MMIDNTFR " + MM_FLTYP + " " + tapetype + " " + installDateMMDD;

            //try
            {
                reg.EnterCommand("MMIDNTFR " + MM_FLTYP + " " + tapetype + " " + installDateMMDD, 3);
                AddOrUpdateStageLog(null, "MMIDNTFR " + MM_FLTYP + " " + tapetype + " Running....", false);

                string errStr = String.Empty;

                if (reg.WaitforString("Processing completed successfully", MMIDNTFR_wait, RegressionErrors.INTERNALREXXERRORS.Select(err => err.Key).ToList(), out errStr) != 0)
                //if (reg.WaitForStringEx("Processing completed", MMIDNTFR_wait, RegressionErrors.MMIDNTFR_ERRORS.Select(err => err.ErrorString).ToList(), out errStr) != 0)
                {
                    ErrorTypes errtyp;
                    if (string.IsNullOrEmpty(errStr))
                    {
                        errtyp = Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait;
                        if (Runsettings.IsSchedulerRun)
                            doHX();
                        errStr = "Timed out, done HX";
                    }
                    else
                    {
                        errtyp = RegressionErrors.INTERNALREXXERRORS.First(err => err.Key == errStr).Value;
                        errStr = getexacterrorfromscreen(errStr);
                    }
                    if (!HandleError(MMIDNTFR_cmd + " : " + errStr, errtyp, ErrorGroup.MMIDNTFR_ERROR))
                        return;
                }
                else
                {
                    AddOrUpdateStageLog(null, "MMIDNTFR " + MM_FLTYP + " " + tapetype + " Completed", false);
                }

            }
            // Handling Unexpected outputs
            //catch (System.TimeoutException)
            //{
            //    AddOrUpdateStageLog(null, "Failed: Timed Out", false);
            //doHX();
            //    HandleError("MMIDNTFR " + tapetype + ": command timedout, did HX", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.MMIDNTFR_ERROR);
            //    //HandleError("MMIDNTFR " + tapetype + ": command timedout, did HX", ErrorTypes.NotifyandWait, ErrorGroup.MMIDNTFR_ERROR);
            //}
            //catch (Exception e)
            //{
            //    AddOrUpdateStageLog("MMIDNTFR " + tapetype, e.Message, true);
            //    HandleError("MMIDNTFR " + tapetype + ": exception in doing HX ", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.MMIDNTFR_ERROR);
            //    //HandleError("MMIDNTFR " + tapetype + ": exception in doing HX ", ErrorTypes.NotifyandWait, ErrorGroup.MMIDNTFR_ERROR);
            //}

            ///////////////////// SPOOL FILES TO TESTCASE READER list//////////////////////
            /*
             •	After all RSI, CSI & DTD mismatch identification are completed, spool the following files from Z disk to TESTCASE reader for further research.
                o	MMCASES <filetype>
                o	MMTABLE <filetype>
                o	ERROR CASES
                o	UNIQUE DATA
            */
            if (tapetype.Equals("DTD", StringComparison.CurrentCultureIgnoreCase))
            {
                reg.EnterCommand("REGP5VIP 11", VMCommandTimeOut);
                reg.SendText("MMCASES " + MM_FLTYP + " Z" + Keys3270.Enter);
                reg.WaitforString("Ready;", 60);

                reg.EnterCommand("REGP5VIP 11", VMCommandTimeOut);
                reg.SendText("MMTABLE " + MM_FLTYP + " Z" + Keys3270.Enter);
                reg.WaitforString("Ready;", 60);

                reg.EnterCommand("REGP5VIP 11", VMCommandTimeOut);
                reg.SendText("UNIQUE DATA Z" + Keys3270.Enter);
                reg.WaitforString("Ready;", 60);

                reg.EnterCommand("REGP5VIP 11", VMCommandTimeOut);
                reg.SendText("ERROR CASES Z" + Keys3270.Enter);
                reg.WaitforString("Ready;", 60);

                //1.	Please add MMIDNTFR step in the Status.txt.
                //2.	Also I need the following files resulted from MMIDNTFR to be uploaded in the server.
                //    •	UNIQUE DATA
                //    •	MMTABLE <ftype>

                reg.ReceiveFile(System.IO.Path.Combine(Runsettings.CoderunServer, "UNIQUE DATA " + MM_FLTYP + ".txt"), "UNIQUE DATA Z");
                reg.ReceiveFile(System.IO.Path.Combine(Runsettings.CoderunServer, "MMTABLE " + MM_FLTYP + ".txt"), "MMTABLE " + MM_FLTYP + " Z");

            }
            ///////////////////////////////////////////////// MMIDNTFR DONE /////////////////////////////////////////////////////////////
            return;
        }
        /// <summary>
        /// First copies all baserun files into coderun folder path and then transfers files from VM/CMS into the coderun folder
        /// </summary>
        /// <returns>true on success else false on failure</returns>
        private bool TransferFiles()
        {
            AddOrUpdateStageLog("Transfer files from " + Runsettings.VMID.ToUpper(), "Running...", true);
            //reg.EnterCommand("CP SET MSG OFF", 1);

            //SKD012417
            //reg.EnterCommand("ERASE * OPRLOG A1", VMCommandTimeOut);
            //reg.EnterCommand("ERASE * CONSLOG A1", VMCommandTimeOut);
            try
            {

                reg.EnterCommand("ERASE * OPRLOG A1", 10);
                reg.WaitforString("Ready", 60);
                reg.EnterCommand("ERASE * CONSLOG A1", 10);
                reg.WaitforString("Ready", 60);
            }
            catch
            {
                HandleError("Did not get the Proper Response", ErrorTypes.LogOnly, ErrorGroup.NO_ERROR);
            }
            //SKD012417

            if (!System.IO.Directory.Exists(Runsettings.CoderunServer))
                System.IO.Directory.CreateDirectory(Runsettings.CoderunServer);

            if (Runsettings.BaserunServer != "")
            {
                try
                {
                    foreach (var file in System.IO.Directory.GetFiles(Runsettings.BaserunServer).Where(l => l.ToLower().Contains("coderun.txt")))
                    {
                        System.IO.File.Copy(file, file.Replace(Runsettings.BaserunServer, Runsettings.CoderunServer).Replace("coderun.txt", "baserun.txt"), true);
                    }
                }
                catch (Exception)
                {
                    // throw;
                }
            }
            reg.ReceiveFile(Runsettings.CoderunServer + "\\setup-coderun.txt", Runsettings.SetupFile + " $TTVDATA A1");
            reg.ReceiveFile(Runsettings.CoderunServer + "\\consolelog-coderun.txt", "PRODREGG SUMMARY");

            reg.ReceiveFile(Runsettings.CoderunServer + "\\dumps-coderun.txt", "PRODREGG DUMPS");
            reg.ReceiveFile(System.IO.Path.Combine(Runsettings.CoderunServer, "UNIQUE DUMPS-coderun.txt"), "UNIDUMPS TXT A1");
            reg.ReceiveFile(Runsettings.CoderunServer + "\\logtapes-coderun.txt ", "TAPE LOG A1");
            foreach (var item in Runsettings.Bucket.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var capturefilename = item.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0].Trim();
                reg.ReceiveFile(Runsettings.CoderunServer + "\\" + capturefilename + "_report-coderun.txt", capturefilename + " REPORT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\" + capturefilename + "_statlog-coderun.txt", capturefilename + " STATLOG");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\" + capturefilename + "_errlog-coderun.txt", capturefilename + " ERRLOG");
                ////DUMP analysis
                //if (Runsettings.IsComparisonRequired)
                //    reg.EnterCommand("REGDUMP " + capturefilename + " " + Runsettings.RegType.Substring(0, 2) + Runsettings.InstallDate.Replace("/", "").Substring(0, 4) + Runsettings.RunNumber.Replace("RUN", "R"), 5);
            }

            reg.ReceiveFile(Runsettings.CoderunServer + "\\testkeyscontrol-coderun.txt", "TESTKEYS CONTROL A1");
            reg.ReceiveFile(Runsettings.CoderunServer + "\\keysyncreport-coderun.txt", "KEYSYNC REPORT A1");
            if (Runsettings.RegType == "APF")
            {
                reg.ReceiveFile(Runsettings.CoderunServer + "\\APFLOG-coderun.txt", "APF LOG A1");
            }
            if (Runsettings.IsAdviceRetrieve)
            {
                reg.ReceiveFile(Runsettings.CoderunServer + "\\report_for_advice_retrieval-coderun.txt", "ZKADV REPORT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\statlog_for_advice_retrieval-coderun.txt", "ZKADV STATLOG");
                // reg.ReceiveFile(Runsettings.CoderunServer + "\\dumps_after_advice_retrieval-coderun.txt", "DUMPS ALOG");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\advice_count_before_retrieval-coderun.txt", "ZKADV BCOUNT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\advice_count_after_retrieval-coderun.txt", "ZKADV ACOUNT");
            }
            if (Runsettings.IsComparisonRequired)
            {
                reg.ReceiveFile(Runsettings.CoderunServer + "\\h14def.txt", (Runsettings.RegType.Contains("SOAP") ? "H14SOAP REPORT" : "H14DEF REPORT"));
                // reg.ReceiveFile(Runsettings.CoderunServer + "\\f39def.txt", (Runsettings.RegType.Contains("SOAP") ? "F39SOAP REPORT" : "F39DEF REPORT"));
                reg.ReceiveFile(Runsettings.CoderunServer + "\\dtdmm.txt", "DTDMM TXT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\rsimm.txt", "RSIMM TXT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\csimm.txt", "CSIMM TXT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\etpdbmm.txt", "ETPDBMM TXT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\icbmm.txt", "ICBMM TXT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\icwmm.txt", "ICWMM TXT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\icxmm.txt", "ICXMM TXT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\tknmm.txt", "TKNMM TXT");
                //DUMP analysis

            }
            if (Runsettings.RegType == "TOKEN")
            {
                //reg.EnterCommand("PIPE < PRTAPE LOG A1 |>> TAPE LOG A1", VMCommandTimeOut);
                reg.ReceiveFile(Runsettings.CoderunServer + "\\provisioning_tapes-coderun.txt ", "PRTAPE LOG");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\provisioning_Report-coderun.txt ", "NCCLOG REPORT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\pan_token_table-coderun.txt ", "PAN_TKN TABLE Z1");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\Provisioning_dtdmm.txt", "PDTDMM TXT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\Provisioning_rsimm.txt", "PRSIMM TXT");
                reg.ReceiveFile(Runsettings.CoderunServer + "\\Provisioning_csimm.txt", "PCSIMM TXT");
            }
            IdentifyNewDumps();
            reg.EnterCommand("ERASE DUMPS UNIQUE A1", 1);
            reg.SendFile(Runsettings.CoderunServer + "\\DUMPS_UNIQUE.txt", "DUMPS UNIQUE A1");
            //DUMP analysis
            foreach (var item in Runsettings.Bucket.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var capturefilename = item.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0].Trim();
                //DUMP analysis
                //reg.EnterCommand("REGDUMP " + capturefilename + " " + Runsettings.InstallDate.Replace("/", "").Substring(0, 4) + Runsettings.RegType.Substring(0, 2) + Runsettings.RunNumber.Replace("BASERUN", "BR").Replace("RUN", (Runsettings.SwitchActivationInfo != "N/A" && Runsettings.SwitchActivationInfo != null ? "S" : null)), 5);
                reg.EnterCommand("REGDUMP " + capturefilename + " " + Runsettings.InstallDate.Replace("/", "").Substring(0, 4) + Runsettings.RegType.Substring(0, 2) + Runsettings.RunNumber.Replace("RUN", null), 5);//Saumen031317
                //Handle situation where PARSEM SCREEN appraes
                string err = "";
                do
                {
                    int waittime = 15 * 60;

                    if (err == "MsgNo Format  Dest   Srce  MTI")
                        waittime = 2 * 60;

                    if (reg.WaitforString("Ready;", waittime, new List<string>() { "MsgNo Format  Dest   Srce  MTI", "Ready(" }, out err) == 1)
                    {

                        if (err == "MsgNo Format  Dest   Srce  MTI")
                        {
                            ///If Parsem window appears press F3
                            reg.SendText(Keys3270.PF3);
                            reg.WaitforString("Ready;", 30);
                            HandleError("PARSEM window appeared during Regdump", ErrorTypes.LogOnly, ErrorGroup.PARSEM_ERROR);
                        }
                        else
                        {
                            HandleError("DUMP testcase was not created properly", ErrorTypes.NotifyAndLog, ErrorGroup.OTHER_INTERNAL_EXEC_ERROR);
                        }
                    }

                } while (err.Contains("MsgNo Format  Dest   Srce  MTI"));
            }
            /////////////////////////// Saving DUMP LIST files ////////////////////////////
            reg.EnterCommand("b");
            reg.WaitforString("Ready", 2 * 60);
            reg.ReceiveFile(System.IO.Path.Combine(Runsettings.CoderunServer, "DUMP_LIST.txt"), "DUMP LIST A1");

            if (System.IO.File.Exists(System.IO.Path.Combine(Runsettings.CoderunServer, "DUMP_LIST.txt")))
            {
                foreach (string file_name in System.IO.File.ReadAllLines(System.IO.Path.Combine(Runsettings.CoderunServer, "DUMP_LIST.txt"))
                                                                        .Select(ln => ln.Trim().ToUpper())
                                                                        .Where(ln => !String.IsNullOrWhiteSpace(ln) && ln.Contains(' '))
                                                                         )
                {
                    reg.ReceiveFile(System.IO.Path.Combine(Runsettings.CoderunServer, file_name.Replace(' ', '_') + ".txt"), file_name);
                }

            }
            UploadRexxErrorLog();
            AddOrUpdateStageLog(null, "Successful.", false);

            return true;
        }
        private void IdentifyNewDumps()
        {
            try
            {
                //Need to check tomorrow
                string server = Runsettings.CoderunServer;
                List<string> baserundumps = new List<string>();
                if (System.IO.File.Exists(server + "\\UNIQUE DUMPS-baserun.txt"))
                    baserundumps = System.IO.File.ReadAllLines(server + "\\UNIQUE DUMPS-baserun.txt").Distinct()
                        .Where(l => !l.Contains("VPARS_ID") && !l.Contains("-------") && !l.Contains("Stage-") && l.Length > 2)
                        .Select(b => string.Join(" ", b.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries))).ToList();
                List<string> coderundumps = new List<string>();
                if (System.IO.File.Exists(server + "\\UNIQUE DUMPS-coderun.txt"))
                    coderundumps = System.IO.File.ReadAllLines(server + "\\UNIQUE DUMPS-coderun.txt").Distinct()
                        .Where(l => !l.Contains("VPARS_ID") && !l.Contains("-------") && l.Length > 2)
                        .Select(b => string.Join(" ", b.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries))).ToList();
                List<string> Knowndumps = System.IO.File.ReadAllLines(App.KnownDumpsServer).Select(l => l.Substring(0, 20).Trim()).ToList();//.Where(l => l.Split(' ').Count() == 2)
                coderundumps = coderundumps.Where(d => !Knowndumps.Any(kd => kd.Split(' ').All(sptkd => d.Contains(sptkd)))).ToList();
                List<string> newdumps =
                    coderundumps.Where(d => !d.Contains("Stage-")).Select(d => string.Join(" ", d.Substring(d.IndexOf(" "), d.IndexOf(":") - d.IndexOf(" ")).Trim().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).Take(4)))
                    .Except(
                    baserundumps.Select(d => string.Join(" ", d.Substring(d.IndexOf(" "), d.IndexOf(":") - d.IndexOf(" ")).Trim().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).Take(4)))
                    ).ToList();
                List<string> dumpsuniqueformatted = new List<string>();
                newdumps.ForEach((d) =>
                {
                    var dumpline = coderundumps.FirstOrDefault(cd => cd.Contains(d));
                    if (dumpline != null)
                    {
                        dumpline += " : " + coderundumps.LastOrDefault(u => u.Contains("Stage-") && coderundumps.IndexOf(u) < coderundumps.IndexOf(dumpline));
                        dumpsuniqueformatted.Add(dumpline.Replace("Stage-", null).Replace("After", "During"));
                    }

                });

                System.IO.File.Delete(server + "\\DUMPS_UNIQUE.txt");
                if (dumpsuniqueformatted.Count > 0)
                    System.IO.File.WriteAllLines(server + "\\DUMPS_UNIQUE.txt", dumpsuniqueformatted);
            }
            catch (Exception ex)
            {
                HandleError("Identify new dumps encountered error." + ex.Message, ErrorTypes.NotifyAndLog, ErrorGroup.UNIDUMPS_ERROR);
            }

        }
        /// <summary>
        /// Performs many environment related task of regression like attaching HSM, running BPROD and other zburz files depending upon the regression type and logs everything in PRODREGG SUMMARY A1 
        /// </summary>
        /// <returns>true on sucess else false on failure</returns>
        private bool EnvironmentSetup()
        {
            bool Result = true;
            string error = "";
            AddOrUpdateStageLog("Prepare environment and get logs", "Running...", true);
            ///////////// CHECK DUMPS using UNIDUMPS//////////////////
            //EraseOldFiles();

            //reg.EnterCommand("GET TESTCASE", VMCommandTimeOut);
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                reg.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            reg.EnterCommand("GET VIPQAAUT", VMCommandTimeOut);//Saumen021417
            UNIDUMPS(String.Join(" ", Runsettings.VIPS
                                        .Where(vic => !String.IsNullOrWhiteSpace(vic.VPARS))
                                        .Select(vic => vic.VPARS).ToList()), "After TPFSETUP"
        );
            reg.EnterCommand("PIPE LITERAL DUMPS BEFORE REGRESSION RUN: |>> PRODREGG DUMPS A1", VMCommandTimeOut);

            foreach (VIP vip in Runsettings.VIPS.Where(v => v.VPARS != "" && v.VPARS != null))
            {

                reg.EnterCommand("PIPE LITERAL ----------------------  |>> PRODREGG SUMMARY A1 ", VMCommandTimeOut);
                reg.EnterCommand("PIPE LITERAL " + vip.VPARS.ToUpper() + ": |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                reg.EnterCommand("PIPE LITERAL ----------------------  |>> PRODREGG SUMMARY A1 ", VMCommandTimeOut);
                reg.EnterCommand("SENDCMD " + vip.VPARS + " ZKTSK ADD FMSG-\"\"ZCP SMSG VPSERV EXTEND\"\" MIN-59 (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                reg.EnterCommand("SENDCMD " + vip.VPARS + " ZKTSK ADD DAILY-10.51 FMSG-\"\"ZCYCL 1052\"\" (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                reg.EnterCommand("SENDCMD " + vip.VPARS + " ZKTSK ADD DAILY-10.52 FMSG-\"\"ZCP LOG\"\" (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                reg.EnterCommand("SENDCMD " + vip.VPARS + " ZKTSK ADD FMSG-\"ZCP SMSG VPSERV EXTEND\" MIN-59 (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                reg.EnterCommand("SENDCMD " + vip.VPARS + " ZKTSK ADD DAILY-10.51 FMSG-\"ZCYCL 1052\" (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                reg.EnterCommand("SENDCMD " + vip.VPARS + " ZKTSK ADD DAILY-10.52 FMSG-\"ZCP LOG\" (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                reg.EnterCommand("SENDCMD " + vip.VPARS + " ZTTCP DISP ALL (L=999 KEEP DEST=PRODREGG SUMMARY A", VMCommandTimeOut);
                if (reg.WaitforString("OSA1PRIV  ACTIVE", 10) == 0)
                {
                    HandleError("OSA Inactive for " + vip.VIPNAME + "(" + vip.VPARS + "). Retrying to get and IP in 5 minutes.", ErrorTypes.LogOnly);
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZOSAE DELETE OSA-OSA1PRIV (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZCP SM IPSERV2 GETIP (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                    for (int i = 0; i < 5; i++)
                    {
                        reg.EnterCommand("SENDCMD " + vip.VPARS + " ZTTCP DISP ALL (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                        if (reg.WaitforString("OSA1PRIV  ACTIVE", 60) > 0)
                        {
                            //vip.IP = reg.GetLines(50).First(l => l.ToUpper().Contains("OSA1PRIV  ACTIVE")).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[3];
                            break;
                        }
                        else
                            if (i == 4)
                            //if (!HandleError("OSA Inactive for " + vip.VIPNAME + "(" + vip.VPARS + "). Retrying didn't work.", ErrorTypes.NotifyandWait, ErrorGroup.OSA_ERROR_AFTER_RETRY))
                            if (!HandleError("OSA Inactive for " + vip.VIPNAME + "(" + vip.VPARS + "). Retrying didn't work.", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.OSA_ERROR_AFTER_RETRY))
                                return false;
                    }

                }
                else
                {
                    //vip.IP = reg.GetLines(50).First(l => l.ToUpper().Contains("OSA1PRIV  ACTIVE")).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[3];
                }

                if (Runsettings.RegType != "DRB") //no HSM for DRB
                {
                    Result = AttachHSM(vip.VPARS, Runsettings.HSMUnit);

                    if (!vip.VIPNAME.Contains("E")) // Do not attatch 2nd HSM on VIPE//Saumen030317
                        Result &= AttachHSM(vip.VPARS, Runsettings.HSMUnit);

                    if (!Result)
                        Result = HandleError("HSM not attached properly in " + vip.VIPNAME, Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.NO_FREE_HSM);
                    //Result = HandleError("HSM not attached properly in " + vip.VIPNAME, ErrorTypes.NotifyandWait, ErrorGroup.NO_FREE_HSM);
                    if (!Result)
                        return Result;

                }
                if (Runsettings.RegType == "PRODD" || Runsettings.RegType == "DURBIN" || Runsettings.RegType == "UNBALANCED")
                {
                    reg.EnterCommand("PIPE LITERAL -------------------------------------------- |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                    reg.EnterCommand("PIPE LITERAL MDSKEYS " + vip.VPARS + " |>> PRODREGG SUMMARY A1", 1);
                    reg.EnterCommand("PIPE CMS MDSKEYS " + vip.VPARS, 2);
                    reg.EnterCommand("PIPE CMS MDSKEYS " + vip.VPARS + " | >> PRODREGG SUMMARY A1", 2);
                    reg.EnterCommand("PIPE CMS SENDCMD " + vip.VPARS + " ZQDKE QREP (L=999 KEEP DEST=PRODREGG SUMMARY A1", 1);
                    reg.EnterCommand("PIPE CMS SENDCMD " + vip.VPARS + " ZKTSK MOD PGM-DKEA MIN-6 (L=999 KEEP DEST=PRODREGG SUMMARY A1", 1);
                    reg.EnterCommand("PIPE CMS SENDCMD " + vip.VPARS + " ZQOKE START (L=999 KEEP DEST=PRODREGG SUMMARY A1", 1);
                    reg.EnterCommand("PIPE LITERAL -------------------------------------------- |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                }
                //Switch 3 ON/OFF Logic
                if (Runsettings.RegType == "ECIP" || Runsettings.RegType == "TOKEN")
                {
                    //ZKSWT 03 MOD RTN-820521 P-NOW
                    //ZKSWT 03 ON RTN-820521
                    reg.EnterCommand("TPFOPR " + vip.VPARS + " ZKSWT 03 MOD RTN-820521 P-NOW", 1);
                    reg.WaitforString("Ready", 5);
                    reg.EnterCommand("TPFOPR " + vip.VPARS + " ZKSWT 03 ON RTN-820521", 1);
                    reg.WaitforString("Ready", 5);
                    // added on 07/27/2016 by Rakesh
                    reg.EnterCommand("TPFOPR " + vip.VPARS + " ZKSET APSD2N");
                    reg.WaitforString("Ready", 5);
                }
                else
                {
                    reg.EnterCommand("TPFOPR " + vip.VPARS + " ZKSWT 03 OFF RTN-820521", 1);
                    reg.WaitforString("Ready", 5);
                }

                if (Runsettings.RegType == "ECIP" || Runsettings.RegType == "UNBALANCED")
                {
                    reg.EnterCommand("TPFZMS " + vip.VPARS + " DWP RECOVERY (NODISPLAY", VMCommandTimeOut);
                    reg.WaitforString("Ready", 180);
                    reg.EnterCommand("TPFZMS " + vip.VPARS + " DWP ALL-STN (NODISPLAY", VMCommandTimeOut);
                    reg.WaitforString("Ready", 180);
                    reg.EnterCommand("TPFZMS " + vip.VPARS + " ZKADV DWPBIN (NODISPLAY", VMCommandTimeOut);
                    reg.WaitforString("Ready", 180);
                }

                if (Runsettings.RegType == "TOKEN")
                {
                    if (vip.VIPNAME.Contains("A") || Runsettings.VIPS.Where(v => v.VPARS != "").Count() == 1)
                    {
                        reg.EnterCommand("REIPL 1G", VMCommandTimeOut);
                        reg.WaitforString("Ready", 20);
                        //reg.EnterCommand("GET RBARIK6", VMCommandTimeOut);
                        //reg.EnterCommand("Get Testcase", VMCommandTimeOut);
                        //GGIRDHAR030717 - Test Framework Enhancement
                        if (InputFile.TestRun)
                        {
                            reg.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
                        }
                        //GGIRDHAR030717 - Test Framework Enhancement
                        reg.EnterCommand("GET VIPQAAUT", VMCommandTimeOut);//Saumen021417
                        reg.EnterCommand("GETD TEMP 1080CYL Z", VMCommandTimeOut);
                        reg.WaitforString("Ready", 100);
                        //reg.EnterCommand("ACCESS VM3:TESTCASE.VIPQAAUTOMATION X ( FORCERW", VMCommandTimeOut);
                        reg.EnterCommand("ACCESS VM3:VIPQAAUT.VIPQAAUTOMATION X ( FORCERW", VMCommandTimeOut);//Saumen021417
                        reg.WaitforString("Ready", 20);
                        String[] Buck = Runsettings.Bucket.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        reg.EnterCommand("ETC -1 " + vip.VPARS + " (" + Buck[0] + " (" + Buck[1], VMCommandTimeOut);
                        reg.WaitforString("Ready", 180);
                    }

                }

                //Removing Special for FTPCDB. Its now common
                //if (vip.VIPNAME.Contains("C") || Runsettings.VIPS.Where(v => v.VPARS != "").Count() == 1)
                //{
                //    reg.EnterCommand("PIPE LITERAL FTPVIP Started with " + "CDB" + Runsettings.RegCapture + " |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                //    reg.EnterCommand("PIPE CMS FTPVIP " + vip.VPARS + " CDB" + Runsettings.RegCapture + " |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                //    if (reg.WaitforString("Ready;", 40) > 0)
                //        reg.EnterCommand("PIPE LITERAL FTPVIP Successful. |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                //    else
                //        reg.EnterCommand("PIPE LITERAL FTPVIP Unsuccessful. |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                //    reg.Pause(10);
                //    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUCDB ALPREW STATUS (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                //    if (reg.WaitforString("Total Updates:      0", 10) > 0)
                //        HandleError("FTPCDB is unsuccessful.", ErrorTypes.NotifyAndLog, ErrorGroup.FTP_ERROR);
                //    /// Note: Check for Sync status TODO 
                //}
                //TODO:RTD
                if (vip.VIPNAME.Contains("B") || Runsettings.VIPS.Where(v => v.VPARS != "").Count() == 1)
                {
                    foreach (var item in Runsettings.FTPFiles.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        reg.EnterCommand("PIPE LITERAL FTPVIP Started with " + item.ToUpper().Trim() + " |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                        reg.EnterCommand("PIPE CMS FTPVIP " + vip.VPARS + " " + item.ToUpper().Trim() + " |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
//GGIRDHAR021617                        if (reg.WaitforString("Ready;", 40) > 0)
                        if (reg.WaitforString("Ready;", 120) > 0)                                                            //GGIRDHAR021617 - Change the Time to 2 minutes
                            reg.EnterCommand("PIPE LITERAL FTPVIP Successful. |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                        else
                        {
                            reg.EnterCommand("PIPE LITERAL FTPVIP Unsuccessful. |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                            HandleError("FTPVIP with " + item + " is unsuccessful.", ErrorTypes.NotifyAndLog, ErrorGroup.FTP_ERROR);
                        }

                    }
                    reg.Pause(20);
                    if (Runsettings.FTPFiles.ToUpper().Contains("CDB"))
                    {
                        //Check th FTPCDB status here
                        //Saumen012717
                        //reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUCDB ALPREW STATUS (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                        //GGIRDHAR021717                        reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUBTU ALPR STATUS (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                        //Saumen012717
                        //GGIRDHAR021617                        if (reg.WaitforString("Total Updates:      0", 10) > 0)
                        //GGIRDHAR021717                        if (reg.WaitforString("Updates Successful:   0", 10) > 0)                                           //GGIRDHAR021617 - Change the Display check to relevant one - TOTAL Update is Outdated
                        //GGIRDHAR021717                        HandleError("FTPCDB is unsuccessful.", ErrorTypes.NotifyAndLog, ErrorGroup.FTP_ERROR);
                        // The above block is commented to take care of both ZUCDB as well as ZUBTU displays for CDB

                        //GGIRDHAR021717 - Check both ZUCDB as well as ZUBTU Status
                        reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUCDB ALPREW STATUS (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                        //if (reg.WaitforString("Total Updates:", 10) != 0)
                        //{
                        if (reg.WaitforString("Total Updates:      0", 10) != 0)
                        {
                            reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUBTU ALPR STATUS (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                            if (reg.WaitforString("Updates Successful:   0", 10) != 0)                                           //GGIRDHAR021617 - Change the Display check to relevant one - TOTAL Update is Outdated
                            {
                                HandleError("FTPCDB is unsuccessful.", ErrorTypes.NotifyAndLog, ErrorGroup.FTP_ERROR);
                            }
                        }
                        //else
                        //{
                        //}
                        //}
                        //else
                        //{
                        //    HandleError("FTPCDB is unsuccessful.", ErrorTypes.NotifyAndLog, ErrorGroup.FTP_ERROR);
                        //}
                        //GGIRDHAR021717 - End of the Block
                    }
                    if (Runsettings.FTPFiles.ToUpper().Contains("TAG"))
                    {
                        //Check th FTPCDB status here
                        reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUBTU TTAG STATUS (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                        if (reg.WaitforString("Updates Successful:   0", 10) > 0)
                            HandleError("FTP of Travel Tag is unsuccessful.", ErrorTypes.NotifyAndLog, ErrorGroup.FTP_ERROR);  // SKD04142017 - Handle Error String has been modified so that we can take a look from where there error is thrown 
                    }
                    //CUPLOAD here
                    foreach (var cup in Runsettings.CUPTapes.Split(new String[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        reg.EnterCommand("PIPE LITERAL CUPLOAD Started with " + cup.Trim() + " |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                        reg.EnterCommand("TPFPROC CUPLOAD " + vip.VPARS + " " + cup.Trim() + " (NODISPLAY", VMCommandTimeOut);
                        if (reg.WaitforString("Ready;", 5 * 60) > 0)
                            reg.EnterCommand("PIPE LITERAL CUPLOAD Successful. |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                        else
                        {
                            reg.EnterCommand("PIPE LITERAL CUPLOAD Unsuccessful |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                            HandleError("CUPLOAD with " + cup + " is unsuccessful.", ErrorTypes.NotifyAndLog, ErrorGroup.CUPLOAD_ERROR);
                        }
                    }
                }
                //reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUODF DIR ALL (L=999 KEEP DEST=PRODREGG DUMPS A1 NODISP", VMCommandTimeOut);
                reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUODF DIR (L=999 KEEP DEST=PRODREGG DUMPS A1 NODISP", VMCommandTimeOut);//Saumen031317
                reg.WaitforString("Ready;", 60);
                reg.EnterCommand("REGP5VIP 3", VMCommandTimeOut);
                reg.EnterCommand(vip.VPARS + " BPROD ZBURZ *", VMCommandTimeOut, false);
                reg.WaitforString("ZBURZ Execution Complete", 10 * 60);
                if (Runsettings.RegType == "STIPD")
                    reg.EnterCommand("PIPE CMS TPFOPR " + vip.VPARS + " ZKSET STIPON |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                #region APF Special

                // Special for APF
                if (Runsettings.RegType == "APF")
                {
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZURSI SET IPA-10.55.27.21 (L=999 KEEP DEST=apf log a1", 1);
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUCSI SET IPA-10.55.27.21 (L=999 KEEP DEST=apf log a1", 1);
                    if (vip.VIPNAME.Contains("A"))
                    {
                        reg.EnterCommand("SENDCMD " + vip.VPARS + " ZURSI SET PORT-51111 (L=999 KEEP DEST=apf log a1", 1);
                        reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUCSI SET PORT-51111 (L=999 KEEP DEST=apf log a1", 1);
                    }
                    else
                    {
                        reg.EnterCommand("SENDCMD " + vip.VPARS + " ZURSI SET PORT-51112 (L=999 KEEP DEST=apf log a1", 1);
                        reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUCSI SET PORT-51112 (L=999 KEEP DEST=apf log a1", 1);
                    }
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZKTSK MOD P-DDAB M-10 SP-SC A-SMS I-SG (L=999 KEEP DEST=apf log a1", 1);
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZURSI SET OLDR-10 SLEEP-1000 ZONE-20 RETRY1-1 RETRY2-10 MAXR-3 (L=999 KEEP DEST=apf log a1", 1);
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUCSI SET OLDR-10 SLEEP-1000 ZONE-20 RETRY1-1 RETRY2-10 MAXR-3 (L=999 KEEP DEST=apf log a1", 1);
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZKTSK STOP", 1);
                    reg.EnterCommand("TPFPROC RSIINIT " + vip.VPARS, 1);
                    if (reg.WaitforString("Ready;", 5 * 60) <= 0)
                        HandleError("RSIINIT is not completed properly in 5 minutes.", ErrorTypes.NotifyAndLog, ErrorGroup.NOT_CLASSIFIED_ERROR);
                    reg.EnterCommand("TPFPROC CSIINIT " + vip.VPARS, 1);
                    if (reg.WaitforString("Ready;", 5 * 60) <= 0)
                        HandleError("CSIINIT is not completed properly in 5 minutes.", ErrorTypes.NotifyAndLog, ErrorGroup.NOT_CLASSIFIED_ERROR);
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZURSI PARMS (L=999 KEEP DEST=apf log a1", 1);
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUCSI PARMS (L=999 KEEP DEST=apf log a1", 1);
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZURSI ACT (L=999 KEEP DEST=apf log a1", 10);
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZURSI STATUS (L=999 KEEP DEST=apf log a1", 1);
                    if (reg.WaitforString("Send process active. Socket ID", 10) <= 0)
                    {
                        Result = HandleError("Connection between VIP and APF(RSI) is NOT established successfully", ErrorTypes.NotifyandWait, ErrorGroup.NOT_CLASSIFIED_ERROR);
                        if (!Result)
                            return Result;
                    }
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUCSI ACT (L=999 KEEP DEST=apf log a1", 10);
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUCSI STATUS (L=999 KEEP DEST=apf log a1", 1);
                    if (reg.WaitforString("Send process active. Socket ID", 10) <= 0)
                    {
                        Result = HandleError("Connection between VIP and APF(CSI) is NOT established successfully", ErrorTypes.NotifyandWait, ErrorGroup.NOT_CLASSIFIED_ERROR);
                        if (!Result)
                            return Result;
                    }
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZKTSK START", 1);

                }
                //End of APF Special
                #endregion
            }
            ///////////// CHECK DUMPS using UNIDUMPS//////////////////
            UNIDUMPS(String.Join(" ", Runsettings.VIPS
                                                    .Where(vic => !String.IsNullOrWhiteSpace(vic.VPARS))
                                                    .Select(vic => vic.VPARS).ToList()), "After FTPVIP and CUPLOAD"
                    );
            ////////////////////////////////////////// LOG CDB and TTAG /////////////////////////////////////////////////////////////////
            string cdbfile = "CDB" + Runsettings.RegCapture;
            reg.EnterCommand("PIPE CMS PARSEM " + cdbfile + " (For 3 CONSOLE|DROP 2|TAKE 1|SPECS W6 1|CONSOLE");    // PAN from CDB file
            Match cdb_pan = reg.WaitForRegex(new Regex(@"(?'pan'\d+).*\n.*(Ready;).*", RegexOptions.Multiline), 5, false);


            string tagfile = Runsettings.FTPFiles
                                         .Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                         .FirstOrDefault(fl => fl.ToUpper().Contains("TAG"));            // GET THE TAG FILE NAME

            reg.EnterCommand("PIPE CMS PARSEM " + tagfile + " (For 3 CONSOLE|DROP 2|TAKE 1|SPECS W6 1|CONSOLE");    // PAN from TAG file
            Match tag_pan = reg.WaitForRegex(new Regex(@"(?'pan'\d+).*\n.*(Ready;).*", RegexOptions.Multiline), 5, false);

            Runsettings.VIPS
                .Where(v => !String.IsNullOrWhiteSpace(v.VPARS))
                .ToList()
                .ForEach((vip) =>
                {
                    ////////////////////////////////// Check for CDB SYNC //////////////////////////////////////////////
                    //ZKPAN XXXXXX310027809 PFO                                                
                    reg.EnterCommand("pipe cms SENDCMD " + vip.VPARS + " ZKPAN " + cdb_pan.Groups["pan"].Value + " PFO |>> PRODREGG SUMMARY A1");
                    //ZKPAN XXXXXX068668755                                                    
                    reg.EnterCommand("pipe cms SENDCMD " + vip.VPARS + " ZKPAN " + cdb_pan.Groups["pan"].Value + " |>> PRODREGG SUMMARY A1");

                    /////////////////////////////////// Check for TTAG ////////////////////////////////////////////////
                    //ZKPAN XXXXXX102158013 TRT                                                
                    reg.EnterCommand("pipe cms SENDCMD " + vip.VPARS + " ZKPAN " + tag_pan.Groups["pan"].Value + " TRT |>> PRODREGG SUMMARY A1");
                    //ZKPAN XXXXXX068668755                                                    
                    reg.EnterCommand("pipe cms SENDCMD " + vip.VPARS + " ZKPAN " + tag_pan.Groups["pan"].Value + " |>> PRODREGG SUMMARY A1");
                });

            if (Result)
                AddOrUpdateStageLog(null, "Successful.", false);
            else
                AddOrUpdateStageLog(null, "Unsuccessful. Error: " + error, false);

            return Result;
        }

        private void EraseOldFiles()
        {
            //reg.EnterCommand("GET TESTCASE");
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                reg.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            reg.EnterCommand("GET VIPQAAUT");//Saumen021417
            reg.EnterCommand("DANGER");
            reg.WaitforString("Ready", 15);
        }
        /// <summary>
        /// Runs APROD zburz and DKEVALID
        /// </summary>
        private void RunAPROD()
        {
            AddOrUpdateStageLog("Run APROD ZBURZ", "Running...", true);
            // reg.EnterCommand("PIPE LITERAL DUMPS AFTER REGRESSION RUN: |>> PRODREGG DUMPS A1", VMCommandTimeOut);
            if (Runsettings.RegType == "ECIP" || Runsettings.RegType == "UNBALANCED")
            {
                reg.EnterCommand("REGP5VIP 8", VMCommandTimeOut);
                reg.EnterCommand(string.Concat(Runsettings.VIPS.Where(v => v.VPARS != "").Select(v => v.VPARS + " ")), 1, false);
                reg.WaitforString("All Advices cleared", 10 * 60);
            }
            foreach (VIP vip in Runsettings.VIPS.Where(v => v.VPARS != "" && v.VPARS != null))
            {
                //reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUODF DIR ALL (L=999 KEEP DEST=PRODREGG DUMPS A1", VMCommandTimeOut);
                //reg.WaitforString("Ready;", 60);
                if (Runsettings.RegType == "PRODD" || Runsettings.RegType == "UNBALANCED")
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZQOKE STOP(L=999 KEEP DEST=PRODREGG SUMMARY A1", 1);
                reg.EnterCommand("REGP5VIP 3", VMCommandTimeOut);
                reg.EnterCommand(vip.VPARS + " APROD ZBURZ *", VMCommandTimeOut, false);
                reg.WaitforString("ZBURZ Execution Complete", 10 * 60);

                if (Runsettings.RegType == "ECIP" || Runsettings.RegType == "UNBALANCED")
                {
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZSTIM INITIALIZE (L=999 KEEP DEST=PRODREGG SUMMARY A1", VMCommandTimeOut);
                    reg.WaitforString("Ready", 20);
                }
            }
            if (Runsettings.RegType == "PRODD" || Runsettings.RegType == "UNBALANCED")
            {
                string ALLVPARS = string.Concat(Runsettings.VIPS.Where(v => v.VPARS != "" && v.VPARS != null).Select(x => x.VPARS + " "));
                reg.EnterCommand("DKEVALID TESTKEYS CONTROL A1 DEST=Z (" + ALLVPARS.Trim(), 1);
                reg.WaitforString("Ready;", 30);
                reg.EnterCommand("COPY VALIDATE DKELOG Z KEYSYNC REPORT A1", 1);
            }

            reg.EnterCommand("PIPE LITERAL -----------------End of " + Runsettings.RegType + "--------------  |>> PRODREGG SUMMARY A1", 1);
            AddOrUpdateStageLog(null, "Successful.", false);

        }
        /// <summary>
        /// Checks for less than 80% usage on the A disk of logged in CMS
        /// </summary>
        /// <returns>true on enough available space else returns false</returns>
        private bool CheckSpace()
        {

            bool Result = true;
            string error = "";
            AddOrUpdateStageLog("Check space in " + Runsettings.VMID, "Running...", true);
            reg.EnterCommand("QUERY DISK", 1);

            //////////// update for AUTOREGs
            //string adisk = reg.GetLines(5).FirstOrDefault(l => l.Contains("DK0191 191  A") || l.Contains("DSK191 192  A") || l.Contains("DSK191 291  A") || l.Contains("DSK192 291  A")).ToUpper();
            string adisk = reg.GetLines(5).FirstOrDefault(l => l.Contains("A   R/W")).ToUpper();//Saumen032817

            if (!adisk.Contains("R/W") || Convert.ToInt16(adisk.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[8].Split('-')[1]) > 85)
            {
                error = "Either A disk is R/W or A disk usage >85%";
                Result = HandleError(error, Runsettings.IsSchedulerRun ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.DISK_SPACE_ERROR);
                //Result = HandleError(error, ErrorTypes.NotifyandWait, ErrorGroup.DISK_SPACE_ERROR);
            }
            if (Result)
                AddOrUpdateStageLog(null, "Successful.", false);
            else
                AddOrUpdateStageLog(null, "Unsuccessful. Error: " + error, false);
            return Result;
        }
        /// <summary>
        /// Counts the advices before retreival, retrieves the advices (by running the created ZKADV CASES bucket) and then counts the advices after retrieval
        /// Statlogs and output files are created for advices
        /// </summary>
        /// <returns>true on success and false on failure</returns>
        private bool AdviceRetrieval()
        {
            if (!Runsettings.IsAdviceRetrieve)
                return true;
            bool Result = true;
            string error = String.Empty;
            AddOrUpdateStageLog("Count Advice before retrieval", "Running...", true);

            string ALLVPARS = string.Concat(Runsettings.VIPS.Where(v => v.VPARS != "" && v.VPARS != null).Select(x => x.VPARS + " ")).Trim();
            reg.EnterCommand("ZKADV " + ALLVPARS.Trim() + "(ALL", VMCommandTimeOut);

            if (reg.WaitforString("Ready;", 20 * 60) == 0)
            {
                reg.EnterCommand("b", 1);
                //Implement handle error when ZKADV was not completed; 
                if (reg.WaitforString("Ready;", 20 * 60) == 0)
                {
                    if (!HandleError("ZKADV <PRODD IDs>(ALL command was not executed in 40 minutes!", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.LogandWait, ErrorGroup.VM_TOOLS_ERROR))
                        return false;
                }
            }
            reg.EnterCommand("RENAME ZKADV OUTPUT A1 ZKADV BCOUNT A1", VMCommandTimeOut);
            if (Runsettings.RegType == "ECIP")
            {
                reg.EnterCommand("PIPE LITERAL -------------------------------------------- |>> ZKADV BCOUNT A1", 1);
                reg.EnterCommand("PIPE LITERAL PUTPENDING ADVICE COUNT BEFORE RETRIEVAL: |>> ZKADV BCOUNT A1", 1);
                reg.EnterCommand("PIPE LITERAL -------------------------------------------- |>> ZKADV BCOUNT A1", 1);
                foreach (VIP vip in Runsettings.VIPS.Where(v => v.VPARS != "" && v.VPARS != null))
                {
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZKADV COUNT PCR SMS DWP (L=999 KEEP DEST=ZKADV BCOUNT A1", 1);
                    reg.WaitforString("Ready;", 10);
                }
            }
            if (Runsettings.RegType == "SOAP")// || Runsettings.RegType == "1VIP" || Runsettings.RegType == "SOAP+1VIP")
            {
                reg.EnterCommand("REGP5VIP 6", VMCommandTimeOut);
                reg.EnterCommand(ALLVPARS, VMCommandTimeOut, false);
                reg.WaitforString("Ready", 10 * 60);
                reg.EnterCommand("ERASE ZKADV XML A1", VMCommandTimeOut);
                reg.EnterCommand("RENAME ZKADV CASES A1 ZKADV XML A1", VMCommandTimeOut);
                reg.EnterCommand("ZKADV " + ALLVPARS.Trim() + "(ALL", VMCommandTimeOut);
                if (reg.WaitforString("Ready;", 20 * 60) == 0)
                {
                    reg.EnterCommand("id", 1);
                    reg.WaitforString("Ready;", 20 * 60);
                }
            }
            reg.EnterCommand("TPFZMS " + Runsettings.VIPS.First(v => v.VPARS != "" && v.VPARS != null).VPARS + " ZKADV ZBURZ (NODISPLAY", VMCommandTimeOut);
            if (reg.WaitforString("Ready", 45 * 60, new List<string>() { "Ready(" }, out error) == 1)
            {
                if (error == "Ready(")
                {
                    reg.EnterCommand("TPFZMS " + Runsettings.VIPS.First(v => v.VPARS != "" && v.VPARS != null).VPARS + " ZKADV ZBURZ (NODISPLAY", VMCommandTimeOut);
                    reg.WaitforString("Ready", 45 * 60);
                }
            }
            AddOrUpdateStageLog(null, "Successful.", false);
            ParsemSetup("ADVICE");
            if (!RunBucket("ZKADV CASES"))
                return false;

            // Not Needed Prashant [05/10/2016]
            //reg.EnterCommand("PIPE LITERAL DUMPS AFTER ADVICE RETRIEVAL: |>> DUMPS ALOG A1", VMCommandTimeOut);
            //foreach (VIP vip in Runsettings.VIPS.Where(v => v.VPARS != "" && v.VPARS != null))
            //{
            //    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZUODF DIR ALL (L=999 KEEP DEST=DUMPS ALOG A1 NODISP", VMCommandTimeOut);
            //    reg.WaitforString("Ready;", 60);
            //}

            AddOrUpdateStageLog("Count Advice after retrieval", "Running...", true);
            reg.EnterCommand("ZKADV " + ALLVPARS.Trim() + "(ALL", VMCommandTimeOut);
            if (reg.WaitforString("Ready;", 20 * 60) == 0)
            {
                reg.EnterCommand("b", 1);
                //Implement handle error when ZKADV was not completed; 
                if (reg.WaitforString("Ready;", 20 * 60) == 0)
                {
                    if (!HandleError("ZKADV <PRODD IDs>(ALL command was not executed in 40 minutes!", Runsettings.IsSchedulerRun ? ErrorTypes.NotifyAndLog : ErrorTypes.LogandWait, ErrorGroup.VM_TOOLS_ERROR))
                        return false;
                }
            }
            reg.EnterCommand("RENAME ZKADV OUTPUT A1 ZKADV ACOUNT A1", VMCommandTimeOut);
            if (Runsettings.RegType == "ECIP")
            {
                reg.EnterCommand("PIPE LITERAL PUTPENDING ADVICE COUNT BEFORE RETRIEVAL: |>> ZKADV ACOUNT A1", 1);
                foreach (VIP vip in Runsettings.VIPS.Where(v => v.VPARS != "" && v.VPARS != null))
                {
                    reg.EnterCommand("SENDCMD " + vip.VPARS + " ZKADV COUNT PCR SMS DWP (L=999 KEEP DEST=ZKADV ACOUNT A1", 1);
                    reg.WaitforString("Ready;", 10);
                }
            }
            if (Result)
                AddOrUpdateStageLog(null, "Successful.", false);
            else
                AddOrUpdateStageLog(null, "Unsuccessful. Error: " + error, false);

            return Result;
        }
        /// <summary>
        /// Parsem settings for the given regression type is set using GLOBALV  
        /// </summary>
        /// <param name="TYPE">type of regression to set parsem settings for</param>
        private void ParsemSetup(string TYPE)
        {
            TYPE = TYPE.ToUpper();
            reg.EnterCommand("ANALYSIS GLOBALV " + Runsettings.VIPS.First(v => v.VPARS != "" && v.VPARS != null).VPARS + " FULL_CYCLE", VMCommandTimeOut);
            //reg.EnterCommand("GLOBALV SELECT PARSEM SET VPARS_SYS.1 " + Runsettings.VIPS.First(v => v.VPARS != "" && v.VPARS != null).VPARS, VMCommandTimeOut);
            reg.EnterCommand("GLOBALV SELECT PARSEM SET AUTO_SEND 1", VMCommandTimeOut);
            reg.EnterCommand("GLOBALV SELECT PARSEM SET INSERT_RESPONSE 1", VMCommandTimeOut);
            reg.EnterCommand("GLOBALV SELECT PARSEM SET PRODD 1", VMCommandTimeOut);
            reg.EnterCommand("GLOBALV SELECT PARSEM SET REPLAY_VICS 1", VMCommandTimeOut);
            reg.EnterCommand("GLOBALV SELECT PARSEM SET VMLH 1 OSA_PLATFORM EASI MCASE_PLATFORM 0", VMCommandTimeOut);
            if (TYPE == "PRODD" || TYPE == "UNBALANCED")
            {
                reg.EnterCommand("GLOBALV SELECT PARSEM SET AUTO_RESPOND 0", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET RESPOND_UNSO 0", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET VPARS_WAITTIME 20", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET ECB_COUNT 20", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET STIPMODE 0", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET PRODKEYS 1", VMCommandTimeOut);
            }
            else if (TYPE == "ECIP")
            {
                reg.EnterCommand("GLOBALV SELECT PARSEM SET AUTO_RESPOND 1", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET RESPOND_UNSO 1", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET VPARS_WAITTIME 15", VMCommandTimeOut); //Make wait time 15
                reg.EnterCommand("GLOBALV SELECT PARSEM SET ECB_COUNT 1", VMCommandTimeOut); // Change ECB Count to 1
                reg.EnterCommand("GLOBALV SELECT PARSEM SET STIPMODE 0", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET PRODKEYS 0", VMCommandTimeOut);
            }
            else if (TYPE == "TOKEN_AUTH")                                                      //For TPW Token Auth Bucket Processing 
            {
                reg.EnterCommand("GLOBALV SELECT PARSEM SET AUTO_RESPOND 1", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET RESPOND_UNSO 0", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET VPARS_WAITTIME 20", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET ECB_COUNT 20", VMCommandTimeOut); 
                reg.EnterCommand("GLOBALV SELECT PARSEM SET STIPMODE 0", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET PRODKEYS 0", VMCommandTimeOut);
            }
            else if (TYPE == "STIPD")
            {
                reg.EnterCommand("GLOBALV SELECT PARSEM SET AUTO_RESPOND 0", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET RESPOND_UNSO 0", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET VPARS_WAITTIME 20", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET ECB_COUNT 20", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET STIPMODE 1", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET PRODKEYS 0", VMCommandTimeOut);
            }
            else if (TYPE == "ADVICE")
            {
                reg.EnterCommand("GLOBALV SELECT PARSEM SET AUTO_RESPOND 1", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET RESPOND_UNSO 1", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET VPARS_WAITTIME 30", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET ECB_COUNT 10", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET STIPMODE 0", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET PRODKEYS 0", VMCommandTimeOut);
            }
            else
            {
                reg.EnterCommand("GLOBALV SELECT PARSEM SET AUTO_RESPOND 0", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET RESPOND_UNSO 0", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET VPARS_WAITTIME 20", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET ECB_COUNT 20", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET STIPMODE 0", VMCommandTimeOut);
                reg.EnterCommand("GLOBALV SELECT PARSEM SET PRODKEYS 0", VMCommandTimeOut);
            }
        }
        /// <summary>
        /// gets a space separated list of tape types to cut, depending on the given regression type 
        /// </summary>
        /// <param name="Regtype">Type of regression</param>
        /// <returns>a space separated list of tape types to cut </returns>
        private string GetTapestoCut(string Regtype)
        {
            string tapes2cut = "";
            switch (Regtype)
            {
                case "PRODD":
                case "BADD":
                case "DURBIN":
                    //tapes2cut = "RSI CSI DTD ICX";
                    tapes2cut = "RSI CSI DTD";//Saumen030617
                    break;
                case "SOAP":
                    //tapes2cut = "RSI CSI DTD ETPD ICX";
                    tapes2cut = "RSI CSI DTD";//Saumen030617
                    break;
                case "STIPD":
                case "PCAS":
                case "BADD+PCAS":                                   //fall forward :: added the commit 9a1733512c3 (VIPENG-218) back to fix VIPENG-1118
                    //tapes2cut = "RSI CSI DTD ETPD ICX";
                    tapes2cut = "RSI CSI DTD";//Saumen030617
                    break;
                case "DRB":
                    //tapes2cut = "RSI DTD ETPD";
                    tapes2cut = "RSI DTD";//Saumen030617
                    break;
                case "ECIP":
                case "TOKEN":
                    //tapes2cut = "RSI CSI DTD ETPD ICX TKN";
                    tapes2cut = "RSI CSI DTD TKN";//Saumen030617
                    break;
                case "UNBALANCED":
                    tapes2cut = "RSI CSI DTD";
                    break;
                default:
                    break;
            }
            return tapes2cut;
        }
        /// <summary>
        /// Analyzes the success of the run by parsing various fetched files in the regression folder.
        /// Appropriate flags and percentages are written in the "Preliminary Analysis-coderun.txt" file
        /// </summary>
        private void PerformPreliminaryAnalysis()
        {
            try
            {
                AddOrUpdateStageLog("Preliminary Analysis", "Running...", true);

                PreliminaryAnalysis prelim = new PreliminaryAnalysis(Runsettings.CoderunServer);
                prelim.CalculateRegressionScore();

                System.IO.File.WriteAllLines(System.IO.Path.Combine(Runsettings.CoderunServer, "Preliminary Analysis-coderun.txt"), prelim.printChecks());

                if (prelim.AreChecksValid())
                //Saumen031017
                {
                    File.Create(Path.Combine(Runsettings.CoderunServer, ".CanBeUsedAsBaseRun")).Dispose();
                    if (Runsettings.RegType.Contains("TOKEN") || Runsettings.RegType.Contains("UNBALANCED"))
                    {
                        File.Create(Path.Combine(Runsettings.CoderunServer, ".ResultCanBeDistributed")).Dispose();
                    }
                }
                //Saumen031017
                AddOrUpdateStageLog(null, "Done", false);
            }
            catch (Exception ex)
            {
                System.IO.File.WriteAllText(System.IO.Path.Combine(Runsettings.CoderunServer, ex.GetHashCode() + ".exception"), ex.ToString());
                AddOrUpdateStageLog("Preliminary Analysis", "Failed", false);
            }

        }

        #endregion

        #region Mail Generation
        private void MailGenerate()
        {
            AddOrUpdateStageLog("Mail Creation", "Running...", true);
            try
            {
                using (OutlookEmail mail = new OutlookEmail(Runsettings))
                {
                    mail.StoreAsJson(Runsettings.CoderunServer + @"\Mail.json");
                    mail.SaveAndSendEmail();
                }
                AddOrUpdateStageLog(null, "Mail saved and sent successfully.", false);
            }
            catch (Exception ex)
            {
                HandleError("Mail error:" + ex.Message, ErrorTypes.LogOnly, ErrorGroup.COM_ERROR);
                AddOrUpdateStageLog(null, "Unsuccessful.", false);
            }
        }
        #endregion

        #region ErrorHandle
        /// <summary>
        /// halts the execution of any exec and ensures that the VM_wnd is at Ready screen\, throws an Exception
        /// </summary>
        private void doHX()
        {
            reg.EnterCommand("HX");
            reg.WaitForRegexEx(new Regex(@"(CMS)|(Ready)"), 5);
            reg.EnterCommand("B");
            reg.WaitForRegexEx(new Regex(@"Ready;"), 3);
        }
        /// <summary>
        /// Return a true if you want continue else return false. 
        /// LogOnly-Return True
        /// NotifyOnly-Return True
        /// NotifyandAbort-Return False
        /// NotifyandWait-Returns True/False based on dialog result
        /// </summary>
        /// <param name="errorstring"></param>
        /// <param name="errortype"></param>
        /// <returns></returns>
        bool HandleError(string errorstring, ErrorTypes errortype, ErrorGroup ERRGRP = ErrorGroup.NOT_CLASSIFIED_ERROR, string subject = null, string emailid = null, bool attacherrorfile = true)
        {
            //Replace notify type in Scheduler run during call
            //For Notify and Abort rather than Notify and wait
            //Runsettings.IsSchedulerRun?ErrorTypes.NotifyandAbort:ErrorTypes.NotifyandWait
            //For Notify and Log rather than notify and wait
            //Runsettings.IsSchedulerRun?ErrorTypes.NotifyAndLog:ErrorTypes.NotifyandWait
            try
            {
                reg.SendText(Keys3270.Reset, false, false);
            }
            catch { }
            if (errortype != ErrorTypes.NotifyOnly)
            {
                ErrorsInRun.Insert(0, DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + "==> " + errorstring);
                System.IO.File.WriteAllLines(Runsettings.CoderunServer + @"\RunErrors.txt", ErrorsInRun);
            }
            try
            {
                if (ERRGRP != ErrorGroup.NO_ERROR)
                {
                    //Add error to ErrorDB csv file
                    //MM/dd/yyyy hh:mm:ss tt,"Error text",ErrorGroup
                    System.IO.File.AppendAllLines(App.RegressionErrorDBfile,
                        new string[] { DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + ",\""
                            + errorstring.Replace("\"", null) + "\","
                            + ERRGRP.ToString()+"," +
                            (Runsettings != null ?  Runsettings.InstallDate + "," + Runsettings.RegType + "," + Runsettings.RunNumber+","+(Runsettings.IsSchedulerRun?"Scheduler Run,":"UI Run,")+"\""+Runsettings.CoderunServer+"\"," : ",,,,,,")
                            +errortype.ToString() });
                }
            }
            catch
            { }
            try
            {
                // Store the screenshot file into coderun server
                System.IO.File.Copy(reg.screenshotfile, System.IO.Path.Combine(Runsettings.CoderunServer, System.IO.Path.GetFileName(reg.screenshotfile)), true);
                //  System.IO.File.Delete(reg.screenshotfile);
            }
            catch { }

            if (errortype != ErrorTypes.LogOnly)
            {
                new Thread(() =>
                {

                    Outlook.Application oApp; Outlook.MailItem oMsg; Outlook.Recipients oRecips; Outlook.Recipient oRecip;
                    try
                    {
                        if (errortype != ErrorTypes.LogandWait)
                        {
                            oApp = new Outlook.Application();
                            oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                            oRecips = (Outlook.Recipients)oMsg.Recipients;
                            if (emailid == null)
                                oRecip = (Outlook.Recipient)oRecips.Add(Runsettings.email + "@visa.com");
                            else
                                oRecip = (Outlook.Recipient)oRecips.Add(emailid + "@visa.com");
                            oRecip.Resolve();
                            if (subject == null)
                                oMsg.Subject = (Runsettings.VIPS.Where(v => v.VPARS != "" && v.VPARS != null).Count() + " VIP ").Replace("0 VIP ", "") + Runsettings.RegType + " Regression for " + Runsettings.InstallDate + " install (" + Runsettings.RunNumber + ") " + "- Error => " + errorstring;
                            else
                                oMsg.Subject = subject;
                            oMsg.BodyFormat = Outlook.OlBodyFormat.olFormatPlain;
                            oMsg.Body = Runsettings.CoderunServer;
                            if (attacherrorfile)
                            {
                                oMsg.Body += "\nPlease review the errors from attached file.\nAuto generated from QACT";
                                oMsg.Attachments.Add(Runsettings.CoderunServer + @"\RunErrors.txt");
                            }
                            else
                                oMsg.Body += "\nAuto generated from QACT";

                            ((Outlook._MailItem)oMsg).Send();
                        }

                    }
                    catch (Exception)
                    {

                    }
                    finally
                    {
                        oApp = null; oMsg = null; oRecip = null; oRecips = null;
                        //GGIRDHAR 01/23/2017 - Introduce GC for Outlook Object. The Entire Block Below takes care of disposing the Outlook Objects.
                        // GGIRDHAR - The Block starts here
                        if (oRecip != null || oRecips != null || oMsg != null || oApp != null)
                        {
                            try
                            {
                                Marshal.ReleaseComObject(oRecip);
                                oRecip = null;
                                Marshal.ReleaseComObject(oMsg);
                                oMsg = null;
                                Marshal.ReleaseComObject(oRecips);
                                oRecips = null;
                                Marshal.ReleaseComObject(oApp);
                                oApp = null;
                            }
                            catch (Exception)
                            {
                                oRecip = null;
                                oRecips = null;
                                oMsg = null;
                                oApp = null;
                            }
                            finally
                            {
                                GC.Collect();
                            }
                        }
                        // GGIRDHAR - The Block ends here
                    }

                }).Start();

                //if (Runsettings.IsSchedulerRun && (errortype == ErrorTypes.NotifyandWait || errortype == ErrorTypes.LogandWait || errortype == ErrorTypes.NotifyandAbort))
                //{/////////// Abort QACT only for scheduler only ////////////////////
                //    ErrorAbort();
                //    return false;
                //}
                if (errortype == ErrorTypes.NotifyandAbort)
                {
                    if (Runsettings.IsSchedulerRun)
                        ErrorAbort();
                    return false;
                }
                else if (errortype == ErrorTypes.NotifyandWait || errortype == ErrorTypes.LogandWait)
                {
                    if (MessageBox.Show("Press Yes to Continue, No to Abort\nError encountered:\n" + errorstring, "Regression Window - " + reg.SessionShortName, MessageBoxButton.YesNo, MessageBoxImage.Error, MessageBoxResult.Yes) == MessageBoxResult.No)
                        return false;
                }
            }
            return true;
        }

        string getexacterrorfromscreen(string errorkey)
        {
            try
            {
                var tmp = reg.GetLines(80).FirstOrDefault(l => l.ToUpper().Contains(errorkey.ToUpper()));
                if (tmp == null)
                    return errorkey;
                else
                    return tmp.Trim();
            }
            catch (Exception)
            {
                return errorkey;
            }
        }
        /// <summary>
        /// Closes QACT by releasing all the resources in the order VPARS-->CMS-->HLLAPI 
        /// </summary>
        public void ErrorAbort()
        {
            //Finishing Regression
            if (IsLoggedon)
            {
                try
                {
                    //Do a Page up +I cms
                    reg.SendText(Keys3270.PA1);
                    reg.EnterCommand("I CMS");
                    reg.SendText(Keys3270.Enter);
                    reg.WaitforString("Ready", 10);
                    //Upload RexxErrlog
                    UploadRexxErrorLog();
                    //
                    LogOffAllVPARS(Runsettings.VIPS.Where(v => !String.IsNullOrWhiteSpace(v.VPARS)).ToList());
                    if (HSM_PRODD77 == "DETACHED")                                                                  //Saumen090116
                    {
                        //Saumen082916
                        if (Runsettings.RegType != "DRB")
                        {
                            //Saumen030317
                            //if (Runsettings.RegType == "DURBIN" || Runsettings.RegType == "ECIP" || Runsettings.RegType == "UNBALANCED" || Runsettings.RegType == "PRODD" || Runsettings.RegType == "TOKEN")
                            //{
                            //Saumen030317
                            ReserveHSM("9", "ATTACH");
                            //Saumen030317
                            //}
                            //else
                            //{
                            //    ReserveHSM("5", "ATTACH");
                            //}
                            //Saumen030317
                        }
                        //Saumen082916
                    }
                }
                catch { }

                try
                {
                    LogOffCMS();
                }
                catch { }
            }
            //Remove the handler before aborting.
            this.RegressionCompleted -= StartArchesFile;
            reg.DisconnectSession();

            ////////////////////// UPdate stages to files ///////////////////////
            AddOrUpdateStageLog("Aborted", "Aborted", true, updateScheduler: false);                                  //Saumen082516
            if (App.InputObj != null)
            {
                App.InputObj.State = InputFile.Status.REGRESSION_COMPLETED;
                InputFile.UpdateStatus(App.InputObj, _RegStages.ElementAt(2).Stage + '\t' + _RegStages.ElementAt(2).Status + "Aborted");//Saumen092816
            }

            // Close QACT
            if (Application.Current != null)
                Application.Current.Dispatcher.Invoke(() =>
                {
                    try
                    {
                        IsIdle = true;
                        Application.Current.Shutdown(-1);
                    }
                    catch
                    {
                        Environment.Exit(-1);
                    }

                });
        }

        private void UploadRexxErrorLog()
        {
            //arinbhat05042017
            if (System.IO.File.Exists(System.IO.Path.Combine(Runsettings.CoderunServer, "REG LOG.txt")))
            {
                System.IO.File.Delete(System.IO.Path.Combine(Runsettings.CoderunServer, "REG LOG.txt"));
            }
            reg.ReceiveFile(System.IO.Path.Combine(Runsettings.CoderunServer, "REG LOG.txt"), "REG LOG A1"); //arinbhat05042017

            if (this.IsLoggedon)
            {

                try
                {
                    string tmpfilepath = Path.GetTempFileName();
                    reg.ReceiveFile(tmpfilepath, "QACTREXX ERRLOG   A1");
                    File.Copy(tmpfilepath, Path.Combine(Runsettings.CoderunServer, "QACTREXX_ERRLOG_regression.txt"), true);
                    if (!File.Exists(Path.Combine(App.AutomationFiles, "QACTREXX_ERRLOG_regression.txt")))
                        File.WriteAllLines(Path.Combine(App.AutomationFiles, "QACTREXX_ERRLOG_regression.txt"), File.ReadAllLines(tmpfilepath));
                    else
                        File.AppendAllLines(Path.Combine(App.AutomationFiles, "QACTREXX_ERRLOG_regression.txt"), new List<string>() { new string('-', 100), Runsettings.CoderunServer, new string('-', 100) }.Concat(File.ReadAllLines(tmpfilepath)));
                    File.Delete(tmpfilepath);
                }
                catch { };
            }
        }
        #endregion

        private void UpdateRunSettings(object sender, System.Windows.Data.DataTransferEventArgs e)
        {
            //if (!string.IsNullOrWhiteSpace(Runsettings.RegType) && Runsettings.RegType=="UNBALANCED")
            //{
            //    StepstoPerform.SetupCreate = false;
            //}
            Runsettings.PopulateDefaultSettings();
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            Runsettings = new RunSettings();
            StepstoPerform = new Steps();
            GLOBALS = new GlobalSet();
            pwdPassword.Password = string.Empty;
        }

        //Saumen082916
        private void ReserveHSM(string noofhsm, string option)
        {
            //reg.EnterCommand("GET TESTCASE", 2);                                                                    //Saumen090816
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                reg.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            reg.EnterCommand("GET VIPQAAUT", 2);//Saumen021417
            reg.EnterCommand("RESHSM " + noofhsm + " " + option, 2);
            if (reg.WaitforString("Processing completed successfully", 5) == 0)
            {
                if (reg.WaitforString("PRODD77 is LOGGED OFF", 5) != 0)
                {
                    reg.EnterCommand("PIPE LITERAL PRODD77 is LOGGED OFF |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                }
                else
                {
                    reg.EnterCommand("PIPE LITERAL HSM could not be " + option + "ED to/from PRODD77 |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                }
            }
            else
            {
                reg.EnterCommand("PIPE LITERAL " + noofhsm + " HSM successfully " + option + "ED to/from PRODD77 |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            }
        }
        //Saumen082916
    }

    public class GlobalSet : INotifyPropertyChanged
    {
        string _FXT, _DCS, _BMX, _NWK, _CFG;
        public string FXT { get { return this._FXT; } set { _FXT = value; NotifyPropertyChanged("FXT"); } }
        public string DCS { get { return this._DCS; } set { _DCS = value; NotifyPropertyChanged("DCS"); } }
        public string BMX { get { return this._BMX; } set { _BMX = value; NotifyPropertyChanged("BMX"); } }
        public string NWK { get { return this._NWK; } set { _NWK = value; NotifyPropertyChanged("NWK"); } }
        public string CFG { get { return this._CFG; } set { _CFG = value; NotifyPropertyChanged("CFG"); } }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {

            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

    }
}


// ***************************************************************************************
//                                  Change Log
// ***************************************************************************************
// Date       - Name            - Description                               - Label
// ***************************************************************************************
// 03/01/2017 - Gaurav Girdhar  - Test Framework Enhancement                - GGIRDHAR030717
//                                All the access will be from VIPTETST      - GGIRDHAR030717
// 02/16/2017 - Gaurav Girdhar  - a) Wait for 2 min for FTPVIP              - GGIRDHAR021617
//                                b) Change the Display check in CDB STATUS 
// 09/28/2016 - Saumen Biswas   - Added the last error step description in  - Saumen092816
//                                regression output text
// 09/08/2016 - Saumen Biswas   - Added 'GET TESTCASE' before calling       - Saumen090816
//                                'RESHSM'
// 09/01/2016 - Saumen Biswas   - Added check before attaching HSM back to  - Saumen090116
//                                PRODD77
// 08/29/2016 - Saumen Biswas   - Added call to RESHSM EXEC to reserve HSMs - Saumen082916
// 08/25/2016 - Saumen Biswas   - More updates in the regression output     - Saumen082516
//                                status text
// 08/24/2016 - Saumen Biswas   - Updated regression output file status to  - Saumen082416
//                                show the last step for error aborted
// 08/23/2016 - Saumen Biswas   - Changed CMS logoff command from 'LOG' to  - Saumen082316
//                                'LOGOFF'
//                              - Added code to abort QACT for Auth24x7
//                                runs if ZKADV CASES run is not successful
// ***************************************************************************************
