﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Excel = Microsoft.Office.Interop.Excel;

namespace QACT_WPF
{
    public enum ErrorTypes
    {
        NotifyandAbort,
        NotifyandWait,
        NotifyAndLog,
        NotifyOnly,
        LogOnly,
        LogandWait
    }
    public class RunSettings : INotifyPropertyChanged
    {
        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        private static readonly string Passphrase = App.Passphrase;

        /// <summary>
        /// Default constructor; Sets Run date to current date
        /// </summary>
        public RunSettings()
        {
            RunDate = DateTime.UtcNow;
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                _email = ((App)App.Current).IsVIPTESTENGMember ? "VIPQAAUTOMATION" : Environment.UserName.Split(new char[] { '\\' }, StringSplitOptions.RemoveEmptyEntries).Last();
            }
            else
            {
                _email = ((App)App.Current).IsVIPTESTENGMember ? "VIPTestSystemSupp" : Environment.UserName.Split(new char[] { '\\' }, StringSplitOptions.RemoveEmptyEntries).Last();
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            //GGIRDHAR030717 - Test Framework Enhancement            _email = ((App)App.Current).IsVIPTESTENGMember ? "VIPTestSystemSupp" : Environment.UserName.Split(new char[] { '\\' }, StringSplitOptions.RemoveEmptyEntries).Last();
        }
        /// <summary>
        /// Constructor with Inputfile; Generally called for Scheduler based regressions.
        /// </summary>
        /// <param name="inputFile"></param>
        public RunSettings(InputFile inputFile)
            : this()
        {
            RegType = inputFile.RegType;
            InstallDate = inputFile.CodeRunInstallDate;
            BaserunInstallDate = inputFile.BaseRunInstallDate;//Saumen031017
            RegCapture = inputFile.Capture;
            RunNumber = inputFile.CodeRunNumber;
            //Saumen013117: new parameters from auth24x7
            SystemDate = inputFile.SystemDate;
            CUPTapes = string.Format("{0},{1}", inputFile.cup_tape1, inputFile.cup_tape2);
            FTPFiles = string.Format("CDB{0},TAG{0}", _RegCapture);
            SwitchActivationInfo = inputFile.SwitchActivationInfo;
            //Saumen013117
            VMID = inputFile.CMSId;
            VMPWD = inputFile.CMSPassword;

            PopulateDefaultSettings();

            if (String.IsNullOrWhiteSpace(inputFile.BaseRunServerPath))
            {// Do a standalone run
                IsComparisonRequired = false;
                BaserunServer = null;
            }
            else
            {// Do a complete run
                BaserunServer = inputFile.BaseRunServerPath;
                IsComparisonRequired = true;
            }


            SetupFile = InstallDate.Replace("/", "").Substring(0, 4) + RegType.Substring(0, 2);


            if (!System.IO.Directory.Exists(CoderunServer))
                System.IO.Directory.CreateDirectory(CoderunServer);

            // Save the Coderun Server path, to be used in analysis
            inputFile.CoderRunServerPath = CoderunServer;
        }
        /// <summary>
        /// Populates default settings according to Run Type,Load Date, Capture Date etc
        /// </summary>
        public void PopulateDefaultSettings()
        {
            try
            {// From RegType

                /////////////////// Comparison ///////////////
                if (String.IsNullOrEmpty(RunNumber) || RunNumber == "BASERUN"
                    || (!string.IsNullOrWhiteSpace(RegType) && RegType.Equals("UNBALANCED", StringComparison.InvariantCultureIgnoreCase))
                    || (!string.IsNullOrWhiteSpace(RegType) && RegType.Equals("LOAD_NIGHT", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IsComparisonRequired = false;
                }
                else
                    IsComparisonRequired = true;

                //////////////////// HSM ///////////////////////
                if (RegType == "DRB")
                    HSMUnit = App.HSMUNITS[0];
                else
                    HSMUnit = App.HSMUNITS[1];
            }
            catch
            {
            }

            try
            {// From RegCapture
                Capture currCapture = captureFile.GetCapture(DateTime.ParseExact(RegCapture + '/' + DateTime.Now.ToString(@"yyyy"), @"MMdd/yyyy", System.Globalization.CultureInfo.InvariantCulture));
                if (string.IsNullOrEmpty(RegCapture))//Saumen013117
                {
                    RegCapture = DateTime.ParseExact(currCapture.CaptureDateString, CaptureInfoFile.DateStringFormat, System.Globalization.CultureInfo.InvariantCulture).ToString(@"MM/dd/yyyy");
                }//Saumen013117
                if (string.IsNullOrEmpty(FTPFiles))//Saumen013117
                {
                    FTPFiles = String.Join(",", currCapture.FTPFiles);
                }//Saumen013117
                if (string.IsNullOrEmpty(CUPTapes))//Saumen013117
                {
                    CUPTapes = String.Join(",", currCapture.CupTapes);
                }//Saumen013117

                Bucket = GetBucketName();

                if (string.IsNullOrEmpty(SystemDate))//Saumen013117
                {
                    if (RegType.Equals("LOAD_NIGHT", StringComparison.InvariantCultureIgnoreCase) || RegType.Equals("UNBALANCED", StringComparison.InvariantCultureIgnoreCase))//Saumen031017
                    {/////////////////// Alternate system date for Load Night //////////////////////////
                        SystemDate = DateTime.ParseExact(InstallDate, CaptureInfoFile.DateStringFormat, System.Globalization.CultureInfo.InvariantCulture)
                                             .AddDays(2)
                                             .ToString(@"MM/dd/yyyy");
                    }
                    else
                    {
                        SystemDate = DateTime.ParseExact(currCapture.SystemDateString, CaptureInfoFile.DateStringFormat, System.Globalization.CultureInfo.InvariantCulture)
                                            .ToString(@"MM/dd/yyyy");
                    }
                }//Saumen013117
            }
            catch
            {
                FTPFiles = String.Empty;
                CUPTapes = String.Empty;
                Bucket = String.Empty;
                SystemDate = null;
            }

            try
            {
                /////////////////// Coderun Server Path //////////////////////////////
                CoderunServer = GetCoderunServer();
            }
            catch
            {
                CoderunServer = null;
            }

        }

        string _RunNumber = null;
        /// <summary>
        /// Valid Values-BASERUN and RUNnn
        /// </summary>
        public string RunNumber
        {
            get { return _RunNumber; }
            set
            {
                _RunNumber = value;
                NotifyPropertyChanged("RunNumber");
            }
        }

        string _RegType = null;

        /// <summary>
        /// Determines the Regression Type
        /// </summary>
        public string RegType
        {
            get { return _RegType; }
            set
            {
                _RegType = value;
                NotifyPropertyChanged("RegType");

            }
        }

        string _InstallDate;
        /// <summary>
        /// Install Date of the Coderun system in MM/dd/yyyy format
        /// </summary>
        public string InstallDate
        {
            get { return _InstallDate; }
            set
            {
                if (!String.IsNullOrEmpty(value))
                    _InstallDate = DateTime.Parse(value).ToString("MM/dd/yyyy");
                else
                    _InstallDate = null;

                NotifyPropertyChanged("InstallDate");
            }
        }
        string _BaserunServer;
        /// <summary>
        /// Complete folder path for Baserun result
        /// </summary>
        public string BaserunServer { get { return _BaserunServer; } set { _BaserunServer = value; NotifyPropertyChanged("BaserunServer"); } }
        string _VMID;
        /// <summary>
        /// VM ID where the Regression will be performed
        /// </summary>
        public string VMID { get { return _VMID; } set { _VMID = value.ToUpper(); NotifyPropertyChanged("VMID"); } }
        /// <summary>
        /// Password of the VMID is being used for Regression
        /// </summary>
        public string VMPWD { get; set; }

        #region Variables from Capture file
        private string _SystemDate = null;
        /// <summary>
        /// System Date of the regression being performed: MM/dd/yyyy format
        /// </summary>
        public string SystemDate
        {
            get
            {
                return _SystemDate;
            }
            set
            {
                if (!String.IsNullOrEmpty(value))
                    _SystemDate = DateTime.Parse(value).ToString("MM/dd/yyyy");
                else
                    _SystemDate = null;
                // _SystemDate = value; 
                NotifyPropertyChanged("SystemDate");
            }
        }

        private string _CUPTapes = null;
        /// <summary>
        /// Cuptapes to load during Regression separated by comma. Uses TPFPROC CUPLOAD
        /// </summary>
        public string CUPTapes
        {
            get
            {
                return _CUPTapes;
            }
            set { _CUPTapes = value; NotifyPropertyChanged("CUPTapes"); }
        }

        private string _FTPFiles = null;
        /// <summary>
        /// Files to FTP during regression separated by comma. Uses FTPVIP
        /// </summary>
        public string FTPFiles
        {
            get { return _FTPFiles; }
            set { _FTPFiles = value; NotifyPropertyChanged("FTPFiles"); }
        }

        private static CaptureInfoFile captureFile = CommonClass.LoadFromJSONFile<CaptureInfoFile>(CaptureInfoFile.CaptureInfoFilePath);

        string _RegCapture;
        /// <summary>
        /// Capture date of used globals abd buckets in MMdd format.
        /// </summary>
        public string RegCapture
        {
            get { return _RegCapture; }
            set
            {
                DateTime captureDate;
                if (DateTime.TryParseExact(value,
                                            new string[] { @"MMdd", @"MM/dd/yyyy" },
                                            System.Globalization.DateTimeFormatInfo.InvariantInfo,
                                            System.Globalization.DateTimeStyles.AdjustToUniversal,
                                            out captureDate))
                {
                    _RegCapture = captureDate.ToString(@"MMdd");
                }
                else
                {
                    _RegCapture = value;
                }

                NotifyPropertyChanged("RegCapture");
            }
        }
        #endregion

        #region AutoPopulated Varibales
        string _HSMUnit = App.HSMUNITS[0];
        /// <summary>
        /// HSM Unit being used in regression .e.g 950-95F
        /// </summary>
        public string HSMUnit
        {
            get
            {
                return _HSMUnit;
            }
            set { _HSMUnit = value; NotifyPropertyChanged("HSMUnit"); }
        }
        string _SetupFile;
        /// <summary>
        /// Name of the setup file without $TTVDATA
        /// </summary>
        public string SetupFile { get { return _SetupFile; } set { _SetupFile = value.ToUpper(); NotifyPropertyChanged("SetupFile"); } }
        string _CoderunServer = null;
        /// <summary>
        /// Folder path of the coderun result
        /// </summary>
        public string CoderunServer
        {
            get { return _CoderunServer; }
            set
            {
                try
                {
                    if (System.IO.Path.GetFullPath(value.TrimEnd('\\')) == System.IO.Path.GetFullPath(GetCoderunServer()))
                    {
                        IsRegularServerPath = true;
                    }
                    else
                        IsRegularServerPath = false;
                }
                catch { }
                _CoderunServer = value;
                NotifyPropertyChanged("CoderunServer");
            }
        }
        bool _IsComparisonRequired = false;
        /// <summary>
        /// Indicates if comparison is required or not
        /// </summary>
        public bool IsComparisonRequired
        {
            get
            {
                return _IsComparisonRequired;
            }
            set
            {
                _IsComparisonRequired = value;

                if (_IsComparisonRequired == false)
                    BaserunServer = String.Empty;

                NotifyPropertyChanged("IsComparisonRequired");
            }
        }
        string _email = "VIPTestSystemSupp";
        /// <summary>
        /// Visa email id without @visa.com to Notify errors and send final result.
        /// </summary>
        public string email { get { return _email; } set { _email = value; NotifyPropertyChanged("VIPTestSystemSupp"); } }
        bool _IsSkipSetup = false;
        /// <summary>
        /// Indicates IF TPFSETUP need to be called or not.
        /// </summary>
        public bool IsSkipSetup { get { return _IsSkipSetup; } set { _IsSkipSetup = value; NotifyPropertyChanged("IsSkipSetup"); } }
        int _TapeRetentionPeriod = 12;
        /// <summary>
        /// Increase the tape lives to provided dates
        /// </summary>
        public int TapeRetentionPeriod { get { return _TapeRetentionPeriod; } set { _TapeRetentionPeriod = value; NotifyPropertyChanged("TapeRetentionPeriod"); } }
        /// <summary>
        /// List of VIPs and their details used in the run.
        /// </summary>
        public List<VIP> VIPS { get; set; }

        private string _Bucket = null;
        /// <summary>
        /// Buckets to run during the regression separated by comma.
        /// </summary>
        public string Bucket
        {
            get
            {
                //if (String.IsNullOrEmpty(_Bucket))
                //    _Bucket = RegSettings.GetBucketName(RegType, RegCapture);
                return _Bucket;
            }
            set { _Bucket = value; NotifyPropertyChanged("Bucket"); }
        }
        bool _IsAdviceRetrieve = true;
        /// <summary>
        /// Indicates If advice retrieval is required or not.
        /// </summary>
        public bool IsAdviceRetrieve { get { return _IsAdviceRetrieve; } set { _IsAdviceRetrieve = value; NotifyPropertyChanged("IsAdviceRetrieve"); } }
        /// <summary>
        /// Indicate Run date and Time
        /// </summary>
        public DateTime RunDate { get; set; }
        /// <summary>
        /// Globals that are being used
        /// </summary>
        public Dictionary<string, string> Globals { get; set; }

        private string _BaserunInstallDate = null;
        /// <summary>
        /// Install date for baserun in MM/dd/yyyy format.
        /// </summary>
        public string BaserunInstallDate
        {
            get
            {
                return _BaserunInstallDate;
            }
            set
            {
                _BaserunInstallDate = value;
                NotifyPropertyChanged("BaserunInstallDate");
            }
        }
        string _SwitchActivationInfo = "N/A";
        /// <summary>
        /// Indicate whether it is a Switch Activated regression or not. Format:RELyy e.g OCT16 or N/A
        /// </summary>
        public string SwitchActivationInfo { get { return _SwitchActivationInfo; } set { _SwitchActivationInfo = value; NotifyPropertyChanged("SwitchActivationInfo"); } }
        //Add new indicator for scheduler run
        bool _IsSchedulerRun = false;
        /// <summary>
        /// Indicates if the Regression is being performed in Scheduler mode or not.
        /// </summary>
        public bool IsSchedulerRun { get { return _IsSchedulerRun; } set { _IsSchedulerRun = value; NotifyPropertyChanged("IsSchedulerRun"); } }
        /// <summary>
        /// System date for the baserun in MM/dd/yyyy format.
        /// </summary>
        public string BaserunSystemDate { get; set; }
        #endregion

        private bool _IsRegularServerPath = false;

        public bool IsRegularServerPath
        {
            get { return _IsRegularServerPath; }
            set { _IsRegularServerPath = value; }
        }

        #region Helper Functions
        /// <summary>
        /// Determine a preformatted coderun server path.
        /// </summary>
        /// <returns></returns>
        private string GetCoderunServer()
        {
            if (String.IsNullOrWhiteSpace(InstallDate) || String.IsNullOrWhiteSpace(RegType)  || String.IsNullOrWhiteSpace(RunNumber))
                return "| More Run Parameters needed |";

            string installDate = String.IsNullOrEmpty(InstallDate) ? String.Empty : InstallDate.Replace("/", "") + "_Install";

            string regType = String.IsNullOrEmpty(RegType) ? String.Empty : RegType;

            //string switchInfo = String.IsNullOrWhiteSpace(SwitchActivationInfo) || SwitchActivationInfo.Equals("N/A", StringComparison.InvariantCultureIgnoreCase) ? String.Empty : "Switch Activated"; //Saumen013117
            string switchInfo = String.Empty;//Saumen013117

            string runNumber = String.IsNullOrWhiteSpace(RunNumber) ? String.Empty : RunNumber;

            //string bucket = String.IsNullOrEmpty(Bucket) ? String.Empty : String.Join("_", Bucket.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
            //bucket = Bucket.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Length > 3 ? RegType + '_' + RegCapture : bucket;
            //return System.IO.Path.Combine(new String[] { App.RegressionResultServer, installDate, switchInfo, bucket, runNumber });

            string bucket = String.Empty;
            //if (!string.IsNullOrWhiteSpace(Bucket) && Bucket!=GetBucketName())
            //{
            //    bucket = String.Join("_", Bucket.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
            //}
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                return System.IO.Path.Combine(new String[] { App.TestRegressionResultServer, installDate, switchInfo, regType, bucket, runNumber });
            }
            else
            {
                return System.IO.Path.Combine(new String[] { App.RegressionResultServer, installDate, switchInfo, regType, bucket, runNumber });
            }
            //GGIRDHAR030717 - Test Framework Enhancement
        }
        private string GetBucketName()
        {
            return GetBucketName(RegType, RegCapture);
        }
        /// <summary>
        /// Get the standard bucket names based on regression type.
        /// </summary>
        /// <returns></returns>
        public static string GetBucketName(string _RegType, string _RegCapture)
        {
            string bucket;
            if (_RegType == null || _RegCapture == null || _RegCapture.Trim() == "")
                return null;
            switch (_RegType)
            {
                case "PRODD":
                    bucket = "PROD" + _RegCapture;
                    break;
                case "STIPD":
                    bucket = "MINI" + _RegCapture;
                    break;
                case "BADD":
                    bucket = "BADD" + _RegCapture;
                    break;
                case "BADD+PCAS":
                    bucket = "BDST" + _RegCapture;
                    break;
                //case "SOAP":
                //    bucket = "SOAP" + _RegCapture;
                //    break;
                //case "1VIP":
                //    bucket = "1VIP" + _RegCapture;
                //    break;
                case "SOAP":
                    bucket = "SOAP" + _RegCapture;//+",1VIP" + _RegCapture;
                    break;
                case "ECIP":
                    bucket = "NCC" + _RegCapture;
                    break;
                case "DRB":
                    bucket = "DRB" + _RegCapture;
                    break;
                case "DURBIN":
                    bucket = "DURB" + _RegCapture;
                    break;
                case "PCAS":
                    bucket = "STIP" + _RegCapture;
                    break;
                case "TOKEN":
                    //bucket = "TKN" + _RegCapture + ",NCC" + _RegCapture;
                    bucket = "TKN" + _RegCapture + "A,NCC" + _RegCapture;//Saumen030617
                    break;
                case "UNBALANCED":
                    //Change Sequence to PROD,MINI,BADD,NCC
                    bucket = "PROD" + _RegCapture + ",MINI" + _RegCapture + ",BADD" + _RegCapture + ",NCC" + _RegCapture;
                    break;
                case "LOAD_NIGHT":
                    //bucket = "PROD" + _RegCapture;
                    bucket = "MINI" + _RegCapture;//Saumen020817 : test with mini bucket
                    break;
                default:
                    bucket = String.Empty;
                    break;
            }
            return bucket;
        }
        #endregion

    }
    public class RegStage : INotifyPropertyChanged
    {
        string _Stage = "", _Startat = "", _EndAt = "", _Status = "", _TimeTaken = "";
        bool _IsEnabled = false;
        public string Stage { get { return this._Stage; } set { _Stage = value; NotifyPropertyChanged("Stage"); } }
        public bool IsEnabled { get { return this._IsEnabled; } set { _IsEnabled = value; NotifyPropertyChanged("IsEnabled"); } }
        public string StartAt { get { return this._Startat; } set { _Startat = value; NotifyPropertyChanged("StartAt"); } }
        public string EndAt { get { return this._EndAt; } set { _EndAt = value; UpdateTimeTaken(); NotifyPropertyChanged("EndAt"); } }
        public string Status { get { return this._Status; } set { _Status = value; NotifyPropertyChanged("Status"); } }
        public string TimeTaken { get { return _TimeTaken; } set { _TimeTaken = value; NotifyPropertyChanged("TimeTaken"); } }

        void UpdateTimeTaken()
        {
            if (StartAt == "" || EndAt == "")
                TimeTaken = "";
            else
            {
                TimeTaken = (DateTime.ParseExact(EndAt, "MM/dd/yy HH:mm:ss", null) - DateTime.ParseExact(StartAt, "MM/dd/yy HH:mm:ss", null)).ToString();
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {

            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }
    /// <summary>
    /// Indicate the steps involved in a regression.
    /// </summary>
    public class Steps : INotifyPropertyChanged
    {
        bool _logon = true, _checkspace = true, _SubmitSetup = true, _Envsetup = true, _bucketrun = true, _setupCreate = ((App)App.Current).IsVIPTESTENGMember ? true : false;
        bool _Aprod = true, _advice = true, _tapecut = true, _compare = true, _filetransfer = true, _mail = true, _prelim = true;
        bool _logOffAllVics = true; bool _EraseOldFiles = true;

        public bool LogOffAllVics
        {
            get { return _logOffAllVics; }
            set { _logOffAllVics = value; NotifyPropertyChanged("LogOffAllVics"); }
        }

        public bool Logon { get { return this._logon; } set { _logon = value; NotifyPropertyChanged("Logon"); } }
        public bool Aprod { get { return this._Aprod; } set { _Aprod = value; NotifyPropertyChanged("Aprod"); } }
        public bool EraseOldFiles { get { return this._EraseOldFiles; } set { _EraseOldFiles = value; NotifyPropertyChanged("EraseOldFiles"); } }
        public bool CheckSpace { get { return this._checkspace; } set { _checkspace = value; NotifyPropertyChanged("CheckSpace"); } }
        public bool SubmitSetup { get { return this._SubmitSetup; } set { _SubmitSetup = value; NotifyPropertyChanged("SubmitSetup"); } }
        public bool EnvSetup { get { return this._Envsetup; } set { _Envsetup = value; NotifyPropertyChanged("EnvSetup"); } }
        public bool BucketRun { get { return _bucketrun; } set { _bucketrun = value; NotifyPropertyChanged("BucketRun"); } }
        public bool SetupCreate { get { return _setupCreate; } set { _setupCreate = value; NotifyPropertyChanged("SetupCreate"); } }
        public bool Advice { get { return this._advice; } set { _advice = value; NotifyPropertyChanged("Advice"); } }
        public bool TapeCut { get { return this._tapecut; } set { _tapecut = value; NotifyPropertyChanged("TapeCut"); } }
        public bool Compare { get { return this._compare; } set { _compare = value; NotifyPropertyChanged("Compare"); } }
        public bool FileTransfer { get { return this._filetransfer; } set { _filetransfer = value; NotifyPropertyChanged("FileTransfer"); } }
        public bool Mail { get { return _mail; } set { _mail = value; NotifyPropertyChanged("Mail"); } }
        public bool Prelim { get { return _prelim; } set { _prelim = value; NotifyPropertyChanged("Prelim"); } }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {

            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }
}
