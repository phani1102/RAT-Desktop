﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace QACT_WPF
{
    /// <summary>
    ///Preliminary Analysis:
    ///Preliminary Analysis is done by QACT to check the validity of Regression runs. It consists of various checks, each check is assigned a particular weightage (numbered from 1 to 3). These weightages are interpreted as follows. 
    ///Level 1 = Check percentage can be ignored.
    ///Level 2 = Check percentage should be above 75% (for Analog percentage values, like messages sent, advices created and advices retrieved)
    ///Level 3 = Check percentage should be 100% or more
    ///The “Score” for each check in preliminary Analysis file consists of {Percentage} X {Weightage} (Displayed there only for debugging)
    ///E.g.:
    ///-------------------------------------------------------------------------------------
    ///Check name :System Dates
    ///System Dates across all VIPs are OK
    ///Score : 100 X 3
    ///-------------------------------------------------------------------------------------
    ///Base run Identification:
    ///QACT marks valid regression runs, those can be used as base run, by placing an empty file named as “.CanBeUsedAsBaseRun” in the regression folder. This file is created in Preliminary Analysis stage of Regression, only if all the checks pass their assigned weightage conditions. For instance, the “Advices Retrieved” check has a weightage of 2 and a percentage of 82.053, since it is above 75% it is considered passed. Similarly all checks are checked as per their weightage conditions and only if they pass, the marker file “.CanBeUsedAsBaseRun” is created. The logic for this is present in the method  “public bool CanBeUsedAsBaserun()” of class “PreliminaryAnalysis”. It returns true if the regression run can be used as Base Run. We can do more fine graded checking by adding more levels of weightages and checking their validity in “public bool CanBeUsedAsBaserun()”.
    /// </summary>
    class PreliminaryAnalysis
    {
        private enum CheckType { CAN_BE_IGNORED = 1, ANALOG_75, CRITICAL };

        private readonly RunSettings runSett = null;

        public List<Check> CheckList = new List<Check>();

        private static string[] impTapeTypes = new string[] { "DTD", "RSI", "CSI" };

        private string regressionConsoleLog = null;
        private Check prelimRegressionErros = new Check("Regression Preliminary Analysis internal", 1.0d);

        public PreliminaryAnalysis(string RunFolderPath)
        {
            runSett = CommonClass.LoadFromJSONFile<RunSettings>(System.IO.Path.Combine(RunFolderPath, "RunSettings.json"));
        }

        public void CalculateTotalScore()
        {
            CheckList.Clear();
            CalculateRegressionScore();
            CalculateAnalysisScore();            
        }

        public List<string> printChecks()
        {
            List<string> allComments = new List<string>();

            CheckList.ForEach(check =>
            {
                allComments.Add("-------------------------------------------------------------------------------------");
                allComments.Add("Check name :" + check.Name);
                allComments.AddRange(check.Comment);
                allComments.Add("Score : " + check.Percent + " X " + check.Credit);
                allComments.Add("-------------------------------------------------------------------------------------");
            });

            return allComments;
        }
        public bool AreChecksValid()
        {
            var criticalChecks = CheckList.Where(check => Math.Abs(check.Credit - (double)CheckType.CRITICAL) < 0.00001);
            var analog_75Checks = CheckList.Where(check => Math.Abs(check.Credit - (double)CheckType.ANALOG_75) < 0.00001);

            return criticalChecks.All(criticalCheck => criticalCheck.Percent > 99.9d)
                   && analog_75Checks.All(chk => chk.Percent > 75.0d);
        }

        #region Regression Checks

        public void CalculateRegressionScore()
        {
            readRegressionFiles();

            CheckList.Add(doSystemDateCheck());
            CheckList.Add(doHSMCheck());
            CheckList.Add(doTTAGCheck());
            CheckList.Add(doCDBCheck());
            CheckList.Add(doBucketRunCheck());
            CheckList.Add(doTapeLogCheck());
            CheckList.Add(doTapeComparisonCheck());
            CheckList.Add(doMMIDNTFRCheck());
            CheckList.Add(doDumpsCheck());
            CheckList.Add(doAdviceCreationCheck());
            CheckList.Add(doAdviceRetrievalCheck());
            CheckList.Add(doMessagesSentCheck());

            if (runSett.RegType.Equals("TOKEN", StringComparison.InvariantCultureIgnoreCase) && runSett.IsComparisonRequired)
            {
                CheckList.Add(doTokenCheck());
            }

            if (prelimRegressionErros.Percent > 0.0d)
                CheckList.Add(prelimRegressionErros);

        }

        private void readRegressionFiles()
        {
            try
            {
                regressionConsoleLog = System.IO.File.ReadAllText(System.IO.Path.Combine(runSett.CoderunServer, "consolelog-coderun.txt"));
            }
            catch (System.IO.FileNotFoundException)
            {
                regressionConsoleLog = null;
                //throw Fex;
            }
            catch (Exception ex)
            {
                prelimRegressionErros.Comment.Add("Error in reading regression console log :" + ex.ToString());
                prelimRegressionErros.Percent += 10.0d;
            }


        }
        private Check doSystemDateCheck()
        {
            Check systemDateCheck = new Check("System Dates", (double)CheckType.CRITICAL);

            try
            {
                MatchCollection zktimOutputs = parseCommandFromConsoleLog("ZKTIM");

                DateTime intendedSystemDateTime = DateTime.ParseExact(runSett.SystemDate, @"MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);

                zktimOutputs.Cast<Match>()
                            .ToList()
                            .ForEach((zktimOutput) =>
                                {
                                    string vpars = zktimOutput.Groups["vpars"].Value;
                                    string command = zktimOutput.Groups["command"].Value;
                                    string output = zktimOutput.Groups["output"].Value;

                                    try
                                    {
                                        string systemTimeDate = output.ToUpper().Split(new string[] { "TIME IS NOW" }, StringSplitOptions.RemoveEmptyEntries)[1].Trim();

                                        DateTime vparsDateTime = DateTime.ParseExact(systemTimeDate, @"HH.mm.ss MM/dd/yy", System.Globalization.CultureInfo.InvariantCulture);

                                        if (vparsDateTime.Date == intendedSystemDateTime.Date)
                                        {
                                            systemDateCheck.Percent += (100.0d) / runSett.VIPS.Count;
                                            //systemDateCheck.Comment.Add(vpars + ':' + systemTimeDate);
                                        }
                                        else
                                        {
                                            systemDateCheck.Comment.Add("Incorrect for " + vpars + ':' + systemTimeDate);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        systemDateCheck.Comment.Add("Unable to parse System Date time for " + vpars + ':' + ex.Message);
                                    }
                                });
            }
            catch (Exception ex)
            {
                systemDateCheck.Comment.Add("Unable to extract ZKTIM output from regression consolelog : " + ex.Message);
                systemDateCheck.Percent = 0.0d;
            }

            if (systemDateCheck.Percent >= 99.9d)
            {
                systemDateCheck.Comment.Add("System Dates across all VIPs are OK");
            }
            else
            {
                systemDateCheck.Comment.Add("Some VIPs do not have proper system date");
                systemDateCheck.Comment.Add("Resolution: Rerun this regression");

            }

            return systemDateCheck;
        }

        private Check doHSMCheck()
        {
            Check HSMCheck = new Check("HSM Attached", (double)CheckType.CRITICAL);
            HSMCheck.Comment.Add("Specified HSM series : " + runSett.HSMUnit);

            if (runSett.HSMUnit.Equals("NA", StringComparison.InvariantCultureIgnoreCase))
            {
                HSMCheck.Percent = 100.0d;
                HSMCheck.Comment.Add("HSMs weren't needed : OK");
                return HSMCheck;
            }

            List<string> VPARSwithHSMs = new List<string>();
            try
            {
                MatchCollection zuvsm_cmds = parseCommandFromConsoleLog("ZUVSM ON");

                VPARSwithHSMs = zuvsm_cmds.Cast<Match>()
                                            .Select(cmd => cmd.Groups["vpars"].Value.Trim().ToUpper())
                                            .Distinct()
                                            .ToList();

                HSMCheck.Percent = VPARSwithHSMs.Count * (100.0d / runSett.VIPS.Count);

                //zuvsm_cmds
                //    .Cast<Match>()
                //    .ToList()
                //    .ForEach((cmd) =>
                //        {
                //            string vpars = cmd.Groups["vpars"].Value;
                //            string command = cmd.Groups["command"].Value;
                //            string output = cmd.Groups["output"].Value;

                //            string hsm = Regex.Match(output, @"\s+\d+").Value;

                //            HSMCheck.Comment.Add(vpars + ':' + hsm);
                //            HSMCheck.Percent += (100.0d) / runSett.VIPS.Count;
                //        });

            }
            catch (Exception ex)
            {
                HSMCheck.Comment.Add("Unable to extract ZUVSM ON output from regression consolelog : " + ex.Message);
                HSMCheck.Percent = 0.0d;
            }

            if (HSMCheck.Percent >= 99.9d)
            {
                HSMCheck.Comment.Add("HSMs were attached to all VIPs : OK");
            }
            else
            {
                HSMCheck.Comment.Add("HSMs were not attached to some VIPs, Please check if you manually added HSM: Not Ok");
                HSMCheck.Comment.Add("VPARS with missing HSMs : " + String.Join(", ", runSett.VIPS
                                                                                            .Select(v => v.VPARS.Trim().ToUpper())
                                                                                            .Except(VPARSwithHSMs)));
                HSMCheck.Comment.Add("Resolution: Rerun this regression");
            }

            return HSMCheck;
        }

        private Check doTTAGCheck()
        {
            Check TTAGSyncCheck = new Check("TTAG sync check", (double)CheckType.CRITICAL);

            /////////////////// check for TTAG file sync across all VICS /////////////////////////
            try
            {
                Regex ttagFailCheck = new Regex(@"(?:==(?'vpars'[\w\d]+)==>\s+ZKPAN\s+\d+\s+TRT{\s*)    # matches ==PRODD35==> ZKPAN XXXXXXXXXX58013 TRT{
                                                  (?:NO\s+TRAVEL\s+TAG\s+SEGMENTS\s+FOUND)              # matches NO TRAVEL TAG SEGMENTS FOUND
                                                 "
                                            , RegexOptions.Multiline | RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace | RegexOptions.Compiled
                                            );

                MatchCollection ttagFailMatches = ttagFailCheck.Matches(regressionConsoleLog);

                if (ttagFailMatches.Count > 0)
                {
                    string failedVPARS = String.Join(", ", ttagFailMatches.Cast<Match>()
                                                                          .Select(failedMatch => failedMatch.Groups["vpars"].Value)
                                                                          .ToList());

                    TTAGSyncCheck.Comment.Add("TTAG update has failed in some VICs : " + failedVPARS);
                    TTAGSyncCheck.Comment.Add("Resolution: Analyze to find problem with TTAG Update, then rerun this regression");

                    TTAGSyncCheck.Percent = 100.0d - (100.0d / runSett.VIPS.Count) * ttagFailMatches.Count;
                }
                else
                {
                    TTAGSyncCheck.Percent = 100.0d;
                    TTAGSyncCheck.Comment.Add("Updated successful across all VICs ");
                }

            }
            catch (Exception ex)
            {
                TTAGSyncCheck.Comment.Add("Unable to check TTAG status from regression consolelog : " + ex.Message);
            }

            return TTAGSyncCheck;
        }

        private Check doCDBCheck()
        {
            Check CDBSyncCheck = new Check("CDB Sync", (double)CheckType.CRITICAL);

            ////////// CDB sync across all VICs check /////////
            try
            {
                Regex cdbSyncFailCheck = new Regex(@"(?:==(?'vpars'[\w\d]+)==>\s+ZKPAN\s+\d+\s+PFO{\s*)                   # matches '==PSATPUT3==> ZKPAN xxxxxxxxx102158013 PFO{'
                                                    (NO\s+PPCS\s+PORTFOLIO\s+SEGMENTS\s*)                                 # matches 'NO PPCS PORTFOLIO SEGMENTS'
                                                    (NO\s+REWARDS\s+PORTFOLIO\s+SEGMENTS\s*)                              # matches 'NO REWARDS PORTFOLIO SEGMENTS'
                                                    "
                                                   , RegexOptions.IgnorePatternWhitespace | RegexOptions.Multiline | RegexOptions.Compiled | RegexOptions.IgnoreCase
                                                   );

                MatchCollection cdbSyncFailMatches = cdbSyncFailCheck.Matches(regressionConsoleLog);

                if (cdbSyncFailMatches.Count > 0)
                {
                    string failedVPARS = String.Join(", ", cdbSyncFailMatches.Cast<Match>()
                                                                            .Select(failedMatch => failedMatch.Groups["vpars"].Value)
                                                                            .ToList());

                    CDBSyncCheck.Comment.Add("CDB update has failed in some VICs : " + failedVPARS);
                    CDBSyncCheck.Comment.Add("Resolution: Analyze to find problem with CDB sync, then rerun this regression");

                    CDBSyncCheck.Percent = 100.0d - (100.0d / runSett.VIPS.Count) * cdbSyncFailMatches.Count;

                }
                else
                {
                    CDBSyncCheck.Percent = 100.0d;
                    CDBSyncCheck.Comment.Add("Updated successfully across all VICs");
                }

            }
            catch (Exception ex)
            {
                CDBSyncCheck.Comment.Add("Unable to check CDB sync status in regression console log : " + ex.Message);
            }

            return CDBSyncCheck;
        }

        private Check doBucketRunCheck()
        {
            Check bucketRunCheck = new Check("Bucket run", (double)CheckType.CRITICAL);

            if (runSett.RegType.Equals("DRB", StringComparison.InvariantCultureIgnoreCase))
            {//////////// FOR DRB runs check for Advice retrieval ///////////////////
                try
                {
                    MatchCollection zkijmMatches = parseCommandFromConsoleLog("ZKIJM DI CCR ITEM-001");

                    zkijmMatches.Cast<Match>()
                                    .ToList()
                                    .ForEach((zkijmMatch) =>
                                    {
                                        string vpars = zkijmMatch.Groups["vpars"].Value;
                                        string command = zkijmMatch.Groups["command"].Value;
                                        string output = zkijmMatch.Groups["output"].Value;

                                        Regex adviceCheck = new Regex(@"(?:ITEM\s+COUNT\s*=\s+\d+\s+(?'advice_creation'STATUS\s*=\s*ADVICE\s+CREATION\s+COMPLETED))", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Compiled);

                                        if (adviceCheck.Match(output).Groups["advice_creation"].Success)
                                        {// advice creation successful
                                            bucketRunCheck.Comment.Add("DRB Advice run Successful for " + vpars);
                                            bucketRunCheck.Percent += 100 / zkijmMatches.Count;
                                        }
                                        else
                                        {// advice creation failed
                                            bucketRunCheck.Comment.Add("DRB Advice run failed for " + vpars);
                                            bucketRunCheck.Comment.Add("Resolution: Analyze to find problem, then rerun this regression");
                                        }

                                    });
                }
                catch (Exception ex)
                {
                    bucketRunCheck.Percent = 0.0d;
                    bucketRunCheck.Comment.Add("Unable to check advice run status for DRB : " + ex.Message);
                }

                return bucketRunCheck;
            }

            ////////////////////////// FOR other regression types ////////////////////////////////
            var allBuckets = runSett.Bucket
                                        .Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                        .TakeWhile(bucket => !(runSett.RegType.Equals("TOKEN", StringComparison.InvariantCultureIgnoreCase) && Regex.IsMatch(bucket, @"NCC\d+")));    

            foreach (string bucket in allBuckets)
            {
                try
                { /////////// other regressions check bucket statlog /////////////////
                    string bucketStatlog = System.IO.File.ReadAllText(System.IO.Path.Combine(runSett.CoderunServer, bucket + "_statlog-coderun.txt"));

                    Regex endOfBucketcheck = new Regex(@"End of file, rc 0");

                    if (endOfBucketcheck.IsMatch(bucketStatlog))
                    {// Bucket run successful
                        bucketRunCheck.Percent += 100.0d / allBuckets.Count();
                        bucketRunCheck.Comment.Add("Bucket " + bucket + " Run: OK");
                    }
                    else
                    {// Bucket run failed
                        bucketRunCheck.Comment.Add("Bucket " + bucket + ": run didn't end with RC 0");
                    }
                }
                catch (System.IO.FileNotFoundException)
                {
                    bucketRunCheck.Comment.Add("Bucket " + bucket + " Run: Statlog not present");
                }
                catch (Exception)
                {
                    bucketRunCheck.Comment.Add("Bucket " + bucket + " Run: Unable to check");
                }
            }

            if (bucketRunCheck.Percent >= 99.9d)
            {// all buckets ran successfully
                bucketRunCheck.Comment.Add("All bucket runs were completed");
            }
            else
            {// some bucket runs have failed
                bucketRunCheck.Comment.Add("Some bucket runs have failed : Not OK");
                bucketRunCheck.Comment.Add("Resolution: Analyze to find problem, then rerun this regression");
            }

            return bucketRunCheck;
        }

        private Check doTapeLogCheck()
        {
            Check TapeLogCheck = new Check("Tape numbers", (double)CheckType.CRITICAL);

            List<string> allFailedTapeTypes = new List<string>();

            try
            {
                string logTapesFile = System.IO.File.ReadAllText(System.IO.Path.Combine(runSett.CoderunServer, "logtapes-coderun.txt"));    //logtapes-coderun.txt

                Regex tapeNumbersExtract = new Regex(@"(?'tapeType'\w+)\s*:\s*(?'tapeNumbers'.+)");
                Regex tapeNumberFormat = new Regex(@"([a-zA-Z]\d+)", RegexOptions.Compiled);



                var allTapeTypes = tapeNumbersExtract.Matches(logTapesFile)
                                                        .Cast<Match>()
                                                        .Select(tapeMatch => tapeMatch.Groups["tapeType"].Value)
                                                        .ToList();

                tapeNumbersExtract.Matches(logTapesFile)
                                .Cast<Match>()
                                .ToList()
                                .ForEach(tape =>
                                {
                                    string tapeType = tape.Groups["tapeType"].Value;
                                    string[] allTapeNumbers = tape.Groups["tapeNumbers"].Value.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                                    var invalidTapeNumbers = allTapeNumbers
                                                                    .Where(eachTape => tapeNumberFormat.IsMatch(eachTape) == false)
                                                                    .ToList();

                                    if (tapeType.ToUpper() != "ETPDB" || tapeType.ToUpper() != "ICX")//Saumen021517
                                    {
                                        if (allTapeNumbers.Count() == runSett.VIPS.Count && invalidTapeNumbers.Count == 0)
                                        {// tape cutting successful
                                            TapeLogCheck.Percent += 100.0d / allTapeTypes.Count;
                                            TapeLogCheck.Comment.Add(tapeType + " tape cutting: OK");
                                        }
                                        else
                                        {// error in tape cutting
                                            TapeLogCheck.Comment.Add("Error in " + tapeType + " tape cutting : " + String.Join(", ", invalidTapeNumbers));
                                            allFailedTapeTypes.Add(tapeType.ToUpper().Trim());
                                        }
                                    }//Saumen021517
                                });

            }
            catch (Exception ex)
            {
                TapeLogCheck.Comment.Add("Error in check for tape cutting : " + ex.Message);
                allFailedTapeTypes.AddRange(impTapeTypes);     //  assume all tape cuttings failed
            }

            if (TapeLogCheck.Percent >= 99.9d)
            {
                TapeLogCheck.Comment.Add("All tape cutting OK");
            }
            else
            {/// Some tape cuttings have failed 

                var impFailedTapeTypes = allFailedTapeTypes.Intersect(impTapeTypes, StringComparer.InvariantCultureIgnoreCase);

                if (impFailedTapeTypes.Count() > 0)
                {
                    TapeLogCheck.Percent = 0.0d;
                    TapeLogCheck.Comment.Add("Resolution: Analyze to find problem with " + String.Join(", ", impFailedTapeTypes) + " tape cuttings and then rerun this regression");
                }
                else
                {
                    TapeLogCheck.Percent = 100.0d;
                }
                var otherFailedTapeTypes = allFailedTapeTypes.Except(impTapeTypes, StringComparer.InvariantCultureIgnoreCase);
                if (otherFailedTapeTypes.Count() > 0)
                {
                    TapeLogCheck.Comment.Add("Resolution: Analyze to find problem with " + String.Join(", ", otherFailedTapeTypes) + " tape cuttings");
                }
            }

            return TapeLogCheck;
        }

        private Check doTapeComparisonCheck()
        {
            Check tapeComparisonCheck = new Check("Tape Comparison", (double)CheckType.CAN_BE_IGNORED);

            if (runSett.IsComparisonRequired == false)
            { // No Comparison was required
                tapeComparisonCheck.Comment.Add("Comparison wasn't required : OK");
                tapeComparisonCheck.Percent = 100.0d;
                return tapeComparisonCheck;
            }

            List<string> allFailedTapeTypes = new List<string>();

            try
            {
                string logTapesFile = System.IO.File.ReadAllText(System.IO.Path.Combine(runSett.CoderunServer, "logtapes-coderun.txt"));    //logtapes-coderun.txt
                Regex tapeNumbersExtract = new Regex(@"(?'tapeType'\w+)\s*:\s*(?'tapeNumbers'.+)");

                var allTapeTypes = tapeNumbersExtract.Matches(logTapesFile)
                                                        .Cast<Match>()
                                                        .Select(tapeMatch => tapeMatch.Groups["tapeType"].Value.Trim().ToLower())
                                                        .ToList();
                /////////////////////// Mismatch Files check //////////////////////////////
                Regex comparePercentRegex = new Regex(@"Compare ended:.*? (?'percentOfInputUsed'\d+\.?\d*)% of input used", RegexOptions.Compiled);

                foreach (string tapeType in allTapeTypes)
                {
                    try
                    {
                        string tapeMMFile = System.IO.File.ReadAllText(System.IO.Path.Combine(runSett.CoderunServer, tapeType + "mm.txt"));

                        double percentOfInputUsed = double.Parse("0" + comparePercentRegex.Match(tapeMMFile).Groups["percentOfInputUsed"].Value);

                        if (tapeType.ToUpper() != "ETPDB" || tapeType.ToUpper() != "ICX")//Saumen021517
                        {
                            if (percentOfInputUsed < 75.0d)
                            { ////////// Low Percentage //////
                                tapeComparisonCheck.Comment.Add(tapeType.ToUpper() + " tape comparison is " + Math.Round(percentOfInputUsed, 3) + "% : Not OK");
                                allFailedTapeTypes.Add(tapeType.ToUpper());
                            }
                            else
                            { /////////// Acceptable Percentage
                                tapeComparisonCheck.Comment.Add(tapeType.ToUpper() + " tape comparison is " + Math.Round(percentOfInputUsed, 3) + "% : OK");
                                tapeComparisonCheck.Percent += 100.0d / allTapeTypes.Count;
                            }
                        }//Saumen021517
                    }
                    catch (Exception MMex)
                    {
                        if (tapeType.ToUpper() != "ETPDB" || tapeType.ToUpper() != "ICX")//Saumen021517
                        {
                            tapeComparisonCheck.Comment.Add("Unable to check compare percent for " + tapeType.ToUpper() + " :" + MMex.Message);
                            allFailedTapeTypes.Add(tapeType.ToUpper());
                        }//Saumen021517
                    }
                }
            }
            catch (Exception ex)
            {
                tapeComparisonCheck.Comment.Add("Error in overall tape comparison Check : " + ex.Message);
                allFailedTapeTypes.AddRange(impTapeTypes);
            }

            if (tapeComparisonCheck.Percent >= 99.9d)
            {
                tapeComparisonCheck.Comment.Add("All Tape comparisons have acceptable compare percentages");
            }
            else
            {// Some tape comparisons have failed

                var impFailedTapeComparisons = allFailedTapeTypes.Intersect(impTapeTypes, StringComparer.InvariantCultureIgnoreCase);

                if (impFailedTapeComparisons.Count() > 0)
                {
                    tapeComparisonCheck.Percent = 0.0d;
                    tapeComparisonCheck.Comment.Add("Resolution: Analyze to find problem with " + String.Join(", ", impFailedTapeComparisons) + " tape comparisons and then rerun this regression");
                }

                var otherFailedTapeTypes = allFailedTapeTypes.Except(impTapeTypes, StringComparer.InvariantCultureIgnoreCase);
                if (otherFailedTapeTypes.Count() > 0)
                {
                    tapeComparisonCheck.Comment.Add("Resolution: Analyze to find problem with " + String.Join(", ", otherFailedTapeTypes) + " tape comparisons");
                }
            }

            return tapeComparisonCheck;
        }

        private Check doMMIDNTFRCheck()
        {
            Check mmidntfrCheck = new Check("MMIDNTFR check", (double)CheckType.CAN_BE_IGNORED);

            //////////////////////////////// MMIDNTFR CHECKS /////////////////////////////////////
            try
            {
                //////// Read Run errors
                string[] RunErrors = new string[] { }; ;
                if (System.IO.File.Exists(System.IO.Path.Combine(runSett.CoderunServer, "RunErrors.txt")))
                {
                    RunErrors = System.IO.File.ReadAllLines(System.IO.Path.Combine(runSett.CoderunServer, "RunErrors.txt"));
                }

                /// Parse MMIDNTFR errors
                Regex MMIDNTFR_errors = new Regex(@"\s*(?'MMIDNTFR_cmd'MMIDNTFR\s+.*?)\s*:\s*(?'error'.*)", RegexOptions.IgnoreCase);

                var MMIDNTFRErrorList = RunErrors.Where(ln => MMIDNTFR_errors.IsMatch(ln))
                                                 .Select(ln => MMIDNTFR_errors.Match(ln).Value)
                                                 .ToList();

                if (MMIDNTFRErrorList.Count > 0)
                {// On encountering MMIDNTFR errors
                    mmidntfrCheck.Comment.AddRange(MMIDNTFRErrorList);
                    mmidntfrCheck.Comment.Add("Resolution: Report to Automation team, then do manual analysis");
                    mmidntfrCheck.Percent = 0.00d;
                }
                else
                {// NO MMIDNTFR error were encountered
                    mmidntfrCheck.Comment.Add("MMIDNTFR execution : COMPLETED");
                    mmidntfrCheck.Percent = 100.0d;
                }
            }
            catch (Exception ex)
            {
                mmidntfrCheck.Comment.Add("MMIDNTFR Checking failed : " + ex.Message);
                mmidntfrCheck.Comment.Add("Resolution: Report to Automation team, then do manual analysis");
            }

            return mmidntfrCheck;
        }

        private Check doDumpsCheck()
        {
            Check dumpsCheck = new Check("Dumps", (double)CheckType.CAN_BE_IGNORED);

            try
            {
                dumpsCheck.Comment.Add("Following dumps are not in baserun but in coderun...");
                string dumpsFilePath = System.IO.Path.Combine(runSett.CoderunServer, "DUMPS_UNIQUE.txt");

                if (System.IO.File.Exists(dumpsFilePath))
                    dumpsCheck.Comment.AddRange(System.IO.File.ReadAllLines(dumpsFilePath));
                else
                    dumpsCheck.Comment.Add("No Dumps were found");

                dumpsCheck.Percent = 100.0d;
            }
            catch (Exception ex)
            {
                dumpsCheck.Comment.Add("Unable to check for dumps : " + ex.Message);
                dumpsCheck.Percent = 0.0d;
            }

            return dumpsCheck;
        }

        private Check doAdviceRetrievalCheck()
        {
            Check adviceRetrievalCheck = new Check("Advices Retrieved", (double)CheckType.ANALOG_75);

            try
            {
                //Regex adviceCountRegex = new Regex(@"(?=\s*Total:\s+(?'MIS'\d+)?\s*(?'CAS'\d+).*)", RegexOptions.IgnoreCase);
                Regex adviceCountRegex = new Regex(@"(?=Total:\s+(?'MIS'\d+)\s+(?'CAS'\d+))", RegexOptions.IgnoreCase);//Saumen040517

                ///////////////////// CODERUNs ADVICE COUNT Before Retreival //////////////////
                long adviceCountBeforeRetrieval = TotalSumInFile(adviceCountRegex, System.IO.Path.Combine(runSett.CoderunServer, "advice_count_before_retrieval-coderun.txt"));
                adviceRetrievalCheck.Comment.Add("Advice count before retrieval : " + adviceCountBeforeRetrieval);

                ///////////////////// CODERUNs ADVICE COUNT After Retreival //////////////////
                long adviceCountAfterRetrieval = TotalSumInFile(adviceCountRegex, System.IO.Path.Combine(runSett.CoderunServer, "advice_count_after_retrieval-coderun.txt"));
                adviceRetrievalCheck.Comment.Add("Advice count after retrieval : " + adviceCountAfterRetrieval);


                adviceRetrievalCheck.Percent = Math.Round((double)((adviceCountBeforeRetrieval - adviceCountAfterRetrieval) * 100) / adviceCountBeforeRetrieval, 3);

                if (Double.IsNaN(adviceRetrievalCheck.Percent))
                {/// Not at all Ok
                    adviceRetrievalCheck.Comment.Add("Percentage of Advices Retrieved (before and after in coderun): " + adviceRetrievalCheck.Percent + "% : Not at all OK");
                    adviceRetrievalCheck.Comment.Add("Advice Count before retrieval is zero");
                }
                //Saumen013117: reduce advice retrieval check to 50%
                //else if (adviceRetrievalCheck.Percent > 85.0f)
                else if (adviceRetrievalCheck.Percent > 50.0f)
                {/// OK
                    if (adviceRetrievalCheck.Percent > 85.0f)
                    {
                        adviceRetrievalCheck.Comment.Add("Percentage of Advices Retrieved (before and after in coderun): " + adviceRetrievalCheck.Percent + "% : OK");
                    }
                    else
                    {
                        adviceRetrievalCheck.Comment.Add("Percentage of Advices Retrieved (before and after in coderun): " + adviceRetrievalCheck.Percent + "% : OK");
                        adviceRetrievalCheck.Comment.Add("Resolution: Analyze to find problem with advice retrieval, then report to Automation team");
                        adviceRetrievalCheck.Percent += 25.0d;//Saumen040517
                    }
                    //Saumen013117
                }
                else
                {/// Not Ok
                    adviceRetrievalCheck.Comment.Add("Percentage of Advices Retrieved (before and after in coderun): " + adviceRetrievalCheck.Percent + "% : Not OK");
                    adviceRetrievalCheck.Comment.Add("Resolution: Analyze to find problem with advice retrieval, then rerun this regression");
                }

            }
            catch (Exception ex)
            {
                adviceRetrievalCheck.Comment.Add("Failed to calculate percentage of Advices Retrieved (before and after in coderun) :" + ex.Message);
                adviceRetrievalCheck.Percent += 75.0d;//Saumen040517
            }

            return adviceRetrievalCheck;
        }

        private Check doAdviceCreationCheck()
        {
            Check adviceCreationCheck = new Check("Advices Created", (double)CheckType.ANALOG_75);

            try
            {
                //Regex adviceCountRegex = new Regex(@"(?=\s*Total:\s+(?'MIS'\d+)?\s*(?'CAS'\d+).*)", RegexOptions.IgnoreCase);
                Regex adviceCountRegex = new Regex(@"(?=Total:\s+(?'MIS'\d+)\s+(?'CAS'\d+))", RegexOptions.IgnoreCase);//Saumen040517

                ///////////////////// CODERUNs ADVICE COUNT Before Retreival //////////////////
                long coderunADVBeforeRetrieval = TotalSumInFile(adviceCountRegex, System.IO.Path.Combine(runSett.CoderunServer, "advice_count_before_retrieval-coderun.txt"));
                adviceCreationCheck.Comment.Add("Total advice count in coderun : " + coderunADVBeforeRetrieval);

                ///////////////////// BASERUNs ADVICE COUNT Before Retreival //////////////////
                long baserunADVBeforeRetrieval = TotalSumInFile(adviceCountRegex, System.IO.Path.Combine(runSett.CoderunServer, "advice_count_before_retrieval-baserun.txt"));
                adviceCreationCheck.Comment.Add("Total advice count in baserun : " + baserunADVBeforeRetrieval);

                adviceCreationCheck.Percent = Math.Round((double)((coderunADVBeforeRetrieval) * 100) / baserunADVBeforeRetrieval, 3);

                if (Double.IsNaN(adviceCreationCheck.Percent))
                {// Not at all ok
                    adviceCreationCheck.Comment.Add("Percentage of Advices Created (baserun vs coderun): " + adviceCreationCheck.Percent + "% : Not at all OK");
                    adviceCreationCheck.Comment.Add("Advice Count before retrieval in baserun is zero");
                    adviceCreationCheck.Comment.Add("Resolution: Analyze to find problem with advice creation, then rerun this regression");
                }
                //Saumen013117: reduce advice creation check to 30%
                //else if (adviceCreationCheck.Percent > 75.0f)
                else if (adviceCreationCheck.Percent > 30.0f)
                {/// OK
                    if (adviceCreationCheck.Percent > 75.0f)
                    {
                        adviceCreationCheck.Comment.Add("Percentage of Advices Created (baserun vs coderun): " + adviceCreationCheck.Percent + "% : OK");
                    }
                    else
                    {
                        adviceCreationCheck.Comment.Add("Percentage of Advices Created (baserun vs coderun): " + adviceCreationCheck.Percent + "% : OK");
                        adviceCreationCheck.Comment.Add("Resolution: Analyze to find problem with advice creation, then report to Automation team");
                        adviceCreationCheck.Percent += 45.0d;//Saumen040517
                    }
                    //Saumen013117
                }
                else
                {/// NOT OK
                    adviceCreationCheck.Comment.Add("Percentage of Advices Created (baserun vs coderun): " + adviceCreationCheck.Percent + "% : Not OK");
                    adviceCreationCheck.Comment.Add("Resolution: Analyze to find problem with advice creation, then rerun this regression");
                }
            }
            catch (Exception ex)
            {
                adviceCreationCheck.Comment.Add("Failed to calculate percentage of Advices Created (baserun vs coderun): " + ex.Message);
                adviceCreationCheck.Percent += 75.0d;//Saumen040517
            }

            return adviceCreationCheck;
        }

        private Check doMessagesSentCheck()
        {
            Check messagesSentCheck = new Check("Messages Sent", (double)CheckType.CRITICAL);

            if (runSett.RegType.Equals("DRB", StringComparison.InvariantCultureIgnoreCase))
            {//////////// FOR DRB runs check for Advice created ///////////////////
                try
                {
                    MatchCollection zkijmMatches = parseCommandFromConsoleLog("ZKIJM DI CCR ITEM-001");

                    zkijmMatches.Cast<Match>()
                                    .ToList()
                                    .ForEach((zkijmMatch) =>
                                    {
                                        string vpars = zkijmMatch.Groups["vpars"].Value;
                                        string command = zkijmMatch.Groups["command"].Value;
                                        string output = zkijmMatch.Groups["output"].Value;

                                        Regex adviceCheck = new Regex(@"(?:ITEM\s+COUNT\s*=\s+\d+\s+(?'advice_creation'STATUS\s*=\s*ADVICE\s+CREATION\s+COMPLETED))", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Compiled);

                                        if (adviceCheck.Match(output).Groups["advice_creation"].Success)
                                        {// advice creation successful
                                            messagesSentCheck.Comment.Add("DRB Advice run Successful for " + vpars);
                                            messagesSentCheck.Percent += 100 / zkijmMatches.Count;
                                        }
                                        else
                                        {// advice creation failed
                                            messagesSentCheck.Comment.Add("DRB Advice run failed for " + vpars);
                                            messagesSentCheck.Comment.Add("Resolution: Analyze to find problem, then rerun this regression");
                                        }
                                    });
                }
                catch (Exception ex)
                {
                    messagesSentCheck.Percent = 0.0d;
                    messagesSentCheck.Comment.Add("Unable to check advice run status for DRB : " + ex.Message);
                }

                return messagesSentCheck;
            }


            /////////////////////// Total messages ran for all buckets /////////////////////////////
            //a.	Total number of messages run during regression (base run vs code run). Use STATLOG file to verify the success. Acceptable limit is 90%.

            var allBuckets = runSett.Bucket
                                      .Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                      .TakeWhile(bucket => !(runSett.RegType.Equals("TOKEN", StringComparison.InvariantCultureIgnoreCase) && Regex.IsMatch(bucket, @"NCC\d+")));    

            foreach (string bucket in allBuckets)
            {
                try
                {
                    Regex totalMessages = new Regex(@"(?:Total\s+messages\s+sent\s*:\s*(?'totalMessages'\d+)\s*\|\s*)", RegexOptions.IgnoreCase);

                    long totalMessagesCoderun = TotalSumInFile(totalMessages, System.IO.Path.Combine(runSett.CoderunServer, bucket + "_statlog-coderun.txt"));
                    long totalMessagesBaserun = TotalSumInFile(totalMessages, System.IO.Path.Combine(runSett.CoderunServer, bucket + "_statlog-baserun.txt"));

                    double percent = Math.Round((double)totalMessagesCoderun * 100 / totalMessagesBaserun, 3);

                    if (Double.IsNaN(percent))
                    {
                        messagesSentCheck.Comment.Add("No messages were sent in baserun");
                        percent = 0.0d;
                    }

                    if (percent > 80.0f)
                    {// ok
                        messagesSentCheck.Comment.Add("Percentage of messages sent for " + bucket + " (coderun vs baserun): " + percent + "% : Ok");
                        messagesSentCheck.Percent += 100.0d / allBuckets.Count();
                    }
                    else
                    {//  NOt ok
                        messagesSentCheck.Comment.Add("Percentage of messages sent for " + bucket + " (coderun vs baserun): " + percent + "% : Not Ok");
                        messagesSentCheck.Comment.Add("Resolution: Analyze to find problem, then rerun this regression");
                    }
                }
                catch (System.IO.FileNotFoundException fex)
                {
                    messagesSentCheck.Comment.Add("Stalog not found for " + bucket + " :" + fex.Message);
                }
                catch (Exception ex)
                {
                    messagesSentCheck.Comment.Add("Check Failed for " + bucket + " :" + ex.Message);
                }
            }

            return messagesSentCheck;
        }

        /// <summary>
        /// A utility function to add all integers in a file according to provided regular expression groups value
        /// </summary>
        /// <param name="numberRegex">Regular expression that captures integers by grouping, if the captured value is not an integer it is taken as 0</param>
        /// <param name="filePath">path of the file to parse</param>
        /// <returns>Sum of all captured integers</returns>
        private long TotalSumInFile(Regex numberRegex, string filePath)
        {
            long total = 0;

            if (!System.IO.File.Exists(filePath))
                return total;

            foreach (Match countMatch in numberRegex.Matches(System.IO.File.ReadAllText(filePath)))
            {
                foreach (Group group in countMatch.Groups)
                    try
                    {
                        total += System.Int32.Parse(group.Success ? group.Value : "0");
                    }
                    catch (Exception)
                    {
                        total += 0;
                    }
            }

            return total;
        }

        private Check doTokenCheck()
        {
            Check tokenCheck = new Check("Token difference", (double)CheckType.CAN_BE_IGNORED);

            try
            {
                Dictionary<string, string> basepantoken = System.IO.File.ReadAllLines(System.IO.Path.Combine(runSett.CoderunServer, "pan_token_table-baserun.txt"))
                                                                .Where(l => l != null && l.Contains(" - ")).ToDictionary(a => a.Split('-')[0].Trim(), b => b.Split('-')[1].Trim());

                Dictionary<string, string> codepantoken = System.IO.File.ReadAllLines(System.IO.Path.Combine(runSett.CoderunServer, "pan_token_table-coderun.txt"))
                                                            .Where(l => l != null && l.Contains(" - ")).ToDictionary(a => a.Split('-')[0].Trim(), b => b.Split('-')[1].Trim());

                var diff = basepantoken.Where(a => !codepantoken[a.Key].Equals(a.Value, StringComparison.CurrentCultureIgnoreCase))
                                        .Select(b => b.Key.PadRight(19) + "-" + basepantoken[b.Key].Replace("RTK20000I", "Not Created").PadRight(16) + ":" + codepantoken[b.Key].Replace("RTK20000I", "Not Created").PadRight(16));

                if (diff.Count() > 0)
                {
                    tokenCheck.Percent = 100.0d;
                    tokenCheck.Comment.Add("Token difference between base and code:");
                    tokenCheck.Comment.Add("PAN                -BASE TOKEN      :CODE TOKEN");
                    tokenCheck.Comment.AddRange(diff);
                }

                ////this will give a list as follows
                //Pan		 - Baserun token  :  Coderun Token
                //4000220066315653-4104920060000004:4104920060000008
            }
            catch (Exception ex)
            {
                tokenCheck.Comment.Add("Token difference check failed : " + ex.Message);
                tokenCheck.Percent = 0.00d;
            }

            return tokenCheck;
        }


        #endregion

        #region Analysis Checks
        public void CalculateAnalysisScore()
        {
            CheckList.Add(doFallbackAndTBFCheck());
        }

        private Check doFallbackAndTBFCheck()
        {
            Check fallbackCheck = new Check("WEs fallen back and TBF items", (double)CheckType.CRITICAL);

            try
            {
                //////////////////////////////// parse fallback script ///////////////////////////////////////
                Regex flbkScriptRegex = new Regex(@"
                                                    (?<=\*-)(?:--------------\ WORK\ EFFORT\ |\ *)(?'WEnumber'(?:WE|SWITCH-)\d+)(?:\ ----------------|\ *)      # matches *- SWITCH-NNN OR *--------------- WORK EFFORT WE015284 ---------------- : start WE delimiter
                                                    (?'flbkCommands'(?:.|\s)*?)                                                                                 # Z commands for WE fallback
                                                    (?=\*---|\*---------------------|\z)                                                                        # matches ending delimiter : # *--------------------- OR *---
                                                    ", RegexOptions.IgnorePatternWhitespace);

                string flbkScript = System.IO.File.ReadAllText(System.IO.Path.Combine(runSett.CoderunServer, "FallbackScript.txt"));

                List<string> flbkScriptWEs = flbkScriptRegex.Matches(flbkScript)
                                                            .Cast<Match>()
                                                            .Where(flbkWE =>
                                                            {
                                                                var flbkCommands = flbkWE.Groups["flbkCommands"].Value.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries).ToList();
                                                                flbkCommands.RemoveAll(cmd => cmd.ToUpper().Contains("ZCYCL"));             // remove all ZCYCL Commands
                                                                return flbkCommands.Count > 0;                                              // i.e. WE fallback contains commands and is not an empty WE
                                                            })
                                                            .OrderBy(flbkWE => flbkWE.Index)
                                                            .Select(flbkWE => flbkWE.Groups["WEnumber"].Value)
                                                            .ToList();

                ///////////////////////////////// parse analysis Log ////////////////////////////////////////
                Regex analysisWEsRegex = new Regex(@"
                                                    (?<=\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\ START\ FALLBCK\ LOG\ \*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*)          # *************** START FALLBCK LOG ***************
                                                    \s*----------START\ (?'StartWE'(?:SWITCH-|WE)\d+)\ -------------                                    # ----------START (SWITCH-|WE)NNNNNNN -------------
                                                    (?'fallbackCommands'(?:.|\s)*?)                                                                     # Z commands for WE fallback   
                                                    ----------END\ (?'EndWE'(?:SWITCH-|WE)\d+)\ -------------\s*                                        # ----------END (SWITCH-|WE)NNNNNNNN -------------
                                                    (?=\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\ END\ FALLBCK\ LOG\ \*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*)             # *************** END FALLBCK LOG ****************  
                                                    ", RegexOptions.IgnorePatternWhitespace);

                string analysisLog = System.IO.File.ReadAllText(System.IO.Path.Combine(runSett.CoderunServer, "ANALYSIS LOG.txt"));

                List<string> analysisWEs = analysisWEsRegex.Matches(analysisLog)
                                                            .Cast<Match>()
                                                            .Where(analysisWE => analysisWE.Groups["StartWE"].Value.Equals(analysisWE.Groups["EndWE"].Value, StringComparison.InvariantCultureIgnoreCase))
                                                            .Where(flbkWE => !String.IsNullOrWhiteSpace(flbkWE.Groups["fallbackCommands"].Value))
                                                            .OrderBy(flbkWE => flbkWE.Index)
                                                            .Select(analysisWE => analysisWE.Groups["StartWE"].Value)
                                                            .ToList();
                ////////////////////////////////// Compare fallback script and analysis log and perform following checks ////////////////////////////////////////

                ////////////////////////// Check for WE fallback order in analysis log vs the fallback script /////////////////////
                // Index of the WE fallen back in analysis log should be same as that in the fallback script
                //string firstIncorrectWE = analysisWEs.FirstOrDefault(analysisWE => analysisWEs.IndexOf(analysisWE) != flbkScriptWEs.IndexOf(analysisWE));

                string firstIncorrectWE = flbkScriptWEs.GetRange(0, analysisWEs.Count)
                                                       .FirstOrDefault(WE => analysisWEs.IndexOf(WE) != flbkScriptWEs.IndexOf(WE));

                if (!String.IsNullOrEmpty(firstIncorrectWE))
                {// i.e. a WE in analysis log was incorrectly fallen back with reference to fallback script
                    fallbackCheck.Comment.Add("WEs were fallen back incorrectly, according to fallback script : " + firstIncorrectWE);
                    fallbackCheck.Percent = 0.0d;
                }
                else
                {// i.e. WEs were fallen back correctly according to analysis log
                    fallbackCheck.Comment.Add("WEs were fallen back in correct order");
                    fallbackCheck.Percent += 50.0d;
                }

                //////////////////////// Check for TBF items in recreate status file /////////////////////////
                string recreateStatus = System.IO.File.ReadAllText(System.IO.Path.Combine(runSett.CoderunServer, "Recreate Status.txt"));
                bool TBFitemsArePresent = Regex.IsMatch(recreateStatus, @"(-\s+TBF\s*)");

                ///////////////////////// Count remaining WEs to fallback //////////////////////////// 
                var remainingWEs = flbkScriptWEs.Except(analysisWEs);

                if (!TBFitemsArePresent && remainingWEs.Count() == 0)
                {// all OK
                    fallbackCheck.Percent += 50.0d;
                    fallbackCheck.Comment.Add("No TBF items in the Recreate status file and all WEs were fallen back");
                }
                else if (!TBFitemsArePresent && remainingWEs.Count() > 0)
                {
                    fallbackCheck.Comment.Add("No TBF items are present in the Recreate Status file, but some WEs weren't fallen back");
                    fallbackCheck.Comment.Add("Remaining WEs : " + String.Join(",", remainingWEs));
                    fallbackCheck.Percent += 50.0d;
                }
                else if (TBFitemsArePresent && remainingWEs.Count() == 0)
                {
                    fallbackCheck.Comment.Add("TBF items are present in the Recreate Status file, and all WEs were fallen back");
                    //fallbackCheck.Percent = 0.0d;
                    fallbackCheck.Percent += 50.0d;//Saumen030617
                }
                else if (TBFitemsArePresent && remainingWEs.Count() > 0)
                {
                    fallbackCheck.Comment.Add("Some WEs weren't fallen back despite the TBF items");
                    fallbackCheck.Comment.Add("Remaining WEs : " + String.Join(",", remainingWEs));
                    //fallbackCheck.Percent = 0.0d;
                    fallbackCheck.Percent += 50.0d;//Saumen030617
                }

            }
            catch (Exception ex)
            {
                fallbackCheck.Comment.Add("Error encountered while doing preliminary analysis of Arches : " + ex.ToString());
                fallbackCheck.Percent = 0.0d;
            }

            if (fallbackCheck.Percent > 99.9d)
            {// all OK
                fallbackCheck.Comment.Add("Regression analysis was done sucessfully : OK");
            }
            else
            { // Resolution
                fallbackCheck.Comment.Add("Resolution: Regression analysis has failed. Report to Automation team, then analyze the test cases manually: Not Ok");
            }

            return fallbackCheck;
        }
        #endregion

        /// <summary>
        /// Parses the provided fileContents to extract command outputs for the given command on different vpars stored in group 'vpars'
        /// </summary>
        /// <param name="fileContents">Contents of the file to be scanned</param>
        /// <param name="command"></param>
        /// <returns>Matched command outputs for different vpars</returns>
        private MatchCollection parseCommandFromConsoleLog(string command)
        {
            Regex cmdExtractingRegex = new Regex(@"==(?'vpars'\w+)==>\s*(?'command'%%%)\s*(?:(?<=%%%)(?'output'(?:.|\n)*?)(?=\==\w+==>|\z))".Replace("%%%", command), RegexOptions.IgnoreCase);

            return cmdExtractingRegex.Matches(regressionConsoleLog);
        }
    }

    public class Check
    {
        public readonly string Name;
        public List<string> Comment = new List<string>();

        public double Percent = 0.0d;
        public readonly double Credit;

        public Check(string checkName, double credit)
        {
            this.Name = checkName;
            this.Credit = credit;
        }
    }

}
