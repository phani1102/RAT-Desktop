﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using Outlook = Microsoft.Office.Interop.Outlook;
using QACT_WPF;
using System.Web.UI;
using System.Web.Script.Serialization;
using System.Runtime.InteropServices;

namespace QACT_WPF
{
    class OutlookEmail : IDisposable
    {
        private RunSettings RunSett;
        private Outlook.Application oApp;
        private Outlook.MailItem oMsg;
        private Outlook.Recipients oRecips;
        private Outlook.Recipient oRecip;
        private HtmlTextWriter html;
        System.IO.StringWriter strWriter;

        public String Subject;
        public String To;

        public IDictionary<string, string> coderunSettings;
        public IDictionary<string, string> coderunFiles;
        public IDictionary<string, string> coderunTapes;
        public IDictionary<string, string> coderunComparison;
        public IDictionary<string, string> coderunGlobals;
        public IDictionary<string, string> coderunProvTapes;


        public IDictionary<string, string> baserunSettings;
        public IDictionary<string, string> baserunFiles;
        public IDictionary<string, string> baserunTapes;
        public IDictionary<string, string> baserunGlobals;
        public IDictionary<string, string> baserunProvTapes;

        public OutlookEmail() 
        {
            this.RunSett = null;
            strWriter = new StringWriter();
            html = new HtmlTextWriter(strWriter, "\t");

        }
        public OutlookEmail(RunSettings RegVar) : this() {
            this.RunSett = RegVar;
            
            this.To = RunSett.email + "@visa.com";
            this.Subject = (RunSett.VIPS.Where(v => v.VPARS != "").Count() + " VIP " + RunSett.RegType).Replace("1 VIP 1VIP", "1VIP") + " Regression for " + RunSett.InstallDate + " install " + (String.IsNullOrWhiteSpace(RunSett.SwitchActivationInfo) || RunSett.SwitchActivationInfo.Equals("N/A", StringComparison.CurrentCultureIgnoreCase) ? null : RunSett.SwitchActivationInfo + " Switch Activated") + "(" + RunSett.RunNumber + ")";
            this.Bucket = RunSett.Bucket;

            coderunSettings = null;
            coderunFiles = new SortedList<string, string>();
            coderunTapes = new SortedList<string, string>();
            coderunComparison = new SortedList<string, string>();
            coderunGlobals = new Dictionary<string, string>();
            coderunProvTapes = new Dictionary<string, string>();

            baserunSettings = null;
            baserunFiles = new SortedList<string, string> ();
            baserunTapes = new SortedList<string, string> ();
            baserunGlobals = new Dictionary<string, string> ();
            baserunProvTapes = new Dictionary<string, string>();

            fetchRegData();

            /////////// sync the dictionaries ////////////
            syncDictionaries(ref coderunSettings, ref baserunSettings);
            syncDictionaries(ref coderunFiles, ref baserunFiles);
            syncDictionaries(ref coderunTapes, ref baserunTapes);
            syncDictionaries(ref coderunGlobals, ref baserunGlobals);

        }
        protected void syncDictionaries(ref IDictionary<string, string> dict1, ref IDictionary<string, string> dict2, string defaultValue = "NA")
        {
            if (dict1 == null || dict2 == null)
                return;

            IDictionary<string,string> tmpdict2 = new Dictionary<string,string>(dict2);

            foreach (KeyValuePair<string, string> entry1 in dict1.Where(e => !tmpdict2.ContainsKey(e.Key)))
            {
                tmpdict2[entry1.Key] = defaultValue;
            }

            IDictionary<string, string> tmpdict1 = new Dictionary<string, string>(dict1);

            foreach (KeyValuePair<string, string> entry2 in dict2.Where(e => !tmpdict1.ContainsKey(e.Key)))
            {
                tmpdict1[entry2.Key] = defaultValue;
            }

            try
            {
                if (tmpdict1.All(e => e.Value.Equals(defaultValue)))
                    tmpdict1.Clear();

                if (tmpdict2.All(e => e.Value.Equals(defaultValue)))
                    tmpdict2.Clear();
            }
            catch (Exception) { }

            dict1 = tmpdict1;
            dict2 = tmpdict2;
            return;
        }

        protected void fetchRegData()
        {
            ////////////////////////////////// Regression Settings /////////////////////////////////////////////////
            coderunSettings = fetchSett(RunSett);
            coderunGlobals = RunSett.Globals;
            baserunSettings = null;
            if (!String.IsNullOrWhiteSpace(RunSett.BaserunServer) && File.Exists(System.IO.Path.Combine(RunSett.BaserunServer, "RunSettings.json")))
            {
                RunSettings BaseRunSett = CommonClass.LoadFromJSONFile<RunSettings>(System.IO.Path.Combine(RunSett.BaserunServer, "RunSettings.json"));
                BaseRunSett.VMPWD = Crypto.Decrypt(BaseRunSett.VMPWD, App.Passphrase);
                baserunGlobals = BaseRunSett.Globals;
                baserunSettings = fetchSett(BaseRunSett);
            }
            ////////////////////////////////// Regression Files /////////////////////////////////////////////////

            string[] CodeRunServerFiles = Directory.GetFiles(RunSett.CoderunServer);

            foreach (string filePath in CodeRunServerFiles)
            {
                string fileName = Path.GetFileName(filePath);

                if (fileName.ToUpper().Contains("-CODERUN.TXT"))
                {
                    if (fileName.ToUpper().Contains("LOGTAPES"))
                    {
                        string[] CodeRunLogTapesFile = System.IO.File.ReadAllLines(filePath);
                        foreach (string line in CodeRunLogTapesFile)
                        {
                            if (line.Contains(":"))
                            {
                                coderunTapes[line.Split(':')[0].Trim()] = line.Split(':')[1].Trim();
                            }
                        }
                    }
                    else if (fileName.ToLower().Contains("provisioning_tapes"))
                    {
                        string[] CodeRunLogTapesFile = System.IO.File.ReadAllLines(filePath);
                        foreach (string line in CodeRunLogTapesFile)
                        {
                            if (line.Contains(":"))
                            {
                                coderunProvTapes[line.Split(':')[0].Trim()] = line.Split(':')[1].Trim();
                            }
                        }
                    }
                    else
                    {
                        coderunFiles[fileName.Split('-')[0].Replace('_', ' ').ToUpper().Trim()] = filePath;
                    }
                }

                else if (fileName.ToUpper().Contains("-BASERUN.TXT"))
                {
                    if (fileName.ToUpper().Contains("LOGTAPES"))
                    {
                        string[] BaseRunLogTapesFile = System.IO.File.ReadAllLines(filePath);
                        foreach (string line in BaseRunLogTapesFile)
                        {
                            if (line.Contains(":"))
                            {
                                baserunTapes[line.Split(':')[0].Trim()] = line.Split(':')[1].Trim();
                            }
                        }
                    }
                    else if (fileName.ToLower().Contains("provisioning_tapes"))
                    {
                        string[] BaseRunLogTapesFile = System.IO.File.ReadAllLines(filePath);
                        foreach (string line in BaseRunLogTapesFile)
                        {
                            if (line.Contains(":"))
                            {
                                baserunProvTapes[line.Split(':')[0].Trim()] = line.Split(':')[1].Trim();
                            }
                        }
                    }
                    else
                        baserunFiles[fileName.Split('-')[0].Replace('_', ' ').ToUpper().Trim()] = filePath;

                }
                else if (fileName.ToUpper().Contains("MM.TXT") || fileName.ToUpper().Contains("H14") || fileName.ToUpper().Contains("F39"))
                {
                    coderunComparison[Path.GetFileNameWithoutExtension(fileName).Replace("MM", " MM").ToUpper().Trim()] = filePath;
                }

            }

            /////////////////////// GLObals /////////////////////////
        }
        protected Dictionary<string, string> fetchSett(RunSettings RunSett)
        {
            Dictionary<string, string> coderun = new Dictionary<string, string>();
            // Globals
            if (File.Exists(RunSett.CoderunServer + @"\setup-coderun.txt"))
            {
                string system = File.ReadAllLines(RunSett.CoderunServer + @"\setup-coderun.txt").First(l => l.ToUpper().Contains("J.VPARSTYPES")).Substring("J.VPARSTYPES".Length).Trim();
                //Take item 2 instead
                if (system.Split(',').Count() > 1)
                    system = system.Split(',')[1];
                else
                    system = system.Split(',')[0];

                coderun["Test Environment"] = system.Remove(system.Length - 1) + "X";
            }
            coderun["Regression type"] = RunSett.RegType;

            coderun["Install Date"] = RunSett.InstallDate;

            coderun["System Date"] = RunSett.SystemDate;

            coderun["Regression Run Date"] = RunSett.RunDate.ToString(@"MM\/dd\/yyyy");

            coderun["Regression Capture"] = RunSett.RegCapture;
            coderun["Release Switch Information"] = RunSett.SwitchActivationInfo;
            coderun["9000 Security Modules"] = RunSett.HSMUnit == null || RunSett.HSMUnit.ToUpper().Contains("NA") ? "NA" : "Attached";
            coderun["Run Number"] = RunSett.RunNumber; // add run number to table
            coderun["Job Submitted/Bucket Run from VM/CMS Id"] = RunSett.VMID;
            coderun["Bucket"] = RunSett.Bucket;

            //coderun["Run#"] = 
            return coderun;
        }
        /// <summary>
        /// Sends and Email using outlook API
        /// </summary>
        public void SaveAndSendEmail()
        {
            string HTMLBODY = CreateHTMLBody();
            //First save the email
            System.IO.File.WriteAllText(RunSett.CoderunServer + @"\Mail.html", HTMLBODY);
            //////////////////////////////////////////// Create the Outlook application ////////////////////////////////////////
            oApp = new Outlook.Application();
            //////////////////////////////////////////// Create a new mail item ////////////////////////////////////////////////
            oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

            ////////////////////////////////////////// Message HTMLBody ////////////////////////////////////////////////////////

            // File.WriteAllText(RunSett.CoderunServer + @"\Mail.html", HTMLString);
            oMsg.HTMLBody = HTMLBODY;

            /*
            ////////////////////////////////////////// ADD AN ATTACHMENT /////////////////////////////////////////////////////
            String sDisplayName = "MyAttachment";
            int iPosition = (int)oMsg.Body.Length + 1;
            int iAttachType = (int)Outlook.OlAttachmentType.olByValue;
            //now attached the file
            Outlook.Attachment oAttach = oMsg.Attachments.Add(@"C:\\fileName.jpg", iAttachType, iPosition, sDisplayName);
            */

            ////////////////////////////////////////////// Subject line /////////////////////////////////////////////////////
            oMsg.Subject = Subject;
            // Save the result email to server required for arches//
            oMsg.SaveAs(RunSett.CoderunServer + "\\Reg_Result_Mail.msg", Outlook.OlSaveAsType.olMSG);
            ///////////////////////////////////////////// Add a recipient ///////////////////////////////////////////////////
            oRecips = (Outlook.Recipients)oMsg.Recipients;
            oRecip = (Outlook.Recipient)oRecips.Add(To);
            oRecip.Resolve();

            //oMsg.SaveAs(RunSett.CoderunServer + "\\Reg_Result_Mail.msg", Outlook.OlSaveAsType.olMSG);
            /////////////////////////////////////////////// Send Message ////////////////////////////////////////////////////
            ((Outlook._MailItem)oMsg).Send();

            Dispose();
        }
        protected string style()
        {
            return
                @"<head>
                    <style>

                        body {
                            font-family:Calibri
                        }

                        h5, h4, h3, h2, h1 {
                            text-decoration: underline;
                        }

                        table {
                            border-collapse: collapse;
                         }

                        table, th, td {
                             border: 1px solid black;
                         }
                         
                        th {
                            background-color: LightYellow;
                        }
                        td {
                            background-color:  LightCyan;
                        }
                        tr.head{
                            background-color: LightGray;
                        }
                        p{
                            font-family:Calibri
                        }
                    </style>
                </head>";
        }
        public string CreateHTMLBody() 
        {

            {
                html.RenderBeginTag(HtmlTextWriterTag.Body);

                html.RenderBeginTag(HtmlTextWriterTag.P);

                html.Write("We have the result of <b>" + Subject + "</b> with <b>" + coderunSettings["Regression Capture"] + @"</b> Capture. 
            The Code Run was performed on the updated " + coderunSettings["Test Environment"] + " (" + coderunSettings["Install Date"] + @" code level) system with all recent changes applied in the system manually. ");

                if (RunSett.IsComparisonRequired)
                {
                    html.Write("The Regression result was Compared with " + baserunSettings["Install Date"] + " install " + baserunSettings["Regression type"] +"("+baserunSettings["Run Number"]+")" + @" regression to create the final report. <b>" + Bucket + "</b> capture was used for both the runs. ");
                }

                if (baserunSettings == null)
                {
                    html.Write("<span>System Date for coderun was <b>" + coderunSettings["System Date"] + "</b></span>");

                }
                else if (coderunSettings["System Date"].Equals(baserunSettings["System Date"]))
                {
                    html.Write("<span>System Date of <b>" + coderunSettings["System Date"] + "</b> was used for both Base Run & Code Run.</span>");

                }
                else
                {
                    html.Write("<span>System Date for coderun was <b>" + coderunSettings["System Date"] + "</b> and for baserun was <b>" + baserunSettings["System Date"] + "</b></span>");
                }
                html.RenderEndTag();//p
                // For autoreg ids
                html.RenderBeginTag(HtmlTextWriterTag.P); 
                html.Write("To get AUTOREG ids use ");
                html.RenderBeginTag(HtmlTextWriterTag.Q);
                        html.Write("GET AUTOREG&lt;N&gt; 291"); 
                        html.RenderEndTag();
                html.RenderEndTag();

                html.RenderBeginTag(HtmlTextWriterTag.P); html.Write("Console log can be viewed using "); html.RenderBeginTag(HtmlTextWriterTag.Q); html.Write("VC  &lt; VPARS ID &gt;"); html.RenderEndTag(); html.RenderEndTag();//p                    

                CreateDumpTable("New Dumps:", RunSett);

                CreateTable1(RunSett.RegType + " Regression Settings:", "Features", "Base Run", "Code Run", baserunSettings, coderunSettings);

                CreateTable1(RunSett.RegType + " Regression Files:", "File Types", "Base Run File Paths", "Code Run File Paths", baserunFiles, coderunFiles, true);

                if (!String.IsNullOrWhiteSpace(RunSett.BaserunServer) && File.Exists(System.IO.Path.Combine(RunSett.BaserunServer, "RunSettings.json")))
                    CreateTable2("Base Run Provisioning tapes:", baserunProvTapes, CommonClass.LoadFromJSONFile<RunSettings>(System.IO.Path.Combine(RunSett.BaserunServer, "RunSettings.json")));

                CreateTable2("Code Run Provisioning tapes:", coderunProvTapes, RunSett);

                if (RunSett.IsComparisonRequired)
                    CreateTable1(RunSett.RegType + " Comparison Files:", "File Types", "", "File Paths", null, coderunComparison, true);

                if (!String.IsNullOrWhiteSpace(RunSett.BaserunServer) && File.Exists(System.IO.Path.Combine(RunSett.BaserunServer, "RunSettings.json")))
                    CreateTable2("Base Run Vtapes:", baserunTapes, CommonClass.LoadFromJSONFile<RunSettings>(System.IO.Path.Combine(RunSett.BaserunServer, "RunSettings.json")));

                CreateTable2("Code Run Vtapes:", coderunTapes, RunSett);

                CreateTable1(RunSett.RegType + " Globals:", "Tapes", "Base Run", "Code Run", baserunGlobals, coderunGlobals);

                html.RenderEndTag(); //body
            }
            return "<html>\n" + style() + strWriter.ToString() + "\n</html>";
        }
        protected string CreateTable1(string table1Header, string table1Col1, string table1Col2, string table1Col3, IDictionary<string,string> baserun, IDictionary<string,string> coderun, bool hyperlink=false)
        {
            if ( baserun==null || baserun.Count == 0)
                 baserun = null;
            {
                html.AddAttribute(HtmlTextWriterAttribute.Class, table1Header.Replace(" ", ""));
                html.RenderBeginTag(HtmlTextWriterTag.Div);

                html.RenderBeginTag(HtmlTextWriterTag.H4); html.Write(table1Header); html.RenderEndTag();

                html.RenderBeginTag(HtmlTextWriterTag.Table);
                html.RenderBeginTag(HtmlTextWriterTag.Thead);
                html.RenderBeginTag(HtmlTextWriterTag.Tr);

                html.RenderBeginTag(HtmlTextWriterTag.Th); html.Write(table1Col1); html.RenderEndTag();         //COL1
                if (baserun != null)
                { html.RenderBeginTag(HtmlTextWriterTag.Th); html.Write(table1Col2); html.RenderEndTag(); }     //COL2
                html.RenderBeginTag(HtmlTextWriterTag.Th); html.Write(table1Col3); html.RenderEndTag();         //COL3

                html.RenderEndTag(); //tr
                html.RenderEndTag();//thead
                for (int i = 0; i < coderun.Count; i++)
                {
                    html.RenderBeginTag(HtmlTextWriterTag.Tr);
                    string key = coderun.ElementAt(i).Key;
                   
                       html.RenderBeginTag(HtmlTextWriterTag.Th); html.Write(key); html.RenderEndTag();
                       if (hyperlink)
                       {
                           if (baserun != null)
                           {
                               html.RenderBeginTag(HtmlTextWriterTag.Td);
                                   if (!baserun[key].Equals("NA",StringComparison.InvariantCultureIgnoreCase)) 
                                            html.AddAttribute(HtmlTextWriterAttribute.Href, baserun[key]);
                                   html.RenderBeginTag(HtmlTextWriterTag.A); html.Write(Path.GetFileNameWithoutExtension(baserun[key]).ToUpper()); html.RenderEndTag();
                               html.RenderEndTag();//td
                           }

                           html.RenderBeginTag(HtmlTextWriterTag.Td);
                                   if (!coderun[key].Equals("NA", StringComparison.InvariantCultureIgnoreCase)) 
                                            html.AddAttribute(HtmlTextWriterAttribute.Href, coderun[key]);
                                html.RenderBeginTag(HtmlTextWriterTag.A); html.Write(Path.GetFileNameWithoutExtension(coderun[key]).ToUpper()); html.RenderEndTag();
                           html.RenderEndTag();//td
                       }
                       else
                       {
                           if (baserun != null)
                                { html.RenderBeginTag(HtmlTextWriterTag.Td); html.Write(baserun[key]); html.RenderEndTag(); }
                        
                           html.RenderBeginTag(HtmlTextWriterTag.Td); html.Write(coderun[key]); html.RenderEndTag();
                       }
                   
                    html.RenderEndTag(); // tr
                }

                html.RenderEndTag();//table
                html.RenderEndTag(); //div
            }

            return strWriter.ToString();
    }
        protected string CreateTable2(string table2Header, IDictionary<string,string> coderunTapes, RunSettings RunSett)
        {
            if (coderunTapes == null || coderunTapes.Count == 0)
                return "";

            else if (RunSett.VIPS == null || RunSett.VIPS.Count <= 0)
            {
                int maxVIPS = coderunTapes.Max(entry => entry.Value.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Length);

                RunSett.VIPS = new List<VIP>();
                for (int i=0 ; i < maxVIPS; i++) 
                {
                    VIP newVIP = new VIP();
                    newVIP.VIPNAME = "NA";
                    newVIP.VPARS = "NA";
                    RunSett.VIPS.Add(newVIP);
                }            
            }

            {
                html.AddAttribute(HtmlTextWriterAttribute.Class, table2Header.Replace(" ", ""));
                html.RenderBeginTag(HtmlTextWriterTag.Div);

                html.RenderBeginTag(HtmlTextWriterTag.H4); html.Write(table2Header); html.RenderEndTag();

                html.RenderBeginTag(HtmlTextWriterTag.Table);
                html.RenderBeginTag(HtmlTextWriterTag.Thead);
                html.RenderBeginTag(HtmlTextWriterTag.Tr);
                     html.RenderBeginTag(HtmlTextWriterTag.Th); html.Write("VTAPES"); html.RenderEndTag();

                    foreach (QACT_WPF.VIP vic in RunSett.VIPS)
                    {
                        if (!vic.VPARS.Equals(""))
                            { html.RenderBeginTag(HtmlTextWriterTag.Th); html.Write(vic.VIPNAME + "(" + vic.VPARS + ")"); html.RenderEndTag(); }

                    }
                html.RenderEndTag(); //tr
                html.RenderEndTag();//thead

                foreach (KeyValuePair<string, string> tape in coderunTapes)
                {
                    html.RenderBeginTag(HtmlTextWriterTag.Tr);
                    html.RenderBeginTag(HtmlTextWriterTag.Th); html.Write(tape.Key); html.RenderEndTag();
                    foreach (string tapeNumber in tape.Value.Split(','))
                    {
                        html.RenderBeginTag(HtmlTextWriterTag.Td); html.Write(tapeNumber); html.RenderEndTag();
                    }
                    html.RenderEndTag(); //tr
                }
                
                html.RenderEndTag();//table
                html.RenderEndTag(); //div
            }

            return strWriter.ToString();
        }
        protected string CreateDumpTable(string tableHeader, RunSettings RunSett) 
        {
            if (!File.Exists(Path.Combine(RunSett.CoderunServer, "DUMPS_UNIQUE.txt")) || File.ReadAllLines(Path.Combine(RunSett.CoderunServer, "DUMPS_UNIQUE.txt")).Count(ln => !String.IsNullOrWhiteSpace(ln)) < 1)
                 return strWriter.ToString();

            {
                html.AddAttribute(HtmlTextWriterAttribute.Class, tableHeader.Replace(" ", ""));
                html.RenderBeginTag(HtmlTextWriterTag.Div);

                html.RenderBeginTag(HtmlTextWriterTag.H4); html.Write(tableHeader); html.RenderEndTag();

                html.RenderBeginTag(HtmlTextWriterTag.Table);
                
                html.RenderBeginTag(HtmlTextWriterTag.Thead);
                html.RenderBeginTag(HtmlTextWriterTag.Tr);

                html.RenderBeginTag(HtmlTextWriterTag.Th); html.Write("ERROR"); html.RenderEndTag();
                html.RenderBeginTag(HtmlTextWriterTag.Th); html.Write("VPARS"); html.RenderEndTag();
                html.RenderBeginTag(HtmlTextWriterTag.Th); html.Write("PROGRAM"); html.RenderEndTag();
                html.RenderBeginTag(HtmlTextWriterTag.Th); html.Write("STAGE"); html.RenderEndTag();
                html.RenderEndTag(); //tr
                html.RenderEndTag();//thead

                foreach (string dumpLine in File.ReadLines(Path.Combine(RunSett.CoderunServer, "DUMPS_UNIQUE.txt"))
                                                                                                               .Where(ln => !String.IsNullOrWhiteSpace(ln)
                                                                                                                   && ln.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Length > 3))
                {
                    html.RenderBeginTag(HtmlTextWriterTag.Tr);

                    string dumpNumber = dumpLine.Split(new char[] { ' ' },StringSplitOptions.RemoveEmptyEntries)[1];
                    var linesplit = dumpLine.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                    string vpars = linesplit.Length>1?linesplit[1]:"Unknown(error)";
                    string stage = linesplit.Length > 2 ? linesplit[2] : "Unknown(error)";
                    string prog = dumpLine.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[2];

                    html.RenderBeginTag(HtmlTextWriterTag.Th);   html.Write(dumpNumber); html.RenderEndTag(); 
                    html.RenderBeginTag(HtmlTextWriterTag.Td); html.Write(vpars); html.RenderEndTag();
                    html.RenderBeginTag(HtmlTextWriterTag.Td); html.Write(prog); html.RenderEndTag();
                    html.RenderBeginTag(HtmlTextWriterTag.Td); html.Write(stage); html.RenderEndTag();
                    html.RenderEndTag(); //tr
                
                }

                html.RenderEndTag();//table
                html.RenderEndTag(); //div
            }


            return strWriter.ToString();
        }

        public void StoreAsJson(string jsonPath)
        {
            JavaScriptSerializer serialize = new JavaScriptSerializer();
            System.IO.File.WriteAllText(jsonPath, FormatJson(serialize.Serialize(this)));
        }
        private string FormatJson(string json, string INDENT_STRING = "   ")
        {

            int indentation = 0;
            int quoteCount = 0;
            var result =
                from ch in json
                let quotes = ch == '"' ? quoteCount++ : quoteCount
                let lineBreak = ch == ',' && quotes % 2 == 0 ? ch + Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, indentation)) : null
                let openChar = ch == '{' || ch == '[' ? ch + Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, ++indentation)) : ch.ToString()
                let closeChar = ch == '}' || ch == ']' ? Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, --indentation)) + ch : ch.ToString()
                select lineBreak == null
                            ? openChar.Length > 1
                                ? openChar
                                : closeChar
                            : lineBreak;

            return String.Concat(result);
        }
        public void Dispose()
        {
            ////////////////////////////////////////////// Dispose Outlook ///////////////////////////////////////////////////
            oRecip = null;
            oRecips = null;
            oMsg = null;
            oApp = null;
            strWriter.Dispose();
            html.Dispose();
            //GGIRDHAR 01/23/2017 - Introduce GC for Outlook Object. The Entire Block Below takes care of disposing the Outlook Objects.
            // GGIRDHAR - The Block starts here
            if (oRecip != null || oRecips != null || oMsg != null || oApp != null)
            {
                try
                {
                    Marshal.ReleaseComObject(oRecip);
                    oRecip = null;
                    Marshal.ReleaseComObject(oMsg);
                    oMsg = null;
                    Marshal.ReleaseComObject(oRecips);
                    oRecips = null;
                    Marshal.ReleaseComObject(oApp);
                    oApp = null;
                }
                catch (Exception)
                {
                    oRecip = null;
                    oRecips = null;
                    oMsg = null;
                    oApp = null;
                }
                finally
                {
                    GC.Collect();
                }
            }
            // GGIRDHAR - The Block ends here
        }

        public string Bucket { get; set; }
    }
}
