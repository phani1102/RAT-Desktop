﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace QACT_WPF
{
    class Using
    {
        private static string usingFilePath = System.IO.Path.Combine(App.AutomationFiles, "Using.json");
        public IDictionary<string, string> UsingData = null;
        private static string logonById = "SAUBISWC";
        public Using()
        {
            UsingData = new Dictionary<string, string>();
        }
        public Using(string usageFilePath)
        {
            UsingData = System.IO.File.ReadAllLines(usageFilePath)
                                        .Where(ln => !String.IsNullOrWhiteSpace(ln) && ln.Contains("==>"))
                                        .ToDictionary(ln => ln.Split(new string[] { "==>" }, 2, StringSplitOptions.RemoveEmptyEntries)[0].Trim().ToUpper(),
                                                       ln => ln.Split(new string[] { "==>" }, 2, StringSplitOptions.RemoveEmptyEntries)[1].Trim().ToUpper());

        }
        public string getNextAutoreg()
        {
            //Saumen020617 : added back commit 22789285877 - handle exception when autoreg id is not available
            //return UsingData.First(e => e.Key.Contains("AUTOREG") && e.Value.Equals("NEXT-USE", StringComparison.InvariantCultureIgnoreCase)).Key;
            try
            {
                return UsingData.First(e => e.Key.Contains("AUTOREG") && e.Value.Equals("NEXT-USE", StringComparison.InvariantCultureIgnoreCase)).Key;
            }
            catch (InvalidOperationException)
            {
                System.IO.File.WriteAllText(@"C:\RunErrors.txt", "No AUTOREG Id is FREE");
                return " ";
            }
            //Saumen020617
        }

        /// <summary>
        /// Returns a previous password according to the previous month
        /// </summary>
        /// <param name="VMId">VMid with atleast one digit</param>
        /// <returns>Previous password for this VM id</returns>
        public static string getPreviousPassword(string VMId)
        {
            return DateTime.Now.AddMonths(-1).ToString("MMMyyyy");  
        }
        /// <summary>
        /// Returns the current password according to the current month
        /// </summary>
        /// <param name="VMId">VMid with atleast one digit</param>
        /// <returns>Current password for this VM id</returns>
        public static string getCurrentPassword(string VMId)
        {
            return DateTime.Now.ToString("MMMyyyy");    // @"\w{3}\d{4}"
        }
        public static string getUserId()
        {
            return Using.LoadFromJSON().getNextAutoreg() + " BY " + logonById;
        }
        //public static bool isLogonByUserId(string userId)
        //{
        //    return userId.ToUpper().Contains(" BY ");
        //}
        //public static string parseLogonById(string userId)
        //{
        //    return userId.ToUpper().Split(new string[] { " BY " }, 2 , StringSplitOptions.RemoveEmptyEntries).Last();
        //}
        public void StoreAsJSON()
        {
            JavaScriptSerializer serialize = new JavaScriptSerializer();

            System.IO.File.WriteAllText(usingFilePath, FormatJson(serialize.Serialize(this)));
        }

        private string FormatJson(string json, string INDENT_STRING = "   ")
        {

            int indentation = 0;
            int quoteCount = 0;
            var result =
                from ch in json
                let quotes = ch == '"' ? quoteCount++ : quoteCount
                let lineBreak = ch == ',' && quotes % 2 == 0 ? ch + Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, indentation)) : null
                let openChar = ch == '{' || ch == '[' ? ch + Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, ++indentation)) : ch.ToString()
                let closeChar = ch == '}' || ch == ']' ? Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, --indentation)) + ch : ch.ToString()
                select lineBreak == null
                            ? openChar.Length > 1
                                ? openChar
                                : closeChar
                            : lineBreak;

            return String.Concat(result);
        }
        public static Using LoadFromJSON(string JsonFilePath = null)
        {
            JsonFilePath = String.IsNullOrWhiteSpace(JsonFilePath) ? usingFilePath : JsonFilePath;

            Using DataObj = null;
            JavaScriptSerializer serialize = new JavaScriptSerializer();
            try
            {
                DataObj = (Using)serialize.Deserialize(System.IO.File.ReadAllText(JsonFilePath), typeof(Using));
            }
            catch (Exception)
            {

            }
            return DataObj;
        }

    }
}
