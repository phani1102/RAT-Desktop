﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;


namespace QACT_WPF
{
    public class Capture
    {
        public string CaptureDateString;
        public string SystemDateString;
        public IList<string> FTPFiles = new List<string>();
        public IList<string> CupTapes = new List<string>();
        
        private static string DateStringFormat = CaptureInfoFile.DateStringFormat;

        public Capture(string captureDateString, string systemDateString, List<string> ftpFiles, List<string> cupTapes)
        {
            DateStringFormat =  CaptureInfoFile.DateStringFormat;
            CaptureDateString = DateTime.ParseExact(captureDateString, DateStringFormat, System.Globalization.CultureInfo.InvariantCulture).ToString(DateStringFormat);
            SystemDateString = DateTime.ParseExact(systemDateString, DateStringFormat, System.Globalization.CultureInfo.InvariantCulture).ToString(DateStringFormat);
            FTPFiles = ftpFiles;
            CupTapes = cupTapes;
        }
        public Capture()
        {
            CaptureDateString = DateTime.Now.ToString(CaptureInfoFile.DateStringFormat);

            SystemDateString = null;
        }
    }

    public class CaptureInfoFile
    {
        public static string CaptureInfoFilePath = System.IO.Path.Combine(App.CaptureDetailsServer, "CaptureInfoFile.json");

        public List<Capture> CaptureList = new List<Capture>();

        public static string DateStringFormat = @"MM/dd/yyyy";

        public CaptureInfoFile()
        {
            DateStringFormat = @"MM/dd/yyyy";
            CaptureList = new List<Capture>();
        }

        public Capture GetCapture(DateTime captureDate)
        {
            return CaptureList.SingleOrDefault(capInfo => DateTime.ParseExact(capInfo.CaptureDateString, DateStringFormat, System.Globalization.CultureInfo.InvariantCulture).Date == captureDate.Date);

            //Capture currCapture = new Capture();
            //try
            //{
            //    currCapture = CaptureList.SingleOrDefault(capInfo => DateTime.ParseExact(capInfo.CaptureDateString, DateStringFormat, System.Globalization.CultureInfo.InvariantCulture).Date == captureDate.Date);
            //}
            //catch 
            //{ }

            //return (currCapture==null) ? new Capture() : currCapture;
        }
        public Capture AddCapture(Capture newCapture)
        {
            CaptureList.RemoveAll(capInfo => DateTime.ParseExact(capInfo.CaptureDateString, DateStringFormat, System.Globalization.CultureInfo.InvariantCulture).Date == DateTime.ParseExact(newCapture.CaptureDateString, @"MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture).Date);

            CaptureList.Add(newCapture);
            this.StoreAsJsonFile(CaptureInfoFilePath);
            return GetCapture(DateTime.ParseExact(newCapture.CaptureDateString, DateStringFormat, System.Globalization.CultureInfo.InvariantCulture));
        }
    //    public void StoreAsJSON()
    //    {
    //        JavaScriptSerializer serialize = new JavaScriptSerializer();

    //        System.IO.File.WriteAllText(CaptureInfoFilePath, FormatJson(serialize.Serialize(this)));
    //    }

    //    private string FormatJson(string json, string INDENT_STRING = "\t")
    //    {
            
    //        int indentation = 0;
    //        int quoteCount = 0;
    //        var result =
    //            from ch in json
    //            let quotes = ch == '"' ? quoteCount++ : quoteCount
    //            let lineBreak = ch == ',' && quotes % 2 == 0 ? ch + Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, indentation)) : null
    //            let openChar = ch == '{' || ch == '[' ? ch + Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, ++indentation)) : ch.ToString()
    //            let closeChar = ch == '}' || ch == ']' ? Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, --indentation)) + ch : ch.ToString()
    //            select lineBreak == null
    //                        ? openChar.Length > 1
    //                            ? openChar
    //                            : closeChar
    //                        : lineBreak;

    //        return String.Concat(result);
    //    }

    //    public static CaptureInfoFile LoadFromJSON(string JsonFilePath = null)
    //    {
         
    //        JsonFilePath = String.IsNullOrWhiteSpace(JsonFilePath) ? CaptureInfoFilePath : JsonFilePath;

    //        CaptureInfoFile DataObj = null;
    //        JavaScriptSerializer serialize = new JavaScriptSerializer();
    //        try
    //        {
    //            DataObj = (CaptureInfoFile)serialize.Deserialize(System.IO.File.ReadAllText(JsonFilePath), typeof(CaptureInfoFile));
    //        }
    //        catch (Exception)
    //        {

    //        }
    //        return DataObj;
    //    }
    }
}
