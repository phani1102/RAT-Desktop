﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for iSetup.xaml
    /// isetup(iSetup) sys=QA1PZx(populate system name) glb=09/15(global capture) noedit(no intermediate window) vipa=anujana1,12,prod0804,test(vpars,qat,zburzs,) vipb=anujana2,13,prod0804 file=baserun(cms filename) run=ECIP(run specific command)
    /// </summary>
    public partial class iSetup : Page, INotifyPropertyChanged
    {
        public ObservableCollection<VIP> ObsAllVIP { get { return this._ObsAllVIP; } set { _ObsAllVIP = value; NotifyPropertyChanged("OBSALLVIP"); } }
        ObservableCollection<VIP> _ObsAllVIP = new ObservableCollection<VIP>();

        public string CurrentError { get { return this._CurrentError; } set { _CurrentError = value; NotifyPropertyChanged("CurrentError"); } }
        string _CurrentError;
        
       
        //public ObservableCollection<string> PresentSystems { get { return this._PresentSystems; } set { _PresentSystems = value; NotifyPropertyChanged("PresentSystems"); } }
        ObservableCollection<string> _PresentSystems = new ObservableCollection<string>();
        List<string> WholeTSU = new List<string>();
        List<string> primarysetup = new List<string>();
        string requestedsystem, requestedglobal, requestedfile, requestedrun, cmsid, pwd, requestedbasesystem;//Saumen030917
        public List<string> FilestoTransfer = new List<string>();
        bool IsRequestedList;
        public iSetup()
        {
            InitializeComponent();
            PrePopulateSettings();
        }
        public iSetup(bool getlist)
        {
            InitializeComponent();
            CurrentError = null;
            IsRequestedList = getlist;
            CommonClass.ChangeStatus("Requesting automated setup.", 0, 0, false);
            //FilestoTransfer = new List<string>();
            PrePopulateSettings();
            
        }
        private void PrePopulateSettings()
        {
            #region Populate_VIP_Details
            if (App.CMDLINEARGS.Any(a => App.ALLVIPS.Any(x => a.ToUpper().Contains("VIP" + x + "="))))
                foreach (var vicid in App.ALLVIPS)
                {
                    VIP tempvip = new VIP() { VIPNAME = "VIP" + vicid, IsEnabled = false };
                    string tmptext = App.CMDLINEARGS.Where(a => a.ToUpper().Contains("VIP" + vicid + "=")).FirstOrDefault();
                    if (tmptext == null)
                        _ObsAllVIP.Add(tempvip);
                    else
                    {
                        string[] tmpdetails = App.CMDLINEARGS.Where(a => a.ToUpper().Contains("VIP" + vicid + "=")).FirstOrDefault().ToUpper().Replace("VIP" + vicid + "=", "").Split(',');
                        tempvip.VPARS = tmpdetails.Count() > 0 ? tmpdetails[0] : "";
                        tempvip.IsEnabled = tmpdetails.Count() > 0 ? true : false;
                        tempvip.QAT = tmpdetails.Count() > 1 ? tmpdetails[1] : "";
                        if (tmpdetails.Count() > 2)
                            for (int i = 2; i < tmpdetails.Count(); i++) tempvip.ZBURZ += tmpdetails[i] + ",";
                        tempvip.ZBURZ = tempvip.ZBURZ != "" ? tempvip.ZBURZ.TrimEnd(',') : "";
                        _ObsAllVIP.Add(tempvip);
                    }
                }
            else
            {
                foreach (var vicid in App.ALLVIPS)
                {
                    VIP tempvip = new VIP() { VIPNAME = "VIP" + vicid, IsEnabled = vicid == "B" ? true : false };
                    _ObsAllVIP.Add(tempvip);
                }
            }
            //listVIPS.ItemsSource = _ObsAllVIP;
            #endregion
            #region Populate Other settings
            if (App.CMDLINEARGS.Any(a => a.ToUpper().Contains("SYS=")))
                requestedsystem = App.CMDLINEARGS.First(c => c.ToUpper().Contains("SYS=")).ToUpper().Replace("SYS=", "").Trim();
            if (App.CMDLINEARGS.Any(a => a.ToUpper().Contains("GLB=")))
                requestedglobal = App.CMDLINEARGS.First(c => c.ToUpper().Contains("GLB=")).ToUpper().Replace("GLB=", "").Trim();
            if (App.CMDLINEARGS.Any(a => a.ToUpper().Contains("FILE=")))
                requestedfile = App.CMDLINEARGS.First(c => c.ToUpper().Contains("FILE=")).ToUpper().Replace("FILE=", "").Trim();
            if (App.CMDLINEARGS.Any(a => a.ToUpper().Contains("RUN=")))
            //Saumen030917
            {
                requestedrun = App.CMDLINEARGS.First(c => c.ToUpper().Contains("RUN=")).ToUpper().Replace("RUN=", "").Trim();
                if (requestedrun.Contains("UNBALANCED"))
                {
                    chkUnbalanced.IsChecked = true;
                }
            }
            //Saumen030917
            if (App.CMDLINEARGS.Any(a => a.ToUpper().Contains("CMS=")))
                txtCMS.Text = App.CMDLINEARGS.First(c => c.ToUpper().Contains("CMS=")).ToUpper().Replace("CMS=", "").Trim();
            if (App.CMDLINEARGS.Any(a => a.ToUpper().Contains("PWD=")))
                txtPWD.Password = App.CMDLINEARGS.First(c => c.ToUpper().Contains("PWD=")).ToUpper().Replace("PWD=", "").Trim();
            //Saumen030917
            if (App.CMDLINEARGS.Any(a => a.ToUpper().Contains("BASESYS=")))
                requestedbasesystem = App.CMDLINEARGS.First(c => c.ToUpper().Contains("BASESYS=")).ToUpper().Replace("BASESYS=", "").Trim();
            //Saumen030917
            //Populate only the file name
            txtCMSFILE.Text = requestedfile != null && requestedfile.Length > 8 ? requestedfile.Substring(0, 8) : requestedfile;

            #endregion
            if (App.CMDLINEARGS.Any(a => a.ToUpper().Contains("USESERV")))
            {
                var presentsystems = PopulateSystems(System.IO.File.ReadAllLines(App.TSUFileServer), ref WholeTSU);
                if (presentsystems.Count != 0)
                {
                    txtTsuPath.Text = App.TSUFileServer;
                    comboTestSystems.ItemsSource = presentsystems;
                    if (requestedsystem != null && requestedsystem != "")
                    {
                        comboTestSystems.SelectedItem = presentsystems.FirstOrDefault(s => s.ToUpper().Contains(requestedsystem));
                    }
                }
                if (App.CMDLINEARGS.Any(a => a.ToUpper().Contains("NOCLICK")))
                    btnCreateSetup_Click(null, null);
            }

        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog() { Multiselect = false, ReadOnlyChecked = true, Title = "Select the file containing TSU", Filter = "All Files|*.*" };
            openfile.ShowDialog();
            if (openfile.FileName != "")
            {
                var presentsystems = PopulateSystems(System.IO.File.ReadAllLines(openfile.FileName), ref WholeTSU);
                if (presentsystems.Count != 0)
                {
                    txtTsuPath.Text = openfile.FileName;
                    comboTestSystems.ItemsSource = presentsystems;
                    if (requestedsystem != null && requestedsystem != "")
                    {
                        comboTestSystems.SelectedItem = presentsystems.FirstOrDefault(s => s.ToUpper().Contains(requestedsystem));
                    }
                }
            }
        }

        private void pageiSetup_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop) || e.Data.GetDataPresent(DataFormats.Text))
            {
                e.Effects = DragDropEffects.Copy;
            }
        }

        private void pageiSetup_Drop(object sender, DragEventArgs e)
        {
            List<string> presentsystems = new List<string>();
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] Myfiles = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (Myfiles.Length != 1)
                {
                    MessageBox.Show("Only the first file will be taken as input.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                presentsystems = PopulateSystems(System.IO.File.ReadAllLines(Myfiles[0]), ref WholeTSU);
                if (presentsystems.Count != 0)
                {
                    txtTsuPath.Text = Myfiles[0];
                    comboTestSystems.ItemsSource = presentsystems;
                }

            }
            else if (e.Data.GetDataPresent(DataFormats.Text))
            {
                presentsystems = PopulateSystems((e.Data.GetData(DataFormats.Text) as string).Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries), ref WholeTSU);
                if (presentsystems.Count != 0)
                {
                    txtTsuPath.Text = "Text Dragged...";
                    comboTestSystems.ItemsSource = presentsystems;
                }
            }
            if (requestedsystem != null && requestedsystem != "")
            {
                comboTestSystems.SelectedItem = presentsystems.FirstOrDefault(s => s.ToUpper().Contains(requestedsystem));
            }
        }

        private List<string> PopulateSystems(string[] lines, ref List<string> outwholetsu)
        {
            List<string> presentsystems = lines.Where(l => l.ToUpper().Contains("Z11X") && l.ToUpper().Contains("A/B/C") && l.ToUpper().Contains("INSTALL")).ToList();
            if (presentsystems.Count != 0)
            {
                outwholetsu = lines.Where(l => l.Trim() != "").ToList();
            }
            else
            {
                MessageBox.Show("No system found in provided file.", "Information!", MessageBoxButton.OK, MessageBoxImage.Information);
                outwholetsu = WholeTSU;
            }
            return presentsystems;
        }

        private string ValidateSettings(bool isUnbalanced)
        {
            string error = null;
            if (!isUnbalanced && comboTestSystems.SelectedItem == null)
                return "Select a system from the list.";
            //VPARS Validation
            try//Saumen020717
            {
                var errVPARS = listVIPS.Items.Cast<VIP>().Where(i => i.IsEnabled == true && i.VPARS.Trim() == "");
                if (errVPARS.Count() != 0)
                {
                    //Get the ItemContainer from the errornious item
                    DependencyObject firsterrorvip = listVIPS.ItemContainerGenerator.ContainerFromItem(errVPARS.First());
                    //Get the Border Object=>Get Content Presenter=>Get The StackPanel Inside It
                    StackPanel sp = (StackPanel)VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(firsterrorvip, 0), 0), 0);
                    //Stack Panel=>Chileren 1(another stack Panel)=>Children[0] VPARS txtbox
                    ((sp.Children[1] as StackPanel).Children[0] as TextBox).Focus();
                    return "VPARS id is not valid for " + errVPARS.First().VIPNAME;
                }
            }//Saumen020717
            catch (ArgumentNullException)
            {
                return "VPARS NOT available";
            }//Saumen020717
            //QAT Validation
            try//Saumen020717
            {
                var errQAT = listVIPS.Items.Cast<VIP>().Where(i => i.IsEnabled == true && (i.QAT != "" && (Convert.ToInt16(i.QAT) < 1 || Convert.ToInt16(i.QAT) > 50)));
                if (errQAT.Count() != 0)
                {
                    //Get the ItemContainer from the errornious item
                    DependencyObject firsterrorvip = listVIPS.ItemContainerGenerator.ContainerFromItem(errQAT.First());
                    //Get the Border Object=>Get Content Presenter=>Get The StackPanel Inside It
                    StackPanel sp = (StackPanel)VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(firsterrorvip, 0), 0), 0);
                    //Stack Panel=>Chileren 1(another stack Panel)=>Children[0] QAT txtbox
                    ((sp.Children[1] as StackPanel).Children[1] as TextBox).Focus();
                    return "QAT number is not valid for " + errQAT.First().VIPNAME;
                }
            }//Saumen020717
            catch (ArgumentNullException)
            {
                return "QAT NOT available";
            }//Saumen020717
            //CMS File Validation
            if (txtCMSFILE.Text.Trim() == "")
            {
                txtCMSFILE.Focus();
                return "CMS Filename is not valid";
            }
            return error;
        }

        private void btnCreateSetup_Click(object sender, RoutedEventArgs e)
        {
            CurrentError = ValidateSettings((bool)chkUnbalanced.IsChecked);
            if (_CurrentError != "" && _CurrentError != null)
                return;
            if (ObsAllVIP.Where(v => v.IsEnabled).Count() == 0)
            {
                CurrentError = "Select at least 1 VIP";
                return;
            }
            List<string> ZCMDList = new List<string>();
            List<string> FinalSetup = new List<string>();
            if (!(bool)chkUnbalanced.IsChecked) //Balanced
            {
                VIP firstvip = ObsAllVIP.First(v => v.IsEnabled);
                if(App.CMDLINEARGS.Any(c=>c.ToUpper().Contains("NOEDIT")))
                {
                    int startindex = WholeTSU.IndexOf((string)comboTestSystems.SelectedItem);
                    int finishindex = WholeTSU.Count;
                    try
                    {
                        finishindex = WholeTSU.IndexOf(WholeTSU.Where(l =>
                            WholeTSU.IndexOf(l) > startindex && l.ToUpper().Contains("Z11X") && l.ToUpper().Contains("A/B/C") && l.ToUpper().Contains("INSTALL")).First());
                    }
                    catch { }

                    foreach (var item in WholeTSU.GetRange(startindex, finishindex - startindex))
                    {
                        firstvip.ThisInstall += item + Environment.NewLine;
                    }
                }
                else
                new EditBox()
                {
                    DataContext = firstvip,
                    Title = "Edit System",
                    WholeTSU = WholeTSU,
                    CurrentItem = comboTestSystems.SelectedItem.ToString(),
                    AllSystems = comboTestSystems.Items.Cast<string>().ToList()
                }.ShowDialog();
                FinalSetup.AddRange(BuildJobInfo());
                FinalSetup.AddRange(BuildHeaderInfo(false));
                FinalSetup.Add("*- Sequential  information --------------------------");
                string systemname = ParseSystemName(firstvip.ThisInstall.Split(new string[] { Environment.NewLine },
                    StringSplitOptions.RemoveEmptyEntries)[0]) + firstvip.VIPNAME.Replace("VIP", "");
                List<string> SeqInfo=BuildSequentialInfo(firstvip,ref ZCMDList);
                foreach (var item in ObsAllVIP.Where(v=>v.IsEnabled))
                {
                    for (int i = 0; i < SeqInfo.Count; i++)
                    {
                        string sinfo = SeqInfo[i];
                        if (sinfo.Contains("IN-"))
                        {
                            if (!sinfo.Substring(sinfo.IndexOf("IN-")).Contains(item.VIPNAME.Replace("-", "")))
                                continue;
                            sinfo = sinfo.Remove(sinfo.IndexOf("IN-"));
                        }
                        FinalSetup.Add(sinfo.Replace("QMAX_" + firstvip.VIPNAME.Replace("VIP", ""), "QMAX_" + item.VIPNAME.Replace("VIP", ""))
                            .Replace(systemname, systemname.Remove(systemname.Length - 1) + item.VIPNAME.Replace("VIP", "")));
                    }
                    foreach (var zburz in AddExtraZburz(item.ZBURZ))
                    {
                        FinalSetup.Add("S." + systemname.Remove(systemname.Length - 1) + item.VIPNAME.Replace("VIP", "") + zburz);
                    }
                    FinalSetup.Add("*------------------------------------------------");
                }
                if (ObsAllVIP.Where(v => v.IsEnabled).Count() > 1)
                {
                    FinalSetup.Add("S."+systemname.Remove(systemname.Length - 1) + ObsAllVIP.Where(v => v.IsEnabled).Last().VIPNAME.Replace("VIP", "")+".NEWCONN");
                    FinalSetup.Add("*------------------------------------------------");
                }

            }
            else//Unbalanced
            {
                foreach (var vip in ObsAllVIP.Where(v => v.IsEnabled))
                {
                    //Saumen030917
                    if (App.CMDLINEARGS.Any(c => c.ToUpper().Contains("NOEDIT")))
                    {
                        var presentsystems = PopulateSystems(System.IO.File.ReadAllLines(App.TSUFileServer), ref WholeTSU);
                        if (vip.VIPNAME.Contains("VIPB"))
                        {
                            comboTestSystems.SelectedItem = presentsystems.FirstOrDefault(s => s.ToUpper().Contains(requestedsystem));
                        }
                        else
                        {
                            comboTestSystems.SelectedItem = presentsystems.FirstOrDefault(s => s.ToUpper().Contains(requestedbasesystem));
                        }
                        int startindex = WholeTSU.IndexOf((string)comboTestSystems.SelectedItem);
                        int finishindex = WholeTSU.Count;
                        try
                        {
                            finishindex = WholeTSU.IndexOf(WholeTSU.Where(l =>
                                WholeTSU.IndexOf(l) > startindex && l.ToUpper().Contains("Z11X") && l.ToUpper().Contains("A/B/C") && l.ToUpper().Contains("INSTALL")).First());
                        }
                        catch { }

                        foreach (var item in WholeTSU.GetRange(startindex, finishindex - startindex))
                        {
                            vip.ThisInstall += item + Environment.NewLine;
                        }
                    }
                    else
                    //Saumen030917
                    {
                        new EditBox()
                        {
                            DataContext = vip,
                            Title = "Edit " + vip.VIPNAME,
                            WholeTSU = WholeTSU,
                            CurrentItem = null,
                            AllSystems = comboTestSystems.Items.Cast<string>().ToList()
                        }.ShowDialog();
                    }
                }
                FinalSetup.AddRange(BuildJobInfo());
                FinalSetup.AddRange(BuildHeaderInfo(true));
                FinalSetup.Add("*- Sequential  information --------------------------");

                foreach (var vip in ObsAllVIP.Where(v => v.IsEnabled))
                {
                    FinalSetup.AddRange(BuildSequentialInfo(vip, ref ZCMDList));
                    foreach (var zburz in AddExtraZburz(vip.ZBURZ))
                    {
                        FinalSetup.Add("S." + ParseSystemName(vip.ThisInstall.Split(new string[] { Environment.NewLine },
                            StringSplitOptions.RemoveEmptyEntries)[0]) + vip.VIPNAME.Replace("VIP", "") + zburz);
                    }
                    FinalSetup.Add("*------------------------------------------------");
                }
                if (ObsAllVIP.Where(v => v.IsEnabled).Count() > 1)
                {
                    VIP lastvip = ObsAllVIP.Where(v => v.IsEnabled).Last();
                    FinalSetup.Add("S." + ParseSystemName(lastvip.ThisInstall.Split(new string[] { Environment.NewLine },
                    StringSplitOptions.RemoveEmptyEntries)[0]) + lastvip.VIPNAME.Replace("VIP", "") + ".NEWCONN");
                    FinalSetup.Add("*------------------------------------------------");
                }
            }
            FilestoTransfer = new List<string>();
            if (IsFilesCreated(FinalSetup, ZCMDList, ref FilestoTransfer) && txtCMS.Text.Trim()!="" && txtPWD.Password!="" && (bool)chkTransfer.IsChecked)
            {
                if (IsRequestedList)
                {
                    CommonClass.ChangeStatus("File List returned to caller.", 0, 0,false);
                    return;
                }
                cmsid = txtCMS.Text; pwd = txtPWD.Password;
                BackgroundWorker bwUploadFiles = new BackgroundWorker() { WorkerReportsProgress = true };
                bwUploadFiles.DoWork += bwUploadFiles_DoWork;
                bwUploadFiles.ProgressChanged += bwUploadFiles_ProgressChanged;
                bwUploadFiles.RunWorkerCompleted += bwUploadFiles_RunWorkerCompleted;
                btnCreateSetup.IsEnabled = txtCMS.IsEnabled = txtPWD.IsEnabled = false;
                CommonClass.ChangeStatus("File transfer is started.", 0, 1,false);
                bwUploadFiles.RunWorkerAsync(FilestoTransfer);
                
            }
        }

        void bwUploadFiles_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            btnCreateSetup.IsEnabled = txtCMS.IsEnabled = txtPWD.IsEnabled = true;
            CommonClass.ChangeStatus("File transfer is ended.", 0, 0,false);
            CurrentError = _CurrentError;
            ((BackgroundWorker)sender).Dispose();
        }

        void bwUploadFiles_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            CommonClass.ChangeStatus("File transfer in progress...", e.ProgressPercentage, 1,false);
        }

        void bwUploadFiles_DoWork(object sender, DoWorkEventArgs e)
        {
            //List<string> files_to_transfer = (List<string>)e.Argument;
            //if (IsRequestedList)
            //{
            //    FilestoTransfer = (List<string>)e.Argument;
            //    return;
            //}
            foreach (var item in FilestoTransfer)
            {
                if (!CommonClass.UploadFiletoVM(App.LocalSetupStoreFolder + "\\" + item, item, cmsid, pwd, out _CurrentError))
                    break;
                ((BackgroundWorker)sender).ReportProgress((FilestoTransfer.IndexOf(item) + 1) * 100 / FilestoTransfer.Count);
            }
                
        }

        private List<string> BuildJobInfo()
        {
            List<string> JobInfo = new List<string>();
            JobInfo.Add("*------------------- TPFSETUP DATA FILE -----------------------");
            JobInfo.Add("* Notes:    Comments are preceeded by an asterisk");
            JobInfo.Add("*           Variable names are CASE sensitive.");
            JobInfo.Add("*-Job information----------------------------------------------");
            JobInfo.Add("J.Filename    " + txtCMSFILE.Text.ToUpper() + " $TTVDATA");
            if (txtDescription.Text == "")
            {
                if ((bool)chkUnbalanced.IsChecked)
                    JobInfo.Add("J.Description Unbalanced Setup");
                else
                    JobInfo.Add("J.Description " + comboTestSystems.SelectedItem.ToString());
            }
            else
                JobInfo.Add("J.Description " + txtDescription.Text);
            JobInfo.Add("J.REQtime     00:00");
            JobInfo.Add("J.REQdate     ASAP");
            JobInfo.Add("J.VPARStypes  " + GetUsedSystemnames((bool)chkUnbalanced.IsChecked));
            JobInfo.Add("J.Options     NODEBUG,NODISPLAY,ROUTE");
            return JobInfo;
        }
        private List<string> BuildHeaderInfo(bool isUnbalanced)
        {
            List<string> HeaderInfo = new List<string>();
            HeaderInfo.Add("*- Header  information --------------------------");
            VIP firstvip = ObsAllVIP.First(v => v.IsEnabled);
            int vipcount = ObsAllVIP.Where(v => v.IsEnabled).Count();
            foreach (var item in ObsAllVIP.Where(v => v.IsEnabled))
            {
                if (isUnbalanced)
                    firstvip = item;
                string systemname = ParseSystemName(firstvip.ThisInstall.Split(new string[] { Environment.NewLine },
                    StringSplitOptions.RemoveEmptyEntries)[0]) + item.VIPNAME.Replace("VIP", "");
                HeaderInfo.Add("H." + systemname + ".Userids " + item.VPARS);
                if (vipcount > 1)
                    HeaderInfo.Add("H." + systemname + ".Options IS3,VPC*ALL");
                else
                    HeaderInfo.Add("H." + systemname + ".Options IS1,VPC*ALL");
                HeaderInfo.Add("H." + systemname + ".IPAddr  NONE");//Saumen032417
                HeaderInfo.Add("H." + systemname + ".VDBName " +
                    (item.QAT == "" || (item.QAT != "" && Convert.ToInt16(item.QAT) == 0) ? "24" : "QAT" + item.QAT.PadLeft(2, '0')));
                HeaderInfo.Add("H." + systemname + ".CCTName");
            }
            return HeaderInfo;
        }
        private string GetUsedSystemnames(bool isUnbalanced)
        {
            string systemnames = "";
            VIP firstvip = ObsAllVIP.First(v => v.IsEnabled);
            foreach (var item in ObsAllVIP.Where(v => v.IsEnabled))
            {
                if (isUnbalanced)
                    firstvip = item;
                systemnames += ParseSystemName(firstvip.ThisInstall.Split(new string[] { Environment.NewLine },
                    StringSplitOptions.RemoveEmptyEntries)[0]) + item.VIPNAME.Replace("VIP", "") + ",";
            }
            return systemnames.TrimEnd(',');
        }
        private string ParseSystemName(string line)
        {
            return (line.ToUpper().Contains("Z11X") && line.ToUpper().Contains("A/B/C") && line.ToUpper().Contains("INSTALL")) ? line.Trim().ToUpper().Substring(0, line.ToUpper().IndexOf("X")) : "";
        }

        private List<string> BuildSequentialInfo(VIP thisvip, ref List<string> ZCMDList)
        {
            List<string> SectionFromTSU = thisvip.ThisInstall.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries).ToList();
            string systemname = ParseSystemName(SectionFromTSU[0]) + thisvip.VIPNAME.Replace("VIP", "");
            string fxtload = "";
            List<string> SequentialInfo = new List<string>();
            int currentzburzno = 1;
            bool prevwaszcommand = false;
            int applystart = 0, applyend = SectionFromTSU.Count;
            bool IsZTRACEFound = false;
            bool IsFirstZRIPLApplied = false;
            try
            {
                applystart = SectionFromTSU.IndexOf(SectionFromTSU.First(s => s.ToUpper().Contains("ZTRACE") && s.ToUpper().Contains("ZBURZ"))) + 1;
                IsZTRACEFound = true;
                applyend = SectionFromTSU.IndexOf(SectionFromTSU.First(s => s.ToUpper().Contains("APSD1F") && s.ToUpper().Contains("ZKSET")));
            }
            catch { }
            finally
            {
                SectionFromTSU = SectionFromTSU.GetRange(applystart, applyend - applystart);
            }

            SequentialInfo.Add("S." + systemname + ".NETWORK  DELETE");//Saumen032417
            SequentialInfo.Add("S." + systemname + ".ADDOSA   1");//Saumen032417
            SequentialInfo.Add("S." + systemname + ".DOZMS    QMAX_" + thisvip.VIPNAME.Replace("VIP","") + ",ZBURZ,*");///It needs to be replaced later
            if ((bool)chkRTA.IsChecked)
                SequentialInfo.Add("S." + systemname + ".DOZMS    RTA,ZBURZ,*");
            if (!IsZTRACEFound)
            {
                SequentialInfo.Add("S." + systemname + ".DOZMS    ZTRACE,ZBURZ,*");
                SequentialInfo.Add("S." + systemname + ".ZRIPL");
                SequentialInfo.Add("S." + systemname + ".DOZMS    ZUKP4,ZBURZ,*");
                //SequentialInfo.Add("S." + systemname + ".RSIINIT");
                //SequentialInfo.Add("S." + systemname + ".CSIINIT");
                SequentialInfo.Add("S." + systemname + ".DOZKTIM  TODSYNC,*");
                SequentialInfo.Add("S." + systemname + ".ZCYCLN");
            }
            else
            {
                foreach (var oneline in SectionFromTSU)
                {
                    if (oneline.ToUpper().Contains("DURING-")) //if Run Type specified then Use the only for that run
                    {
                        string during = oneline.ToUpper().Substring(oneline.ToUpper().IndexOf("DURING-"));
                        during = during.Substring(0, during.IndexOf(';'));
                        if (requestedrun != null && !(requestedrun.Split(new string[]{","},StringSplitOptions.RemoveEmptyEntries).Any(r=>during.Contains(r.ToUpper())))) 
                            continue;
                    }

                    string toapply = TryGlobalLoad(oneline, ref prevwaszcommand);
                    if (toapply.Contains("FXTLOAD"))
                        fxtload = toapply;
                    else if (toapply != "")
                        SequentialInfo.Add("S." + systemname + toapply);
                    else
                    {
                        toapply = TryOLDRLoad(oneline, ref prevwaszcommand);
                        if (toapply != "")
                            SequentialInfo.Add("S." + systemname + toapply);
                        else
                        {
                            toapply = TryZCYCL(oneline, ref prevwaszcommand);
                            if (toapply != "")
                            {
                                SequentialInfo.Add("S." + systemname + toapply);
                                if (toapply.Contains(".ZRIPL") && !IsFirstZRIPLApplied)
                                {
                                    IsFirstZRIPLApplied = true;
                                    SequentialInfo.Add("S." + systemname + ".DOZMS    ZUKP4,ZBURZ,*");
                                    //SequentialInfo.Add("S." + systemname + ".RSIINIT");
                                    //SequentialInfo.Add("S." + systemname + ".CSIINIT");
                                    SequentialInfo.Add("S." + systemname + ".DOZKTIM  TODSYNC,*");
                                    continue;
                                }
                            }
                            else
                            {
                                toapply = TryZBURZ(oneline, ref prevwaszcommand);
                                if (toapply != "")
                                    SequentialInfo.Add("S." + systemname + toapply);
                                else
                                {
                                    toapply = TryZCMD(oneline, systemname, ref ZCMDList, ref prevwaszcommand, ref currentzburzno);
                                    if (toapply != "")
                                        SequentialInfo.Add("S." + systemname + toapply);
                                }
                            }
                        }
                    }
                }
            }
            if(fxtload!="")
                SequentialInfo.Add("S." + systemname + fxtload);
            SequentialInfo.Add("S." + systemname + ".DOZMS    PARSEM,ZBURZ,*");
            //Cut a dummy DTD just after PARSEM ZBURZ
//GGIRDHAR031717            SequentialInfo.Add("S." + systemname + ".CUTDTD   DUM"); - No More Needed. VIP A CUTDTD fixed.
            if ((bool)chkPCR937I.IsChecked)
                SequentialInfo.Add("S." + systemname + ".DOZMS    PCR9371I,ZBURZ,*");
            if ((bool)chkVTPESTA.IsChecked)
                SequentialInfo.Add("S." + systemname + ".DOZMS    VIPESTA,ZBURZ,*");
            return SequentialInfo;
        }

        string TryGlobalLoad(string line, ref bool prevwaszcommand)
        {
            string toapply = "";
            line = line.ToUpper();
            if (requestedglobal != "" && requestedglobal != null && !line.Contains(requestedglobal)) //if Global Capture is provided then check for that string
                return toapply;
            string Vtape = ParseVtape(line);
            if (App.ALLGLOBALS.Any(g => line.Contains(g)) && Vtape != "")
                toapply = "." + App.ALLGLOBALS.First(g => line.Contains(g)) + "LOAD  " + Vtape;
            if (toapply != "")
                prevwaszcommand = false;
            if (line.Contains("IN-") && toapply!="")
                toapply+= line.Substring(line.IndexOf("IN-"), line.IndexOf(";", line.IndexOf("IN-")) - line.IndexOf("IN-"));
            return toapply;
        }
        private string TryOLDRLoad(string line, ref bool prevwaszcommand)
        {
            line = line.ToUpper();
            string toapply = "";
            string Vtape = ParseVtape(line);
            if (Vtape == "")
                return toapply;
            if (App.VALIDLOADS.Any(l => line.Contains(l.ToUpper())))
            {
                toapply = ".OLDRLOAD " + Vtape + ",REP       |" + ParseWE(line) + "," + App.VALIDLOADS.First(l => line.Contains(l.ToUpper()));
            }
            else if (line.Contains("LOAD") && line.Contains("ACT"))
                toapply = toapply = ".OLDRLOAD " + Vtape + ",REP       |" + ParseWE(line) + "," + "Load & Act";
            if (toapply != "")
                prevwaszcommand = false;
            if (line.Contains("IN-") && toapply!="")
                toapply += line.Substring(line.IndexOf("IN-"), line.IndexOf(";", line.IndexOf("IN-")) - line.IndexOf("IN-"));
            return toapply;

        }
        private string TryZCYCL(string line, ref bool prevwaszcommand)
        {
            string toapply = "";
            if (line.ToUpper().Contains("ZRIPL"))
                toapply = ".ZRIPL";
            else if (line.ToUpper().Contains("ZCYCL NORM") || line.ToUpper().Contains("ZCYCLN"))
                toapply = ".ZCYCLN";
            else if (line.ToUpper().Contains("ZCYCL 1052") || line.ToUpper().Contains("ZCYCLT"))
                toapply = ".ZCYCLT";
            if (toapply != "")
                prevwaszcommand = false;
            return toapply;
        }
        private string TryZBURZ(string line, ref bool prevwaszcommand)
        {
            string toapply = ""; string tmpline = "";
            line = line.ToUpper();
            if (line.Contains("ZBURZ"))
            {
                tmpline = line.Substring(0, line.IndexOf("ZBURZ")).Trim();
                tmpline = RemoveSpclChars(tmpline);
                int index = tmpline.LastIndexOf(" ");
                tmpline = tmpline.Substring(index, tmpline.Length - index).Trim();
                tmpline = tmpline.Replace(Convert.ToChar(34), '\0');
                tmpline = tmpline.Replace(Convert.ToChar(39), '\0');
                tmpline = tmpline.Replace(Convert.ToChar(44), '\0');
                if (tmpline != "")
                {
                    toapply = ".DOZMS    " + tmpline + ",ZBURZ,*";
                    //tempsetup.Add("S." + systemname + VIC + ".DOZMS    " + FindZburzToApply(curline) + ",ZBURZ,*");
                    prevwaszcommand = false;
                }
            }
            if (line.Contains("IN-") && toapply != "")
                toapply += line.Substring(line.IndexOf("IN-"), line.IndexOf(";", line.IndexOf("IN-")) - line.IndexOf("IN-"));
            return toapply;
        }
        private string TryZCMD(string line,string systemname ,ref List<string> ZCMDList, ref bool prevwaszcommand, ref int currentzburzno)
        {
            string toapply = "";
            if (line.ToUpper().Contains("WE0") && !line.ToUpper().Contains("ZUHFD"))
            {
                string wenumber = ParseWE(line);
                if (line.ToUpper().Contains("DEACT")||line.ToUpper().Contains("DEL"))
                {
                    if (!prevwaszcommand)
                    {
                        ZCMDList.Add(systemname.Remove(systemname.Length - 3, 3) + currentzburzno + ".ZBURZ");
                        toapply = ".DOZMS    " + systemname.Remove(systemname.Length - 3, 3) + currentzburzno + ",ZBURZ,*";
                        currentzburzno++;
                    }
                    if (line.ToUpper().Contains("DEACT"))
                        ZCMDList.AddRange(new string[] { "ZOLDR DEACT " + wenumber, "/DELAY=2" });
                    if (line.ToUpper().Contains("DEL"))
                        ZCMDList.AddRange(new string[] { "ZOLDR DEL " + wenumber, "/DELAY=2" });
                    prevwaszcommand = true;
                    return toapply;
                }
            }
            if (line.ToUpper().Contains("Z"))
            {
                if (!prevwaszcommand)
                {
                    ZCMDList.Add(systemname.Remove(systemname.Length - 3, 3) + currentzburzno + ".ZBURZ");
                    toapply = ".DOZMS    " + systemname.Remove(systemname.Length - 3, 3) + currentzburzno + ",ZBURZ,*";
                    currentzburzno++;
                }
                string delay = 
                    (
                    line.ToUpper().Contains("ZUHFD") && 
                    (line.ToUpper().Contains("RECEIVE") || line.ToUpper().Contains("INSTALL"))
                    ) ? "10" : "2";
                ZCMDList.AddRange(new string[] {ParseZCMD(line),"/DELAY="+delay });
                prevwaszcommand = true;
            }
            return toapply;
        }
        private List<string> AddExtraZburz(string line)
        {
            string[] zburzs = line.ToUpper().Split(',');
            List<string> ListZBURZs = new List<string>();
            foreach (var item in zburzs)
                if (item.Trim() != "")
                    ListZBURZs.Add(".DOZMS    " + item + ",ZBURZ,*");
            return ListZBURZs;
        }
        public static string ParseVtape(string line)
        {
            string Vtape = "";
            line = line.ToUpper();
            if (App.VALIDVTAPES.Any(v => line.Contains(v)))
            {
                int startofvtape = line.IndexOf(App.VALIDVTAPES.First(v => line.Contains(v)));
                Vtape = line.Substring(startofvtape, 2);
                for (int i = startofvtape + 2; i < startofvtape + 6; i++)
                {
                    if (Char.IsNumber(line, i))
                        Vtape += line[i];
                    else
                        break;
                }

            }
            return Vtape;
        }
        public static string ParseWE(string line)
        {
            string WE = "WE0";
            line = line.ToUpper();
            if (line.Contains(WE))
                WE = line.Substring(line.IndexOf(WE)).Split(' ')[0];
            return WE;
        }
        public static string ParseZCMD(string line)
        {
            line = line.Substring(line.ToUpper().IndexOf("Z"), line.Length - line.ToUpper().IndexOf("Z"));
            line = RemoveSpclChars(line);
            return line;
        }
        public static string RemoveSpclChars(string line)
        {
            for (int i = 145; i <= 148; i++)
            {
                line = line.Replace(Convert.ToChar(i), ' ');
            }
            if (line.Contains('{'))
            {
                line = line.Substring(0, line.IndexOf('{'));
            }
            if (line.Contains('['))
            {
                line = line.Substring(0, line.IndexOf('['));
            }
            if (line.Contains('('))
            {
                line = line.Substring(0, line.IndexOf('('));
            }
            return line.Trim();
        }

        private bool IsFilesCreated(List<string>FinalSetup,List<string>ZCMDList,ref List<string> FilestoTransfer)
        {
            try
            {

                if (!System.IO.Directory.Exists(App.LocalSetupStoreFolder))
                    System.IO.Directory.CreateDirectory(App.LocalSetupStoreFolder);
                System.IO.File.WriteAllLines(App.LocalSetupStoreFolder + "\\" + txtCMSFILE.Text + ".$TTVDATA", FinalSetup);
                FilestoTransfer.Add(txtCMSFILE.Text + ".$TTVDATA");
                string filename = "";
                foreach (var item in ZCMDList)
                {
                    if (item.Contains(".ZBURZ"))
                    {
                        filename = item;
                        if (System.IO.File.Exists(App.LocalSetupStoreFolder + "\\" + filename))
                            System.IO.File.Delete(App.LocalSetupStoreFolder + "\\" + filename);
                        if(!FilestoTransfer.Contains(item))
                            FilestoTransfer.Add(item);
                        continue;
                    }
                    else
                    {
                        System.IO.File.AppendAllLines(App.LocalSetupStoreFolder + "\\" + filename, new string[] { item });
                    }
                }
                CommonClass.ChangeStatus("All files saved to setup folder in your Desktop.", 0, 0, false);
                return true;
            }
            catch (Exception)
            {
                CurrentError = "Error in creating file.";
                return false;
            }
        }
        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            chkUnbalanced.IsChecked = false;
            chkTransfer.IsChecked = true;
            chkPCR937I.IsChecked = false;
            chkRTA.IsChecked = false;
            chkVTPESTA.IsChecked = false;
            requestedsystem = requestedglobal = requestedfile = requestedrun = cmsid = pwd = "";
            txtDescription.Text = "";
            CurrentError = null; comboTestSystems.SelectedItem = null; WholeTSU.Clear(); primarysetup.Clear(); comboTestSystems.ItemsSource=null;
            txtTsuPath.Clear();
        }

        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        private void btnserver_Click(object sender, RoutedEventArgs e)
        {
            this.Cursor = Cursors.Wait;
            var presentsystems = PopulateSystems(System.IO.File.ReadAllLines(App.TSUFileServer), ref WholeTSU);
            if (presentsystems.Count != 0)
            {
                txtTsuPath.Text = App.TSUFileServer;
                comboTestSystems.ItemsSource = presentsystems;
                if (requestedsystem != null && requestedsystem != "")
                {
                    comboTestSystems.SelectedItem = presentsystems.FirstOrDefault(s => s.ToUpper().Contains(requestedsystem));
                }
            }
            this.Cursor = Cursors.Arrow;
        }

    }

    public class VIP : INotifyPropertyChanged
    {
        string _VIPNAME = "", _VPARS = "", _QAT = "", _ZBURZ = "";
        bool _IsEnabled = false;
        public string VIPNAME { get { return this._VIPNAME; } set { _VIPNAME = value; NotifyPropertyChanged("VIPNAME"); } }
        [ScriptIgnore]
        public bool IsEnabled { get { return this._IsEnabled; } set { _IsEnabled = value; NotifyPropertyChanged("IsEnabled"); } }
        public string VPARS { get { return this._VPARS; } set { _VPARS = value; NotifyPropertyChanged("VPARS"); } }
        public string QAT { get { return this._QAT; } set { _QAT = value; NotifyPropertyChanged("QAT"); } }
        [ScriptIgnore]
        public string ZBURZ { get { return this._ZBURZ; } set { _ZBURZ = value; NotifyPropertyChanged("ZBURZ"); } }
        string _ThisInstall;
        [ScriptIgnore]
        public string ThisInstall { get { return _ThisInstall; } set { _ThisInstall = value; NotifyPropertyChanged("ThisInstall"); } }
        protected string ip = null;
       // public string IP { get { return ip; } set { ip = value.Trim(); } }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }

}
