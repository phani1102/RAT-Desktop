﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for IntersectPage.xaml
    /// </summary>
    public partial class IntersectPage : Page
    {
        List<string> List_Intersect;
        public IntersectPage()
        {
            InitializeComponent();
        }

        private void btnfind_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtReport.Text))
            {
                MessageBox.Show("Intersect report can not be blank.","Intersect Report");
                txtReport.Focus();
                return;
            }
            else
            {
                try
                {
                    string wenum = int.Parse(txtWE.Text).ToString();
                    txtoutput.Clear();
                    List_Intersect = txtReport.Text.Replace("\t", " ").Replace("**",null)
                        .Split(new string[] { Environment.NewLine, "\n" }, StringSplitOptions.RemoveEmptyEntries)
                        .Where(l => l.Contains("CRQ"))
                        .Select(l => string.Join(" ",l.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).Take(4)))
                        .GroupBy(l => l.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0])
                        .Where(g => g.Count() > 1).SelectMany((g) => g.ToList()).ToList();
                    var intersects = FindIntersect(wenum)
                        .OrderBy(i => int.Parse(i.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[3]))
                        .OrderBy(i => DateTime.ParseExact(i.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[2], "yyyy/MM/dd", null));
                    if (intersects == null || intersects.Count() == 0)
                        MessageBox.Show("No intersect found for " + txtWE.Text, "Intersect Report");
                    else
                        txtoutput.Text = string.Join(Environment.NewLine, intersects.Select(i => string.Join(" ", i.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Skip(1))));
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error in finding Intersect. Error: "+ex.Message, "Intersect Report");
                }
                txtWE.Focus();
            }
        }
        private List<string> FindIntersect(string InputWE)
        {
            DateTime ld;
            List<string> intersects = new List<string>();
            foreach (var item in List_Intersect.Where(p => p.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[1] == InputWE))//Get all items with the WE number
            {
                ld = DateTime.ParseExact(item.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[2], "yyyy/MM/dd", null);
                var intermediateintersect = 
                    List_Intersect.Where(x => x.Contains(item.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0]+" ")) //add a space after the program
                    .SkipWhile(y => y != item).Skip(1)              //Get all WEs after Input WE with same program name
                    .Where(k => !intersects.Any(l => l.Contains(k.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[1])));
                foreach (var intr in intermediateintersect)
                    if (DateTime.ParseExact(intr.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[2], "yyyy/MM/dd", null) >= ld)
                        intersects.AddRange(FindIntersect(intr.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[1]).Where(k => !intersects.Any(l => l.Contains(k.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[1])))); //Recursive Intersect, Intsersect of Intersects
                intersects.AddRange(intermediateintersect);
            }
            return intersects;
        }
    }
}
