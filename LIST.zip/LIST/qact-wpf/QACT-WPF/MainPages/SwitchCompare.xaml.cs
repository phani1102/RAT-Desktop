﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for SwitchCompare.xaml
    /// </summary>
    public partial class SwitchCompare : Page
    {
        public SwitchCompare()
        {
            InitializeComponent();
        }
        string[] SwitchStatus = new string[] { "NOT USED", "RESERVED ", "ACTIVE  " };
        private void btnCompare_Click(object sender, RoutedEventArgs e)
        {
            if ((string)btnCompare.Content  == "Go Back")
            {
                gridResult.Visibility = Visibility.Collapsed;
                btnCompare.Content = "Compare";
                return;
            }
            List<string> ReferenceSwitch = txtReference.Text.Trim().ToUpper().Replace("|", "").Replace("SCHEDULED", " ACTIVE  ").Trim().Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries)
                .Where(sw => SwitchStatus.Any(status => sw.Contains(status))).Select(l=>l.Length>60?l.Substring(0,60).Trim():l).ToList();
            List<string> CurrentSwitch = txtCurrent.Text.Trim().ToUpper().Replace("|", "").Replace("SCHEDULED", " ACTIVE  ").Trim().Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries)
                .Where(sw => SwitchStatus.Any(status => sw.Contains(status))).Select(l => l.Length > 60 ? l.Substring(0, 60).Trim() : l).ToList();
            ReferenceSwitch = ReferenceSwitch.Where(refsw => !CurrentSwitch.Any(cursw => cursw.Trim() == refsw.Trim())).ToList();
            CurrentSwitch = CurrentSwitch.Where(cursw => ReferenceSwitch.Any(refsw => refsw.Trim().Split(' ')[0] == cursw.Trim().Split(' ')[0])).ToList();
            List<string> CommandstoApply = new List<string>();
            foreach (var swt in ReferenceSwitch)
            {
                string curswt = CurrentSwitch.FirstOrDefault(csw => csw.Trim().Split(' ')[0] == swt.Trim().Split(' ')[0]);
                if (curswt != null)
                    CommandstoApply.AddRange(GetModificationCommands(GetZKSWT(swt), GetZKSWT(curswt)));
            }
            txtResult.Clear();
            foreach (var item in CommandstoApply)
            {
                txtResult.Text += item + Environment.NewLine;
            }
            gridResult.Visibility = Visibility.Visible;
            btnCompare.Content = "Go Back";

        }
        public static  List<string> GetModificationCommands(ZKSWT refswt, ZKSWT curswt)
        {
            List<string> ModCommands = new List<string>();
            if (!refswt.Equals(curswt))
            {
                string stepstoperform = "";
                if (refswt.RTN != curswt.RTN)
                {
                    for (int i = curswt.StatusIndex - 1; i >= 1; i--)
                        stepstoperform += "-" + i + ",";
                    for (int i = 1; i <= refswt.StatusIndex - 1; i++)
                        stepstoperform += i + ",";
                }
                else
                {
                    if (refswt.StatusIndex > curswt.StatusIndex)
                    {
                        for (int i = curswt.StatusIndex; i <= refswt.StatusIndex - 1; i++)
                            stepstoperform += i + ",";
                    }
                    else if (refswt.StatusIndex < curswt.StatusIndex)
                    {
                        for (int i = curswt.StatusIndex - 1; i >= refswt.StatusIndex; i--)
                            stepstoperform += "-" + i + ",";
                    }
                    else
                    {
                        if (refswt.StatusIndex == 2)
                            stepstoperform = "3";
                        else if (refswt.StatusIndex == 3)
                            stepstoperform = "-2,3,2";
                    }
                }
                stepstoperform = stepstoperform.TrimEnd(',');
                foreach (var step in stepstoperform.Split(','))
                {
                    string stepcommand = "";
                    switch (step)
                    {
                        case "3":
                            stepcommand = ModifySwitch(refswt,curswt);
                            break;
                        case "2":
                            if(refswt.ActivationDate!=curswt.ActivationDate)
                                ModCommands.Add(ModifySwitch(refswt,curswt));
                            stepcommand = TurnOnSwitch(refswt);
                            break;
                        case "1":
                            stepcommand = ReserveSwitch(refswt);
                            break;
                        case "-1":
                            stepcommand = UnreserveSwitch(curswt);
                            break;
                        case "-2":
                            stepcommand = TurnOffSwitch(curswt);
                            break;
                        default:
                            break;
                    }
                    ModCommands.Add(stepcommand);
                }
            }
            return ModCommands.Distinct().ToList();
        }
        public static string TurnOffSwitch(ZKSWT curswt)
        {
            return "ZKSWT " + curswt.SwitchNumber + " OFF RTN-" + curswt.RTN;
        }  //-2
        public static string TurnOnSwitch(ZKSWT refswt)
        {
            return "ZKSWT " + refswt.SwitchNumber + " ON RTN-" + refswt.RTN;
        }  //2
        public static string ReserveSwitch(ZKSWT refswt)
        {
            return "ZKSWT " + refswt.SwitchNumber + " RES RTN-" + refswt.RTN +
                (refswt.ActivationDate != "" ? " DATE-" + refswt.ActivationDate.Replace(" ", " TIME-").Replace("/", ".") : "") +
                " LEAD-" + refswt.Lead;
        } //1
        public static string ModifySwitch(ZKSWT refswt, ZKSWT curswt)
        {
            return "ZKSWT " + refswt.SwitchNumber + " MOD RTN-" + refswt.RTN +
            (refswt.ActivationDate != "" ? " DATE-" + refswt.ActivationDate.Replace(" ", " TIME-").Replace("/", ".") : ""); /*+
            (curswt.Lead == null ? " LEAD-" + refswt.Lead : null);*/
        } //3
        public static string UnreserveSwitch(ZKSWT curswt)
        {
            return "ZKSWT " + curswt.SwitchNumber + " UNR RTN-" + curswt.RTN;
        } //-1

        public static ZKSWT GetZKSWT(string line)
        {
            ZKSWT zkswt = new ZKSWT();
            line = line.ToUpper().Replace("|", "").Trim();
            var splitted = line.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
            zkswt.SwitchNumber = splitted[0];
            if (line.Contains("NOT USED"))
                zkswt.Status = "NOT USED";
            else
            {
                zkswt.Status = splitted[1];
                zkswt.ActivationDate = splitted.Length == 6 ? splitted[2] + " " + splitted[3] : "";
                zkswt.RTN = splitted[splitted.Length - 2];
                zkswt.Lead = splitted[splitted.Length - 1];
            }
            if (zkswt.Status == "NOT USED")
                zkswt.StatusIndex = 1;
            else if (zkswt.Status == "RESERVED")
                zkswt.StatusIndex = 2;
            else if (zkswt.Status == "ACTIVE" || zkswt.Status == "SCHEDULED")
                zkswt.StatusIndex = 3;
            return zkswt;
        }

    }
    public class ZKSWT : IEquatable<ZKSWT>
    {
        public string SwitchNumber { get; set; }
        public string Status { get; set; }
        public string ActivationDate { get; set; }
        public string RTN { get; set; }
        public string Lead { get; set; }
        public int StatusIndex { get; set; }

        public bool Equals(ZKSWT other)
        {
            if (this.SwitchNumber == other.SwitchNumber && this.ActivationDate == other.ActivationDate && this.RTN == other.RTN && this.StatusIndex == other.StatusIndex )//&& this.Lead == other.Lead)
                return true;
            else
                return false;
        }
    }
}
