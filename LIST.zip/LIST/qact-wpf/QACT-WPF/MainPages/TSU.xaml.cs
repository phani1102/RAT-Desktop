﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Excel = Microsoft.Office.Interop.Excel;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for TSU.xaml
    /// </summary>
    public partial class TSU : Page, INotifyPropertyChanged
    {
        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        #region Members
        List<string> GeneratedTSUList = new List<string>();
        //public ObservableCollection<string> GeneratedTSU { get { return _GeneratedTSUList; } set { _GeneratedTSUList = value; NotifyPropertyChanged("GeneratedTSU"); } }
        string _SVScriptPath = "SLiMS Web Script";
        public string SVScriptPath { get { return _SVScriptPath; } set { _SVScriptPath = value; NotifyPropertyChanged("SVScriptPath"); } }
        string _QAScriptPath = "Sharepoint QA Script";
        public string QAScriptPath { get { return _QAScriptPath; } set { _QAScriptPath = value; NotifyPropertyChanged("QAScriptPath"); } }
        string _IntersectPath = "SLiMS Web Intersect";
        public string IntersectPath { get { return _IntersectPath; } set { _IntersectPath = value; NotifyPropertyChanged("IntersectPath"); } }
        private DateTime? _StartDate = null;
        List<string> IgnoreCommands = new List<string>(){"ZCP VTRUN",
        "ZCP VTM" ,
        "ZTMNT OLD" ,
        //"ZOLDR LOAD OLD NODEBUG",
        "ZCP VTRUN",
        "ZOLDR DISP L",
        "ZOLDR LOAD OLD NODEBUG"
        };
        public DateTime? StartDate
        {
            get { return _StartDate; }
            set { _StartDate = value; NotifyPropertyChanged("StartDate"); }
        }
        private DateTime? _EndDate = null;

        public DateTime? EndDate
        {
            get { return _EndDate; }
            set { _EndDate = value; NotifyPropertyChanged("EndDate"); }
        }

        bool _UseSlims = true;
        public bool UseSlims
        {
            get { return _UseSlims; }
            set
            {
                _UseSlims = value; NotifyPropertyChanged("UseSlims");
                Application.Current.Dispatcher.Invoke((Action)(() =>
                {
                    if (!(bool)value)
                    {
                        brSVScript.IsEnabled = true;
                        brIntersect.IsEnabled = true;
                    }
                    else
                    {
                        brSVScript.IsEnabled = false;
                        brIntersect.IsEnabled = false;
                    }
                }));
            }
        }
        private bool _IsIdle = true;

        public bool IsIdle
        {
            get { return _IsIdle; }
            set { _IsIdle = value; NotifyPropertyChanged("IsIdle"); }
        }

        //public bool Working = false;
        #endregion

        const int WENUMBERCOL = 1, WEDATEGRPCOL = 3, WESTATUSCOL = 6, WESTATECOL = 7, WETYPECOL = 8, WEVTAPECOL = 10, WEFUNCCOMMANDCOL = 12, WEFALLBACKCOL = 13;
        List<string> List_Intersect = new List<string>();
        List<GlobalsWithLD> GlobalsFromSheet;
        string[] DontShowApplied = new string[] { "ZCYCL NORM", "ZRIPL", "ZCYCL 1052", "ZOLDR DISP", "ZOLDR ACT" };
        List<string> testsystemstatus;
        private bool IsAUTOTSUCalled = App.CMDLINEARGS.Contains("TSU") && App.CMDLINEARGS.Contains("AUTO");
        public TSU()
        {
            InitializeComponent();
            if (IsAUTOTSUCalled && ((App)App.Current).IsVIPTESTENGMember)
            {
                btnGenerateTsu_Click(null, null);
            }
        }
        public static string GetScriptfromSharePoint()
        {
            try
            {
                using (WebClient wc = new WebClient())
                {
                    wc.Proxy.Credentials = System.Net.CredentialCache.DefaultCredentials;
                    wc.UseDefaultCredentials = true;
                    System.IO.File.Delete(App.TempFolder + "QA_System_Script.xlsx");
                    wc.DownloadFile(App.SharepointQAScriptFile, App.TempFolder + "QA_System_Script.xlsx");
                    //QAScriptPath = App.TempFolder + "QA_System_Script.xls";
                }
                return App.TempFolder + "QA_System_Script.xlsx";
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void brSVScript_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog opndialog = new OpenFileDialog() { Filter = "SliMS Script Files |*.xls;*.xlsx", ReadOnlyChecked = true, Multiselect = false };
            opndialog.ShowDialog();
            if (opndialog.FileName != string.Empty)
                SVScriptPath = opndialog.FileName;
        }

        private void brQAScript_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog opndialog = new OpenFileDialog() { Filter = "QA Script Files |*.xls;*.xlsx", ReadOnlyChecked = true, Multiselect = false };
            opndialog.ShowDialog();
            if (opndialog.FileName != string.Empty)
                QAScriptPath = opndialog.FileName;
        }
        private void brIntersect_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog opndialog = new OpenFileDialog() { Filter = "Intersect Files |*.txt;*.xls;*.xlsx", ReadOnlyChecked = true, Multiselect = false };
            opndialog.ShowDialog();
            if (opndialog.FileName != string.Empty)
                IntersectPath = opndialog.FileName;
        }
        private void btnGenerateTsu_Click(object sender, RoutedEventArgs e)
        {
            //Working = true;

            btnGenerateTsu.IsEnabled = false;
            //The whole work should be in background

            BackgroundWorker GenerateTSU = new BackgroundWorker();
            GenerateTSU.DoWork += GenerateTSU_DoWork;
            GenerateTSU.RunWorkerCompleted += GenerateTSU_RunWorkerCompleted;
            btnEmail.IsEnabled = false;
            btnSave.IsEnabled = false;

            GenerateTSU.RunWorkerAsync();
            ///

        }

        void GenerateTSU_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            btnGenerateTsu.IsEnabled = true;
            btnEmail.IsEnabled = true;
            btnSave.IsEnabled = true;
            IsIdle = true;
            CommonClass.ChangeStatus("Done", 0, 0, false);
            // QAScriptPath = "QA Script";
            if (GeneratedTSUList.Count != 0)
            {
                txtTSU.Text = string.Concat(GeneratedTSUList.Select(t => t + Environment.NewLine));
                if (IsAUTOTSUCalled)
                {
                    try
                    {

                        //For Scheduler TSU
                        btnSave_Click(null, null);
                        SendTSUMail();
                    }
                    catch (Exception ex) { SendTSUMail(error: ex.Message); }
                    finally { Application.Current.Shutdown(); }
                }
            }
            if (e.Result != null)
            {
                if (IsAUTOTSUCalled)
                {
                    SendTSUMail(error: e.Result.ToString());
                    Application.Current.Shutdown();//Saumen021317
                }
                else
                    MessageBox.Show(e.Result.ToString());
            }
            //GeneratedTSU = _GeneratedTSUList;
            ((BackgroundWorker)sender).Dispose();
            // Working = false;
        }

        void GenerateTSU_DoWork(object sender, DoWorkEventArgs e)
        {
            testsystemstatus = null;
            IsIdle = false;
            List<DateTime> LoadDates = GetLoadDates();
            GeneratedTSUList.Clear();
            List<string> Extracommands = new List<string>();
            Excel.Application xlapp = null;
            List<InstallDetail> InstallsFromQAScript = new List<InstallDetail>();
            List<InstallDetail> InstallsFromSVScript = new List<InstallDetail>();
            try
            {
                xlapp = new Excel.Application();
                xlapp.DisplayAlerts = false;
                if (testsystemstatus == null)
                    testsystemstatus = System.IO.File.ReadAllLines(App.TestSystemStatusServer).ToList();
                //Get QA Install Script for these LoadDates
                if (!System.IO.File.Exists(QAScriptPath))
                {
                    QAScriptPath=GetScriptfromSharePoint();
                }
                InstallsFromQAScript = GetInstallsFromExcel(QAScriptPath, LoadDates, xlapp);
                if (InstallsFromQAScript.Count(i => i != null) == 0)
                {
                    e.Result = "Nothing valuable found from provided QA Script.";
                    return;
                }
                Extracommands = System.IO.File.ReadAllLines(App.ExtraTSUCMDServer).Where(c => c.Trim().ToCharArray()[0] != '*').ToList();
                if (UseSlims)
                {
                    var res = GetSliMsFiles(LoadDates.First(), LoadDates.Last(), true);
                    if (res != null)
                    {
                        UseSlims = false;
                        e.Result = res;
                        return;
                    }
                    SVScriptPath = App.TempFolder + "sv_Script.xls";
                    IntersectPath = App.TempFolder + "sv_Intersect.xls";
                }
                //Get SV Install Script-i.e. Current Script for these LoadDates
                InstallsFromSVScript = GetInstallsFromExcel(SVScriptPath, LoadDates, xlapp);
                if (InstallsFromSVScript.Count(i => i != null) == 0)
                {
                    e.Result = "Nothing valuable found from provided SLiMS SV Script.";
                    return;
                }
                //Just Get all the lines intersects to a list
                List_Intersect = GetIntersectList(IntersectPath, xlapp);
                //Get Globals in background
                //GetGlobals(LoadDates, xlapp);
                PopulateGlobals(LoadDates, xlapp);//Saumen020617 : added back commit c0145d16aac
            }
            catch (Exception ex)
            {
                e.Result = ex.Message;
                return;
            }
            finally
            {
                if (xlapp != null)
                    xlapp.Quit();
            }

            CommonClass.ChangeStatus("Now applying TSU creation logic...", 0, 1, true);
            foreach (var install in InstallsFromQAScript)
            {
                if (install != null)
                {
                    GeneratedTSUList.Add("+----------------------------------------------------------+");
                    GeneratedTSUList.Add("+ " + install.InstallDate.ToString("MM/dd/yyyy") + "  =>  " + install.SystemName.ToUpper().PadRight(41));
                }
            }
            if (InstallsFromQAScript != null && InstallsFromQAScript.Count(p => p != null) > 0)
                GeneratedTSUList.Add("+----------------------------------------------------------+\n\n");

            //Now for multiple loaddate==>
            List<WEEntry> EmergencyWEs = new List<WEEntry>();
            List<WEEntry> ChangedWEs = new List<WEEntry>();
            List<WEEntry> CancelledWEs = new List<WEEntry>();
            List<WEEntry> MoveOutWEs = new List<WEEntry>();
            foreach (var loaddate in LoadDates)
            {
                bool IsSystemin1052 = true;
                //Find SV Install Script for current date
                var SV_ThisInstall = InstallsFromSVScript.FirstOrDefault(install => install != null && install.InstallDate == loaddate);
                //Find QA Install Script for current date
                var QA_ThisInstall = InstallsFromQAScript.FirstOrDefault(install => install != null && install.InstallDate == loaddate);
                //if (SV_ThisInstall == null)
                //    continue;
                //MessageBox.Show("Load date "+loaddate.Date+" does not exist in SV install script.");
                if (QA_ThisInstall == null)
                    continue;
                //MessageBox.Show("Load date " + loaddate.Date + " does not exist in QA install script.");
                else
                {
                    if (SV_ThisInstall != null)
                    {
                        //Get Emergency WEs=>Those WEs in SVInstall which doesnot have a correcponding WE number in QAInstall
                        EmergencyWEs.AddRange(SV_ThisInstall.LoadedWEs.Where(svwe => svwe.Status != "Fallback" && svwe.Status != "Canceled" && !QA_ThisInstall.LoadedWEs.Any(qawe => svwe.WENumber == qawe.WENumber)).ToList());
                        //Get Changed WEs=>Those WEs in SVInstall which doesnot have a correcponding WE in QAInstall and not present in Emergency List
                        ChangedWEs.AddRange(SV_ThisInstall.LoadedWEs.Where(svwe => !QA_ThisInstall.LoadedWEs.Any(qawe => svwe.Equals(qawe)) && !EmergencyWEs.Contains(svwe) && svwe.Status != "Fallback" && svwe.Status != "Canceled").ToList());
                        //Get Cancelled WEs=>Those WEs in QAInstall which doesnot have a correcponding WE number in SVInstall and loaddate is current loaddate in question
                        CancelledWEs.AddRange(QA_ThisInstall.LoadedWEs.Where(qawe => !SV_ThisInstall.LoadedWEs.Any(svwe => svwe.WENumber == qawe.WENumber) && qawe.LoadDate == loaddate).ToList());
                        //Fallback we also has status of Fallback
                        CancelledWEs.AddRange(SV_ThisInstall.LoadedWEs.Where(svwe => (svwe.Status == "Fallback" || svwe.Status == "Canceled") && !CancelledWEs.Any(cw => cw.WENumber == svwe.WENumber) && !QA_ThisInstall.LoadedWEs.Any(qawe => svwe.Equals(qawe))));
                        MoveOutWEs = EmergencyWEs.Where(ew => CancelledWEs.Any(cw => ew.WENumber == cw.WENumber && ew.LoadDate > cw.LoadDate)).ToList();
                    }
                    List<string> AllIntersects = new List<string>();
                    //For all Emergency + Changed WEs +MoveOut WEs find Intersects and Add them to List
                    foreach (var emgwe in EmergencyWEs.Concat(ChangedWEs).Concat(MoveOutWEs))
                    {
                        //If already loaded in system then don't find intersects
                        bool loadedinpreviousinstall = false;
                        foreach (var item in InstallsFromQAScript.Where(inst => inst != null && inst.UpdatedOn <= QA_ThisInstall.UpdatedOn && inst.InstallDate <= QA_ThisInstall.InstallDate))
                        {
                            if (item.LoadedWEs.Any(p => emgwe.Equals(p)))
                            {
                                loadedinpreviousinstall = true;
                                break;
                            }
                        }
                        if (loadedinpreviousinstall)//(QA_ThisInstall.LoadedWEs.Any(p => emgwe.Equals(p)))
                            continue;
                        //Intersects Should not be in (changed list and emergency list and intersect list) and load date should be <=current loaddate in question
                        if (!AllIntersects.Any(i => i.Contains(emgwe.WENumber)))
                            AllIntersects.AddRange(FindIntersect(emgwe.WENumber.Replace("WE", string.Empty).TrimStart('0'), loaddate).Where(i => !AllIntersects.Contains(i)
                                && DateTime.ParseExact(i.Split(' ')[2], "yyyy/MM/dd", null) <= loaddate));
                    }
                    //Find corresponding WEs of Intersects
                    List<WEEntry> ReloadedWEs = new List<WEEntry>();

                    foreach (var install in InstallsFromSVScript)  //Reloaded WEs whould be coming from each Week
                        if (install != null && install.InstallDate <= loaddate)
                            ReloadedWEs.AddRange(install.LoadedWEs.Where(svwe => AllIntersects.Any(i => i.Split(' ')[1] == svwe.WENumber.Replace("WE", string.Empty).TrimStart('0'))).ToList());
                    if (SV_ThisInstall != null)
                    {
                        //For cancelled WE, we are trying to fit it in the SV install itself
                        foreach (var canclwe in CancelledWEs)
                        {
                            if (canclwe.LoadDate != loaddate)
                                continue;
                            if (SV_ThisInstall.LoadedWEs.Contains(canclwe))
                                continue;
                            var preventry = QA_ThisInstall.LoadedWEs.IndexOf(canclwe) > 0 ? QA_ThisInstall.LoadedWEs[QA_ThisInstall.LoadedWEs.IndexOf(canclwe) - 1] : null;
                            var nextentry = QA_ThisInstall.LoadedWEs.IndexOf(canclwe) < QA_ThisInstall.LoadedWEs.Count - 1 ? QA_ThisInstall.LoadedWEs[QA_ThisInstall.LoadedWEs.IndexOf(canclwe) + 1] : null;

                            if (preventry != null)
                            {
                                try
                                {
                                    InstallsFromSVScript[InstallsFromSVScript.IndexOf(SV_ThisInstall)].LoadedWEs.Insert(SV_ThisInstall.LoadedWEs.IndexOf(SV_ThisInstall.LoadedWEs.First(svwe => svwe.WENumber == preventry.WENumber)) + 1, canclwe);
                                }
                                catch (Exception)
                                {
                                    InstallsFromSVScript[InstallsFromSVScript.IndexOf(SV_ThisInstall)].LoadedWEs.Insert(0, canclwe);
                                }

                            }

                            else if (nextentry != null)
                            {
                                int indx = SV_ThisInstall.LoadedWEs.IndexOf(SV_ThisInstall.LoadedWEs.First(svwe => svwe.WENumber == nextentry.WENumber));
                                if (indx > 0)
                                    InstallsFromSVScript[InstallsFromSVScript.IndexOf(SV_ThisInstall)].LoadedWEs.Insert(indx - 1, canclwe);
                                else
                                    InstallsFromSVScript[InstallsFromSVScript.IndexOf(SV_ThisInstall)].LoadedWEs.Insert(indx, canclwe);
                            }
                        }
                    }

                    //Build basic info such as system name Global etc-Applied Elements
                    if (SV_ThisInstall != null)
                    {
                        GeneratedTSUList.Add("+------------------------------------------------------------------------------------+");
                        GeneratedTSUList.Add(QA_ThisInstall.SystemName + " " + string.Join("/", App.ALLVIPS) + " - " + loaddate.ToString("MM/dd") + " Install (" + QA_ThisInstall.GlobalVersion + ")");
                        GeneratedTSUList.Add("+------------------------------------------------------------------------------------+");
                    }
                    else
                    {
                        GeneratedTSUList.Add("+------------------------------------------------------------------------------------+");
                        GeneratedTSUList.Add(QA_ThisInstall.SystemName + " " + string.Join("/", App.ALLVIPS) + " - " + loaddate.ToString("MM/dd") + " Install (" + QA_ThisInstall.GlobalVersion + ") - SliMS Script not found");
                        GeneratedTSUList.Add("+------------------------------------------------------------------------------------+");
                    }
                    GeneratedTSUList.Add("DDRed From " + QA_ThisInstall.DDRedFrom + " system on " + QA_ThisInstall.UpdatedOn.ToString("MM/dd/yy HH:mm:ss") + " GMT");
                    GeneratedTSUList.Add("Applied: DCS " + QA_ThisInstall.DCS + ", BMX " + QA_ThisInstall.BMX + ", NWK " + QA_ThisInstall.NWK + ", CFG " + QA_ThisInstall.CFG + ", FXT " + QA_ThisInstall.FXT);

                    //GeneratedTSUList.Add("Apply ZTRACE ZBURZ available in TESTCASE");
                    GeneratedTSUList.Add("Apply ZTRACE ZBURZ available in VIPQAAUT");//Saumen021417

                    var globals_thisinstall = GlobalsFromSheet.Where(g => g.LoadDate == loaddate);
                    if (globals_thisinstall != null)
                        foreach (var glb in globals_thisinstall)
                        {
                            if (glb.DCS != QA_ThisInstall.DCS)
                                GeneratedTSUList.Add("Apply DCS: " + glb.DCS + " [" + glb.Capture + "]");
                            if (glb.BMX != QA_ThisInstall.BMX)
                                GeneratedTSUList.Add("Apply BMX: " + glb.BMX + " [" + glb.Capture + "]");
                            if (glb.NWK != QA_ThisInstall.NWK)
                                GeneratedTSUList.Add("Apply NWK: " + glb.NWK + " [" + glb.Capture + "]");
                            if (glb.CFG != QA_ThisInstall.CFG)
                                GeneratedTSUList.Add("Apply CFG: " + glb.CFG + " [" + glb.Capture + "]");
                            if (glb.FXT != QA_ThisInstall.FXT)
                                GeneratedTSUList.Add("Apply FXT: " + glb.FXT + " [" + glb.Capture + "]");
                        }
                        GeneratedTSUList.Add("Apply ZRIPL in 1052 state");
                    //GGIRDHAR031717                    GeneratedTSUList.Add("Apply ZKSET APSC7F"); //[JIRA] (VIPP-55)
                    // Loop in here=> We need to scan every install upto current load date in question to get reload,change etc overflowed to next system
                    for (int installindex = 0; installindex <= LoadDates.IndexOf(loaddate); installindex++)
                    {
                        InstallDetail tempinstall = InstallsFromSVScript[installindex];
                        if (tempinstall == null)
                            continue;
                        //Saumen020617: added back commit d721face0d7
                        //GeneratedTSUList.Add("[Incorporate following " + tempinstall.InstallDate.ToString("yyyy-MM-dd") + " Install Changes]");
                        GeneratedTSUList.Add("[Incorporate following " + tempinstall.InstallDate.ToString("MM/dd/yy") + " Install Changes]");
                        //Saumen020617
                        foreach (var we in tempinstall.LoadedWEs)
                        {
                            if (we.Type == "TLD")
                                continue;
                            bool IsApplied = false;
                            string generalinfo = " [" + we.LoadDate.ToString("MM/dd/yy") + "," + we.LoadState.PadRight(19) + ", Gr-" + we.Group.ToString("D2") + "]";
                            #region For Moveout WEs
                            if (MoveOutWEs.Any(mw => mw.WENumber == we.WENumber))
                            {
                                //If the current date is less than the Moveout then Delete it
                                if (MoveOutWEs.First(mw => mw.WENumber == we.WENumber).LoadDate > tempinstall.InstallDate)
                                {
                                    //Delete according to the cancelled WE
                                    var canwe = CancelledWEs.First(cw => cw.WENumber == we.WENumber);
                                    ChangeState(canwe.LoadState, ref IsSystemin1052);
                                    if (canwe == null)
                                    {
                                        GeneratedTSUList.Add(("Deactivate and delete " + we.WENumber).PadRight(40) + generalinfo);
                                    }
                                    else
                                    {
                                        //if (QACTSwitches.IsSwitchActive(1))//Switch 1 - SliMS Script Fallback Commands to TSU
                                        //{
                                        if (canwe.Type != "TLD")
                                        {
                                            if (!string.IsNullOrWhiteSpace(canwe.FallbackCommands))
                                            {
                                                foreach (var fbcmd in we.FallbackCommands.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                                                {
                                                    if (fbcmd.ToUpper().Contains("ZCYCL"))
                                                        ChangeState(fbcmd, ref IsSystemin1052);
                                                    else if (fbcmd.ToUpper().Contains("ZOLDR DISP L"))
                                                        continue;
                                                    else if (fbcmd.ToUpper().Contains("ZOLDR DEA"))
                                                        GeneratedTSUList.Add(("Deactivate and delete " + canwe.WENumber).PadRight(40) + generalinfo);
                                                    else
                                                        GeneratedTSUList.Add(fbcmd);
                                                }
                                            }
                                            else
                                            {
                                                GeneratedTSUList.Add(("Deactivate and delete " + canwe.WENumber).PadRight(40) + generalinfo);
                                            }
                                        }
                                        /*}
                                        else
                                        {
                                            if ((canwe.Type == "OLD" && canwe.Vtape != "") || (canwe.Type == "NOLOAD" && canwe.FuncCommands != "") || (canwe.Type == "HFD" && canwe.FuncCommands != ""))
                                            {
                                                GeneratedTSUList.Add(("Deactivate and delete " + canwe.WENumber).PadRight(40) + generalinfo);
                                                List<string> switchonoffcommands = canwe.FuncCommands.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries)
                                                    .Where(c => c.ToUpper().Contains("ZKSWT") && (c.ToUpper().Contains("ON") || c.ToUpper().Contains("OFF"))).ToList();
                                                switchonoffcommands.ForEach((c) =>
                                                {
                                                    if (!string.IsNullOrWhiteSpace(c))
                                                        GeneratedTSUList.Add(c.ToUpper().Contains("OFF") ? c.ToUpper().Replace("OFF", "ON") : c.ToUpper().Replace("ON", "OFF"));
                                                });
                                            }
                                        }*/
                                    }
                                    IsApplied = true;
                                }

                            }
                            #endregion
                            #region For Emergency WEs
                            if (EmergencyWEs.Any(ew => ew.WENumber == we.WENumber) && !IsApplied)
                            {
                                bool loadedinpreviousinstall = false;
                                foreach (var item in InstallsFromQAScript.Where(inst => inst != null && inst.UpdatedOn <= QA_ThisInstall.UpdatedOn && inst.InstallDate <= QA_ThisInstall.InstallDate))
                                {
                                    if (item.LoadedWEs.Any(p => we.Equals(p)))
                                    {
                                        loadedinpreviousinstall = true;
                                        break;
                                    }
                                }
                                if (!loadedinpreviousinstall)//(!QA_ThisInstall.LoadedWEs.Any(p => p.Equals(we)))
                                {
                                    ChangeState(we.LoadState, ref IsSystemin1052);
                                    IEnumerable<string> commands;//= we.FuncCommands.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries).Where(c => !string.IsNullOrWhiteSpace(c));
                                    //if (QACTSwitches.IsSwitchActive(1))
                                    //{
                                    if (we.Type != "TLD" && !string.IsNullOrWhiteSpace(we.FuncCommands))
                                    {
                                        commands = we.FuncCommands.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries).Where(c => !string.IsNullOrWhiteSpace(c) && !IgnoreCommands.Any(ic => c.ToUpper().Contains(ic)));
                                        //If the WE do not have any ACT command, we need to mention that in TSU
                                        if (!we.FuncCommands.ToUpper().Contains("ZOLDR ACT"))
                                        {
                                            GeneratedTSUList.Add(("Load and Activate " + we.WENumber).PadRight(40) + generalinfo);
                                        }
                                        foreach (var command in commands)
                                        {
                                            if (command.ToUpper().Contains("ZCYCL "))
                                                ChangeState(command, ref IsSystemin1052);
                                            else if (command.ToUpper().Contains("ZOLDR ACT"))
                                                GeneratedTSUList.Add(("Load and Activate " + we.WENumber + " with " + we.Vtape).PadRight(40) + generalinfo);
                                            else
                                                GeneratedTSUList.Add(command.Trim());
                                        }
                                    }
                                    /*}
                                    else
                                    {
                                        commands = we.FuncCommands.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries).Where(c => !string.IsNullOrWhiteSpace(c));
                                        foreach (var command in commands)
                                        {
                                            if (command.ToUpper().Contains("ZCYCL "))
                                                ChangeState(command, ref IsSystemin1052);
                                            else if (command.ToUpper().Contains("ZOLDR") && command.ToUpper().Contains("DISP"))
                                                continue;
                                            else if (command.ToUpper().Contains("ZOLDR") && command.ToUpper().Contains("ACT"))
                                                GeneratedTSUList.Add(("Load and Activate " + we.WENumber + " with " + we.Vtape).PadRight(40) + generalinfo);
                                            else if (command.ToUpper().Contains("ZUHFD") && command.ToUpper().Contains("DISP"))
                                                GeneratedTSUList.Add(("ZUHFD DISP " + we.WENumber + "A"));
                                            else if (command.ToUpper().Contains("ZUHFD") && command.ToUpper().Contains("INSTALL"))
                                            {
                                                GeneratedTSUList.Add("ZUHFD ROLLBACK " + we.WENumber + "A");
                                                GeneratedTSUList.Add("ZUHFD DELETE " + we.WENumber + "A");
                                                GeneratedTSUList.Add("ZUFTP SET HFD DNS-sl55pslimsapp.visa.com");
                                                GeneratedTSUList.Add("ZUFTP SET HFD RFILE-/zHFD/");
                                                GeneratedTSUList.Add("ZUHFD RECEIVE " + we.WENumber + "A");
                                                GeneratedTSUList.Add(("ZUHFD INSTALL " + we.WENumber + "A"));
                                            }
                                            else if (command.ToUpper().Contains("ZUHFD") && command.ToUpper().Contains("RECEIVE"))
                                                GeneratedTSUList.Add(("ZUHFD RECEIVE " + we.WENumber + "A"));

                                            else
                                                GeneratedTSUList.Add(command.Trim());
                                        }
                                    }*/
                                    IsApplied = true;
                                }

                            }
                            #endregion
                            #region For Changed WEs
                            else if (ChangedWEs.Any(cw => cw.WENumber == we.WENumber) && !IsApplied)
                            {
                                //if the WE is exists in cancelled WE list move to next
                                if (!CancelledWEs.Any(c => c.LoadDate == we.LoadDate && c.WENumber == we.WENumber))
                                {
                                    bool loadedinpreviousinstall = false;
                                    foreach (var item in InstallsFromQAScript.Where(inst => inst != null && inst.UpdatedOn <= QA_ThisInstall.UpdatedOn && inst.InstallDate <= QA_ThisInstall.InstallDate))
                                    {
                                        if (item.LoadedWEs.Any(p => we.Equals(p)))
                                        {
                                            loadedinpreviousinstall = true;
                                            break;
                                        }
                                    }
                                    if (!loadedinpreviousinstall)//(!QA_ThisInstall.LoadedWEs.Any(p => p.Equals(we)))
                                    {
                                        ChangeState(we.LoadState, ref IsSystemin1052);
                                        WEEntry loadedwe = null;
                                        for (int i = 0; i <= LoadDates.IndexOf(loaddate); i++)
                                        {
                                            if (InstallsFromQAScript[i] != null)
                                            {
                                                var tmpwe = InstallsFromQAScript[i].LoadedWEs.LastOrDefault(p => p.WENumber == we.WENumber);
                                                if (tmpwe != null)
                                                    loadedwe = tmpwe;
                                            }
                                        }
                                        //if (QACTSwitches.IsSwitchActive(1))
                                        //{
                                        if (loadedwe.FuncCommands.Replace("ZCP VTM 34C " + loadedwe.Vtape, null) == we.FuncCommands.Replace("ZCP VTM 34C " + we.Vtape, null) && !we.FuncCommands.Contains("HFD"))
                                        {
                                            if (we.Type == "OLD")
                                                GeneratedTSUList.Add(("Replace " + we.WENumber + " with " + we.Vtape).PadRight(40) + generalinfo);
                                        }
                                        else
                                        {
                                            if (!we.FuncCommands.ToUpper().Contains("ZOLDR ACT"))
                                            {
                                                GeneratedTSUList.Add(("Replace " + we.WENumber).PadRight(40) + generalinfo);
                                            }
                                            var commands = we.FuncCommands.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries).Where(c => !string.IsNullOrWhiteSpace(c) && !IgnoreCommands.Any(ic => c.ToUpper().Contains(ic)));
                                            foreach (var command in commands)
                                            {
                                                if (command.ToUpper().Contains("ZCYCL "))
                                                    ChangeState(command, ref IsSystemin1052);
                                                else if (command.ToUpper().Contains("ZOLDR ACT"))
                                                    GeneratedTSUList.Add(("Replace " + we.WENumber + " with " + we.Vtape).PadRight(40) + generalinfo);
                                                else
                                                    GeneratedTSUList.Add(command.Trim());
                                            }
                                        }

                                        /*}
                                        else
                                        {
                                            if (loadedwe.FuncCommands == we.FuncCommands)
                                            {
                                                if (we.Type == "OLD")
                                                    GeneratedTSUList.Add(("Replace " + we.WENumber + " with " + we.Vtape).PadRight(40) + generalinfo);
                                            }
                                            else
                                            {
                                                var commands = we.FuncCommands.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries).Where(c => !string.IsNullOrWhiteSpace(c));
                                                foreach (var command in commands)
                                                {
                                                    if (command.ToUpper().Contains("ZCYCL "))
                                                        ChangeState(command, ref IsSystemin1052);
                                                    else if (command.ToUpper().Contains("ZOLDR") && command.ToUpper().Contains("DISP"))
                                                        continue;
                                                    else if (command.ToUpper().Contains("ZOLDR") && command.ToUpper().Contains("ACT"))
                                                        GeneratedTSUList.Add(("Replace " + we.WENumber + " with " + we.Vtape).PadRight(40) + generalinfo);
                                                    else if (commands.Any(c => c.ToUpper().Contains("ZUHFD") && c.ToUpper().Contains("INSTALL")))
                                                    {
                                                        if (command.ToUpper().Contains("ZUHFD") && command.ToUpper().Contains("DISP"))
                                                            GeneratedTSUList.Add(("ZUHFD DISP " + we.WENumber + "A"));
                                                        else if (command.ToUpper().Contains("ZUHFD") && command.ToUpper().Contains("INSTALL"))
                                                        {
                                                            GeneratedTSUList.Add("ZUHFD ROLLBACK " + we.WENumber + "A");
                                                            GeneratedTSUList.Add("ZUHFD DELETE " + we.WENumber + "A");
                                                            GeneratedTSUList.Add("ZUFTP SET HFD DNS-sl55pslimsapp.visa.com");
                                                            GeneratedTSUList.Add("ZUFTP SET HFD RFILE-/zHFD/");
                                                            GeneratedTSUList.Add("ZUHFD RECEIVE " + we.WENumber + "A");
                                                            GeneratedTSUList.Add(("ZUHFD INSTALL " + we.WENumber + "A"));
                                                        }
                                                        else if (command.ToUpper().Contains("ZUHFD") && command.ToUpper().Contains("RECEIVE"))
                                                            GeneratedTSUList.Add(("ZUHFD RECEIVE " + we.WENumber + "A"));
                                                        else
                                                            GeneratedTSUList.Add(command.Trim());
                                                    }
                                                }
                                            }
                                        }*/
                                        IsApplied = true;
                                    }
                                }

                            }
                            #endregion
                            #region For Cancelled WEs
                            else if (CancelledWEs.Any(cw => cw.WENumber == we.WENumber) && !IsApplied)
                            {
                                //This is specially for moveout WEs
                                if (!InstallsFromSVScript.Any(i => i != null && i.InstallDate <= loaddate && i.LoadedWEs.Any(w => w.WENumber == we.WENumber && w.LoadDate > CancelledWEs.First(c => c.WENumber == we.WENumber).LoadDate)))
                                {
                                    //Find when the WE was applied
                                    var fallbackweapplied = InstallsFromQAScript.FirstOrDefault(i => i != null && i.LoadedWEs.Any(w => w.WENumber == we.WENumber));//&& w.Status == we.Status
                                    if (fallbackweapplied != null)
                                    {
                                        if (QA_ThisInstall.InstallDate >= fallbackweapplied.InstallDate)
                                        {
                                            ChangeState(we.LoadState, ref IsSystemin1052);
                                            //if (QACTSwitches.IsSwitchActive(1))
                                            //{
                                            if (we.Type != "TLD")
                                            {
                                                if (!string.IsNullOrWhiteSpace(we.FallbackCommands))
                                                {
                                                    foreach (var fbcmd in we.FallbackCommands.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                                                    {
                                                        if (fbcmd.ToUpper().Contains("ZCYCL"))
                                                            ChangeState(fbcmd, ref IsSystemin1052);
                                                        else if (fbcmd.ToUpper().Contains("ZOLDR DISP L"))
                                                            continue;
                                                        else if (fbcmd.ToUpper().Contains("ZOLDR DEA"))
                                                            GeneratedTSUList.Add(("Deactivate and delete " + we.WENumber).PadRight(40) + generalinfo);
                                                        else
                                                            GeneratedTSUList.Add(fbcmd);
                                                    }
                                                }
                                                else
                                                    GeneratedTSUList.Add(("Deactivate and delete " + we.WENumber).PadRight(40) + generalinfo);
                                            }
                                            /*}
                                            else
                                            {
                                                if ((we.Type == "OLD" && we.Vtape != "") || (we.Type == "NOLOAD" && we.FuncCommands != "") || (we.Type == "HFD" && we.FuncCommands != ""))
                                                {
                                                    GeneratedTSUList.Add(("Deactivate and delete " + we.WENumber).PadRight(40) + generalinfo);
                                                    List<string> switchonoffcommands = we.FuncCommands.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries)
                                                        .Where(c => c.ToUpper().Contains("ZKSWT") && (c.ToUpper().Contains("ON") || c.ToUpper().Contains("OFF"))).ToList();
                                                    switchonoffcommands.ForEach((c) =>
                                                    {
                                                        if (!string.IsNullOrWhiteSpace(c))
                                                            GeneratedTSUList.Add(c.ToUpper().Contains("OFF") ? c.ToUpper().Replace("OFF", "ON") : c.ToUpper().Replace("ON", "OFF"));
                                                    });
                                                }
                                            }*/
                                        }
                                    }
                                    else
                                    {
                                        var appliedwe = InstallsFromQAScript.FirstOrDefault(i => i != null && i.LoadedWEs.Any(w => w.WENumber == we.WENumber && w.Status != we.Status));
                                        if (appliedwe != null && QA_ThisInstall.UpdatedOn > appliedwe.UpdatedOn)
                                        {
                                            ChangeState(we.LoadState, ref IsSystemin1052);
                                            //if (QACTSwitches.IsSwitchActive(1))
                                            //{
                                            if (we.Type != "TLD")
                                            {
                                                if (!string.IsNullOrWhiteSpace(we.FallbackCommands))
                                                {
                                                    foreach (var fbcmd in we.FallbackCommands.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                                                    {
                                                        if (fbcmd.ToUpper().Contains("ZCYCL"))
                                                            ChangeState(fbcmd, ref IsSystemin1052);
                                                        else if (fbcmd.ToUpper().Contains("ZOLDR DISP L"))
                                                            continue;
                                                        else if (fbcmd.ToUpper().Contains("ZOLDR DEA"))
                                                            GeneratedTSUList.Add(("Deactivate and delete " + we.WENumber).PadRight(40) + generalinfo);
                                                        else
                                                            GeneratedTSUList.Add(fbcmd);
                                                    }
                                                }
                                                else
                                                    GeneratedTSUList.Add(("Deactivate and delete " + we.WENumber).PadRight(40) + generalinfo);
                                            }
                                            /*}
                                            else
                                            {
                                                if ((we.Type == "OLD" && we.Vtape != "") || (we.Type == "NOLOAD" && we.FuncCommands != "") || (we.Type == "HFD" && we.FuncCommands != ""))
                                                {
                                                    GeneratedTSUList.Add(("Deactivate and delete " + we.WENumber).PadRight(40) + generalinfo);
                                                    List<string> switchonoffcommands = we.FuncCommands.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries)
                                                        .Where(c => c.ToUpper().Contains("ZKSWT") && (c.ToUpper().Contains("ON") || c.ToUpper().Contains("OFF"))).ToList();
                                                    switchonoffcommands.ForEach((c) =>
                                                    {
                                                        if (!string.IsNullOrWhiteSpace(c))
                                                            GeneratedTSUList.Add(c.ToUpper().Contains("OFF") ? c.ToUpper().Replace("OFF", "ON") : c.ToUpper().Replace("ON", "OFF"));
                                                    });
                                                }
                                            }*/
                                        }
                                    }
                                    IsApplied = true;
                                }
                            }
                            #endregion
                            #region For Reloaded WEs
                            else if (ReloadedWEs.Any(rw => rw.WENumber == we.WENumber) && !IsApplied)
                            {
                                //if the WE is exists in cancelled WE list move to next
                                if (!CancelledWEs.Any(c => c.LoadDate == we.LoadDate && c.WENumber == we.WENumber))
                                {
                                    ChangeState(we.LoadState, ref IsSystemin1052);
                                    GeneratedTSUList.Add(("Reload " + we.WENumber + " with " + we.Vtape).PadRight(40) + generalinfo);
                                    IsApplied = true;
                                }
                            }

                        }
                        #endregion
                        //Loop out here
                    }
                    GeneratedTSUList.Add("[Incorporate Extra commands from TSU Request Entry]");
                    ChangeState("NORM", ref IsSystemin1052);

                    /////////////////////////////////////// check if the format for TSU request entry is correct //////////////////////////
                    if (Extracommands.TrueForAll(cmd => cmd.Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries).Length >= 3))
                    {
                        var thisweekextracommands = Extracommands.Where(c =>
                                                                    DateTime.ParseExact(c.Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries)[1], "MM/dd/yyyy", null) <= loaddate
                                                                    && DateTime.ParseExact(c.Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries)[2], "MM/dd/yyyy", null) >= loaddate
                                                                    );
                        if (thisweekextracommands != null)
                            foreach (string excmd in thisweekextracommands)
                                GeneratedTSUList.Add(excmd.Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries)[0]);
                    }
                    else
                    {
                        if (!IsAUTOTSUCalled)
                            Application.Current.Dispatcher.Invoke((Action)(() => { MessageBox.Show("Error in parsing the file " + App.ExtraTSUCMDServer + ", Invalid text format."); }));
                        else
                        {
                            SendTSUMail(error: "Error in parsing the file " + App.ExtraTSUCMDServer + ", Invalid text format.");
                            Application.Current.Shutdown();//Saumen021317
                        }
                    }

                    GeneratedTSUList.Add("Deactivate Mod 11, enter ZKSET APSD1F");
                    GeneratedTSUList.Add("Use PARSEM, PRODxxxx ZBURZ file");
                    GeneratedTSUList.Add("Use COMPXXX for comparison\n\n");
                }
            }
        }
        /// <summary>
        /// Get the Loads from QA SCript file
        /// </summary>
        /// <param name="excelpath"></param>
        /// <param name="LoadDates"></param>
        /// <returns></returns>
        List<InstallDetail> GetInstallsFromExcel(string excelpath, List<DateTime> LoadDates, Excel.Application xlapp)
        {
            CommonClass.ChangeStatus("Opening " + System.IO.Path.GetFileName(excelpath) + " for weekly loads...", 0, 1, true);
            List<InstallDetail> Installs = new List<InstallDetail>();

            Excel.Workbook xlworkbook = null; Excel.Worksheet xlworksheet = null;
            try
            {
                xlworkbook = xlapp.Workbooks.Open(excelpath, Type.Missing, true);
                xlworksheet = xlworkbook.Worksheets[1];// Hopefully 1st will be "SCRIPT"
                foreach (var loaddate in LoadDates)
                {
                    string searchstring = "system (" + loaddate.ToString("MM/dd/yyyy") + " install)";
                    var firstrow = xlworksheet.Cells.Find(searchstring, Type.Missing, Excel.XlFindLookIn.xlValues,
                        Excel.XlLookAt.xlPart, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext,
                        false, Type.Missing, Type.Missing);
                    //Saumen020617: added back commit d721face0d7
                    if (firstrow == null)
                    {
                        searchstring = "system (" + loaddate.ToString("MM/dd/yy") + " install)";
                        firstrow = xlworksheet.Cells.Find(searchstring, Type.Missing, Excel.XlFindLookIn.xlValues,
                        Excel.XlLookAt.xlPart, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext,
                        false, Type.Missing, Type.Missing);
                    }
                    //Saumen020617
                    if (firstrow == null)
                        Installs.Add(null);
                    else
                    {
                        //Saumen020617: added back commit 8184744a25f
                        ////Generally for QA script
                        //var endrow = xlworksheet.Cells.Find("FXT", firstrow, Excel.XlFindLookIn.xlValues,
                        //    Excel.XlLookAt.xlPart, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext,
                        //    false, Type.Missing, Type.Missing);
                        var endrow = xlworksheet.Cells.Find("End of " + loaddate.ToString("MM/dd/yy") + " script", firstrow, Excel.XlFindLookIn.xlValues,
                                Excel.XlLookAt.xlPart, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext,
                                false, Type.Missing, Type.Missing);
                        //Saumen020617
                        if (endrow == null)
                            //generally for SV Script
                            //endrow = xlworksheet.Cells.Find("code level", firstrow, Excel.XlFindLookIn.xlValues,
                            endrow = xlworksheet.Cells.Find("End of " + loaddate.ToString("MM/dd/yyyy") + " script", firstrow, Excel.XlFindLookIn.xlValues,//Saumen020617: added back commit 8184744a25f
                                Excel.XlLookAt.xlPart, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext,
                                false, Type.Missing, Type.Missing);
                        //Saumen020617: added back commit 4b44d2e6bc9 - TSU-'End of MM/dd/yyyy Install script' is added to identifier
                        if (endrow == null)
                            //generally for SV Script
                            //endrow = xlworksheet.Cells.Find("End of " + loaddate.ToString("MM/dd/yyyy") + " script", firstrow, Excel.XlFindLookIn.xlValues,
                            endrow = xlworksheet.Cells.Find("code level", firstrow, Excel.XlFindLookIn.xlValues,//Saumen020617: added back commit 8184744a25f
                                Excel.XlLookAt.xlPart, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext,
                                false, Type.Missing, Type.Missing);
                        //Saumen020617
                        //Remove XXXX later hoping that Scripts will have some end identifier
                        //Saumen020617: added back commit 8184744a25f
                        //var nextinstallstart = xlworksheet.Cells.Find(" XXXXXXX)", firstrow, Excel.XlFindLookIn.xlValues,
                        //Generally for QA script
                        if (endrow == null)
                            endrow = xlworksheet.Cells.Find("FXT", firstrow, Excel.XlFindLookIn.xlValues,
                            //Saumen020617
                            Excel.XlLookAt.xlPart, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext,
                            false, Type.Missing, Type.Missing);
                        //Saumen020617: added back commit 8184744a25f
                        //if (endrow == null || (nextinstallstart != null && endrow != null && nextinstallstart.Row < endrow.Row))

                        ////Remove XXXX later hoping that Scripts will have some end identifier
                        //var nextinstallstart = xlworksheet.Cells.Find(" XXXXXXX)", firstrow, Excel.XlFindLookIn.xlValues,
                        //    Excel.XlLookAt.xlPart, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext,
                        //    false, Type.Missing, Type.Missing);
                        if (endrow == null /*|| (nextinstallstart != null && endrow != null && nextinstallstart.Row < endrow.Row)*/)
                        //Saumen020617
                            Installs.Add(null);
                        else
                        {
                            InstallDetail thisinstall = new InstallDetail() { InstallDate = loaddate };
                            thisinstall.SystemName = (firstrow.Text as string).Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0];
                            thisinstall.LoadedWEs = new List<WEEntry>();
                            foreach (Excel.Range row in xlworksheet.get_Range(firstrow, endrow).Rows)
                            {
                                string WEnumber = ((row.Columns[WENUMBERCOL] as Excel.Range).Text as string).Trim().ToUpper();
                                if (WEnumber == null || WEnumber == "")
                                    continue;
                                else if (WEnumber.Contains("WE") && WEnumber.Length == 8)
                                {
                                    WEEntry we = new WEEntry() { WENumber = WEnumber };
                                    string ldgrp = ((row.Columns[WEDATEGRPCOL] as Excel.Range).Text as string).Replace("(", "").Replace(")", "");
                                    we.LoadDate = DateTime.Parse(ldgrp.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0]);
                                    we.Group = Convert.ToInt16(ldgrp.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[2]);
                                    we.Status = ((row.Columns[WESTATUSCOL] as Excel.Range).Text as string).Trim();
                                    if (we.Status != null && we.Status.Contains("Fallback"))
                                        we.Status = "Fallback";
                                    we.LoadState = ((row.Columns[WESTATECOL] as Excel.Range).Text as string).Trim();
                                    we.Type = ((row.Columns[WETYPECOL] as Excel.Range).Text as string).Trim();
                                    we.Vtape = ((row.Columns[WEVTAPECOL] as Excel.Range).Text as string).Trim();
                                    we.FuncCommands = ((row.Columns[WEFUNCCOMMANDCOL] as Excel.Range).Text as string).Trim();
                                    //.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries).ToList();
                                    //This is still not in SV Script, We need to contact SliMS team to include this and additionally
                                    //to include first turnover. Just parsed the string as in History panel of SLiMS
                                    //we.LastUpdatedOn = DateTime.ParseExact((row.Columns[LASTUPDATEDCOL] as Excel.Range).Text as string,"yyyy-MM-dd HH:mm:ss",null);
                                    we.FallbackCommands = ((row.Columns[WEFALLBACKCOL] as Excel.Range).Text as string).Trim();
                                    thisinstall.LoadedWEs.Add(we);
                                }
                                else if (WEnumber.Contains("GLOBALS"))
                                {
                                    //Stop using the excel global version
                                    // thisinstall.GlobalVersion = ((row.Columns[1] as Excel.Range).Text as string);//.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0]; //2nd column has the value
                                    //Saumen020617: added back commit e21fd6b5074
                                    //var glb = testsustemstatus.FirstOrDefault(a => a != null && a.Split(',')[0].ToUpper() == thisinstall.SystemName.ToUpper());
                                    //if (glb != null)
                                    //{

                                    //    var gg = glb.Split(',');
                                    //    //start using test system status global version
                                    //    thisinstall.GlobalVersion = gg[4];
                                    //    thisinstall.DCS = gg[5];
                                    //    thisinstall.BMX = gg[6];
                                    //    thisinstall.NWK = gg[7];
                                    //    thisinstall.CFG = gg[8];
                                    //    thisinstall.FXT = gg[9];
                                    //}
                                    //Saumen020617
                                    break;
                                }
                                else if (WEnumber.Contains("DDR FROM"))
                                    thisinstall.DDRedFrom = ((row.Columns[2] as Excel.Range).Text as string).Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0]; //2nd column has the value
                                else if (WEnumber.Contains("UPDATED ON"))
                                    thisinstall.UpdatedOn = DateTime.Parse(((row.Columns[2] as Excel.Range).Text as string)); //2nd column has the value
                            }
                            //Saumen020617: added back commit e21fd6b5074
                            //Always use global from Test system status
                            var glb = testsystemstatus.FirstOrDefault(a => a != null && a.Split(',')[0].ToUpper() == thisinstall.SystemName.ToUpper());
                            if (glb != null)
                            {

                                var gg = glb.Split(',');
                                //start using test system status global version
                                thisinstall.GlobalVersion = gg[4];
                                thisinstall.DCS = gg[5];
                                thisinstall.BMX = gg[6];
                                thisinstall.NWK = gg[7];
                                thisinstall.CFG = gg[8];
                                thisinstall.FXT = gg[9];
                            }
                            //Saumen020617
                            Installs.Add(thisinstall);

                        }

                    }
                }
                CommonClass.ChangeStatus("Ready", 0, 0, false);
            }
            catch (Exception ex) { CommonClass.ChangeStatus("Error." + ex.Message, 0, 0, false); }
            finally
            {
                if (xlworkbook != null)
                    xlworkbook.Close(false);
                if (xlapp != null)
                {
                    xlapp.Quit();
                    xlapp = null;
                }
                try
                {
                    //Remove the temp folder file only
                    if (excelpath.Contains(App.TempFolder))
                        System.IO.File.Delete(excelpath);
                }
                catch { }
            }

            return Installs;
        }
        /// <summary>
        /// Get the Globals from the Server Globals Excel sheet
        /// </summary>
        /// <param name="LoadDates"></param>
        //void GetGlobals(List<DateTime> LoadDates, Excel.Application xlapp)
        void PopulateGlobals(List<DateTime> LoadDates, Excel.Application xlapp)//Saumen020617 : added back commit c0145d16aac
        {
            CommonClass.ChangeStatus("Opening Globals Excel sheet from server...", 0, 1, true);
            List<GlobalsWithLD> globals = new List<GlobalsWithLD>();
            try
            {
                //Get Global from Sharepoint
                //GetGlobalfromSharePoint();
                //
                //
                // System.IO.File.Copy(App.QAGlobalServer, App.TempFolder + "temp_global.xlsx", true);
                xlapp.DisplayAlerts = false;
                Excel.Workbook xlworkbook = xlapp.Workbooks.Open(CommonClass.GetQAGlobalFromSharepoint(), Type.Missing, true, true);
                Excel.Worksheet xlsheet = xlworkbook.Worksheets[1]; ///Check the first Sheet
                //Saumen020617: added back commit d721face0d7
                int maxrow = xlsheet.UsedRange.Rows.Count;
                //Saumen020617
                foreach (var ld in LoadDates)
                {
                    int row = 1;
                    int loaddatecol = 0;
                    while (true)
                    {
                        if (((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Contains("PROD DATA"))
                        {
                            //Find the column of install date from next line
                            //Form the new Global class;
                            //Saumen020617 : added back commit c0145d16aac
                            //string capturedate = ((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Replace("PROD", "").Replace("DATA", "").Trim();
                            //GlobalsWithLD tempglobal = new GlobalsWithLD() { LoadDate = ld, Capture = ((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Trim().Replace("PROD DATA", "CAPTURE, ") + ((xlsheet.Cells[row, 2] as Excel.Range).Text as string).Trim() };
                            //string capturedate = ((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Replace("PROD", "").Replace("DATA", "").Trim();
                            GlobalsWithLD tempglobal = new GlobalsWithLD() { LoadDate = ld, Capture = ((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Trim() + ":" + ((xlsheet.Cells[row, 2] as Excel.Range).Text as string).Trim() };
                            // Global tempglobal = new Global() { Capture = ((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Trim() + ":" + ((xlsheet.Cells[row, 2] as Excel.Range).Text as string).Trim() };
                            tempglobal.Capture = tempglobal.Capture.ToUpper().Replace("PROD DATA", "CAPTURE").Trim();
                            var capturedate = DateTime.Parse(tempglobal.Capture.Split(' ')[0]);
                            if (capturedate > DateTime.Now)
                            {
                                capturedate = capturedate.AddYears(-1);
                            }
                            //Saumen020617
                            //Check first 20 columns for Load date
                            for (int col = 1; col <= 20; col++)
                            {
                                //if (((xlsheet.Cells[row + 1, col] as Excel.Range).Text as string).Contains(ld.ToString("MM/dd")))
                                //{//
                                //    loaddatecol = col;
                                //    break;
                                //}
                                //Saumen020617 : added back commit c0145d16aac
                                //string celltext = ((xlsheet.Cells[row + 1, col] as Excel.Range).Text as string).ToUpper().Trim();
                                DateTime celldate;
                                string celltext = ((xlsheet.Cells[row + 1, col] as Excel.Range).Text as string).ToUpper();
                                //Saumen020617
                                if (celltext == "" || celltext == null || celltext.Contains("DATA"))
                                    continue;
                                //Saumen020617 : added back commit c0145d16aac
                                //else if (celltext.Contains("BASELINE"))
                                //{
                                //    loaddatecol = col;
                                //    continue;
                                //}
                                //Saumen020617
                                else
                                {
                                    //Saumen020617 : added back commit c0145d16aac
                                    //int mnthdiff = ld.Month - Convert.ToInt16(celltext.Split('/')[0]);
                                    //int yr = ld.Year;
                                    //if (mnthdiff <= -6)
                                    //    yr = yr - 1;

                                    //if ((DateTime.ParseExact(celltext + "/" + yr, "MM/dd/yyyy", null) <= ld))
                                    if (celltext.Contains("BASELINE"))
                                    {
                                        celldate = capturedate;
                                    }
                                    else
                                        celldate = (DateTime.ParseExact(celltext + "/" + capturedate.Year, "MM/dd/yyyy", null));
                                    if (celldate < capturedate)
                                    {
                                        celldate = celldate.AddYears(1);
                                    }
                                    if (celldate <= ld)
                                    //Saumen020617
                                    {
                                        loaddatecol = col;
                                    }
                                    else
                                        break;

                                }
                            }
                            row++;
                            if (loaddatecol == 0)
                                continue;
                            do
                            {
                                row++;
                                string celltext = ((xlsheet.Cells[row, 1] as Excel.Range).Text as string).ToUpper();
                                if (celltext.Contains("DCS"))
                                {
                                    //check all columns from 2nd column
                                    for (int i = loaddatecol; i >= 2; i--)
                                    {
                                        if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                        {
                                            tempglobal.DCS = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                            break;
                                        }
                                    }
                                }
                                else if (celltext.Contains("BMX"))
                                {
                                    for (int i = loaddatecol; i >= 2; i--)
                                    {
                                        if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                        {
                                            tempglobal.BMX = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                            break;
                                        }
                                    }
                                }
                                else if (celltext.Contains("NWK"))
                                {
                                    for (int i = loaddatecol; i >= 2; i--)
                                    {
                                        if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                        {
                                            tempglobal.NWK = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                            break;
                                        }
                                    }
                                }
                                else if (celltext.Contains("CFG"))
                                {
                                    for (int i = loaddatecol; i >= 2; i--)
                                    {
                                        if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                        {
                                            tempglobal.CFG = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                            break;
                                        }
                                    }
                                }
                                else if (celltext.Contains("FXT"))
                                {
                                    for (int i = loaddatecol; i >= 2; i--)
                                    {
                                        if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                        {
                                            tempglobal.FXT = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                            break;
                                        }
                                    }
                                }
                                else if (celltext.Contains("MVV"))
                                    globals.Add(tempglobal);
                            } while (!((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Contains("MVV"));
                        }
                        row++;
                        //Saumen020617: added back commit d721face0d7
                        //if (row >= 30)//Cehck maximum 50 lines
                        if (row >= maxrow)//Saumen020617
                        {
                                break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            CommonClass.ChangeStatus("Ready", 0, 0, false);
            GlobalsFromSheet = globals;
        }

        private void SendTSUMail(string error = null)
        {

            Outlook.Application oApp; Outlook.MailItem oMsg; Outlook.Recipient oRecip;
            try
            {
                oApp = new Outlook.Application();
                oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                //oMsg.BodyFormat = Outlook.OlBodyFormat.olFormatRichText;

                oRecip = (Outlook.Recipient)oMsg.Recipients.Add("QA-VIP-Support@visa.com");
                oMsg.Subject = "Test System Update: " + DateTime.UtcNow.ToString("MM/dd/yy hh:mm:ss tt") + " GMT";
                if (error != null)
                {
                    oMsg.Subject = "Error in TSU:" + error + DateTime.UtcNow.ToString("MM/dd/yy hh:mm:ss tt") + " GMT";
                }
                //oMsg.RTFBody = System.Text.Encoding.ASCII.GetBytes(GetRTF(txtTSU));
                oMsg.BodyFormat = Outlook.OlBodyFormat.olFormatHTML;
                oMsg.HTMLBody =
                                @"<head>
                                    <style>
                                        body {font-family:""Courier New"";font-size:""12px"";}
                                    <style>
                                  </head>
                                <body>
                                " + txtTSU.Text.Replace(Environment.NewLine, "<br>") + "</body>";
                ((Outlook._MailItem)oMsg).Send();
            }
            catch (Exception)
            {
                if (!IsAUTOTSUCalled)
                    MessageBox.Show("Error in sending Email.");
            }
            finally
            {
                oRecip = null; oMsg = null; oApp = null;
                //Saumen021317
                if (oRecip != null || oMsg != null || oApp != null)
                {
                    try
                    {
                        Marshal.ReleaseComObject(oRecip);
                        oRecip = null;
                        Marshal.ReleaseComObject(oMsg);
                        oMsg = null;
                        Marshal.ReleaseComObject(oApp);
                        oApp = null;
                    }
                    catch (Exception)
                    {
                        oRecip = null;
                        oMsg = null;
                        oApp = null;
                    }
                    finally
                    {
                        GC.Collect();
                    }
                }
                //Saumen021317
            }
        }
        private void ChangeState(string LoadState, ref bool Is1052)
        {
            if (LoadState.Trim().ToUpper().Contains("1052") && !Is1052)
            {
                if (GeneratedTSUList.Last().Trim().ToUpper() == "ZCYCL NORM")
                {
                    GeneratedTSUList.RemoveAt(GeneratedTSUList.Count - 1);
                }
                else
                    GeneratedTSUList.Add("ZCYCL 1052");
                Is1052 = true;
            }
            else if (LoadState.Trim().ToUpper().Contains("NORM") && Is1052)
            {
                if (GeneratedTSUList.Last().Trim().ToUpper() == "ZCYCL 1052")
                {
                    GeneratedTSUList.RemoveAt(GeneratedTSUList.Count - 1);
                }
                else
                    GeneratedTSUList.Add("ZCYCL NORM");
                Is1052 = false;
            }
        }
        private List<string> FindIntersect(string InputWE, DateTime ld)
        {
            List<string> intersects = new List<string>();
            foreach (var item in List_Intersect.Where(p => p.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[1] == InputWE))//Get all items with the WE number
            {
                var intermediateintersect = List_Intersect.Where(x => x.Contains(item.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0] + " ")) //add a space after the program
                    .SkipWhile(y => y != item).Skip(1)
                    .Where(k => !intersects.Any(l => l.Contains(k.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[1])));//Get all WEs after Input WE with same program name
                foreach (var intr in intermediateintersect)
                    if (DateTime.ParseExact(intr.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[2], "yyyy/MM/dd", null) <= ld)
                        intersects.AddRange(FindIntersect(intr.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[1], ld).Where(k => !intersects.Any(l => l.Contains(k.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[1])))); //Recursive Intersect, Intsersect of Intersects
                intersects.AddRange(intermediateintersect);
            }
            return intersects;
        }
        private List<string> GetIntersectList(string intersectpath, Excel.Application xlapp)
        {
            CommonClass.ChangeStatus("Formating intersect...", 0, 1, true);
            List<string> Intrsect = new List<string>();
            string wholefile = "";
            if (intersectpath.Contains(".xls"))
            {
                Excel.Workbook xlworkbook = null; Excel.Worksheet xlworksheet = null;
                try
                {
                    xlworkbook = xlapp.Workbooks.Open(intersectpath, Type.Missing, true);
                    xlworksheet = xlworkbook.Worksheets[1];// Hopefully 1st will be "SCRIPT"
                    object[,] xx = xlworksheet.UsedRange.Value2;
                    int singlerow = xx.GetLength(1);
                    for (int i = 1; i <= (xx.Length / singlerow); i++)
                    {
                        for (int j = 1; j <= singlerow; j++)
                        {
                            wholefile += (string)xx[i, j] + " ";
                        }
                        wholefile += Environment.NewLine;
                    }

                }
                catch (Exception)
                {

                }
                finally
                {
                    if (xlworkbook != null)
                        xlworkbook.Close(false);
                    xlworksheet = null;

                }
            }
            else
            {
                try
                {
                    wholefile = System.IO.File.ReadAllText(intersectpath);
                }
                catch (Exception)
                {
                    return new List<string>();
                }
            }
            CommonClass.ChangeStatus("Done", 0, 0, false);
            return wholefile.Replace("\t", " ").Replace("**", null)
                        .Split(new string[] { Environment.NewLine, "\n" }, StringSplitOptions.RemoveEmptyEntries)
                        .Where(l => l.Contains("CRQ"))
                        .Select(l => string.Join(" ", l.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).Take(4)))
                        .GroupBy(l => l.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0])
                        .Where(g => g.Count() > 1).SelectMany((g) => g.ToList()).ToList();
            //return wholefile.Replace("\t", " ").Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries)
            //    .Where(l => l.Trim() != "" && l.Contains("CRQ")).Select(l => string.Concat(l.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).Select(x => x + " "))).ToList(); ;
        }
        private List<DateTime> GetLoadDates()
        {
            List<DateTime> LoadDates = new List<DateTime>();
            if (StartDate == null || EndDate == null)
            {

                try
                {
                    testsystemstatus = System.IO.File.ReadAllLines(App.TestSystemStatusServer).ToList();
                    StartDate = DateTime.Parse(testsystemstatus.First(ts => ts.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)[0].Contains("BASEZ11X")).Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)[1]);
                    EndDate = testsystemstatus.Skip(1).Max(ts => DateTime.Parse(ts.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)[1]));
                }
                catch
                {
                    StartDate = DateTime.Now - TimeSpan.FromDays((int)DateTime.Now.DayOfWeek);
                    //Upto Wednesday show start date as Sunday before Last sunday
                    if ((int)DateTime.Now.DayOfWeek <= 3)
                        StartDate = StartDate - TimeSpan.FromDays(7);
                    EndDate = StartDate + TimeSpan.FromDays(42);
                    EndDate = EndDate - TimeSpan.FromDays((int)((DateTime)EndDate).DayOfWeek);
                }
            }
            for (int i = 0; i <= (((DateTime)EndDate - (DateTime)StartDate)).Days; i++)
            {
                var tmp = (StartDate + TimeSpan.FromDays(i));
                if (((DateTime)tmp).DayOfWeek == DayOfWeek.Sunday)
                    LoadDates.Add((DateTime)tmp);
            }
            return LoadDates;
        }

        private void btnEmail_Click(object sender, RoutedEventArgs e)
        {
            SendTSUMail();
            btnSave.RaiseEvent(new RoutedEventArgs(System.Windows.Controls.Primitives.ButtonBase.ClickEvent));
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                File.WriteAllText(App.TSUFileServer, txtTSU.Text);
            }
            catch (Exception)
            {
                if (!IsAUTOTSUCalled)
                    MessageBox.Show("Error in saving TSU to server.");
                else
                    throw new IOException("Error in saving TSU to server.");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="type"></param>
        public static string GetSliMsFiles(DateTime start, DateTime end, bool isIntersectRequired)
        {

            using (WebClientEx webclient = new WebClientEx())
            {
                webclient.TimeOut = 3 * 60 * 1000;
                var Loginpage = webclient.DownloadString("http://pslimsapp.visa.com/slims/login");
                var Logindata = new NameValueCollection
                {
                    { "username", App.SliMSID},
                    { "password", App.SliMSPWD },
                    {"_csrf",Loginpage.Substring(Loginpage.IndexOf("_csrf")+ 14, 36)}
                };
                try
                {
                    //Login
                    var loginresp = webclient.UploadValues("http://pslimsapp.visa.com/slims/login", Logindata);
                    if (Encoding.ASCII.GetString(loginresp).Contains("Invalid username or password."))
                    {
                        throw new System.Security.Authentication.AuthenticationException("Invalid username or password.");
                    }
                    //Get The XL script
                    CommonClass.ChangeStatus("Downloading SLiMS Script file from Web App...", 0, 1, true);
                    if (System.IO.File.Exists(App.TempFolder + "sv_Script.xls"))
                        System.IO.File.Delete(App.TempFolder + "sv_Script.xls");

                    webclient.DownloadFile(@"http://pslimsapp.visa.com/slims/report?type=qa-install&format=xls&dates=" + start.ToString("yyyy-MM-dd") + "&dates=" + end.ToString("yyyy-MM-dd"), App.TempFolder + "sv_Script.xls");
                    
                    //Get Intersect
                    if (isIntersectRequired)
                    {
                        CommonClass.ChangeStatus("Downloading Intersect file from Web App...", 50, 1, true);
                        if (System.IO.File.Exists(App.TempFolder + "sv_intersect.xls"))
                            System.IO.File.Delete(App.TempFolder + "sv_intersect.xls");
                        webclient.DownloadFile(@"http://pslimsapp.visa.com/slims/report?type=intersect&format=xls&dates=" + start.ToString("yyyy-MM-dd") + "&dates=" + end.ToString("yyyy-MM-dd"), App.TempFolder + "sv_intersect.xls");
                    }
                    CommonClass.ChangeStatus("Ready.", 0, 0, false);
                }
                catch (Exception ex)
                {
                    CommonClass.ChangeStatus("Error." + ex.Message, 0, 0, false);
                    return ex.Message;
                }
            }
            return null;
        }



    }

    class WEEntry : IEquatable<WEEntry>
    {
        public string WENumber { get; set; }
        public DateTime LoadDate { get; set; }
        public int Group { get; set; }
        public string Status { get; set; }
        public string LoadState { get; set; }
        public string Type { get; set; }
        public string Vtape { get; set; }
        public string FuncCommands { get; set; }
        public string FallbackCommands { get; set; }
        public DateTime LastUpdatedOn { get; set; }

        public bool Equals(WEEntry other)
        {
            if (other == null)
                return false;
            if (this.WENumber == other.WENumber && this.LoadDate == other.LoadDate &&// this.Status == other.Status &&//this.Group == other.Group &&//this.Status == other.Status && this.LoadState == other.LoadState &&
                this.Type == other.Type && this.Vtape == other.Vtape)//&& this.FuncCommands == other.FuncCommands
            {
                if (this.Status == "Fallback" || this.Status == "Canceled" || other.Status == "Fallback" || other.Status == "Canceled")
                {
                    if (this.Status == other.Status)
                    {
                        return true;
                    }
                    return false;
                }
                return true;
            }
            else
                return false;
        }

        //public string DifferenceAt(WEEntry other)
        //{
        //    string diffat = "";
        //    if (this.LoadDate != other.LoadDate)
        //        diffat += "LoadDate,";
        //    if (this.Vtape != other.Vtape)
        //        diffat += "Vtape,";
        //    if (this.FuncCommands != other.FuncCommands)
        //        diffat += "FuncCommands,";
        //    if (this.LoadState != other.LoadState)
        //        diffat += "LoadState,";
        //    if (this.Group != other.Group)
        //        diffat += "Group,";
        //    if (this.Status != other.Status)
        //        diffat += "Status,";
        //    if (this.Type != other.Type)
        //        diffat += "Type,";
        //    return diffat.TrimEnd(',');
        //}
    }
    class InstallDetail
    {
        public DateTime InstallDate { get; set; }
        public string SystemName { get; set; }
        public string DDRedFrom { get; set; }
        public DateTime UpdatedOn { get; set; }
        public List<WEEntry> LoadedWEs { get; set; }
        public string DCS { get; set; }
        public string BMX { get; set; }
        public string NWK { get; set; }
        public string CFG { get; set; }
        public string FXT { get; set; }
        public string GlobalVersion { get; set; }

    }
    public class GlobalsWithLD : Global
    {
        public DateTime LoadDate { get; set; }
    }
}
