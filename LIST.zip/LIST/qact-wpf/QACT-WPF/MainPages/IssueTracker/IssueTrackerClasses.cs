﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QACT_WPF
{
    public class Observation:INotifyPropertyChanged
    {
        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        //Issue identification fields
        long _ObsId;
        public long ObsId { get { return _ObsId; } set { _ObsId = value; NotifyPropertyChanged("ObsId"); } }
        string _RTN;
        public string RTN { get { return _RTN; } set { _RTN = value; NotifyPropertyChanged("RTN"); } }
        DateTime? _InstallDate = null;
        public DateTime? InstallDate { get { return _InstallDate; } set { _InstallDate = value; NotifyPropertyChanged("InstallDate"); } }
        string _WE;
        public string WE { get { return _WE; } set { _WE = value; NotifyPropertyChanged("WE"); } }
        int _ObsNo;
        public int ObsNo { get { return _ObsNo; } set { _ObsNo = value; NotifyPropertyChanged("ObsNo"); } }
        string _IssueType;
        public string IssueType { get { return _IssueType; } set { _IssueType = value; NotifyPropertyChanged("IssueType"); } } //Functional/regression
        string _RunDetails;
        public string RunDetails { get { return _RunDetails; } set { _RunDetails = value; NotifyPropertyChanged("RunDetails"); } } //PRODD RUN1
        string _Summary;
        public string Summary { get { return _Summary; } set { _Summary = value; NotifyPropertyChanged("Summary"); } }
        string _Description;
        public string Description { get { return _Description; } set { _Description = value; NotifyPropertyChanged("Description"); } } // Each line will have each field
        string _Tags;
        public string Tags { get { return _Tags; } set { _Tags = value; NotifyPropertyChanged("Tags"); } }
        string _ReportedBy;
        public string ReportedBy { get { return _ReportedBy; } set { _ReportedBy = value; NotifyPropertyChanged("ReportedBy"); } }
        DateTime? _SubmitDate = null;
        public DateTime? SubmitDate { 
            get 
            {
                if (_SubmitDate != null)
                    return DateTime.SpecifyKind((DateTime)_SubmitDate, DateTimeKind.Utc);
                else
                    return null;
            } 
            set { _SubmitDate = value; NotifyPropertyChanged("SubmitDate"); } }
        string _Devs;
        public string Devs { get { return _Devs; } set { _Devs = value; NotifyPropertyChanged("Devs"); } }
        string _Attachment;
        public string Attachment { get { return _Attachment; } set { _Attachment = value; NotifyPropertyChanged("Attachment"); } } //Link to attachment
        //After Response
        DateTime? _RespDate = null;
        public DateTime? RespDate { get {
            if (_RespDate != null)
                return DateTime.SpecifyKind((DateTime)_RespDate, DateTimeKind.Utc);
            else
                return null;
        } set { _RespDate = value; NotifyPropertyChanged("RespDate"); } }
        string _RespFrom;
        public string RespFrom { get { return _RespFrom; } set { _RespFrom = value; NotifyPropertyChanged("RespFrom"); } }
        string _Status;
        public string Status { get { return _Status; } set { _Status = value; NotifyPropertyChanged("Status"); } }
        string _DRNumber;
        public string DRNumber { get { return _DRNumber; } set { _DRNumber = value; NotifyPropertyChanged("DRNumber"); } }
        string _Resolution;
        public string Resolution { get { return _Resolution; } set { _Resolution = value; NotifyPropertyChanged("Resolution"); } }//Fix required/Acceptable etc
        string _DevComments;
        public string DevComments { get { return _DevComments; } set { _DevComments = value; NotifyPropertyChanged("DevComments"); } }
        string _Custom1;
        public string Custom1 { get { return _Custom1; } set { _Custom1 = value; NotifyPropertyChanged("Custom1"); } }
        string _Custom2;
        public string Custom2 { get { return _Custom2; } set { _Custom2 = value; NotifyPropertyChanged("Custom2"); } }
        string _Custom3;
        public string Custom3 { get { return _Custom3; } set { _Custom3 = value; NotifyPropertyChanged("Custom3"); } }
        string _Custom4;
        public string Custom4 { get { return _Custom4; } set { _Custom4 = value; NotifyPropertyChanged("Custom4"); } }
        string _Custom5;
        public string Custom5 { get { return _Custom5; } set { _Custom5 = value; NotifyPropertyChanged("Custom5"); } }
    }
    public class ExtObservation:Observation,INotifyPropertyChanged
    {
        //Implement InotifyPropertyChanged
        //public event PropertyChangedEventHandler PropertyChanged;
        //protected void NotifyPropertyChanged(string property)
        //{
        //    if (PropertyChanged != null)
        //    {
        //        PropertyChanged(this, new PropertyChangedEventArgs(property));
        //    }
        //}
        DateTime? _InstallDateEnd = null;
        public DateTime? InstallDateEnd { get {
            if (_InstallDateEnd != null)
                return DateTime.SpecifyKind((DateTime)_InstallDateEnd, DateTimeKind.Utc);
            else
                return null;
        } set { _InstallDateEnd = value; NotifyPropertyChanged("InstallDateEnd"); } }
        DateTime? _SubmitDateEnd = null;
        public DateTime? SubmitDateEnd { get {
            if (_SubmitDateEnd != null)
                return DateTime.SpecifyKind((DateTime)_SubmitDateEnd, DateTimeKind.Utc);
            else
                return null;
        } set { _SubmitDateEnd = value; NotifyPropertyChanged("SubmitDateEnd"); } }
    }
}
