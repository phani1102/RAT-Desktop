﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Web.Script.Serialization;
using System.IO;
using Outlook=Microsoft.Office.Interop.Outlook;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for IssueTracker.xaml
    /// </summary>
    public partial class IssueTracker : Page,INotifyPropertyChanged
    {
        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        static List<string> Statuses = new List<string>() { "Open", "Closed" };
        static List<string> Resolutions = new List<string>() { "", "Expected", "Acceptable", "Already Replied", "Fix Required", "Invalid Testing", "Test System Issue" };
        #region Members
        ExtObservation _AdvancedSearchParam = new ExtObservation();
        public ExtObservation AdvancedSearchParam { get { return _AdvancedSearchParam; } set { _AdvancedSearchParam = value; NotifyPropertyChanged("AdvancedSearchParam"); } }
        ObservableCollection<Observation> _ObservationsOnList = new ObservableCollection<Observation>();
        public ObservableCollection<Observation> ObservationsOnList { get { return _ObservationsOnList; } set { _ObservationsOnList = value; NotifyPropertyChanged("ObservationsOnList"); } }
        string _SearchStatus;
        public string SearchStatus { get { return _SearchStatus; } set { _SearchStatus = value; NotifyPropertyChanged("SearchStatus"); } }
        string _TxtBasicSearch;
        public string TxtBasicSearch { get { return _TxtBasicSearch; } set { _TxtBasicSearch = value; NotifyPropertyChanged("TxtBasicSearch"); } }
        string Basicsearchcriteria = "/we/";
        BackgroundWorker resultfetchbw = new BackgroundWorker();
        JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();
        #endregion
        public IssueTracker()
        {
            InitializeComponent();
            comboResolution.ItemsSource = Resolutions;
            combostatus.ItemsSource = Statuses;
            resultfetchbw.DoWork += resultfetchbw_DoWork;
            resultfetchbw.RunWorkerCompleted += resultfetchbw_RunWorkerCompleted;
            GetObservations(App.IssueTrackerAPIPath + "latest/20");
            
        }

        void resultfetchbw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            ObservationsOnList =(ObservableCollection<Observation>) e.Result;
            SearchStatus = "Showing "+ObservationsOnList.Count+" observations";
            CommonClass.ChangeStatus("Ready", 0, 0, false);
            if (ObservationsOnList.Count == 0)
                MessageBox.Show("Nothing found using the search criteria.");
        }

        void resultfetchbw_DoWork(object sender, DoWorkEventArgs e)
        {
            UriValue urivalue = (UriValue)e.Argument;
            ObservableCollection<Observation> Observations = new ObservableCollection<Observation>();
            try
            {
                CommonClass.ChangeStatus("Searching for records...", 0, 1, true);
                HttpWebRequest request = WebRequest.Create(urivalue.uri) as HttpWebRequest;
                request.UseDefaultCredentials = true;
                if (urivalue.jsontopost!= null)
                {
                    request.Method = "POST";
                    request.ContentType = "application/json";
                    using (Stream reqstream = request.GetRequestStream())
                    {
                        var byteArray = Encoding.UTF8.GetBytes(urivalue.jsontopost);
                        reqstream.Write(byteArray, 0, byteArray.Length);
                    }
                }
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {

                        using (var sr = new StreamReader(response.GetResponseStream()))
                        {
                            string jsonstring = sr.ReadToEnd();
                            Observations = (ObservableCollection<Observation>)jsonSerializer.Deserialize(jsonstring, ObservationsOnList.GetType());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
            }
            e.Result = Observations;
        }

        private void expAdvSrch_Expanded(object sender, RoutedEventArgs e)
        {
            stackBasicSrch.Visibility = Visibility.Collapsed;
        }

        private void expAdvSrch_Collapsed(object sender, RoutedEventArgs e)
        {
            stackBasicSrch.Visibility = Visibility.Visible;
        }

        private void lstResult_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var item = ((FrameworkElement)e.OriginalSource).DataContext as Observation;
            if (item != null)
            {
                new DetailedObservation() { DataContext = item }.ShowDialog();
            }
            
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            TxtBasicSearch = null;
            //Reset Search parameters here
            AdvancedSearchParam = new ExtObservation();
            GetObservations(App.IssueTrackerAPIPath + "latest/20");
            //SearchStatus = "Showing latest 20 observations.";
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (((RadioButton)sender).Content == null)
                return;
            switch (((RadioButton)sender).Content.ToString())
            {
                case "Work effort":
                    Basicsearchcriteria = "/we/";
                    break;
                case "RTN":
                    Basicsearchcriteria = "/rtn/";
                    break;
                case "Load Date(mm/dd/yy)":
                    Basicsearchcriteria = "/loaddate/";
                    break;
                case "Status":
                    Basicsearchcriteria = "/status/";
                    break;
                case "Tester":
                    Basicsearchcriteria = "/reporter/";
                    break;
                default:
                    break;
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (resultfetchbw.IsBusy)
                return;
            if (!expAdvSrch.IsExpanded)
            {
                if (TxtBasicSearch == "" || TxtBasicSearch == null)
                {
                    GetObservations(App.IssueTrackerAPIPath + "latest/20");
                    return;
                }
                GetObservations(App.IssueTrackerAPIPath + "search" + Basicsearchcriteria + TxtBasicSearch);
              //  SearchStatus = "Showing search results...";
            }
            else
            {
                //if (AdvancedSearchParam.InstallDate != null)
                //    AdvancedSearchParam.InstallDate = AdvancedSearchParam.InstallDate.Value.ToUniversalTime();
                //if (AdvancedSearchParam.InstallDateEnd != null)
                //    AdvancedSearchParam.InstallDateEnd = AdvancedSearchParam.InstallDateEnd.Value.ToUniversalTime();
                //if (AdvancedSearchParam.SubmitDate != null)
                //    AdvancedSearchParam.SubmitDate = AdvancedSearchParam.SubmitDate.Value.ToUniversalTime();
                //if (AdvancedSearchParam.SubmitDateEnd != null)
                //    AdvancedSearchParam.SubmitDateEnd = AdvancedSearchParam.SubmitDateEnd.Value.ToUniversalTime();
                GetObservations(App.IssueTrackerAPIPath + "search/advanced", jsonSerializer.Serialize(AdvancedSearchParam).ToString());
                //SearchStatus = "Showing search results...";
            }
        }

        public void GetObservations(string uri,string jsontopost=null)
        {
            resultfetchbw.RunWorkerAsync(new UriValue(){uri=uri, jsontopost=jsontopost});
        }

        private void FCIssue_Click(object sender, RoutedEventArgs e)
        {
            if (((MenuItem)sender).DataContext == null)
                return;
            HttpWebRequest request = WebRequest.Create(App.IssueTrackerAPIPath + "forceclose/" +((Observation)((MenuItem)sender).DataContext).ObsId) as HttpWebRequest;
            request.UseDefaultCredentials = true;
            using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    MessageBox.Show("Selected observation is closed successsfully.");
                    ((Observation)((MenuItem)sender).DataContext).Status = "Closed";
                    ((Observation)((MenuItem)sender).DataContext).Custom2 = Environment.UserName;
                }
            }
        }

        private void CancelIssue_Click(object sender, RoutedEventArgs e)
        {
            if (((MenuItem)sender).DataContext == null)
                return;
            if (MessageBox.Show("Are you sure to delete the item from server?", "Confirm Delete", MessageBoxButton.YesNo) == MessageBoxResult.No)
                return;
            HttpWebRequest request = WebRequest.Create(App.IssueTrackerAPIPath + ((Observation)((MenuItem)sender).DataContext).ObsId) as HttpWebRequest;
            request.UseDefaultCredentials = true;
            request.Method = "DELETE";
            using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    MessageBox.Show("Selected observation is deleted successsfully.");
                    ObservationsOnList.Remove((Observation)((MenuItem)sender).DataContext);
                }
            }
            //Use the ForceClose method Here
        }

        private void FollowupIssue_Click(object sender, RoutedEventArgs e)
        {
            //Use the followup Here
            if (((MenuItem)sender).DataContext == null)
                return;
            Observation obs = ((Observation)((MenuItem)sender).DataContext);
            if (obs.Resolution != null && obs.Resolution!="")
            if(MessageBox.Show("Looks like someone has replied to this observation.\nDo you want to follow up again?","Confirm follow up",MessageBoxButton.YesNo)==MessageBoxResult.No)
                return;
            //Prepare the followup email here:
            string Subject = "Follow Up:: " + obs.WE + " : Load Date-" + obs.InstallDate.Value.ToString("MM/dd") +" " + obs.IssueType + (obs.IssueType == "Regression" ? "-" + obs.RunDetails : " Obs#"+obs.ObsNo);
            string htmlbody = "<html>Hi,<br>Please let us know your comments on the following observation.<br><br><b>" 
                + obs.Summary + "</b><br>" + obs.Description.Replace("\r\n", "<br>").Replace("\n", "<br>") 
                + "<br><br>Please respond on the following link:<br><a href=\"" + App.IssueTrackerViewPath + obs.ObsId + "\">Response</a><br><br>Thanks<br>This is a QACT generated email.</html>";
            Outlook.Application oApp = null; Outlook.MailItem oMsg = null; Outlook.Recipients oRecips = null; Outlook.Recipient oRecip = null;
            try
            {
                oApp = new Outlook.Application();
                oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                oMsg.HTMLBody = htmlbody;
                oMsg.Subject = Subject;
                oRecips = (Outlook.Recipients)oMsg.Recipients;
                if (obs.Devs != null)
                {
                    foreach (var dev in obs.Devs.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Distinct())
                    {
                        //For debug add my name
                        oRecip = (Outlook.Recipient)oRecips.Add(dev);
                        oRecip.Resolve();
                    }
                    oRecip = (Outlook.Recipient)oRecips.Add("QASSEPJL");//Add("QASSEPJL");
                    oRecip.Type = 2;//CC
                    oRecip.Resolve();
                }
                else
                {
                    Subject = "No developer found: " + Subject;
                    oRecip = (Outlook.Recipient)oRecips.Add("QASSEPJL");//Add("QASSEPJL");
                    oRecip.Type = 1;//CC
                    oRecip.Resolve();
                }
                ((Outlook._MailItem)oMsg).Send();
                MessageBox.Show("Follow up email sent.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not send follow up email.\nError:" + ex.Message);
            }
            finally
            {
                oRecips = null;
                oMsg = null;
                oApp = null;
            }

        }


        private void btnexport_Click(object sender, RoutedEventArgs e)
        {
            if (ObservationsOnList.Count == 0)
                return;
            string htmltablestring =
@"<style>
table {
    border-collapse: collapse;font-family: ""Courier New"";
}

table, td, th {
    border: 1px solid black;
}
</style>
<table>
<tr><th>Obs No</th><th>WE</th><th>RTN</th><th>Install Date</th><th>Status</th><th>Resolution</th><th>Issue Type</th><th>Summary</th><th>Details</th><th>DR#</th><th>View Link</th></tr>";
            foreach (Observation obs in ObservationsOnList)
            {
                htmltablestring += "<tr><td>" + obs.ObsNo + "</td><td>" + obs.WE + "</td><td>" + 
                    obs.RTN + "</td><td>" + obs.InstallDate.Value.ToString("MM/dd/yyyyy") + "</td><td>" + 
                    obs.Status + "</td><td>" + obs.Resolution + "</td><td>" + obs.IssueType + "</td><td width=\"500\">" + 
                    obs.Summary + "</td><td width=\"700\">" + obs.Description.Replace("\r\n", "<br style=\"mso-data-placement:same-cell;\">") + "</td><td>" + 
                    obs.DRNumber + "</td><td><a href=\"" + App.IssueTrackerViewPath + obs.ObsId + "\">View</a></td></tr>\n";
            }
            htmltablestring+="</table>";
            System.IO.File.WriteAllText(App.TempFolder + "Issue Report.xls", htmltablestring);
            System.Diagnostics.Process.Start(App.TempFolder + "Issue Report.xls");
        }
    }
    class UriValue
    {
        public string uri { get; set; }
        public string jsontopost { get; set; }
    }
}
