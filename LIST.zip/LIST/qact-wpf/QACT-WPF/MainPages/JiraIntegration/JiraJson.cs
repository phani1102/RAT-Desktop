﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
//using System.Web;
//using System.Web.Script.Serialization;
using System.IO;
using System.Text.RegularExpressions;
using System.Runtime.CompilerServices;


namespace QACT_WPF.MainPages.JiraIntegration
{
    class JiraJson
    {
        //mostly for reference, can be used to make code more readable by using the values then replacing them with their keys
        private static Dictionary<string, string> JsonDictionary = new Dictionary<string, string>()
        {
            { "customfield_17894", "we" },
            { "customfield_17893", "loadDate" },
            { "customfield_17797", "weType" },
            { "customfield_17800", "loadState" },
            { "customfield_17801", "loadType" },
            { "customfield_17881", "rtn" },
            { "customfield_17802", "vtape" },
            { "customfield_17803", "debugVtape" },
            { "customfield_17983", "developers" },
            { "customfield_19981", "manager" },
            { "customfield_14347", "costCenter" },
            { "customfield_15921", "reviewer" },
            { "customfield_16835", "typeOfTesting" },
            { "customfield_15911", "severity" },
            { "customfield_16415", "projectStage" },
            { "customfield_16626", "testToolUsedtoDiscover" },
            { "summary", "summary" },
            { "description", "description" },
            { "key", "key" },
            { "status", "status" },
            { "assignee", "assignee" },
            { "epiclink", "epicLink" },
        };
        //all the different types of regression
        private static string[] RegTypes = { "PRODD", "STIPD", "BADD", "SOAP", "DRB", "TOKEN", "PCAS", "BADD+PCAS", "UNBALANCED", "LOAD_NIGHT" };
        //URLS
        private static string searchUrl = @"https://issues/rest/api/latest/search?";
        private static string openUrl = @"https://issues/rest/api/latest/issue";
        private static string linkUrl = @"https://issues/rest/api/latest/issueLink";
        //login credentials
        private static string user = "svcvipqa";
        private static string pass = "3#Zt'!eSND";
        //private static string user = "bmolynea";
        //private static string pass = "********";
        private static string mergedCredentials = string.Format("{0}:{1}", user, pass);
        private static byte[] byteCredentials = Encoding.UTF8.GetBytes(mergedCredentials);
        private static string encodedCredentials = Convert.ToBase64String(byteCredentials);

        private static string regType = "NONE";

        public static string key = "";
        public static string status = "";
        public static string descr = "";
        //
        //BMOLYNEA
        public static string RegSubject = "Regression Issue";
        //

        private static bool duplicate = false;

        private static string logFilePath = "";


        public static int mmType = 0; //0 = we, 1 = switch, 2 = global
        //

        //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
        //                             | SecurityProtocolType.Tls11
        //                             | SecurityProtocolType.Tls12;



        private static string project = "VIPENG";
        //private static string project = "VIPQA";

        public static void JsonRegCheck(string[] checkFields)
        {
            JiraJson.WriteLog("Entered JsonRegCheck\n");//BMOLYNEAXXXXXX

            string[] fields = { "description", "key", "status" };

            descr = checkFields[3];

            JiraJson.WriteLog(string.Format("Description: {0}\n", descr));//BMOLYNEAXXXXXX
            JiraJson.WriteLog(string.Format("Is This Testing: {0}\n", checkFields[4]));//BMOLYNEAXXXXXX

            try
            {
                //GGIRDHAR030717 - Test Framework Enhancement
                if (checkFields[4] != null && checkFields[4] == "Y")
                {
                    JiraJson.WriteLog("Entered Checkfields[4] check\n");//BMOLYNEAXXXXXX
                    project = "VIPQA";
                }
                //GGIRDHAR030717 - Test Framework Enhancement
            }
            catch
            {
                JiraJson.WriteLog("Check Fields issue when looking for index 4\n");//BMOLYNEAXXXXXX
            }

            WriteLog(string.Format("Project: {0}\n", project)); //BMOLYNEAXXXXXX

            JsonMessage jsonBuilder = new JsonMessage();
            //
            //BMOLYNEA - 12/15/2016
            //check if it's a WE, Switch, or Global
            //checkFields[0] = we
            //
            //int mmType = 0; //0 = we, 1 = switch, 2 = global
            char[] charArray = checkFields[0].ToUpper().ToCharArray();

            if (charArray[0] == 'W' && charArray[1] == 'E')
            {
                mmType = 0;
            }
            else if (charArray[0] == 'S' && charArray[1] == 'W')
            {
                mmType = 1;
            }
            else
            {
                mmType = 2;
            }
            //
            WriteLog(string.Format("Mismatch Type: {0}\n",mmType)); //BMOLYNEAXXXXXX
            //
            if (mmType == 0)
            {
                jsonBuilder.jql = String.Format("project = {0} AND issuetype = Observation AND cf[17894] = {1} AND cf[17881] = {2} AND cf[17893] = \"{3}\"", project, checkFields[0], checkFields[1], checkFields[2]);
            }
            else if (mmType == 1)
            {
                jsonBuilder.jql = String.Format("project = {0} AND issuetype = Observation AND cf[20489] = {1} AND cf[17881] = {2} AND cf[17893] = \"{3}\"", project, checkFields[0], checkFields[1], checkFields[2]);
            }
            else if (mmType == 2)
            {
                jsonBuilder.jql = String.Format("project = {0} AND issuetype = Observation AND cf[20488] = {1} AND cf[17881] = {2} AND cf[17893] = \"{3}\"", project, checkFields[0].Split(':').First(), checkFields[1], checkFields[2]);
            }

            WriteLog(string.Format("Duplicatge Check JQL: {0}\n", jsonBuilder.jql)); //BMOLYNEAXXXXXX

            jsonBuilder.startAt = 0;
            jsonBuilder.maxResults = 100;
            jsonBuilder.fields = fields;

            string Json = Newtonsoft.Json.JsonConvert.SerializeObject(jsonBuilder);
            //
            //BMOLYNEA - 12/19/2016
            //File.AppendAllText(logFilePath, "***JSON Message: \n" + Json + "\n");

            string jsonNullRemove = Newtonsoft.Json.JsonConvert.SerializeObject(jsonBuilder, Newtonsoft.Json.Formatting.Indented, new Newtonsoft.Json.JsonSerializerSettings { NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore });
            WriteLog(string.Format("Duplicatge Check JSON: {0}\n", jsonNullRemove)); //BMOLYNEAXXXXXX
            //jsonNullRemove = "{\r\n  \"jql\": \"project = VIPQA AND issuetype = Observation AND cf[17894] = WE015787 AND cf[17881] = 807648 AND cf[17893] = \"12/4/2016\"\",\r\n  \"startAt\": 0,\r\n  \"maxResults\": 100,\r\n  \"fields\": [\r\n    \"description\",\r\n    \"key\",\r\n    \"status\"\r\n  ]\r\n}";
            byte[] requestByte = Encoding.UTF8.GetBytes(jsonNullRemove);

            //if (File.Exists(@"C:\Users\bmolynea\Desktop\RegressionTests\files\json.txt"))
            //{
            //    File.Delete(@"C:\Users\bmolynea\Desktop\RegressionTests\files\json.txt");
            //}

            //File.WriteAllText(@"C:\Users\bmolynea\Desktop\RegressionTests\files\json.txt", jsonNullRemove);

            using (QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx webClient = new QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx())
            {
                webClient.Headers.Set("Authorization", "Basic " + encodedCredentials);
                webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
                var request = webClient.UploadData(searchUrl, requestByte);
                try
                {
                    string strResponse = webClient.Encoding.GetString(request);

                    Newtonsoft.Json.Linq.JObject o = Newtonsoft.Json.Linq.JObject.Parse(strResponse);

                    RetrieveObsFields(strResponse, checkFields[3]);

                    WriteLog(string.Format("Duplicate: {0}\n", duplicate)); //BMOLYNEAXXXXXX

                    if (duplicate != true)
                    {
                        //
                        //BMOLYNEA - 12/19/2016
                        //File.AppendAllText(logFilePath, "***Not Considered Duplicate:\n");
                        //
                        //Get WE info
                        string[] weinfo = WEInfo(checkFields[0], checkFields[2]);
                        //
                        //BMOLYNEA - 12/14/2016
                        if (weinfo.Length == 0 || weinfo == null)
                        {
                            weinfo = new string[] { "", "", ",", "", "", "" };
                            //weinfo = new string[] { checkFields[0], checkFields[1], ",", checkFields[2], "", "" }; //we, rtn, watchers, load date, summary, key
                        }
                        //
                        string[] watchers = weinfo[2].Split(',');
                        string weKey = weinfo[5];
                        status = "Opened";
                        //open ticket
                        RegOpenTicket(weinfo, checkFields);
                        //get key & status
                        string obsKey = key;
                        //add watchers
                        AddWatchers(watchers, obsKey);
                        //link
                        LinkIssues(obsKey, weKey);

                        duplicate = false;
                    }
                    else
                    {
                        WriteLog(string.Format("Duplicate Key: {0}\nDuplicate Status: {1}", key, status)); //BMOLYNEAXXXXXX
                        //get key & status
                        duplicate = false;
                    }
                }
                catch (Exception e)
                {
                    WriteLog(string.Format("Duplicate Check Exception: {0}\n", e)); //BMOLYNEAXXXXXX
                }
            }
        }

        private static void RetrieveObsFields(string strResponse, string description)
        {
            //
            Newtonsoft.Json.Linq.JObject srchJson = Newtonsoft.Json.Linq.JObject.Parse(strResponse);

            List<string> information = new List<string>();

            int results = (int)srchJson["total"];
            //Console.WriteLine("Results: {0}\n", results.ToString());

            //removes everything after test case and replaces all the new lines with spaces
            string[] descrArray = Regex.Split(description, "Test_Case");
            string newOriginalDescr = descrArray[0];
            newOriginalDescr = Regex.Replace(newOriginalDescr, @"\r\n?|\n", " ");

            WriteLog(string.Format("newOriginalDescr: {0}\n", newOriginalDescr)); //BMOLYNEAXXXXXX

            for (int i = 0; i < results; i++)
            {
                WriteLog(string.Format("Duplicate Check Loop #{0}\n", i)); //BMOLYNEAXXXXXX

                string issueDescription = "";
                string issueKey = "";
                string issueStatus = "";

                try
                {
                    //Issue Key
                    try
                    {
                        issueKey = (string)srchJson["issues"][i]["key"];
                        key = issueKey;
                        WriteLog(string.Format("key: {0}\n", issueKey)); //BMOLYNEAXXXXXX
                    }
                    catch { }
                    //
                    //Issue Type
                    try
                    {
                        string issueType = (string)srchJson["issues"][i]["fields"]["issuetype"]["name"];
                        WriteLog(string.Format("issue type: {0}\n", issueType)); //BMOLYNEAXXXXXX
                    }
                    catch { }
                    //
                    //Issue Status
                    try
                    {
                        issueStatus = (string)srchJson["issues"][i]["fields"]["status"]["name"];
                        status = issueStatus;
                        WriteLog(string.Format("status: {0}\n", issueStatus)); //BMOLYNEAXXXXXX
                    }
                    catch { }
                    //
                    //Issue WE
                    try
                    {
                        Newtonsoft.Json.Linq.JArray issueWE = (Newtonsoft.Json.Linq.JArray)srchJson["issues"][i]["fields"]["customfield_17894"];
                        WriteLog(string.Format("we: {0}\n", issueWE)); //BMOLYNEAXXXXXX
                    }
                    catch { }
                    //
                    //Issue Load Date
                    try
                    {
                        Newtonsoft.Json.Linq.JArray issueLoadDate = (Newtonsoft.Json.Linq.JArray)srchJson["issues"][i]["fields"]["customfield_17893"];
                        WriteLog(string.Format("load date: {0}\n", issueLoadDate)); //BMOLYNEAXXXXXX
                    }
                    catch { }
                    //
                    //Issue RTN No.
                    try
                    {
                        Newtonsoft.Json.Linq.JArray issueRTN = (Newtonsoft.Json.Linq.JArray)srchJson["issues"][i]["fields"]["customfield_17881"];
                        WriteLog(string.Format("rtn: {0}\n", issueRTN)); //BMOLYNEAXXXXXX
                    }
                    catch { }
                    //
                    //Description
                    try
                    {
                        issueDescription = (string)srchJson["issues"][i]["fields"]["description"];
                        WriteLog(string.Format("desciption: {0}\n", issueDescription)); //BMOLYNEAXXXXXX
                    }
                    catch { }

                    //
                    //check values
                    //removes everything after test case and replaces the new lines with spaces
                    string[] checkDescrArray = Regex.Split(issueDescription, "Test_Case");
                    string newCheckDescr = checkDescrArray[0];
                    newCheckDescr = Regex.Replace(newCheckDescr, @"\r\n?|\n", " ");
                    WriteLog(string.Format("Check Desciption: {0}\n", newCheckDescr)); //BMOLYNEAXXXXXX
                    //
                    //
                    WriteLog(string.Format("Duplicate: {0}\n", duplicate)); //BMOLYNEAXXXXXX
                    //
                    //returns true if both descriptions are the same, meaning it's a duplicate
                    duplicate = String.Equals(newOriginalDescr, newCheckDescr);
                    if (duplicate == true)
                    {
                        break;
                    }
                }
                catch { }

            }
        }

        private static void RegOpenTicket(string[] weInfo, string[] obsInfo)
        {
            //Required Fields:
            //Summary
            //Description
            //RTN No.
            //WE
            //Watcher Field
            //Cost Center
            //Type of Testing
            //Severity
            //Test Tool Used to Discover
            //Linked Issues
            //Issue

            //JsonMessage jsonBuilder = new JsonMessage();

            string issuelink = key + " - " + weInfo[4]; //Key + " - " WESummary
            WriteLog(string.Format("issue link: {0}\n", issuelink)); //BMOLYNEAXXXXXX

            //if we and rtn are blank, put the observation info there
            if (weInfo[0] == "")
            {
                //WE
                weInfo[0] = obsInfo[0];
            }
            if (weInfo[1] == "")
            {
                //RTN
                weInfo[1] = obsInfo[1];
                if (weInfo[1] == "")
                {
                    weInfo[1] = "NONE";
                }
            }
            if (weInfo[2] == "")
            {
                //Developers
                weInfo[2] = "NONE";
            }
            if (weInfo[3] == "")
            {
                //Load Date
                weInfo[3] = obsInfo[2];
            }

            string weField = "";
            string swField = "";
            string gblField = "";
            //
            //BMOLYNEA - 12/23/2016
            string gblassign = "";
            //

            //BMOLYNEA - 12/14/2016
            //Check if WE, Switch, or Global mismatch
            char[] charArray = weInfo[0].ToUpper().ToCharArray();

            if (charArray[0] == 'W' && charArray[1] == 'E')
            {
                weField = weInfo[0];
                swField = "";
                gblField = "";
            }
            else if (charArray[0] == 'S' && charArray[1] == 'W')
            {
                weField = "NONE";
                swField = weInfo[0];
                gblField = "";
            }
            else
            {
                weField = "NONE";
                swField = "";
                gblField = weInfo[0].Split(':').First();
                //
                //BMOLYNEA - 12/23/2016
                if (project == "VIPQA")
                {
                    gblassign = "bmolynea";
                }
                else
                {
                    gblassign = "jmanto";
                }
                //
            }
            //

            WriteLog(string.Format("WE: {0}\nSwitch: {1}\nGlobal: {2}\n", weField, swField, gblField)); //BMOLYNEAXXXXXX

            //find the regression type
            try
            {
                RegressionRunType();
            }
            catch { }
            //

            Newtonsoft.Json.Linq.JObject rss =
                new Newtonsoft.Json.Linq.JObject(
                    new Newtonsoft.Json.Linq.JProperty("fields",
                        new Newtonsoft.Json.Linq.JObject(
                            new Newtonsoft.Json.Linq.JProperty("project", new Newtonsoft.Json.Linq.JObject(new Newtonsoft.Json.Linq.JProperty("key", project))),
                            new Newtonsoft.Json.Linq.JProperty("issuetype", new Newtonsoft.Json.Linq.JObject(new Newtonsoft.Json.Linq.JProperty("name", "Observation"))),
                            //new Newtonsoft.Json.Linq.JProperty("summary", weInfo[0] + " - " + "Regression Issue"),
                            new Newtonsoft.Json.Linq.JProperty("summary", weInfo[0] + " - " + RegSubject),
                            new Newtonsoft.Json.Linq.JProperty("description", descr),
                            //
                            //BMOLYNEA - 12/23/2016
                            new Newtonsoft.Json.Linq.JProperty("assignee", new Newtonsoft.Json.Linq.JObject(new Newtonsoft.Json.Linq.JProperty("name", gblassign))),
                            //
                            new Newtonsoft.Json.Linq.JProperty("customfield_17881", new Newtonsoft.Json.Linq.JArray(weInfo[1])),
                            new Newtonsoft.Json.Linq.JProperty("customfield_17894", new Newtonsoft.Json.Linq.JArray(weField)),
                            new Newtonsoft.Json.Linq.JProperty("customfield_20489", new Newtonsoft.Json.Linq.JArray(swField)),
                            new Newtonsoft.Json.Linq.JProperty("customfield_20488", new Newtonsoft.Json.Linq.JArray(gblField)),
                            new Newtonsoft.Json.Linq.JProperty("customfield_14347", "85300"),
                            new Newtonsoft.Json.Linq.JProperty("customfield_17893", new Newtonsoft.Json.Linq.JArray(weInfo[3])),
                            new Newtonsoft.Json.Linq.JProperty("customfield_16835", new Newtonsoft.Json.Linq.JObject(new Newtonsoft.Json.Linq.JProperty("value", "Regression"))),
                            new Newtonsoft.Json.Linq.JProperty("customfield_15911", new Newtonsoft.Json.Linq.JObject(new Newtonsoft.Json.Linq.JProperty("value", "Minimal"))),
                            new Newtonsoft.Json.Linq.JProperty("customfield_16626", new Newtonsoft.Json.Linq.JObject(new Newtonsoft.Json.Linq.JProperty("value", "PARSEM"))),
                            new Newtonsoft.Json.Linq.JProperty("customfield_20397", new Newtonsoft.Json.Linq.JArray(regType))
                            )));

            WriteLog(string.Format("Ticket Opening JSON:\n{0}\n", rss.ToString())); //BMOLYNEAXXXXXX

            //if (File.Exists(@"C:\Users\bmolynea\Desktop\RegressionTests\files\dljson.txt"))
            //{
            //    File.Delete(@"C:\Users\bmolynea\Desktop\RegressionTests\files\dljson.txt");
            //}
            //File.WriteAllText(@"C:\Users\bmolynea\Desktop\RegressionTests\files\dljson.txt", rss.ToString());
            byte[] requestByte = Encoding.UTF8.GetBytes(rss.ToString());

            SendJSON(requestByte); //BMOLYNEA041017

            //using (QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx webClient = new QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx())
            //{
            //    webClient.Headers.Set("Authorization", "Basic " + encodedCredentials);
            //    webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
            //    var request = webClient.UploadData(openUrl, requestByte);
            //    try
            //    {
            //        string strResponse = webClient.Encoding.GetString(request);

            //        Newtonsoft.Json.Linq.JObject o = Newtonsoft.Json.Linq.JObject.Parse(strResponse);
            //        key = (string)o["key"];

            //    }
            //    catch (Exception e)
            //    {
            //        WriteLog(string.Format("Ticket Opening Exception:\n{0}\n", e)); //BMOLYNEAXXXXXX
            //    }
            //}
        }

        //BMOLYNEA030717
        public static void TBFOpenTicket(string tbfFile)
        {
            string TBFdescr = "*+TBF Item File Link:+*\n" + tbfFile;

            Newtonsoft.Json.Linq.JObject rss =
                new Newtonsoft.Json.Linq.JObject(
                    new Newtonsoft.Json.Linq.JProperty("fields",
                        new Newtonsoft.Json.Linq.JObject(
                            new Newtonsoft.Json.Linq.JProperty("project", new Newtonsoft.Json.Linq.JObject(new Newtonsoft.Json.Linq.JProperty("key", project))),
                            new Newtonsoft.Json.Linq.JProperty("issuetype", new Newtonsoft.Json.Linq.JObject(new Newtonsoft.Json.Linq.JProperty("name", "Automation-Bug"))),
                            new Newtonsoft.Json.Linq.JProperty("summary", RegSubject),
                            new Newtonsoft.Json.Linq.JProperty("description", TBFdescr),
                            new Newtonsoft.Json.Linq.JProperty("assignee", new Newtonsoft.Json.Linq.JObject(new Newtonsoft.Json.Linq.JProperty("name", "VIPQAAutomation")))
                            )));

            byte[] requestByte = Encoding.UTF8.GetBytes(rss.ToString());

            SendJSON(requestByte); //BMOLYNEA041017

            //using (QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx webClient = new QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx())
            //{
            //    webClient.Headers.Set("Authorization", "Basic " + encodedCredentials);
            //    webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
            //    var request = webClient.UploadData(openUrl, requestByte);
            //    try
            //    {
            //        string strResponse = webClient.Encoding.GetString(request);

            //        Newtonsoft.Json.Linq.JObject o = Newtonsoft.Json.Linq.JObject.Parse(strResponse);
            //        key = (string)o["key"];

            //    }
            //    catch (Exception e) { }
            //}
        }

        //BMOLYNEA041017
        public static void DAReportTicket(string loadDate, string folderPath)
        {
            string[] tempDate = loadDate.Split(' ');
            string dateNum = tempDate[0];

            string descr = RegSubject + " - Report Distribution\n" + folderPath;
            string switchLbl = "";

            WriteLog(string.Format("Load Date: {0}\nDescription: {1}\n", dateNum, descr)); //BMOLYNEAXXXXXX

            RegressionRunType();

            if (SwitchActCheck(RegSubject))
            {
                switchLbl = SwitchType(RegSubject);
            }

            Newtonsoft.Json.Linq.JObject rss =
                new Newtonsoft.Json.Linq.JObject(
                    new Newtonsoft.Json.Linq.JProperty("fields",
                        new Newtonsoft.Json.Linq.JObject(
                            new Newtonsoft.Json.Linq.JProperty("project", new Newtonsoft.Json.Linq.JObject(new Newtonsoft.Json.Linq.JProperty("key", project))),
                            new Newtonsoft.Json.Linq.JProperty("issuetype", new Newtonsoft.Json.Linq.JObject(new Newtonsoft.Json.Linq.JProperty("name", "Daily-Assignment"))),
                            new Newtonsoft.Json.Linq.JProperty("summary", RegSubject),
                            new Newtonsoft.Json.Linq.JProperty("description", descr),
                            new Newtonsoft.Json.Linq.JProperty("customfield_17893", new Newtonsoft.Json.Linq.JArray(dateNum)), //Load Date
                            new Newtonsoft.Json.Linq.JProperty("customfield_20396", new Newtonsoft.Json.Linq.JArray("Report_Distribution")), //Type of Assignment
                            new Newtonsoft.Json.Linq.JProperty("customfield_20397", new Newtonsoft.Json.Linq.JArray(regType, switchLbl)), //Type of Run
                            new Newtonsoft.Json.Linq.JProperty("customfield_19981", new Newtonsoft.Json.Linq.JObject(new Newtonsoft.Json.Linq.JProperty("value", "Prasad Kolishetti"))) //VIPQA Manager
                            )));

            byte[] requestByte = Encoding.UTF8.GetBytes(rss.ToString());

            WriteLog(string.Format("JSON Message:\n{0}\n", rss.ToString())); //BMOLYNEAXXXXXX

            SendJSON(requestByte);
        }

        private static string[] WEInfo(string we, string loadDate)
        {
            //upload with WE number, load date and issue type
            List<string> infoList = new List<string>();

            string[] fields = { "key", "summary", "status", "customfield_17894", "customfield_17881", "customfield_17983", "customfield_17893", "customfield_15799" };

            JsonMessage jsonBuilder = new JsonMessage();
            jsonBuilder.jql = String.Format("project = {0} AND issuetype = WorkEffort-Story AND cf[17894] = {1} AND cf[17893] = \"{2}\"", project, we, loadDate);
            jsonBuilder.startAt = 0;
            jsonBuilder.maxResults = 100;
            jsonBuilder.fields = fields;

            string Json = Newtonsoft.Json.JsonConvert.SerializeObject(jsonBuilder);
            string jsonNullRemove = Newtonsoft.Json.JsonConvert.SerializeObject(jsonBuilder, Newtonsoft.Json.Formatting.Indented, new Newtonsoft.Json.JsonSerializerSettings { NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore });
            byte[] requestByte = Encoding.UTF8.GetBytes(jsonNullRemove);

            using (QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx webClient = new QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx())
            {
                webClient.Headers.Set("Authorization", "Basic " + encodedCredentials);
                webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
                var request = webClient.UploadData(searchUrl, requestByte);
                try
                {
                    string strResponse = webClient.Encoding.GetString(request);

                    Newtonsoft.Json.Linq.JObject o = Newtonsoft.Json.Linq.JObject.Parse(strResponse);

                    infoList = RetrieveFields(strResponse);
                }
                catch (Exception e)
                {

                }
            }
            return infoList.ToArray();
        }

        private static List<string> RetrieveFields(string strResponse)
        {
            //
            Newtonsoft.Json.Linq.JObject srchJson = Newtonsoft.Json.Linq.JObject.Parse(strResponse);

            List<string> information = new List<string>();
            //information[0] = we
            //information[1] = rtn
            //information[2] = watchers
            //information[3] = loadDate
            //information[4] = summary
            //information[5] = key

            int results = (int)srchJson["total"];

            string issueKey = "";
            string issueStatus = "";

            for (int i = 0; i < results; i++)
            {
                try
                {
                    //Issue Key
                    try
                    {
                        issueKey = (string)srchJson["issues"][i]["key"];
                        key = issueKey;
                    }
                    catch { }
                    //
                    //Issue Type
                    try
                    {
                        string issueType = (string)srchJson["issues"][i]["fields"]["issuetype"]["name"];
                    }
                    catch { }
                    //
                    //Issue Status
                    try
                    {
                        issueStatus = (string)srchJson["issues"][i]["fields"]["status"]["name"];
                        status = issueStatus;
                    }
                    catch { }
                    //
                    //Issue WE
                    try
                    {
                        Newtonsoft.Json.Linq.JArray issueWE = (Newtonsoft.Json.Linq.JArray)srchJson["issues"][i]["fields"]["customfield_17894"];
                        information.Add(issueWE.First.ToString()); //0
                    }
                    catch { }
                    //
                    //Issue RTN No.
                    try
                    {
                        Newtonsoft.Json.Linq.JArray issueRTN = (Newtonsoft.Json.Linq.JArray)srchJson["issues"][i]["fields"]["customfield_17881"];
                        information.Add(issueRTN.First.ToString()); //1
                    }
                    catch { }
                    //
                    //Description
                    try
                    {
                        string issueDescription = (string)srchJson["issues"][i]["fields"]["description"];
                    }
                    catch { }
                    //
                    //Watchers
                    try
                    {
                        string issueWatchers = "";
                        int watcherAmount = srchJson["issues"][i]["fields"]["customfield_15799"].Count();

                        for (int j = 0; j < watcherAmount; j++)
                        {
                            if (j == 0)
                            {
                                issueWatchers = (string)srchJson["issues"][i]["fields"]["customfield_15799"][j]["name"];
                            }
                            else
                            {
                                issueWatchers = issueWatchers + "," + (string)srchJson["issues"][i]["fields"]["customfield_15799"][j]["name"];
                            }
                        }

                        information.Add(issueWatchers); //2
                    }
                    catch { }
                    //
                    //Developers
                    try
                    {
                        string issueDevs = (string)srchJson["issues"][i]["fields"]["customfield_17983"];
                        issueDevs.Replace("\"", "");
                        string[] devsList = issueDevs.Split(',');
                        string oldWatchers = information[2];
                        foreach (string s in devsList)
                        {
                            if (!oldWatchers.Contains(s))
                            {
                                string tempS = s.Trim();
                                oldWatchers = oldWatchers + "," + tempS;
                            }
                        }
                        information[2] = oldWatchers;
                    }
                    catch { }
                    //
                    //Issue Load Date
                    try
                    {
                        Newtonsoft.Json.Linq.JArray issueLoadDate = (Newtonsoft.Json.Linq.JArray)srchJson["issues"][i]["fields"]["customfield_17893"];
                        information.Add(issueLoadDate.First.ToString()); //3
                    }
                    catch { }
                    //
                    //Issue Summary
                    try
                    {
                        string issueSummary = (string)srchJson["issues"][i]["fields"]["summary"];
                        information.Add(issueSummary); //4
                    }
                    catch { }
                    //
                    //Add to information at end
                    try
                    {
                        information.Add(key);//5
                    }
                    catch { }
                }
                catch { }
            }



            return information;
        }

        private static void LinkIssues(string obsKey, string weKey)
        {
            //link to WE
            Newtonsoft.Json.Linq.JObject rss =
                new Newtonsoft.Json.Linq.JObject(
                    new Newtonsoft.Json.Linq.JProperty("type",
                    new Newtonsoft.Json.Linq.JObject(
                        new Newtonsoft.Json.Linq.JProperty("name", "is part of"))),
                    new Newtonsoft.Json.Linq.JProperty("inwardIssue",
                    new Newtonsoft.Json.Linq.JObject(
                        new Newtonsoft.Json.Linq.JProperty("key", obsKey))),
                    new Newtonsoft.Json.Linq.JProperty("outwardIssue",
                    new Newtonsoft.Json.Linq.JObject(
                        new Newtonsoft.Json.Linq.JProperty("key", weKey))));

            byte[] requestByte = Encoding.UTF8.GetBytes(rss.ToString());

            using (QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx linkWebClient = new QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx())
            {
                linkWebClient.Headers.Set("Authorization", "Basic " + encodedCredentials);
                linkWebClient.Headers[HttpRequestHeader.ContentType] = "application/json";
                try
                {
                    var request = linkWebClient.UploadData(linkUrl, requestByte);
                    try
                    {
                        string strLinkResponse = linkWebClient.Encoding.GetString(request);

                        Newtonsoft.Json.Linq.JObject o = Newtonsoft.Json.Linq.JObject.Parse(strLinkResponse);

                        Console.WriteLine("link response: " + o.ToString());
                    }
                    catch (Exception ex) { }
                }
                catch (Exception e) { }
            }
        }

        private static void AddWatchers(string[] watchers, string obsKey)
        {
            string watchersUrl = @"https://issues/rest/api/latest/issue/" + obsKey + @"/watchers";
            //
            //BMOLYNEA - 12/19/2016
            List<string> watchList = watchers.ToList<string>();
            watchList.Add("qassepjl");
            //
            //BMOLYNEA - 12/23/2016
            if (mmType == 2) //if the mismatch is a global
            {
                watchList.Add("VIPDEV.TESTGLOBALS");
            }
            //
            watchers = watchList.ToArray();
            //

            foreach (string s in watchers)
            {
                string tempS = s.Replace("\"", "");
                string json = "\"" + tempS + "\"";

                byte[] requestByte = Encoding.UTF8.GetBytes(json);

                using (QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx webClient = new QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx())
                {
                    webClient.Headers.Set("Authorization", "Basic " + encodedCredentials);
                    webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
                    var request = webClient.UploadData(watchersUrl, requestByte);
                    try
                    {
                        string strLinkResponse = webClient.Encoding.GetString(request);

                        Newtonsoft.Json.Linq.JObject o = Newtonsoft.Json.Linq.JObject.Parse(strLinkResponse);

                        Console.WriteLine("watchers response: " + o.ToString());

                    }
                    catch (Exception e)
                    {
                        WriteLog(string.Format("Mismatch Type: {0}\n", mmType)); //BMOLYNEAXXXXXX
                    }
                }
            }
        }
        //
        //BMOLYNEA - 12/19/2016-1
        public static void FilePath(string serverPath)
        {
            logFilePath = serverPath + @"\RegressionJsonLog.txt";

            //if (File.Exists(logFilePath))
            //{
            //    logFilePath = serverPath + @"\RegressionJsonLog_" + DateTime.Now + ".txt";
            //    //logFilePath = logFilePath + "_" + DateTime.Now;
            //}
        }
        //

        private static void RegressionRunType()
        {
            string[] tempArr = RegSubject.Split(' ');

            foreach (string s in tempArr)
            {
                if (RegTypes.Contains(s))
                {
                    regType = s;
                    WriteLog(string.Format("Run Type: {0}\n", s)); //BMOLYNEAXXXXXX
                    break;
                }
            }
        }

        //BMOLYNEA041017
        private static void SendJSON(byte[] requestByte)
        {
            using (QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx webClient = new QACT_WPF.MainPages.JiraIntegration.WebContainer.WebClientEx())
            {
                webClient.Headers.Set("Authorization", "Basic " + encodedCredentials);
                webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
                var request = webClient.UploadData(openUrl, requestByte);
                try
                {
                    string strResponse = webClient.Encoding.GetString(request);

                    Newtonsoft.Json.Linq.JObject o = Newtonsoft.Json.Linq.JObject.Parse(strResponse);
                    key = (string)o["key"];
                    WriteLog(string.Format("Ticket Key: {0}\n", (string)o["key"])); //BMOLYNEAXXXXXX
                }
                catch (Exception e)
                {
                    WriteLog(string.Format("Ticket Opening Exception:\n{0}\n", e)); //BMOLYNEAXXXXXX
                }
            }
        }

        //BMOLYNEA041017
        private static bool SwitchActCheck(string RegSubject)
        {
            bool switchAct;

            switchAct = RegSubject.Contains("Switch Activated");

            return switchAct;
        }

        //BMOLYNEA041017
        private static string SwitchType(string RegSubject)
        {
            string switchName = "";

            string[] tempS = RegSubject.Split(' ');

            foreach (string s in tempS)
            {
                if (s.Contains("APR") || s.Contains("OCT"))
                {
                    switchName = s + "_SwitchActivated";
                    break;
                }
            }

            return switchName;
        }

        //BMOLYNEA033017
        public static void WriteLog(string toWrite, [CallerLineNumber] int callerLineNumber = 0, [CallerMemberName] string memberName = "", [CallerFilePath] string callerFilePath = "")
        {
            callerFilePath = callerFilePath.Split('/').Last();

            File.AppendAllText(logFilePath, string.Format("!!!!!-------Class {0}, Method {1}, Line {2}-------!!!!!\nMessage:\n{3}", callerFilePath, memberName, callerLineNumber, toWrite));
        } 
    }
}

//**********************************************************
//Version
//
//BMOLYNEA - 04/10/2017:
//              Added DAReportTicket, SendJSON, SwitchActCheck, and SwitchType
//              Added SendJSON(requestByte) to RegOpenTicket and TBFOpenTicket
//
//BMOLYNEA - 03/30/2017:
//              Added WriteLog and multitudes of logging
//
//BMOLYNEA - 03/07/2017:
//              Added TBF Item ticket opening
//
//BMOLYNEA - 12/23/2016:
//              Move mmType to a public variable
//              Added global gdl for global mismatches
//              Assigned Manto, James to global mismatches
//
//BMOLYNEA - 12/19/2016:
//              Added SSPEJL to watcher list for all observations opened from regressions
//              Added log file path and writing
//
//BMOLYNEA - 12/14/2016: 
//              Blank out WE array if no WE is found, prevents breaking of opening observation when no WE is found
//              Added check to see if the mismatch is a WE, Switch, or Global
//**********************************************************
