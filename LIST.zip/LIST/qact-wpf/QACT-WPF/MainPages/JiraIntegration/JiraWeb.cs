﻿//using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Net;
//using System.Text;
//using System.Web;
//using System.Web.Script.Serialization;
//using System.IO;

namespace QACT_WPF.MainPages.JiraIntegration
{
    class JiraWeb
    {
        private static Dictionary<string, string> JsonDictionary = new Dictionary<string, string>()
        {
            { "customfield_17894", "we" },
            { "customfield_17893", "loadDate" },
            {"customfield_17797", "weType" },
            {"customfield_17983", "leadDeveloper"},
            {"customfield_17800", "loadState"},
            {"customfield_17801", "loadType"},
            {"customfield_17881", "rtn"},
            {"customfield_17802", "vtape"},
            {"customfield_17803", "debugVtape"},
            {"customfield_17983", "developers"},
            {"customfield_19981", "manager"},
            {"customfield_14347", "costCenter"},
            {"customfield_15921", "reviewer"},
            {"customfield_16835", "typeOfTesting"},
            {"customfield_15911", "severity"},
            {"customfield_16415", "projectStage"},
            {"customfield_16626", "testToolUsedtoDiscover"},
            {"summary", "summary"},
            {"description", "description"},
            {"key", "key"},
            {"status", "status"},
            {"assignee", "assignee"},
            {"epiclink", "epicLink"}
        };

        private string originDescription = "";
    }

    public class JsonMessage
    {
        public string jql;
        public int startAt;
        public int maxResults;
        public string[] fields;
        public string summary; //required for everything
        public string issuetype;
        public string assignee;
        public string description; //required for we
        public string[] we; //required for observation and we
        public string[] rtn; //required for observation and we
        public string watchers; //required for observation
        public string costCenter; //required for observation
        public string reviewer;
        public string developers; //required for observation and we
        public string reporter; //required for observation
        public string typeOfTesting; //required for observation
        public string severity; //required for observation
        public string projectStage; //required for observation
        public string testToolUsedtoDiscover; //required for observation
        public string[] loadDate; //required for we
        public string originalEstimate;
        public string epicLink;
        public string loadType;
        public string manager; //required for we
        public string vtape;
        public string weType;
        public string leadDeveloper;
        public string debugVtape;
        public string loadState;
        public string linkedIssue;
        public string[] issue;
    }
}
