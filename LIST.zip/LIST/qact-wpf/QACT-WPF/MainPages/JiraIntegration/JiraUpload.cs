﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.IO;

namespace QACT_WPF.MainPages.JiraIntegration
{
    class JiraUpload
    {
        public static void Jira(
            string user,
            string pass,
            string we,
            string wetype,
            string loaddate,
            string summary,
            string leaddev,
            string state,
            string loadstate,
            string loadtype,
            string rtn,
            string vtape,
            string debugvtape,
            string issuetype,
            string developers,
            string assignee
            /*string description*/)
        {
            string url = @"https://issues/rest/api/latest/issue";
            var mergedCredentials = string.Format("{0}:{1}", user, pass);
            var byteCredentials = Encoding.UTF8.GetBytes(mergedCredentials);
            var encodedCredentials = Convert.ToBase64String(byteCredentials);
            DR newdr = new DR();

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                                     | SecurityProtocolType.Tls11
                                     | SecurityProtocolType.Tls12;

            //#if DEBUG
            //            developers = "bmolynea, sseth";
            //            assignee = "pkolishe";
            //            newdr.fields.Add("project", new Field() { key = "VIPQA" });//Project Name
            //#endif

            newdr.fields.Add("project", new Field() { key = "VIPENG" });//Project Name
            //newdr.fields.Add("project", new Field() { key = "VIPQA" });//Project Name
            newdr.fields.Add("summary", we + "::" + loaddate + "::" + summary);//Summary
            newdr.fields.Add("issuetype", new Field() { name = issuetype });//Issue Type (Story, Bug, Etc)
            newdr.fields.Add("description", (we + " - " + summary));//Description
            newdr.fields.Add("assignee", new Field() { name = assignee });//Assignee
            newdr.fields.Add("customfield_17894", we);//WE
            newdr.fields.Add("customfield_17893", loaddate);//Load Date
            newdr.fields.Add("customfield_17797", wetype);//WE Type
            //newdr.fields.Add("customfield_17983", leaddev );//Lead Dev
            //newdr.fields.Add("customfield_17799", state );//State (QA Ready, etc)
            newdr.fields.Add("customfield_17800", loadstate);//Load State
            newdr.fields.Add("customfield_17801", loadtype);//Load Type
            newdr.fields.Add("customfield_17881", rtn);//RTN
            newdr.fields.Add("customfield_17802", vtape);//VTape
            newdr.fields.Add("customfield_17803", debugvtape);//Debug Vtape
            newdr.fields.Add("customfield_17983", developers);//Developers
            newdr.fields.Add("customfield_19981", new Field() { value = ReverseAssign(assignee) });//VIPQA Manager
            //
            JavaScriptSerializer serialize = new JavaScriptSerializer();
            var drtext = serialize.Serialize(newdr);

            //Edit array fields
            drtext = drtext.Replace("894\":", "894\":[");
            drtext = drtext.Replace(",\"customfield_17893\"", "],\"customfield_17893\"");
            drtext = drtext.Replace("893\":", "893\":[");
            drtext = drtext.Replace(",\"customfield_17797\"", "],\"customfield_17797\"");
            drtext = drtext.Replace("881\":", "881\":[");
            drtext = drtext.Replace(",\"customfield_17802\"", "],\"customfield_17802\"");
            //

            byte[] requestByte = Encoding.UTF8.GetBytes(drtext);

            try
            {
                using (WebClient webClient = new WebClient())
                {
                    webClient.Headers.Set("Authorization", "Basic " + encodedCredentials);
                    webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
                    //var response = webClient.UploadString(url, drtext);
                    //
                    var str = System.Text.Encoding.Default.GetString(requestByte);
                    File.AppendAllText(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\Request.txt", str);
                    //
                    var request = webClient.UploadData(url, requestByte);

                    try
                    {
                        //#if DEBUG
                        //                        string strResponse = webClient.Encoding.GetString(request);
                        //                        File.AppendAllText(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\Response.txt", (strResponse + "\n"));
                        //#endif         
                    }
                    catch (WebException ex)
                    {
                        //File.AppendAllText(@"C:\Users\bmolynea\Documents\Jira\WEList\Exception.txt", ex.ToString());
                    }
                }
            }
            catch (Exception e)
            {
                //Console.WriteLine("\n***EXCEPTION CAUGHT***\n{0}\n***EXCEPTION CAUGHT***\n",e);
                //Console.WriteLine("Failed Uploading WE: {0}\nFailed JSON Message: \n{1}", we, drtext);
                File.AppendAllText(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\UploadException.txt", e.ToString());
            }
        }

        private static string ReverseAssign(string assigneeId)
        {
            string idName = "";

            if (assigneeId == "PRadykar")
            {
                idName = "Pradyot Kar";
            }
            else if (assigneeId == "andasgup")
            {
                idName = "Aniruddha Dasgupta";
            }
            else if (assigneeId == "dhabaner")
            {
                idName = "Dharasu Banerjee";
            }
            else if (assigneeId == "sumachak")
            {
                idName = "Suman Chakraborty";
            }
            else if (assigneeId == "pkolishe")
            {
                idName = "Prasad Kolishetti";
            }
            else
            {
                //do nothing
            }

            return idName;
        }
    }
    public class DR
    {
        public Dictionary<string, dynamic> fields { get; set; }
        public DR()
        {
            fields = new Dictionary<string, dynamic>();
        }
    }
    public class Field
    {
        public string id { get; set; }
        public string key { get; set; }
        public string value { get; set; }
        public string name { get; set; }
    }
}
