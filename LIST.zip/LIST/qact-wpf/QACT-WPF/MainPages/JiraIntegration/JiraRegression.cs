﻿//using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

namespace QACT_WPF.MainPages.JiraIntegration
{
    class JiraRegression
    {
        private static string description = "";
        private static string weNum = "";
        private static string rtnNum = "";
        private static string loadDateNum = "";
        private static string testRun = null;                   //GGIRDHAR030717 Test Framwork Enhancement
        private static List<string> fields = new List<string>();

        public static void RegDescription(string text)
        {
            description = description + text + "\n";
            JiraJson.WriteLog(string.Format("RegDescription: {0}\n", description));//BMOLYNEA033017
        }

        //GGIRDHAR030717 public static void JiraMessage(string we, string rtn, string loadDate)
        public static void JiraMessage(string we, string rtn, string loadDate, bool TestRun)
        {
            JiraJson.WriteLog(string.Format("WE: {0}\nRTN: {1}\nLoad Date: {2}\nTest Run: {3}\n", we, rtn, loadDate, TestRun));//BMOLYNEA033017

            //
            //BMOLYNEA123016
            description = description.Replace("and Coderun", "  and Coderun");
            //

            if (rtn == "")
            {
                rtn = "807648";
            }

            weNum = we.Replace("SWITCH ", "SW");//BMOLYNEA040417
            rtnNum = rtn;

            string[] tempdate = loadDate.Split(' ');
            loadDateNum = tempdate[0];
            //GGIRDHAR030717 Test Framwork Enhancement
            if (TestRun)
            {
                testRun = "Y";
            }
            else
            {
                testRun = "N";
            }
            //GGIRDHAR030717 Test Framwork Enhancement

            JiraJson.WriteLog(string.Format("WE: {0}\nRTN: {1}\nLoad Date: {2}\nDescription: {3}\nTest Run: {4}\n", weNum, rtnNum, loadDateNum, description, testRun));//BMOLYNEA033017

            fields.Add(weNum);
            fields.Add(rtnNum);
            fields.Add(loadDateNum);
            fields.Add(description);
            fields.Add(testRun);    //GGIRDHAR030717 Test Framwork Enhancement
            string[] fieldsArray = fields.ToArray();

            //BMOLYNEA033017
            string logMess = "";
            foreach (string s in fields)
            {
                logMess = logMess + "\n" + s;
            }
            //END BMOLYNEA033017

            JiraJson.WriteLog(string.Format("Fields List: {0}\n", logMess));//BMOLYNEA033017

            //BMOLYNEA033017
            string logMessA = "";
            foreach (string s in fieldsArray)
            {
                logMessA = logMessA + "\n" + s;
            }
            //END BMOLYNEA033017

            JiraJson.WriteLog(string.Format("Fields List from Array: {0}\n", logMessA));//BMOLYNEA033017

            fields.Clear();
            description = "";

            JiraJson.JsonRegCheck(fieldsArray);
        }
    }
}
