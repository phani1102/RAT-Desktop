﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace QACT_WPF.MainPages
{
    /// <summary>
    /// Interaction logic for JiraIntegrate.xaml
    /// </summary>
    public partial class JiraIntegrate : Page
    {
        private static int listIndex;
        private static string[] assignedArray;

        public JiraIntegrate()
        {
            InitializeComponent();
            PopulateComboBx();
        }

        private void Button_Click(object sender, System.EventArgs e)
        {
            //Don't know what this is for but I have to keep it
        }

        private void btnJDownload_Click(object sender, RoutedEventArgs e)
        {
            WEListBx.Items.Clear();

            string textDate = "0000-00-00";
            DateTime dt;
            if (dtInstall.SelectedDate.HasValue == true)
            {
                dt = dtInstall.SelectedDate.Value;
                textDate = dt.ToString("yyyy-MM-dd");

                JiraIntegration.JiraIntegrator.JiraIntegrate(txtuser.Text, txtpass.Password, textDate);

                btnJUpload.IsEnabled = true;
                btnJAssign.IsEnabled = true;
                UserComboBx.IsEnabled = true;
                btnBrowse.IsEnabled = true;
                txtsprdsht.IsEnabled = true;

                assignedArray = JiraIntegration.JiraIntegrator.JiraLoop();

                for (int i = 0; i < assignedArray.Length; i += 3)
                {
                    if (assignedArray[i + 2] == "")
                    {
                        assignedArray[i + 2] = "<NONE>";
                    }

                    WEListBx.Items.Add(String.Format("{0} - {1} - {2}", assignedArray[i], assignedArray[i + 1], assignedArray[i + 2]));
                }

                WEListBx.IsEnabled = true;
            }
            else
            {
                //Don't let them download
                MessageBox.Show("Select a Load Date");
            }   
        }

        private void btnJUpload_Click(object sender, RoutedEventArgs e)
        {
            JiraIntegration.JiraIntegrator.JiraAssign(assignedArray);
            JiraIntegration.JiraIntegrator.UploadJira();  //Actually Upload The New CSV File
            MessageBox.Show("Upload Complete");

            //CleanUp Files
            JiraIntegration.JiraIntegrator.CleanUp(); //deletes all the files created during this process //TODO: Cleanup the code so this isn't needed

            btnJUpload.IsEnabled = false;
            btnJAssign.IsEnabled = false;
            UserComboBx.IsEnabled = false;
            btnBrowse.IsEnabled = false;
            txtsprdsht.IsEnabled = false;
            btnAutoAssign.IsEnabled = false;
            txtsprdsht.Clear();
            WEListBx.Items.Clear();
        }

        private void btnJAssign_Click(object sender, RoutedEventArgs e)
        {
            //assignedArray = JiraIntegration.JiraIntegrator.JiraLoop();
            if (WEListBx.SelectedIndex != -1)
            {
                //assignedArray[(WEListBx.SelectedIndex * 3) + 2] = txtassign.Text;  //text box manual enter

                if (UserComboBx.SelectedIndex != -1)
                {
                    assignedArray[(WEListBx.SelectedIndex * 3) + 2] = IDSelect(UserComboBx.Items[UserComboBx.SelectedIndex].ToString());  //combo box select
                }

                /*if (txtassign.Text == "")
                {
                    assignedArray[(WEListBx.SelectedIndex * 3) + 2] = "<NONE>";
                }*/

                WEListBx.Items[listIndex] = String.Format("{0} - {1} - {2}", assignedArray[listIndex * 3], assignedArray[(listIndex * 3) + 1], assignedArray[(listIndex * 3) + 2]);
            }
            else
            {
                MessageBox.Show("Please Select A WE");
            }
        }

        private void WEListBx_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            listIndex = WEListBx.SelectedIndex;
        }

        private void UserComboBx_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void PopulateComboBx()
        {
            UserComboBx.Items.Add("Pradyot Kar");
            UserComboBx.Items.Add("Aniruddha Dasgupta");
            UserComboBx.Items.Add("Dharasu Banerjee");
            UserComboBx.Items.Add("Suman Chakraborty");
            UserComboBx.Items.Add("Prasad Kolishetti");
//#if DEBUG
//            UserComboBx.Items.Add("Brandon Molyneaux");
//#endif
        }

        private string IDSelect(string name)
        {
            string idName = "";
            name = name.Replace(" ", "");

            if (name == "PradyotKar")
            {
                idName = "PRadykar";
            }
            else if (name == "AniruddhaDasgupta")
            {
                idName = "andasgup";
            }
            else if (name == "DharasuBanerjee")
            {
                idName = "dhabaner";
            }
            else if (name == "SumanChakraborty")
            {
                idName = "sumachak";
            }
            else if (name == "PrasadKolishetti")
            {
                idName = "pkolishe";
            }
            else
            {
                //do nothing
            }
//#if DEBUG
//            if (name == "Brandon Molyneaux")
//            {
//                idName = "bmolynea";
//            }
//#endif

            return idName;
        }

        private void txtuser_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {
            // Create OpenFileDialog 
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

            // Set filter for file extension and default file extension 
            //dlg.DefaultExt = ".xcl";
            //dlg.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif";

            // Display OpenFileDialog by calling ShowDialog method 
            Nullable<bool> result = dlg.ShowDialog();

            // Get the selected file name and display in a TextBox 
            if (result == true)
            {
                // Open document 
                string filename = dlg.FileName;
                txtsprdsht.Text = filename;
                //Enable Auto Assign
                btnAutoAssign.IsEnabled = true;
            }
        }

        private void btnAutoAssign_Click(object sender, RoutedEventArgs e)
        {
            string[] assigned;

            if (txtsprdsht.Text != "")
            {
                assigned = QACT_WPF.MainPages.JiraIntegration.JiraIntegrator.AutoAssign(txtsprdsht.Text);

                foreach (string s in assigned)
                {
                    string[] tempArray = s.Split(',');
                    for (int i = 0; i < assignedArray.Length; i++)
                    {
                        if (assignedArray[i] == tempArray[0].Split(' ').First())
                        {
                            assignedArray[i + 2] = IDSelect(tempArray[1]);
                            WEListBx.Items[i/3] = String.Format("{0} - {1} - {2}", 
                                assignedArray[(i / 3) * 3], 
                                assignedArray[((i / 3) * 3) + 1], 
                                assignedArray[((i / 3) * 3) + 2]);
                            break;
                        }
                        i = i + 2;
                    }
                }
            }
        }
    }
}
