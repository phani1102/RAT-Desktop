﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

namespace QACT_WPF.MainPages.JiraIntegration
{
    class JiraStandardize
    {
        public static void Standardize(string fName)
        {
            string delimter = ",";
            string assignee = "";
            string file = fName + ".csv";
            string newFile = fName + "Updated.csv";

            //Console.WriteLine("\nEditing File...\n");

            if (File.Exists(newFile))
            {
                File.Delete(newFile);
            }

            using (StreamReader sr = new StreamReader(file))
            {
                bool firstLine = true;
                string[] splitLine;
                string currentLine;
                while ((currentLine = sr.ReadLine()) != null)
                {
                    if (firstLine == false)
                    {
                        splitLine = currentLine.Split(',');
                        string newLine = "";
                        
                        newLine = string.Join(delimter, splitLine);
                        newLine = newLine + string.Format(",WorkEffort-Story,{0}", assignee);
                        File.AppendAllText(newFile, newLine + Environment.NewLine);
                    }
                    else
                    {
                        currentLine = currentLine + ",Issue Type,Assignee";
                        //Console.WriteLine("Header Line:\n{0}", currentLine);
                        //Console.WriteLine("\n");
                        File.AppendAllText(newFile, currentLine + Environment.NewLine);
                        firstLine = false;
                    }
                }
            }

            //Console.WriteLine("\nFile Edited!\n");
        }
    }
}
