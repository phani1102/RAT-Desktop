﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;

namespace QACT_WPF.MainPages.JiraIntegration
{
    class JiraIntegrator
    {
        private static string csvFilePath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\WECSV"; //application_folder_WECSV
        private static string fileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\WEFile"; //application_folder_WEFILE
        private static string[] extension = { ".xls", ".csv" };

        public static void JiraIntegrate(string user, string pass, string date)
        {
            //format: yyyy-MM-dd
            //string startDate = "yyyy-MM-dd";
            //string endDate = "yyyy-MM-dd";
            string startDate = date;
            string endDate = date;
            string[] credentials = { user, pass };
            string loginP = "http://pslimsapp.visa.com/slims/login";
            string fullFileName = fileName + extension[0];

            string fullCSVFilePath = csvFilePath + extension[1];
            Workbook csvFile;

            using (WebClient webclient = new WebContainer.WebClientEx())
            {
                var loginPage = webclient.DownloadString(loginP);
                var loginData = new NameValueCollection
                {
                    { "username", credentials[0]},
                    { "password", credentials[1]},
                    {"_csrf",loginPage.Substring(loginPage.IndexOf("_csrf")+ 14, 36)}
                };

                //Login
                var loginResp = webclient.UploadValues(loginP, loginData);

                DuplicateFileCheck(startDate, endDate, fullFileName, webclient);
            }

            //Edit Columns
            EditColumns(fullFileName);

            //Convert Excel to CSV
            csvFile = ConvertFile(fullFileName, fullCSVFilePath);

            //Edit File
            JiraStandardize.Standardize(csvFilePath);
        }

        //Delete Edit Columns
        public static void EditColumns(string fName)
        {
            Application excel = new Application();
            excel.DisplayAlerts = false;

            Workbook tempWorkbook = excel.Workbooks.Open(fName);
            Worksheet tempWorkSheet = tempWorkbook.Worksheets.get_Item(1);

            int rows = tempWorkSheet.UsedRange.Rows.Count;
            Range excelRange = tempWorkSheet.UsedRange;
            Range cellContent;

            string[] devs = new string[rows];

            //combine Lead Dev column with Dev
            for (int i = 0; i < rows; i++)
            {
                try
                {
                    if (i != 0)
                    {
                        //Change Load Date Format
                        Range leadDevCell = tempWorkSheet.Cells[i + 1, 12];
                        Range devCell = tempWorkSheet.Cells[i + 1, 13];

                        string leadDevStr = leadDevCell.Value;
                        string devStr = devCell.Value;

                        string allDevs = "";

                        leadDevStr = Regex.Replace(leadDevStr, @" ?\(.*?\)", "");
                        devStr = Regex.Replace(devStr, @" ?\(.*?\)", "");

                        string[] tempArray1 = leadDevStr.Split(',');
                        string[] tempArray2 = devStr.Split(',');

                        foreach (string t in tempArray1)
                        {
                            if (devStr == "")
                            {
                                if (t == tempArray1.Last())
                                {
                                    allDevs = allDevs + t;
                                }
                                else
                                {
                                    allDevs = allDevs + t + ",";
                                }
                            }
                            else
                            {
                                allDevs = allDevs + t + ",";
                            }
                        }
                        foreach (string t in tempArray2)
                        {
                            if (t == tempArray2.Last())
                            {
                                allDevs = allDevs + t;
                            }
                            else
                            {
                                allDevs = allDevs + t + ",";
                            }
                        }
                        devs[i] = allDevs;
                    }
                    else
                    {
                        devs[i] = "Developers";
                    }
                }
                catch (Exception e)
                {

                }
            }

            //Change Column to all Developers
            for (int i = 0; i < rows; i++)
            {
                tempWorkSheet.Cells[i + 1, 12] = devs[i];
            }

            //Delete Column
            tempWorkSheet.Columns[13].Delete();

            //Remove anything in parenthesis
            for (int i = 1; i < rows + 1; i++)
            {
                //Change Load Date Format
                cellContent = tempWorkSheet.Cells[i, 3];
                string splString = cellContent.Value;
                string[] tempArray = splString.Split(' ');
                excelRange.Cells.set_Item(i, 3, tempArray[0]);

                //Change Owner Format
                cellContent = tempWorkSheet.Cells[i, 5];
                splString = cellContent.Value;
                tempArray = splString.Split(' ');
                excelRange.Cells.set_Item(i, 5, tempArray[0]);
            }

            tempWorkSheet.SaveAs(fName);

            tempWorkbook.Close();
        }

        //Convert Excel to CSV
        public static Workbook ConvertFile(string fName, string csvFilePath)
        {
            Application excel = new Application();
            excel.DisplayAlerts = false;

            Workbook csvFile = excel.Workbooks.Open(fName);

            if (File.Exists(csvFilePath + ".csv"))
            {
                File.Delete(csvFilePath + ".csv");
            }

            csvFile.SaveAs(csvFilePath, Microsoft.Office.Interop.Excel.XlFileFormat.xlCSV);
            csvFile.Close();
            excel.Workbooks.Close();

            return csvFile;
        }

        //Check For Duplicate File
        public static void DuplicateFileCheck(string sDate, string eDate, string fName, WebClient wClient)
        {
            //Download File
            if (File.Exists(fName))
            {
                File.Delete(fName);
                DownloadFile(wClient, sDate, eDate, fName);
            }
            else
            {
                DownloadFile(wClient, sDate, eDate, fName);
            }
        }

        //Download WE list of LoadDate
        public static void DownloadFile(WebClient webC, string sDate, string eDate, string fName)
        {
            if (sDate == "yyyy-MM-dd" | eDate == "yyyy-MM-dd")
            {
                //Console.WriteLine("Dates Not Given");
            }
            else
            {
                try
                {
                    webC.DownloadFile(@"http://pslimsapp.visa.com/slims/report?type=simple-we-list&format=xls&dates=" + string.Format("{0}&dates={1}", sDate, eDate), fName);
                }
                catch (Exception e)
                {
                    //Console.WriteLine(e);
                }
            }
        }

        public static void UploadJira()
        {
            string srvUser = "svcvipqa";
            string srvPass = "3#Zt'!eSND";

            using (StreamReader sr = new StreamReader(csvFilePath + "UpdatedFinal" + extension[1]))
            {
                bool firstLine = true;
                string[] splitLine;
                string currentLine;
                while ((currentLine = sr.ReadLine()) != null)
                {
                    if (firstLine == false)
                    {
                        //splitLine = currentLine.Split(',');
                        splitLine = Regex.Split(currentLine, ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                        //
                        //BMOLYNEA 123016 - if no one is assigned, skip uploading that one
                        if (splitLine[13] != "<NONE>")
                        {
                            //
                            //BMOLYNEA123016 - if RTN is blank, put 807648, if Developers is blank, put group as developer
                            if (splitLine[8] == "")
                            {
                                splitLine[8] = "807648";
                            }
                            if (splitLine[12] == "")
                            {
                                splitLine[12] = "svcvipqa";
                            }
                            //

                            JiraUpload.Jira(
                                srvUser,
                                srvPass,
                                splitLine[0],//WE
                                splitLine[1],//WE Type
                                splitLine[2],//Load Date
                                splitLine[3],//Summary
                                splitLine[4],//Lead Dev
                                splitLine[5],//State
                                splitLine[6],//Load State
                                splitLine[7],//Load Type
                                splitLine[8],//RTN
                                splitLine[9],//VTape
                                splitLine[10],//Debug VTape
                                splitLine[12],//Developers
                                splitLine[11],//Issue Type
                                splitLine[13]//Assignee
                                );
                        }
                        //
                    }
                    else
                    {
                        firstLine = false;
                    }
                }
            }
        }

        public static string[] JiraLoop()
        {
            List<string> assignedList = new List<string>();

            using (StreamReader sr = new StreamReader(csvFilePath + "Updated" + extension[1]))
            {
                bool firstLine = true;
                string[] splitLine;
                string currentLine;
                while ((currentLine = sr.ReadLine()) != null)
                {
                    if (firstLine == false)
                    {
                        splitLine = Regex.Split(currentLine, ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)"); //split at commas outside of quotes
                        assignedList.Add(splitLine[0]);
                        assignedList.Add(splitLine[3]);
                        assignedList.Add(splitLine[13]);
                    }
                    else
                    {
                        firstLine = false;
                    }
                }
            }

            string[] assignedArray = assignedList.ToArray();

            return assignedArray;
        }

        public static void JiraAssign(string[] assigned)
        {
            Application excel = new Application();
            excel.DisplayAlerts = false;

            string fName = csvFilePath + "Updated" + extension[1];
            string newFName = csvFilePath + "UpdatedFinal" + extension[1];

            Workbook tempWorkbook = excel.Workbooks.Open(fName);
            Worksheet tempWorkSheet = tempWorkbook.Worksheets.get_Item(1);

            int rows = tempWorkSheet.UsedRange.Rows.Count;
            Range excelRange = tempWorkSheet.UsedRange;

            for (int i = 1; i < (assigned.Length / 3) + 2; i++)
            {
                if (i != 1)
                {
                    try
                    {
                        excelRange.Cells.set_Item(i, 14, assigned[((i - 2) * 3) + 2]);
                    }
                    catch (Exception e)
                    {

                    }
                }
            }

            tempWorkSheet.SaveAs(newFName);
            tempWorkbook.Close();
        }

        public static string[] AutoAssign(string spreadsheet)
        {
            List<string> assignees = new List<string>();

            try
            {
                Application excel = new Application();
                excel.DisplayAlerts = false;
                Workbook tempWorkbook = excel.Workbooks.Open(spreadsheet);
                Worksheet tempWorkSheet = tempWorkbook.Worksheets.get_Item(1);

                //column 1 = WE
                //column 12 = Manager
                int rows = tempWorkSheet.UsedRange.Rows.Count;
                Range excelRange = tempWorkSheet.UsedRange;
                Range wecellcontent;
                Range managercellcontent;

                for (int i = 1; i < rows + 1; i++)
                {
                    if (i != 1)
                    {
                        try
                        {
                            wecellcontent = tempWorkSheet.Cells[i, 1];
                            managercellcontent = tempWorkSheet.Cells[i, 12];
                            assignees.Add(String.Format("{0},{1}", (wecellcontent.Value), (managercellcontent.Value)));
                        }
                        catch (Exception e)
                        {

                        }
                    }
                }

                tempWorkbook.Close();
            }
            catch { }

            return assignees.ToArray();
        }

        public static void CleanUp()
        {
            if (File.Exists(csvFilePath + extension[1]))
            {
                File.Delete(csvFilePath + extension[1]);
            }
            if (File.Exists(fileName + extension[0]))
            {
                File.Delete(fileName + extension[0]);
            }
            if (File.Exists(csvFilePath + "UpdatedFinal" + extension[1]))
            {
                File.Delete(csvFilePath + "UpdatedFinal" + extension[1]);
            }
            if (File.Exists(csvFilePath + "Updated" + extension[1]))
            {
                File.Delete(csvFilePath + "Updated" + extension[1]);
            }
        }
    }
}
