﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web.Script.Serialization;

namespace QACT_WPF
{
    public class AnalysisData:INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        //private const string Passphrase = "VIP_QA_PassPhrase";
        private static readonly string Passphrase = App.Passphrase;
        string _VMId;
        public string VMId { get { return _VMId; } set { _VMId = value.ToUpper(); NotifyPropertyChanged("VMId"); } }
        public string VMPassword { get; set; }
        string _BaseRunVpars;
        public string BaseRunVpars { get { return _BaseRunVpars; } set { _BaseRunVpars = value.ToUpper(); NotifyPropertyChanged("BaseRunVpars"); } }
        string _CodeRunVpars;
        public string CodeRunVpars { get { return _CodeRunVpars; } set { _CodeRunVpars = value.ToUpper(); NotifyPropertyChanged("CodeRunVpars"); } }
        string _HSM_Series = "900-90F";
        public string HSM_Series { get { return _HSM_Series; } set { _HSM_Series = value; NotifyPropertyChanged("HSM_Series"); } }
        public string SystemDate { get; set; }
        string _RegBucket;
        public string RegBucket { get { return _RegBucket; } set { _RegBucket = value; NotifyPropertyChanged("RegBucket"); } }
        public string Capture { get; set; }
        string _RegServer;
        public string RegServer { get { return _RegServer; } set { _RegServer = value; NotifyPropertyChanged("RegServer"); } }
        string _Email;
        public string Email { get { return _Email; } set { _Email = value; NotifyPropertyChanged("Email"); } }
        string _MM_Fltype;
        public string MM_Fltype { get { return _MM_Fltype; } set { _MM_Fltype = value.ToUpper(); NotifyPropertyChanged("MM_Fltype"); } }
        bool _SkipSetup = false;
        public bool SkipSetup { get { return _SkipSetup; } set { _SkipSetup = value; NotifyPropertyChanged("SkipSetup"); } }
        string _SwitchActivationInfo;
        public string SwitchActivationInfo { get { return _SwitchActivationInfo; } set { _SwitchActivationInfo = value; NotifyPropertyChanged("SwitchActivationInfo"); } }
        [Obsolete]
        public string WorkingFolderPath { get; set; }
        public string BaserunInstallDate { get; set; }
        public string BaserunSystemDate { get; set; }
        public string FTPFiles { get; set; }
        public string CUPTapes { get; set; }
        public string CupTapeToUplaod { get; set; }

        //Add new indicator for scheduler run
        bool _IsSchedulerAnalysis = false;
        public bool IsSchedulerAnalysis { get { return _IsSchedulerAnalysis; } set { _IsSchedulerAnalysis = value; NotifyPropertyChanged("IsSchedulerRun"); } }
        public Dictionary<string,string> BaserunGlobals = new Dictionary<string,string>();
        /// <summary>
        /// Install Date in MM/dd/yyyy format
        /// </summary>
        public string InstallDate { get; set; }
        //public string BucketRunId { get; set; }
        //public string BucketRunPwd { get; set; }
        public string RegType { get; set; }
        public string FallbackPath { get; set; }
        public string RunNumber { get; set; }
        public AnalysisData() {
            this.SkipSetup = false;
            this.HSM_Series = App.HSMUNITS[0];
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                this.Email = "VIPQAAUTOMATION";
            }
            else
            {
                this.Email = "VIPTestSystemSupp";
            }
            //GGIRDHAR030717 - Test Framework Enhancement
        }
        public AnalysisData(IDictionary<string,string> CMDVariables) : this()
        {
            RegServer = CMDVariables["SERVER"];
            RunSettings RegSett = CommonClass.LoadFromJSONFile<RunSettings>(System.IO.Path.Combine(RegServer, "RunSettings.json"));
            RegSett.VMPWD = Crypto.Decrypt(RegSett.VMPWD, App.Passphrase);
            RegType = RegSett.RegType;
            InstallDate = RegSett.InstallDate;
            RunNumber = RegSett.RunNumber;
            SystemDate = RegSett.SystemDate;
            BaserunSystemDate = RegSett.BaserunSystemDate;
            BaserunInstallDate = RegSett.BaserunInstallDate;
            RegBucket = RegSett.Bucket;
            Capture = RegSett.RegCapture;
            SwitchActivationInfo = RegSett.SwitchActivationInfo;
            //this.MM_Fltype = RegSett.InstallDate.Replace("/", "").Substring(0, 4) + RegSett.RegType.Substring(0, 2) + RegSett.RunNumber.Replace("BASERUN", "BR").Replace("RUN", (RegSett.SwitchActivationInfo != "N/A" && RegSett.SwitchActivationInfo != null ? "S" : null));
            this.MM_Fltype = RegSett.InstallDate.Replace("/", "").Substring(0, 4) + RegSett.RegType.Substring(0, 2) + RegSett.RunNumber.Replace("RUN", null);//Saumen031317

            this.VMId = RegSett.VMID;
            FTPFiles = RegSett.FTPFiles;
            CUPTapes = RegSett.CUPTapes;
            this.VMPassword = RegSett.VMPWD;

            if (CMDVariables.ContainsKey("BASERUN_VPARS"))
                this.BaseRunVpars = CMDVariables["BASERUN_VPARS"];
            else
                this.BaseRunVpars = RegSett.VIPS[0].VPARS;

            if (CMDVariables.ContainsKey("CODERUN_VPARS"))
                this.BaseRunVpars = CMDVariables["CODERUN_VPARS"];
            else
                this.CodeRunVpars = RegSett.VIPS[1].VPARS;

            this.Email = RegSett.email;

            this.SkipSetup = false;
            this.HSM_Series = RegSett.HSMUnit;
        }
        public AnalysisData(RunSettings RegSett): this()
        {
            RegType = RegSett.RegType;
            InstallDate = RegSett.InstallDate;
            RunNumber = RegSett.RunNumber;
            RegServer = RegSett.CoderunServer;
            //MM_Fltype = RegSett.InstallDate.Replace("/", "").Substring(0, 4) + RegSett.RegType.Substring(0, 2) + RegSett.RunNumber.Replace("BASERUN", "BR").Replace("RUN", (RegSett.SwitchActivationInfo != "N/A" && RegSett.SwitchActivationInfo != null ? "S" : null));
            MM_Fltype = RegSett.InstallDate.Replace("/", "").Substring(0, 4) + RegSett.RegType.Substring(0, 2) + RegSett.RunNumber.Replace("RUN", null);//Saumen031317
            this.VMId = RegSett.VMID;
            this.VMPassword = RegSett.VMPWD;
            this.BaseRunVpars = RegSett.VIPS[0].VPARS;
            this.CodeRunVpars = RegSett.VIPS[1].VPARS;
            FTPFiles = RegSett.FTPFiles;
            CUPTapes = RegSett.CUPTapes;
            Capture = RegSett.RegCapture;
            this.SkipSetup = false;
            this.HSM_Series = RegSett.HSMUnit;
            this.Email = "VIPTestSystemSupp";
        }
        public AnalysisData(InputFile inputFile) : this()
        {
            this.VMId = inputFile.CMSId;
            this.VMPassword = inputFile.CMSPassword;
            this.BaseRunVpars = inputFile.BaseRunVPARS;
            this.CodeRunVpars = inputFile.CodeRunVPARS;
            RegServer = inputFile.CoderRunServerPath;
        }
        //[Obsolete]
        //public void StoreAsJson(string jsonPath = null)
        //{
        //    if (jsonPath == null)
        //        jsonPath = this.RegServer + "\\" +this.GetType().Name + ".json";
        //    string tmp1 = this.VMPassword; //string tmp2 = this.BucketRunPwd;
        //    this.VMPassword = Crypto.Encrypt(this.VMPassword, Passphrase);
        //   // this.BucketRunPwd = Crypto.Encrypt(this.BucketRunPwd, Passphrase);
        //    JavaScriptSerializer serialize = new JavaScriptSerializer();
        //    System.IO.File.WriteAllText(jsonPath, FormatJson(serialize.Serialize(this)));
        //   this.VMPassword = tmp1; //this.BucketRunPwd = tmp2;
        //}
        //[Obsolete]
        //private string FormatJson(string json, string INDENT_STRING = "   ")
        //{
        //    int indentation = 0;
        //    int quoteCount = 0;
        //    var result =
        //        from ch in json
        //        let quotes = ch == '"' ? quoteCount++ : quoteCount
        //        let lineBreak = ch == ',' && quotes % 2 == 0 ? ch + Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, indentation)) : null
        //        let openChar = ch == '{' || ch == '[' ? ch + Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, ++indentation)) : ch.ToString()
        //        let closeChar = ch == '}' || ch == ']' ? Environment.NewLine + String.Concat(Enumerable.Repeat(INDENT_STRING, --indentation)) + ch : ch.ToString()
        //        select lineBreak == null
        //                    ? openChar.Length > 1
        //                        ? openChar
        //                        : closeChar
        //                    : lineBreak;

        //    return String.Concat(result);
        //}
        //[Obsolete]
        //public static AnalysisData LoadFromJSON(string JsonFilePath)
        //{
        //    JavaScriptSerializer serialize = new JavaScriptSerializer();
        //    AnalysisData DataObj = (AnalysisData)serialize.Deserialize(System.IO.File.ReadAllText(JsonFilePath), typeof(AnalysisData));
        //    DataObj.VMPassword = Crypto.Decrypt(DataObj.VMPassword, Passphrase);
        //    return DataObj;
        //}
    }

    public class TestCase
    {
        public string TestCaseName { get; set; }
        public string ExecutionMode { get; set; }
        public List<string>Status { get; set; }
        public string Tape2Cut { get; set; }
        public TestCase(string tcname, string tape,string em,int wecount)
        {

            TestCaseName = tcname;
            ExecutionMode = em;
            Status = new string[wecount].ToList();
            Tape2Cut = tape;
        }
    }
    public class Tape
    {
        public string TapeType { get; set; }
        public List<string> TapeNumbers { get; set; }
        public Tape(string type, int wecount)
        {
            TapeType = type;
            TapeNumbers = new string[wecount].ToList(); ;
        }
    }

    public class TestData
    {
        public List<TestCase> TestCases { get; set; }
        public List<string> SpecialFB { get; set; }
        public List<Tape> Tapes { get; set; }

        public TestData(string MMList_FilePath, string FLBK_FilePath,RunSettings runsett,out List<string> WELIST,out string error)
        {
            //Initialize variables'
            error = null;
            TestCases = new List<TestCase>(); Tapes = new List<Tape>();
            //Populate WEs
            try
            {
                List<string> fallbackscript = System.IO.File.ReadAllLines(FLBK_FilePath).Where(p => p != "" && p != "*---").Select(l => l.ToUpper()).ToList();
                WELIST = new List<string>();
                WELIST.Add("Base Run :");
                WELIST.Add("Code Run :");
                string wenumber = null;
                foreach (var line in fallbackscript)
                {
                    //if ((line.Contains("WORK EFFORT") || line.Contains("SWITCH")) && wenumber == null)// 
                    if ((line.Contains("WORK EFFORT") || line.Contains("SWITCH")) && line.Contains("*-"))
                    {
                        if (line.Contains("SWITCH"))
                            wenumber = line.ToUpper().Substring(line.IndexOf("SWITCH")).Replace("-", " ").Replace("*", "").Trim();
                        else
                        {
                            string[] x = line.Split(' ');
                            wenumber = x[x.Length - 2];
                        }
                    }
                    if (wenumber != null)
                        if (line.ToCharArray()[0] == 'Z' && !line.Contains("ZCYCL") && !line.Contains("ZRIPL"))
                        {
                            WELIST.Add(wenumber);
                            wenumber = null;
                        }
                }
                //Now Get Globals from Run Settings.json
                //
                //var coderunsett=RunSettings.LoadFromJSON(RunsettingsPath);

                // Add Globals only if they are different
                if (runsett != null && System.IO.File.Exists(System.IO.Path.Combine(runsett.BaserunServer, "RunSettings.json")))
                {
                    RunSettings baserunsett = CommonClass.LoadFromJSONFile<RunSettings>(System.IO.Path.Combine(runsett.BaserunServer, "RunSettings.json"));
                   // baserunsett.VMPWD = Crypto.Decrypt(baserunsett.VMPWD, App.Passphrase);
                    foreach (KeyValuePair<string, string> codeRunGlb in runsett.Globals
                                                                            .Where(code_glb =>
                                                                                App.ALLGLOBALS.Any ( g_type => g_type.Equals(code_glb.Key,  StringComparison.InvariantCultureIgnoreCase))
                                                                                && baserunsett.Globals.ContainsKey(code_glb.Key)
                                                                                && !object.Equals(baserunsett.Globals[code_glb.Key],code_glb.Value) && !string.IsNullOrWhiteSpace(code_glb.Value)
                                                                                ))
                    {
                        WELIST.Add(codeRunGlb.Key + ':' + codeRunGlb.Value);
                    }
                    /*
                    WELIST.Add("NWK:" + runsett.Globals["NWK"]);
                    WELIST.Add("DCS:" + runsett.Globals["DCS"]);
                    WELIST.Add("BMX:" + runsett.Globals["BMX"]);
                    WELIST.Add("CFG:" + runsett.Globals["CFG"]);
                    */
                    if (runsett.SystemDate != runsett.BaserunSystemDate)
                    {
                        WELIST.Add("SYS_DATE");
                    }
                }
                if (WELIST.Count<=2)
                {
                    error = "No record to be fallen back. Check fallback script.";
                    //throw new ArgumentException("No record to be fallen back. Check fallback script.");
                }

                //Take DTD RSI CSI By default
                Tapes.Add(new Tape("DTD", WELIST.Count));
                Tapes.Add(new Tape("RSI", WELIST.Count));
                Tapes.Add(new Tape("CSI", WELIST.Count));

                ///
                SpecialFB = new string[WELIST.Count].Select(s => "NA").ToList();
                //Now Get the Testcases
                var MMLIST = System.IO.File.ReadAllLines(MMList_FilePath);
                foreach (var MM in MMLIST)
                {
                    string tempmm = MM.Trim().ToUpper();
                    if (tempmm != "" && tempmm.Length > 4 && tempmm.ToCharArray()[0] != '*')
                    {
                        var temparray = tempmm.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                        string testcase = temparray[0], runmode = temparray.Count() >= 2 ? temparray[1].Trim() : "FC",
                            tape = temparray.Count() >= 3 ? temparray[2].Trim() : "DTD";
                        //if (!Tapes.Exists(t => t.TapeType == tape))
                        //    Tapes.Add(new Tape(tape, WELIST.Count));
                        switch (runmode)
                        {
                            case "FC":
                                runmode = "Full_Cycle";
                                break;
                            case "ATR":
                                runmode = "STIP:ATR";
                                break;
                            case "LR":
                                runmode = "STIP:Late_Response";
                                break;
                            case "INR":
                                runmode = "STIP:Iss_Node_Ret";
                                break;
                            case "ANR":
                                runmode = "STIP:Acq_Node_Ret";
                                break;
                            case "DR":
                                runmode = "STIP:Duplicate_Resp";
                                break;
                            case "IU":
                                runmode = "STIP:Issuer_Unavailable";
                                break;
                            case "DRB":
                                runmode = "DRB";
                                break;
                            default:
                                runmode = "Unknown";
                                break;
                        }
                        TestCases.Add(new TestCase(testcase, tape, runmode, WELIST.Count));

                    }
                }
                if (TestCases.Count==0)
                {
                    error = "No Testcase to run.";

                    //throw new ArgumentException("No Testcase to run.");
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
                WELIST = null;
            }
            
        }
    }

    public enum MMRecreateStatus
    {
        Mismatch_NOT_recreated,
        Mismatch_recreated,
        Mismatch_Isolated_Fully,
        Mismatch_Isolated_Partly
    }
    public enum DUMPRecreateStatus
    {
        Dump_NOT_recreated,
        Dump_recreated,
        Dump_Isolated_Fully,
        Dump_Isolated_Partly
    }
}
