﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Web.Script.Serialization;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using System.Net;
using Web = System.Web.UI;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using QACT_WPF.MainPages.JiraIntegration;


namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for ARCHES.xaml
    /// </summary>
    public partial class ARCHES : Page, INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        public delegate string GroupEvaluator(Match match, string groupName);


        #region Members and Properties
        int VMCommandTimeOut = 1;
        string _buttoncontent = "Start";
        List<string> WELIST;
        List<string> ErrorsInRun = new List<string>();
        public Thread AnalysisThread { get; set; }
        public Thread TimerThread { get; set; }
        public ObservableCollection<RegStage> AnaStages { get { return this._AnaStages; } set { _AnaStages = value; NotifyPropertyChanged("AnaStages"); } }
        ObservableCollection<RegStage> _AnaStages = new ObservableCollection<RegStage>();
        bool _analysisSuccessful = false;
        public bool AnalysisSuccessful { get { return _analysisSuccessful; } set { _analysisSuccessful = value; NotifyPropertyChanged("AnalysisSuccessful"); } }
        bool _isIdle = true;
        public bool IsIdle { get { return _isIdle; } set { _isIdle = value; NotifyPropertyChanged("IsIdle"); } }
        public string SessionName { get; set; }
        int _elapsedSeconds;
        public int ElapsedSeconds { get { return _elapsedSeconds; } set { _elapsedSeconds = value; NotifyPropertyChanged("ElapsedSeconds"); } }

        public string ButtonContent { get { return _buttoncontent; } set { _buttoncontent = value; NotifyPropertyChanged("ButtonContent"); } }
        HLLAPI ana;
        [Obsolete]
        public string Mismatch_Analysis_Folder = System.Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\Regression_Analysis";
        RunSettings Runsettings;
        AnalysisData _Anadata = new AnalysisData();
        public AnalysisData Anadata { get { return _Anadata; } set { _Anadata = value; NotifyPropertyChanged("Anadata"); } }
        //public AnalysisData Anadata = null;
        bool IsLoggedon = false;
        JavaScriptSerializer serializer = new JavaScriptSerializer();
        #endregion
        #region Analysis Events
        public delegate void AnalysisCompletedHandler();
        public event AnalysisCompletedHandler OnAnalysisCompleted;
        #endregion

        #region UI
        public ARCHES()
        {
            InitializeComponent();
            if (App.InputObj != null)
                this.Loaded += ARCHES_Loaded_File;
            else if (App.CMDLINEARGS.Count > 2)
                this.Loaded += ARCHES_Loaded_CMD;
        }

        void ARCHES_Loaded_File(object sender, RoutedEventArgs e)
        {
            // Bypass if regression is running or Arches is already running
            if (App.InputObj.State < InputFile.Status.REGRESSION_COMPLETED || App.InputObj.State >= InputFile.Status.ARCHES_RUNNNING)
                return;

            this.OnAnalysisCompleted += Scheduler_OnAnalysisCompleted;
            ////////////////////////// Click the Start Button ////////////////////////////////
            this.btnSTART.RaiseEvent(new RoutedEventArgs(System.Windows.Controls.Primitives.ButtonBase.ClickEvent));
            App.InputObj.State = InputFile.Status.ARCHES_RUNNNING;
        }
        void Scheduler_OnAnalysisCompleted()
        {
            // Log off VPARSes
            LogOffVpars(new string[] { Anadata.BaseRunVpars, Anadata.CodeRunVpars });
            if (HSM_PRODD77 == "DETACHED")                                                                          //Saumen090116
            {
                ReserveHSM("2", "ATTACH");                                                                          //Saumen082916
            }
            // Log off CMS
            LogOffCMS();//Saumen020917
            // Update Status
            App.InputObj.State = InputFile.Status.ARCHES_COMPLETED;
            InputFile.UpdateStatus(App.InputObj, "Analysis Completed");                                             //Saumen082416

            // Close QACT
            if (Application.Current != null)
                Application.Current.Dispatcher.Invoke(() =>
                {
                    try
                    {
                        Application.Current.Shutdown(-1);
                        IsIdle = true;
                    }
                    catch
                    {
                        Environment.Exit(-1);
                    }

                });
        }
        void LogOffVpars(IEnumerable<string> VPARSes)
        {
            AddOrUpdateStageLog("Log Off VICs", "Runnning...", true);

            foreach (string VPARS in VPARSes.Where(v => !String.IsNullOrWhiteSpace(v)))
            {
                //Saumen031017
                ana.EnterCommand("TPFOPR " + VPARS + " ZCYCL 1052", 2);
                ana.EnterCommand("TPFOPR " + VPARS + " ZDSYS", 2);
                int max_try = 0;
                while (ana.WaitforString("IN 1052", 60) == 0 && max_try <= 5)
                {
                    ana.EnterCommand("TPFOPR " + VPARS + " ZDSYS", 2);
                    max_try++;
                }
                //Saumen031017
                ana.EnterCommand("TPFOPR " + VPARS + " ZCP LOG", 1);
                ana.WaitforString("not open (no longer open)", 60);
                ana.WaitforString("Ready", 60);
            }

            AddOrUpdateStageLog("Log Off VICs", "Successful", false);
        }

        public ARCHES(string ShortSessionName)
            : this()
        {
            comboHSM.ItemsSource = App.HSMUNITS;
            //comboHSM.SelectedItem = "NA";
            ButtonContent = "Start";
            this.Title = "ARCHES Window " + ShortSessionName.ToUpper();// +"(Beta)";
            ana = new HLLAPI(ShortSessionName, true, "ANALYSIS");
            SessionName = ShortSessionName;
            //txtfallbackpath.Text = Mismatch_Analysis_Folder + "\\svfallback.txt";
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                Anadata.Email = ((App)App.Current).IsVIPTESTENGMember ? "VIPQAAUTOMATION" : Environment.UserName.Split(new char[] { '\\' }, StringSplitOptions.RemoveEmptyEntries).Last();
            }
            else
            {
                Anadata.Email = ((App)App.Current).IsVIPTESTENGMember ? "VIPTestSystemSupp" : Environment.UserName.Split(new char[] { '\\' }, StringSplitOptions.RemoveEmptyEntries).Last();
            }
            //GGIRDHAR030717 - Test Framework Enhancement
        }

        void ARCHES_Loaded_CMD(object sender, RoutedEventArgs e)
        {
            Dictionary<string, string> CMDVariables = new Dictionary<string, string>();

            foreach (string cmd in App.CMDLINEARGS.Where(str => str.Contains("=")))
                CMDVariables.Add(cmd.Split('=')[0].ToUpper().Trim(), cmd.Split('=')[1]);
            ////////////////////////////// FOR VALID COMMANDLINE ARGUMENTS //////////////////////
            if (App.CMDLINEARGS.Count >= 2
                && App.CMDLINEARGS[0].Equals("ARCHES", StringComparison.CurrentCultureIgnoreCase)
                && App.CMDLINEARGS[1].Equals(SessionName, StringComparison.CurrentCultureIgnoreCase)
                && CMDVariables.ContainsKey("SERVER"))
            //&& CMDVariables.ContainsKey("REG_TYPE") 
            //&& CMDVariables.ContainsKey("CODE_RUN_INSTALL_DATE"))
            {
                Anadata = new AnalysisData(CMDVariables);
                ////////////////////////// Click the Start Button ////////////////////////////////
                this.btnSTART.RaiseEvent(new RoutedEventArgs(System.Windows.Controls.Primitives.ButtonBase.ClickEvent));
            }

        }

        private void btnSTART_Click(object sender, RoutedEventArgs e)
        {
            if (ButtonContent == "Start")
            {
                ErrorsInRun.Clear();
                _AnaStages.Clear();
                AddOrUpdateStageLog("Validate UI Fields", "Started...", true);
                if (!ValidateUI()) //Stop Analysis right now.
                {
                    AddOrUpdateStageLog(null, "Failed", false);
                    return;
                }
                AddOrUpdateStageLog(null, "Successful", false);
                AnalysisThread = new Thread(PerformAnalysis);
                TimerThread = new Thread(IncreaseTime);
                ElapsedSeconds = 0;
                AnalysisThread.Start();
                TimerThread.Start();
                IsIdle = false;
                ButtonContent = "Pause";
            }
            else if (ButtonContent == "Pause")
            {
                AnalysisThread.Suspend();
                TimerThread.Suspend();
                ButtonContent = "Resume";
            }
            else if (ButtonContent == "Resume")
            {
                AnalysisThread.Resume();
                TimerThread.Resume();
                ButtonContent = "Pause";
            }

        }
        void IncreaseTime()
        {
            while (true)
            {
                Thread.Sleep(1000);
                ElapsedSeconds++;
            }
        }
        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            if (AnalysisThread == null)
                return;
            if (MessageBox.Show("Do you really want to stop ongoing analysis?", "Stop Analysis", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No) == MessageBoxResult.No)
                return;
            if (AnalysisThread.ThreadState == ThreadState.Suspended)
            {
                AnalysisThread.Resume();
                TimerThread.Resume();
            }
            AnalysisThread.Abort();
            //Finishing Regression
            IsIdle = true;
            try
            {
                TimerThread.Abort();
            }
            catch (Exception)
            {

            }
            _AnaStages.Insert(0, new RegStage() { Stage = "Analysis Ended.", Status = "Stopped via STOP button", StartAt = DateTime.Now.ToString("MM/dd/yy HH:mm:ss"), EndAt = DateTime.Now.ToString("MM/dd/yy HH:mm:ss") });
            UpdateStagestofile();
            AnalysisThread = null;
            TimerThread = null;
            ButtonContent = "Start";

            // Stop the Inopput file
            if (App.InputObj != null)
                App.InputObj.State = InputFile.Status.ARCHES_STOPPED;

        }
        private bool ValidateUI()
        {
            if (App.InputObj != null)
            {
                Anadata = new AnalysisData(App.InputObj);
                Anadata.IsSchedulerAnalysis = true;
            }
            else
                Anadata.IsSchedulerAnalysis = false;
            if (Anadata.VMId == null || Anadata.VMId == "")
            {
                MessageBox.Show("CMS ID cannot be blank.", " ARCHES window " + ana.SessionShortName);
                txtVMID.Focus();
                return false;
            }
            if (App.InputObj == null)
                Anadata.VMPassword = pwdVMPWD.Password.Trim();
            if (Anadata.VMPassword == null || Anadata.VMPassword == "")
            {
                MessageBox.Show("CMS Password cannot be blank.", " ARCHES window " + ana.SessionShortName);
                pwdVMPWD.Focus();
                return false;
            }
            if (Anadata.BaseRunVpars == null || Anadata.BaseRunVpars == "")
            {
                MessageBox.Show("BaseRun VPARS cannot be blank.", " ARCHES window " + ana.SessionShortName);
                txtbasevpars.Focus();
                return false;
            }
            if (Anadata.CodeRunVpars == null || Anadata.CodeRunVpars == "")
            {
                MessageBox.Show("CodeRun VPARS cannot be blank.", " ARCHES window " + ana.SessionShortName);
                txtcodevpars.Focus();
                return false;
            }
            if (Anadata.Email == null || Anadata.Email == "")
            {
                MessageBox.Show("Email cannot be blank.", " ARCHES window " + ana.SessionShortName);
                txtemail.Focus();
                return false;
            }
            if ((Anadata.MM_Fltype == null || Anadata.MM_Fltype == "") && App.InputObj == null)
            {
                MessageBox.Show("Mismatch file type cannot be blank.", " ARCHES window " + ana.SessionShortName);
                txtfiletype.Focus();
                return false;
            }
            Anadata.RegServer = txtRunserver.Text.Trim().TrimEnd('\\');
            if (!System.IO.Directory.Exists(Anadata.RegServer))
            {
                MessageBox.Show("Server path doesnot exist", " ARCHES window " + ana.SessionShortName);
                txtRunserver.Focus();
                return false;
            }
            Anadata.FallbackPath = txtfallbackpath.Text;
            return true;
        }
        private bool ValidateServerData()
        {
            //Anadata.WorkingFolderPath = Mismatch_Analysis_Folder = Anadata.RegServer;
            Runsettings = CommonClass.LoadFromJSONFile<RunSettings>(Anadata.RegServer + "\\RunSettings.json");
            if (Runsettings != null)
            {
                Runsettings.VMPWD = Crypto.Decrypt(Runsettings.VMPWD, App.Passphrase);
                if (Runsettings.IsComparisonRequired == false)
                {
                    MessageBox.Show("Regression was not compared.", " ARCHES window " + ana.SessionShortName);
                    return false;
                }
                Anadata.SystemDate = Runsettings.SystemDate;
                //txtSystemdate.Text = Runsettings.SystemDate;
                Anadata.RegBucket = Runsettings.Bucket;
                //txtBucket.Text = Runsettings.Bucket;
                Anadata.HSM_Series = Runsettings.HSMUnit;

                //comboHSM.SelectedItem = Runsettings.HSMUnit;
                Anadata.BaserunInstallDate = Runsettings.BaserunInstallDate;
                Anadata.BaserunSystemDate = Runsettings.BaserunSystemDate;
                Anadata.SwitchActivationInfo = Runsettings.SwitchActivationInfo == null ? "N/A" : Runsettings.SwitchActivationInfo;
                //Load cuptapes and ftp files from regression settings
                Anadata.FTPFiles = Runsettings.FTPFiles;
                Anadata.CUPTapes = Runsettings.CUPTapes;
                //
                if (App.InputObj != null)
                    //Anadata.MM_Fltype = Runsettings.InstallDate.Replace("/", "").Substring(0, 4) + Runsettings.RegType.Substring(0, 2) + Runsettings.RunNumber.Replace("BASERUN", "BR").Replace("RUN", (Runsettings.SwitchActivationInfo != "N/A" && Runsettings.SwitchActivationInfo != null ? "S" : null));
                    Anadata.MM_Fltype = Runsettings.InstallDate.Replace("/", "").Substring(0, 4) + Runsettings.RegType.Substring(0, 2) + Runsettings.RunNumber.Replace("RUN", null);//Saumen031317
                Anadata.RegType = Runsettings.RegType;
                Anadata.RunNumber = Runsettings.RunNumber;
                Anadata.Capture = Runsettings.RegCapture;
                Anadata.InstallDate = Runsettings.InstallDate;
                RunSettings basesettings = CommonClass.LoadFromJSONFile<RunSettings>(Runsettings.BaserunServer + "\\Runsettings.json");
                basesettings.VMPWD = Crypto.Decrypt(basesettings.VMPWD, App.Passphrase);
                if (basesettings != null)
                    Anadata.BaserunGlobals = basesettings.Globals;
            }
            var tmppwd = Anadata.VMPassword;
            Anadata.VMPassword = Crypto.Encrypt(Anadata.VMPassword, App.Passphrase);
            Anadata.StoreAsJsonFile(Anadata.RegServer + "\\AnalysisData.json");
            Anadata.VMPassword = tmppwd;


            return true;
        }
        private void btnShowHide_Click(object sender, RoutedEventArgs e)
        {
            if (btnShowHide.Content.ToString().Contains("Show"))
            {
                ana.ShowWindow(true);
                btnShowHide.Content = "Hide Attachmate Window";
            }
            else
            {
                ana.ShowWindow(false);
                btnShowHide.Content = "Show Attachmate Window";
            }
        }
        private void btnregcompletedialog_Click(object sender, RoutedEventArgs e)
        {
            AnalysisSuccessful = false;
        }
        #endregion
        [System.Runtime.ExceptionServices.HandleProcessCorruptedStateExceptionsAttribute()]
        private void PerformAnalysis()
        {
            //AnalysisData Anadata = (AnalysisData)obj;
            try
            {
                #region Analysis Procedure
                AddOrUpdateStageLog("Get regression settings from server", "Started...", true);
                if (!ValidateServerData()) //Stop Analysis 
                {
                    AddOrUpdateStageLog(null, "Failed", false);
                    goto FINISH;
                }
                AddOrUpdateStageLog(null, "Successful", false);

                AddOrUpdateStageLog("Transfer H14DEF,SAVETAPE,FLBK", "Started...", true);
                //PreQTP Files Upload
                var res = ARCHESFiles.UploadOtherfiles(Anadata);
                if (res != null)
                {
                    HandleError("Transfer H14DEF,SAVETAPE,FLBK failed. " + res, ErrorTypes.NotifyandAbort, ErrorGroup.FTP_ERROR);
                    //MessageBox.Show("ARCHES Failed.\nTransfer H14DEF,SAVETAPE,FLBK failed.", "Regression Window - " + ana.SessionShortName, MessageBoxButton.OK, MessageBoxImage.Error);
                    AddOrUpdateStageLog(null, "Failed." + res, false);
                    goto FINISH;
                }
                AddOrUpdateStageLog(null, "Successful", false);
                //Create Setup  and transfer files 
                if (!Anadata.SkipSetup)
                {
                    AddOrUpdateStageLog("Create and transfer setups", "Started...", true);
                    if (ARCHESFiles.CreateAndTransferSetups(Anadata))
                    {
                        AddOrUpdateStageLog(null, "Successful", false);
                    }
                    else
                    {
                        //if (!HandleError("Setup Creation and transfer failed." + res, ErrorTypes.NotifyandWait))
                        if (!HandleError("Setup Creation and transfer failed." + res, Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.SETUP_CREATION_ERROR))
                        {
                            AddOrUpdateStageLog(null, "Failed.", false);
                            goto FINISH;
                        }
                        else
                            AddOrUpdateStageLog(null, "Done.", false);
                    }
                }
                ana.ShowWindow(true);
                AddOrUpdateStageLog("Connect to session " + ana.SessionShortName, "Started...", true);
                if (ana.ConnectSession() != 0)
                {
                    HandleError("Connect to session " + ana.SessionShortName, ErrorTypes.NotifyandAbort, ErrorGroup.SYSTEM_PROBLEM);
                    AddOrUpdateStageLog(null, "Failed.", false);
                    goto FINISH;
                }
                AddOrUpdateStageLog(null, "Successful", false);

                // Save log files
                App.debuggingFilePaths[ana.screenshotfile] = System.IO.Path.Combine(Anadata.RegServer, System.IO.Path.GetFileName(ana.screenshotfile));


                {
                    AddOrUpdateStageLog("Login", "Started...", true);
                    string loginString = Anadata.VMId;

                    //////////////////// check login status ///////////////
                    if (Login(ref loginString, Anadata.VMPassword))
                    {
                        AddOrUpdateStageLog("Login", "Successful", false);
                        IsLoggedon = true;
                        Anadata.VMId = loginString;     // for logon by string
                    }
                    else
                    {
                        IsLoggedon = false;
                        AddOrUpdateStageLog("Login", "Unsuccessful", false);
                        goto FINISH;
                    }
                }
                //Submit Setup
                if (!Anadata.SkipSetup)
                {
                    //AddOrUpdateStageLog("Submit baserun setup", "Started...", true);
                    if (!SubmitAndTrackSetup("BASERUN", (Anadata.BaserunSystemDate != null ? Anadata.BaserunSystemDate : Anadata.SystemDate), true))
                    {
                        //if (!HandleError("Besrun setup failed.", ErrorTypes.NotifyandWait))
                        if (!HandleError("Baserun setup failed.", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.TPFSETUP_ERROR))
                        {
                            AddOrUpdateStageLog(null, "Failed.", false);
                            goto FINISH;
                        }
                        else
                            AddOrUpdateStageLog(null, "Done.", false);
                    }
                    else
                        AddOrUpdateStageLog(null, "Successful", false);
                    ana.EnterCommand("TPFOPR " + Anadata.BaseRunVpars + " ZKTSK STOP", 1);
                    if (Anadata.HSM_Series != "NA")
                        AttachHSM(Anadata.BaseRunVpars, Anadata.HSM_Series);

                    //
                    //AddOrUpdateStageLog("Submit coderun setup", "Started...", true);
                    /*
                     *Before submitting the setup Get a QAT as we are ftping all files, DB is getting filled up 
                     * 
                     * 
                     * 
                     * 
                     */
                    //ana.EnterCommand("GET TESTCASE", 1);
                    //GGIRDHAR030717 - Test Framework Enhancement
                    if (InputFile.TestRun)
                    {
                        ana.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
                    }
                    //GGIRDHAR030717 - Test Framework Enhancement
                    ana.EnterCommand("GET VIPQAAUT", 1);//Saumen021417
                    //Saumen021417 - stopped using QAT for regressions
                    //ana.EnterCommand("USING 1QAT", 1);
                    //ana.WaitforString("Ready;", 5);
                    //var response = ana.GetLines(10).Where(l => l.Trim() != "" && !l.Contains("Ready;") && !l.Contains("AVAILABLE") && !l.Contains("Not available"));
                    //var qatline = response.FirstOrDefault(l => l.Contains("QAT"));
                    //if (qatline != null)
                    //{
                    //    ana.EnterCommand("pipe < CODERUN $TTVDATA A1 | change  /.VDBName 24/ /.VDBName " + qatline.Trim() + "/ |> CODERUN $TTVDATA A1", 1);
                    //    HandleError(qatline.Trim() + " is being used for Analysis.", ErrorTypes.NotifyOnly, ErrorGroup.NO_ERROR, "I will be using " + qatline.Trim() + " for Analysis", "QA-VIP-Support", false);
                    //}
                    //else
                    //    if (HandleError("Free QAT is not available for Analysis.\nPlease attach QAT to CODERUN $TTVDATA and continue.", ErrorTypes.LogandWait, ErrorGroup.OUT_OF_PRODDQAT_ID) == false)
                    //    goto FINISH;
                    //Saumen021417
                    if (!SubmitAndTrackSetup("CODERUN", Anadata.SystemDate, true))
                    {

                        //if (!HandleError("Coderun setup failed.", ErrorTypes.NotifyandWait))
                        if (!HandleError("Coderun setup failed.", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.TPFSETUP_ERROR))
                        {
                            AddOrUpdateStageLog(null, "Failed.", false);
                            goto FINISH;
                        }
                        else
                            AddOrUpdateStageLog(null, "Done.", false);
                    }
                    else
                        AddOrUpdateStageLog(null, "Successful", false);
                    ana.EnterCommand("TPFOPR " + Anadata.CodeRunVpars + " ZKTSK STOP", 1);
                    if (Anadata.HSM_Series != "NA")
                        AttachHSM(Anadata.CodeRunVpars, Anadata.HSM_Series);

                }
                string TestcasesToRun = null;
                string DumpstoIsolate = null;
                string Tapes2Cut = null;
                bool PerformH14DEF = true;
                bool PerformDUMPSTAT = true;
                if (!CreateMismatchList(Anadata, ref PerformH14DEF, ref PerformDUMPSTAT))
                    goto FINISH;

                AddOrUpdateStageLog("Get testcase details", "Started...", true);
                System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "MISMATCH.LIST"));
                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "MISMATCH.LIST"), "MISMATCH LIST A1");
                string error = null;
                TestData testdata = new TestData(System.IO.Path.Combine(Anadata.RegServer, "MISMATCH.LIST"), Anadata.FallbackPath, Runsettings, out WELIST, out error);
                //
                if (error == null)
                    AddOrUpdateStageLog(null, "Done", false);
                else
                {
                    AddOrUpdateStageLog(null, "Failed." + error, false);
                    HandleError(error, ErrorTypes.NotifyAndLog, ErrorGroup.NOT_CLASSIFIED_ERROR);
                    //goto FINISH;
                }
                //string GlobalV = null;
                ///// No advice retreival for SOAP
                bool RADVICEREQUIRED = Anadata.RegType.ToUpper().Contains("SOAP") ? false : true;
                ///////////////////////////////////// WEs One by One ///////////////////////////////////////////
                foreach (string WE in WELIST)
                {

                    // string runmodes = null;
                    string VPARSID = null;
                    if (WELIST.IndexOf(WE) == 0)//Do the Baserun
                    {
                        AddOrUpdateStageLog("Current Record-" + WE, "Started...", true);
                        VPARSID = Anadata.BaseRunVpars;
                        ana.EnterCommand("ANALYSIS BLDZBURZ", 1);
                        //ana.WaitforString("Ready", 29);
                        //ana.WaitforString("Processing completed successfully;", 29);
                        if (!WaitAndHandleInternalRexxError("ANALYSIS BLDZBURZ", 5 * 60))
                            goto FINISH;

                        for (int i = 0; i < 3; i++)
                        {
                            ana.EnterCommand("TPFZMS " + VPARSID + " SIGNON ZBURZ(NODISPLAY", 1);
                            if (ana.WaitforString("Ready;", 120) == 0)
                            {
                                if (i == 2)
                                    //if (!HandleError("SIGNON ZBURZ not run in " + VPARSID + " even after 3 try.", ErrorTypes.NotifyandWait))
                                    if (!HandleError("SIGNON ZBURZ not run in " + VPARSID + " even after 3 try.", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.VM_TOOLS_ERROR))
                                        goto FINISH;
                            }
                            else
                                break;
                        }
                        //First time we'll run all the testcases and cut all the Tapes
                        TestcasesToRun = string.Concat(testdata.TestCases.Select((tc, index) => index + 1 + ",")).Trim(',');
                        Tapes2Cut = (string.Concat(testdata.TestCases.Select(tc => tc.Tape2Cut + ",").Distinct())).Trim(',');//string.Concat(testdata.Tapes.Select(t => t.TapeType + ",")).Trim(',');
                    }
                    else //Do the Coderun
                    {
                        VPARSID = Anadata.CodeRunVpars;
                        if (WELIST.IndexOf(WE) == 1)//RUN SIgn on ZBURZ for the first time only
                        {
                            AddOrUpdateStageLog("Current Record-" + WE, "Started...", true);
                            for (int i = 0; i < 3; i++)
                            {
                                ana.EnterCommand("TPFZMS " + VPARSID + " SIGNON ZBURZ(NODISPLAY", 1);
                                if (ana.WaitforString("Ready;", 120) == 0)
                                {
                                    if (i == 2)
                                        //if (!HandleError("SIGNON ZBURZ not run in " + VPARSID + " even after 3 try.", ErrorTypes.NotifyandWait))
                                        if (!HandleError("SIGNON ZBURZ not run in " + VPARSID + " even after 3 try.", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.VM_TOOLS_ERROR))
                                            goto FINISH;
                                }
                                else
                                    break;
                            }
                            ana.EnterCommand("COPY MISMATCH LIST A1 MISMATCH UPDATE A1 (REP", 1);
                        }
                        else //Here we'll fallback WEs one by one
                        {
                            if ((TestcasesToRun == "None" || TestcasesToRun == "" || TestcasesToRun == null) && (DumpstoIsolate == "None" || DumpstoIsolate == "" || DumpstoIsolate == null))
                                break;
                            else
                            {
                                AddOrUpdateStageLog("Current Record-" + WE + " (" + (WELIST.IndexOf(WE) - 1) + " of " + (WELIST.Count - 2) + ")", "Started...", true);
                                //AddOrUpdateStageLog("Fallback record " + WE + " (" + (WELIST.IndexOf(WE) - 1) + " of " + (WELIST.Count - 2) + ")", "Started...", true);
                                AddOrUpdateStageLog(null, "Fallback " + WE, false);

                                string fallbackWE = App.ALLGLOBALS.Any(glb => WE.Contains(glb + ':')) ? WE.Split(':')[0] + ':' + Anadata.BaserunGlobals[WE.Split(':')[0]] : WE;


                                if (Fallback(fallbackWE, VPARSID, testdata.SpecialFB[WELIST.IndexOf(WE)]))
                                    AddOrUpdateStageLog(null, "Successful", false);
                                else
                                {
                                    AddOrUpdateStageLog(null, "Failed.", false);
                                    goto FINISH;
                                    ////if (!HandleError("Fallback record " + WE + " failed.", ErrorTypes.NotifyandWait))
                                    //if (!HandleError("Fallback record " + WE + " failed.", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.INTERNAL_EXEC_ERROR))
                                    //{
                                    //    AddOrUpdateStageLog(null, "Failed.", false);
                                    //    goto FINISH;
                                    //}
                                    //else
                                    //    AddOrUpdateStageLog(null, "Done.", false);
                                }
                            }

                        }

                    }
                    //Before running testcases Initialize Databases
                    ana.EnterCommand("ANALYSIS INITDB " + VPARSID, 1);
                    //ana.WaitforString("Initialization Completed", 60);
                    //ana.WaitforString("Processing completed successfully;", 60);
                    WaitAndHandleInternalRexxError("ANALYSIS INITDB", 60);

                    //Run all the testcases available in TestcasesToRun
                    //
                    //AddOrUpdateStageLog("Run Testcases in " + VPARSID + " for " + WE, "Started...", true);

                    // 
                    //Add dump list to it:
                    //We need to run the FTP and CUPLOAD
                    AddOrUpdateStageLog(null, "CUPTAPES and FTPVIP", false);

                    //Upload Travel CDB
                    //ana.EnterCommand("PIPE CMS FTPVIP " + VPARSID + " FTPT FILE Z1 |>> ANALYSIS LOG A1", 10);
                    ana.EnterCommand("PIPE CMS FTPVIP " + VPARSID + " FTPT FILE Z1 |>> ANALYSIS LOG Z1", 10);//Saumen022717
                    ana.WaitforString("Ready;", 1 * 60);
                    //Upload Travel Tag
                    //ana.EnterCommand("PIPE CMS FTPVIP " + VPARSID + " FTPC FILE Z1 |>> ANALYSIS LOG A1", 10);
                    ana.EnterCommand("PIPE CMS FTPVIP " + VPARSID + " FTPC FILE Z1 |>> ANALYSIS LOG Z1", 10);//Saumen022717
                    ana.WaitforString("Ready;", 1 * 60);

                    //Now do only the required CUPLOAD 
                    if (Anadata.CupTapeToUplaod != null)
                    {
                        ana.EnterCommand("TPFPROC CUPLOAD " + VPARSID + " " + Anadata.CupTapeToUplaod + " (NODISPLAY", VMCommandTimeOut);
                        ana.WaitforString("Ready", 3 * 60);

                    }
                    //foreach (var item in Anadata.CUPTapes.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                    //{
                    //    ana.EnterCommand("TPFPROC CUPLOAD " + VPARSID + " " + item.Trim() + " (NODISPLAY", VMCommandTimeOut);
                    //    ana.WaitforString("Ready", 3 * 60);
                    //}
                    //

                    List<TestCase> runthesetestcases = testdata.TestCases.Where((tc, index) => TestcasesToRun.Split(',').Contains((index + 1).ToString()) || (DumpstoIsolate != null && DumpstoIsolate.Split(',').Contains((index + 1).ToString()))).ToList();

                    {
                        ///////////////////////// FOR ALL OTHER RUNS USE ANALYSIS GRPTSTCS ////////////////////////////////////////
                        //ANALYSIS GRPTSTCS PRODD11 -1 for Base Run
                        //ANALYSIS GRPTSTCS PRODD11 0 for Code Run 1st iteration
                        //ANALYSIS GRPTSTCS PRODD11 1 for Code Run 2nd iteration
                        ana.EnterCommand("ANALYSIS GRPTSTCS " + VPARSID + " " + (WELIST.IndexOf(WE) - 1), 2);

                        AddOrUpdateStageLog(null, "GRPTSTCS: " + runthesetestcases.Count + " testcases", false);

                        /// max 100 testcases, assuming each testcase contains 2 transactions, so 200 transactions, each transaction takes 4 seconds
                        /// so in all 800 secs --> 800/60 minutes
                        /// update required 1000 secs

                        // if (ana.WaitforString("Processing completed successfully;", 1000) == 0)
                        if (!WaitAndHandleInternalRexxError("ANALYSIS GRPTSTCS", 60 * 60))
                            goto FINISH;
                        //if (ana.WaitforString("GRPTSTCS Processing Completed", 30 * 60) == 0)
                        //{
                        //    AddOrUpdateStageLog(null, "GRPTSTCS FAILED for " + runthesetestcases.Count, false);
                        //    //HandleError("ANALYSIS GRPTSTCS is taking more than 30 minutes to complete", ErrorTypes.NotifyandWait);
                        //    HandleError("ANALYSIS GRPTSTCS is taking more than 30 minutes to complete", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.INTERNAL_EXEC_ERROR);
                        //}

                    }


                    //for (int i = 0; i < 3; i++)
                    //{
                    if (RADVICEREQUIRED)
                    {
                        string radviceresponse = "";
                        ana.EnterCommand("ANALYSIS RADVICE " + VPARSID, 1);
                        if (ana.WaitforString("RADVICE CASES Created", 60 * 5, new List<string>() { "Advice Retrieval Not Required" }, out radviceresponse) == 1)
                        {
                            if (radviceresponse == "Advice Retrieval Not Required")
                            {
                                RADVICEREQUIRED = false;
                                //break;
                            }
                            else
                                if (!HandleError("ANALYSIS RADVICE taking too long, more than 5 minutes ", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.ANALYSIS_EXECS_ERROR))
                                goto FINISH;
                            //HandleError("ANALYSIS RADVICE taking too long, more than 5 minutes ", ErrorTypes.NotifyandWait);
                        }
                        else
                        {
                            for (int s = 0; s < 3; s++)
                            {
                                ana.EnterCommand("TPFZMS " + VPARSID + " RADVICE ZBURZ(NODISPLAY", 1);
                                if (ana.WaitforString("Ready;", 120) == 0)
                                {
                                    if (s == 2)
                                        //if (!HandleError("RADVICE ZBURZ not run in " + VPARSID + " even after 3 try.", ErrorTypes.NotifyandWait))
                                        if (!HandleError("RADVICE ZBURZ not run in " + VPARSID + " even after 3 try.", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.VM_TOOLS_ERROR))
                                            goto FINISH;
                                }
                                else
                                    break;
                            }

                            //if (!RunTestCase(new TestCase("RADVICE CASES", null, "ADVICE_RET", WELIST.Count), VPARSID, 30 * 60))
                            //    HandleError("Testcase RADVICE CASES running failed at " + VPARSID, ErrorTypes.LogOnly, ErrorGroup.BUCKET_EXECUTION_ERROR);
                        }
                        if (RADVICEREQUIRED)
                        {
                            ana.EnterCommand("ANALYSIS GLOBALV " + VPARSID + " ADVICE_RET", 1);
                            // AddOrUpdateStageLog(null, "Run RADVICE CASES", false);
                            AddOrUpdateStageLog(null, "RADVICE CASES", false);
                            for (int i = 0; i < 3; i++)
                            {

                                if (!RunTestCase(new TestCase("RADVICE CASES", null, "ADVICE_RET", WELIST.Count), VPARSID, 30 * 60))
                                    HandleError("Testcase RADVICE CASES running failed at " + VPARSID, ErrorTypes.LogOnly, ErrorGroup.BUCKET_EXECUTION_ERROR);
                                ana.EnterCommand("ANALYSIS CHECKADVCOUNT " + (WELIST.IndexOf(WE) - 1) + " " + VPARSID, 2);
                                if (ana.WaitforString("No More Advice Pending - All advice Cleared", 60 * 5, new List<string>() { "Advices Still in Queue" }, out radviceresponse) == 0)
                                {
                                    break;
                                }
                                else if (i == 2)
                                {
                                    HandleError("Advices still in queue, for iteration : " + (WELIST.IndexOf(WE) - 1), ErrorTypes.LogOnly);
                                }
                            }
                        }

                    }
                    //}


                    //AddOrUpdateStageLog(null, "Completed", false);
                    //AddOrUpdateStageLog("Cut tapes from " + VPARSID, "Started...", true);
                    AddOrUpdateStageLog(null, "Cut tapes from " + VPARSID, false);
                    bool tapecuttingresult = true;
                    testdata.Tapes = CutLogTapes(VPARSID, Tapes2Cut, testdata.Tapes, WELIST.IndexOf(WE), out tapecuttingresult);//Ref is not valid on indexer or property
                    //AddOrUpdateStageLog(null, "Done", false);
                    if (!tapecuttingresult)
                    {
                        goto FINISH;
                    }

                    if (WELIST.IndexOf(WE) == 1)    // for coderun
                    {
                        TestcasesToRun = "None"; DumpstoIsolate = "None";
                    }

                    if (WELIST.IndexOf(WE) >= 1)//Compare starts from Coderun Instance
                    {
                        //AddOrUpdateStageLog("Compare tape after: " + WE, "Started...", true);
                        AddOrUpdateStageLog(null, "Compare tapes", false);
                        bool compareresult = true;
                        testdata.TestCases = CompareTapes(testdata.TestCases, testdata.Tapes, WE, WELIST.IndexOf(WE), VPARSID, Anadata.BaseRunVpars, ref TestcasesToRun, ref DumpstoIsolate, ref PerformH14DEF, ref PerformDUMPSTAT, out compareresult);
                        // testdata.TestCases = CompareTapes(testdata.TestCases, testdata.Tapes, "XXX", 1, VPARSID, Anadata.BaseRunVpars, ref TestcasesToRun, ref DumpstoIsolate, ref PerformH14DEF, ref PerformDUMPSTAT, out compareresult);
                        if (!compareresult)
                            goto FINISH;
                        Tapes2Cut = string.Concat(
                                            testdata.TestCases.Where((tc, index) =>
                                            TestcasesToRun.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Contains((index + 1).ToString()) ||
                                            DumpstoIsolate.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Contains((index + 1).ToString()))
                                            .Select(tc => tc.Tape2Cut + ",").Distinct()).Trim(',');
                        AddOrUpdateStageLog("Still to run:", (TestcasesToRun + "," + DumpstoIsolate).Replace(",None", "").Replace("None,", ""), true);
                    }
                    //AddOrUpdateStageLog(null, "Done", false);
                }
                AddOrUpdateStageLog("Transfer files", "Started", true);
                //get Recreate Status here.
                ana.Pause(3);
                //SKD012417
                //ana.EnterCommand("ANALYSIS MSGFLD", 2);
                try
                {

                    ana.EnterCommand("ANALYSIS MSGFLD", 10);
                    ana.WaitforString("Processing completed successfully", 60);
                }
                catch (Exception ex)
                {
                    HandleError("ANALYSIS MSGFLD - Proper Response not found" + ex.Message, Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.ANALYSIS_EXECS_ERROR);
                }
                //SKD012417

                ////////////////////////////////////////// FETCH FILES ///////////////////////////////////////////////////////////////
                //5.	Upload the following files in the server after regression analysis which are needed for debugging issues. These used to be uploaded in the QTP version but this is currently not being done in the C# code.
                //a.	RECREATE STATUS
                //b.	MM TXT
                //c.	MISMATCH LIST
                //d.	ANALYSIS LOG
                //e.	DUMP STATUS
                //f.	DUMPS UNIQUE
                //g.	DUMP LIST
                //Priority 1

                debugdtd(Anadata.CodeRunVpars);//Saumen021417
                UploadAnalysisFiles();//Saumen020617
                UploadRexxErrorLog();
                AddOrUpdateStageLog(null, "Done", false);
                AddOrUpdateStageLog("Create and save Analysis email", "Started...", true);
                CreateResultTable(Anadata, testdata);
                ana.EnterCommand("ERASE DUMPS UNIQUE A1", 1);
                ana.EnterCommand("ERASE COPYTAPE LOG A1", 1);
                try
                {
                    if (((App)App.Current).IsVIPTESTENGMember)
                        sendTBFMail(Runsettings, new string[] { "VIPTestEnggLeadership@visa.com", "PRadykar@visa.com", "VIPQAAutomation@visa.com" , "VIPTestSystemSupp@visa.com" });//Saumen031317
                }
                catch { }

                AddOrUpdateStageLog(null, "Done", false);
                #endregion
                ////// perform Preliminary analysis
                try
                {
                    AddOrUpdateStageLog("Preliminary Analysis", "Running...", true);
                    PreliminaryAnalysis prelim = new PreliminaryAnalysis(Anadata.RegServer);
                    prelim.CalculateAnalysisScore();

                    System.IO.File.AppendAllLines(System.IO.Path.Combine(Runsettings.CoderunServer, "Preliminary Analysis-coderun.txt"), prelim.printChecks());

                    if (prelim.AreChecksValid())
                        System.IO.File.Create(System.IO.Path.Combine(Runsettings.CoderunServer, ".ResultCanBeDistributed")).Dispose();

                    //BMOLYNEA041017
                    try
                    {
                        JiraJson.DAReportTicket(DateTime.Parse(Anadata.InstallDate).ToString(), Runsettings.CoderunServer);
                    }
                    catch (Exception e)
                    {
                        JiraJson.WriteLog(e.ToString());
                    }
                    //BMOLYNEA041017 END

                    AddOrUpdateStageLog(null, "Done.", false);
                }
                catch (Exception ex)
                {
                    System.IO.File.WriteAllText(System.IO.Path.Combine(Anadata.RegServer, ex.GetHashCode() + ".exception"), ex.ToString());
                    AddOrUpdateStageLog("Preliminary Analysis", "Failed", false);
                }
                AnalysisSuccessful = true;
                FINISH:
                /// remove the log 
                if (App.debuggingFilePaths.ContainsKey(ana.screenshotfile))
                    App.debuggingFilePaths.Remove(ana.screenshotfile);

                // Fire the Analysis completed event
                if (OnAnalysisCompleted != null)
                    OnAnalysisCompleted();
                App.InputObj = null;
                IsIdle = true;
            }
            catch (TaskCanceledException)
            {
            }
            catch (ThreadAbortException)
            {

            }
            catch (Exception ex)
            {
                //Saumen012617 - removed stacktrace to get the whole exception information
                //System.IO.File.WriteAllText(Anadata.RegServer + @"\unherr_analysis.dbg", ex.StackTrace);
                File.WriteAllText(Anadata.RegServer + @"\unherr_analysis.dbg", ex.ToString());
                //Saumen012617
                HandleError("Unhandled error:" + ex.Message, Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyAndLog, ErrorGroup.UNHANDLED_ERROR);
                if (!Anadata.IsSchedulerAnalysis)
                    MessageBox.Show("This is an unhandled error during analysis.\n" + ex.Message, "ARCHES window-" + ana.SessionShortName);
            }
            finally
            {
                //Finishing Regression
                // Store the screenshot file into coderun server
                try
                {
                    System.IO.File.Copy(ana.screenshotfile, System.IO.Path.Combine(Anadata.RegServer, System.IO.Path.GetFileName(ana.screenshotfile)), true);
                    //System.IO.File.Delete(ana.screenshotfile);
                }
                catch (Exception) { }

                //
                IsIdle = true;
                try
                {
                    TimerThread.Abort();
                }
                catch (Exception)
                {

                }
                AnalysisThread = null;
                TimerThread = null;
                ButtonContent = "Start";
            }
        }

        //Saumen020617
        private void UploadAnalysisFiles()
        {
            try
            {
                System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "Recreate Status.txt"));
                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "Recreate Status.txt"), "RECREATE STATUS A1");

                System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "MM TXT.txt"));
                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "MM TXT.txt"), "MM TXT A1");

                System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "MISMATCH LIST.txt"));
                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "MISMATCH LIST.txt"), "MISMATCH LIST A1");

                System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "ANALYSIS LOG.txt"));
                //ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "ANALYSIS LOG.txt"), "ANALYSIS LOG A1");
                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "ANALYSIS LOG.txt"), "ANALYSIS LOG Z1");//Saumen022717

                System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "Dump Status.txt"));
                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "Dump Status.txt"), "DUMP STATUS A1");

                //System.IO.File.Delete(System.IO.Path.Combine(Anadata.WorkingFolderPath, Anadata.VMId + "_DUMPS UNIQUE.txt"));
                //ana.ReceiveFile(System.IO.Path.Combine(Anadata.WorkingFolderPath, Anadata.VMId + "_DUMPS UNIQUE.txt"), "DUMPS UNIQUE A1");

                System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "DUMP LIST.txt"));
                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "DUMP LIST.txt"), "DUMP LIST A1");

                System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "MSGFLD LIST.txt"));
                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "MSGFLD LIST.txt"), "MSGFLD LIST A1");
                //Progress Listing file
                System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "Progress Listing.txt"));
                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "Progress Listing.txt"), "PROGRESS LISTING A1");

                System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "PROGRESS LISTING.txt"));
                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "PROGRESS LISTING.txt"), "PROGRESS LISTING A1");

                System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "ANALYSIS_TRANLOG.txt"));//Saumen021417
//Moumita031017                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "ANALYSIS_TRANLOG.txt"), "ANALYSIS TRANLOG A1");//Saumen021417
                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "ANALYSIS_TRANLOG.txt"), "GRPT OUTPUT Z1");//Moumita031017
                System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "ANALYSIS_STATLOG.txt"));//Moumita031017
                ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "ANALYSIS_STATLOG.txt"), "GRPT STATLOG Z1"); //Moumita031017

            }
            catch (Exception)
            {
            }
        }

        private void UploadRexxErrorLog()
        {
            if (this.IsLoggedon)
            {
                try
                {
                    string tmpfilepath = Path.GetTempFileName();
                    ana.ReceiveFile(tmpfilepath, "QACTREXX ERRLOG   A1");
                    File.Copy(tmpfilepath, Path.Combine(Anadata.RegServer, "QACTREXX_ERRLOG_analysis.txt"), true);
                    if (!File.Exists(Path.Combine(App.AutomationFiles, "QACTREXX_ERRLOG_analysis.txt")))
                        File.WriteAllLines(Path.Combine(App.AutomationFiles, "QACTREXX_ERRLOG_analysis.txt"), File.ReadAllLines(tmpfilepath));
                    else
                        File.AppendAllLines(Path.Combine(App.AutomationFiles, "QACTREXX_ERRLOG_analysis.txt"), new List<string>() { new string('-', 100), Anadata.RegServer, new string('-', 100) }.Concat(File.ReadAllLines(tmpfilepath)));
                    File.Delete(tmpfilepath);
                }
                catch { };
            }
        }
        private bool WaitAndHandleInternalRexxError(string Step, int maxwaittimeinsec)
        {
            string errStr = String.Empty;
            if (ana.WaitforString("Processing completed successfully", maxwaittimeinsec, RegressionErrors.INTERNALREXXERRORS.Select(err => err.Key).ToList(), out errStr) != 0)
            {
                ErrorTypes errtyp;
                if (string.IsNullOrEmpty(errStr))
                {
                    errtyp = Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait;
                    errStr = "Timed out";
                }
                else
                {
                    errtyp = RegressionErrors.INTERNALREXXERRORS.First(err => err.Key == errStr).Value;
                    errStr = getexacterrorfromscreen(errStr);
                }
                return HandleError(Step + " error:" + errStr, errtyp, ErrorGroup.ANALYSIS_EXECS_ERROR);
            }
            else
                return true;
        }

        private void sendTBFMail(RunSettings RunSett, IEnumerable<string> To)
        {
            List<string> files = new List<string>(new string[] { System.IO.Path.Combine(Anadata.RegServer, "Recreate Status.txt") });

            Regex toCheck = new Regex(@"(-\s+TBF\s*)");

            if (!files.All(fl => System.IO.File.Exists(fl)) || !toCheck.IsMatch(File.ReadAllText(System.IO.Path.Combine(Anadata.RegServer, "Recreate Status.txt"))))
            {
                return;
            }

            string Subject = (RunSett.VIPS.Where(v => v.VPARS != "").Count() + " VIP " + RunSett.RegType) + " Regression for " + RunSett.InstallDate + " install " + (String.IsNullOrWhiteSpace(RunSett.SwitchActivationInfo) || RunSett.SwitchActivationInfo.Equals("N/A", StringComparison.CurrentCultureIgnoreCase) ? null : RunSett.SwitchActivationInfo + " Switch Activated") + "(" + RunSett.RunNumber + ")";
            Subject = "TBF items " + Subject;

            //////////////////////////// Add TBF items to a CSV file ////////////////////////////////
            try
            {
                string newTBFRow = String.Join(",", new string[] { Subject, DateTime.UtcNow.ToString(@"MM/dd/yyyy hh:mm:ss tt"), RunSett.CoderunServer, "Open" });
                System.IO.File.AppendAllLines(App.CSV_TBF_File, new string[] { newTBFRow });
            }
            catch { }
            //////////////////////////////////////////// Create the Outlook application ////////////////////////////////////////
            Outlook.Application oApp = new Outlook.Application();
            //////////////////////////////////////////// Create a new mail item ////////////////////////////////////////////////
            Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

            ////////////////////////////////////////// Message HTMLBody ////////////////////////////////////////////////////////
            oMsg.HTMLBody = "<h3>TBF items in the RUN</h3>"
                            + "<a href=\"" + System.IO.Path.Combine(RunSett.CoderunServer, "Recreate Status.txt") + "\"><b>Recreate Status</b></a>"
                            + System.IO.File.ReadAllText(System.IO.Path.Combine(RunSett.CoderunServer, "Analysis Result.html"));

            ////////////////////////////////////////////// ADD ATTACHMENTs /////////////////////////////////////////////////////
            //files.ForEach( filePath => {
            //    oMsg.Attachments.Add(
            //            filePath
            //            , Outlook.OlAttachmentType.olByValue
            //            , oMsg.Body.Length + 1
            //            , System.IO.Path.GetFileName(filePath)
            //        );
            //});
            //String sDisplayName = "MyAttachment";
            //int iPosition = (int)oMsg.Body.Length + 1;
            //int iAttachType = (int)Outlook.OlAttachmentType.olByValue;
            ////now attached the file
            //Outlook.Attachment oAttach = oMsg.Attachments.Add(@"C:\\fileName.jpg", iAttachType, iPosition, sDisplayName);

            ////////////////////////////////////////////// Subject line /////////////////////////////////////////////////////
            oMsg.Subject = Subject;
            //
            /* BMOLYNEA030717 */
            try
            {
                JiraJson.FilePath(RunSett.CoderunServer);//BMOLYNEA033017
                JiraJson.RegSubject = Subject;
                JiraJson.TBFOpenTicket(System.IO.Path.Combine(RunSett.CoderunServer, "Recreate Status.txt"));
            }
            catch { }
            /* END BMOLYNEA030717 */
            //
            ///////////////////////////////////////////// Add recipients ///////////////////////////////////////////////////
            Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
            To.ToList().ForEach(eachTo => { oRecips.Add(eachTo); });
            //Outlook.Recipient oRecip = 

            oRecips.ResolveAll();
            /////////////////////////////////////////////// Send Message ////////////////////////////////////////////////////
            ((Outlook._MailItem)oMsg).Send();
        }

        private bool CreateMismatchList(AnalysisData anadata, ref bool PerformH14DEF, ref bool PerformDUMPSTAT)
        {
            //ana.EnterCommand("REIPL 96M", 2);
            ana.EnterCommand("DEF STOR 1T");
            ana.WaitforString("Ready", 5);
            Regex maxsizeregex = new Regex(@"maximum\s+\((?<MAX>\w+)\)");
            var max = ana.GetLines(5).FirstOrDefault(l => maxsizeregex.IsMatch(l));
            ana.EnterCommand("REIPL " + (max == null ? "96M" : maxsizeregex.Match(max).Groups["MAX"].Value), 1);
            //ana.EnterCommand("GET TESTCASE", 1);
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                ana.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            ana.EnterCommand("GET VIPQAAUT", 1);//Saumen021417
            /////////////// z DISK ATTACHMENT FOR Autoregs ////////////////
            //ana.EnterCommand("GETD TEMP 540CYL Z", 2);
            ana.EnterCommand("GETD TEMP 1080CYL Z", 2);//Saumen022717

            //Start of SKD04142017

            if (ana.WaitforString("Ready;", 5 * 60) == 0)   // WaitforString will wait for 300 secs so that it will get the ready response within thye time framne
            {
                // Tried once again to attach 
                ana.EnterCommand("GETD TEMP 1080CYL Z", 2);//Saumen022717
                if (ana.WaitforString("Ready;", 5 * 60) == 0)
                {
                    HandleError("Not Able to Attch Z disk", ErrorTypes.NotifyandAbort, ErrorGroup.VM_ERROR);
                }
            }

            ana.EnterCommand("ERASE DUMP STATUS A1", 1);
            ana.WaitforString("Ready", 60);

            ana.EnterCommand("ERASE DUMPS UNIQUE A1", 1);
            ana.WaitforString("Ready", 60);

            ana.EnterCommand("ERASE FALLBACK LOG A1", 1);
            ana.WaitforString("Ready", 60);

            ana.EnterCommand("ERASE COPYTAPE LOG A1", 1);
            ana.WaitforString("Ready", 60);

            ana.EnterCommand("ERASE ANALYSIS LOG a1", 1);
            ana.WaitforString("Ready", 60);

            ana.EnterCommand("ERASE * OUTPUT ", 1);
            ana.WaitforString("Ready", 60);

            ana.EnterCommand("ERASE * STATLOG ", 1);
            ana.WaitforString("Ready", 60);

            ana.EnterCommand("ERASE QACTREXX ERRLOG   A1", 1);
            ana.WaitforString("Ready", 60);

            //ana.EnterCommand("ERASE TEST DATA A1", 1);
            ana.EnterCommand("ERASE PROGRESS LISTING A1", 1);
            ana.WaitforString("Ready", 60);

            //ana.EnterCommand("RENAME ANALYSIS EXEC A1 ANALYSIS BAK" + DateTime.Now.ToString("MMdd") + " A1");//Saumen022517
            ana.EnterCommand("ERASE PRODREGG SUMMARY A1", 1);//Saumen022717
            ana.WaitforString("Ready", 60);

            //End of SKD04142017 - WaitforString with Ready has been added 
            ana.SendFile(anadata.RegServer + "\\DUMPS_UNIQUE.txt", "DUMPS UNIQUE A1");

            AddOrUpdateStageLog("ANALYSIS H14GEN", "Started...", true);
            ana.EnterCommand("ANALYSIS H14GEN " + anadata.RegBucket, 1);

            if (WaitAndHandleInternalRexxError("ANALYSIS H14GEN", 5 * 60) == false)
                return false;

            //if (ana.WaitforString("does not exist", 5) == 0) //if doesnot exist found then
            //    ana.WaitforString("Ready", 5 * 60);
            ////ana.WaitforString("Processing completed successfully;", 5 * 60);
            //else
            //    PerformH14DEF = false;

            //Check if DUMPSTAT is required
            ana.EnterCommand("LISTFILE DUMPS UNIQUE A1", 1);
            if (ana.WaitforString("File not found", 2) != 0)
                PerformDUMPSTAT = false;
            else
            {
                ana.EnterCommand("TPFPROC OLDRLOAD " + anadata.CodeRunVpars + " " + App.DUMPINITTAPE, 1);
                ana.WaitforString("Ready;", 2 * 60);
            }
            AddOrUpdateStageLog(null, "Done", false);

            AddOrUpdateStageLog("AUTOSAVE/AUTODRB", "Started...", true);
            if (anadata.RegBucket.Contains("DRB"))
                ana.EnterCommand("AUTODRB", 1);
            else
                ana.EnterCommand("AUTOSAVE", 1);
            //string saveerror = "";
            if (!WaitAndHandleInternalRexxError("AUTOSAVE/AUTODRB", 3 * 60 * 60))
            {
                AddOrUpdateStageLog(null, "Failed.", false);
                return false;
            }
            else
                AddOrUpdateStageLog(null, "Done.", false);
            //if (ana.WaitforString("Processing completed successfully;", 3 * 60 * 60, RegressionErrors.AUTOSAVE_ERRORS, out saveerror) == 1) ///Autosave delay increased to 3 hours
            //if (ana.WaitforString("AUTOSAVE EXECUTION IS COMPLETE", 3 * 60 * 60, RegressionErrors.AUTOSAVE_ERRORS, out saveerror) == 1) ///Autosave delay increased to 3 hours
            //{
            //    //Handle autosave errors.
            //    //if (!HandleError("AUTOSAVE EXECUTION failed." + saveerror, ErrorTypes.NotifyandWait))
            //    if (!HandleError("AUTOSAVE EXECUTION failed." + saveerror, Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.INTERNAL_EXEC_ERROR))
            //    {
            //        AddOrUpdateStageLog(null, "Failed.", false);
            //        return false;
            //    }
            //    else
            //        AddOrUpdateStageLog(null, "Done.", false);
            //}
            //AddOrUpdateStageLog(null, "Successful", false);
            // Write Transaction Data table
            AddOrUpdateStageLog("Transaction Data Table write", "Started...", true);
            ana.EnterCommand("ERASE TRAN DATATBL A1", 1);
            ana.EnterCommand("ANALYSIS WRITETRANDATA", 1);

            if (!WaitAndHandleInternalRexxError("ANALYSIS WRITETRANDATA", 5 * 60))
            {
                AddOrUpdateStageLog(null, "Failed.", false);
                return false;
            }
            else
                AddOrUpdateStageLog(null, "Done.", false);

            ////if (ana.WaitforString("Processing completed successfully;", 5 * 60) == 0)
            //if (ana.WaitforString("TRANSACTION DATA TABLE IS CREATED SUCCESSFULLY", 5 * 60) == 0)
            //{
            //    //if (!HandleError("Transaction Data Table write failed.", ErrorTypes.NotifyandWait))
            //    if (!HandleError("Transaction Data Table write failed.", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.INTERNAL_EXEC_ERROR))
            //    {
            //        AddOrUpdateStageLog(null, "Failed.", false);
            //        return false;
            //    }
            //    else
            //        AddOrUpdateStageLog(null, "Done.", false);
            //}
            //else
            //    AddOrUpdateStageLog(null, "Successful", false);
            //Transfer the created file
            System.IO.File.Delete(System.IO.Path.Combine(Anadata.RegServer, "Transaction Data Table.csv"));
            ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, "Transaction Data Table.csv"), "TRAN DATATBL A1");
            // Create the the files to be FTPED during Analysis

            ana.EnterCommand("ANALYSIS BUILDCDB " + Anadata.FTPFiles.Replace(",", " "), 1);
            WaitAndHandleInternalRexxError("ANALYSIS BUILDCDB", 5 * 60);
            // ana.WaitforString("TAG/CDB file creation completed", 5 * 60);
            //ana.WaitforString("Processing completed successfully;", 5 * 60);

            ana.EnterCommand("ANALYSIS BUILDCUP " + Anadata.CUPTapes, 1);

            WaitAndHandleInternalRexxError("ANALYSIS BUILDCUP", 5 * 60);
            var cupline = ana.GetLines(50).FirstOrDefault(l => l.Contains("CUPTAPE:"));
            if (cupline != null)
            {
                if (new Regex(@"(?<cuptape>CUPTAPE:\w*)").IsMatch(cupline))
                    Anadata.CupTapeToUplaod = new Regex(@"(?<cuptape>CUPTAPE:\w*)").Match(cupline).Groups["cuptape"].Value.Replace("CUPTAPE:", null);
            }
            //string error = null;
            //if (ana.WaitforString("CUPTAPE:", 5 * 60, new List<string>() { "Ready" }, out error) == 0)
            //{
            //    var cupline = ana.GetLines(50).FirstOrDefault(l => l.Contains("CUPTAPE:"));
            //    Anadata.CupTapeToUplaod = cupline != null ? cupline.Replace("CUPTAPE:", null).Trim() : null;
            //}

            //
            //ana.EnterCommand("ERASE ANALYSIS LOG", 1);
            AddOrUpdateStageLog("CHKMODE", "Started...", true);
            ana.EnterCommand("ANALYSIS CHKMODE ", 1);
            if (!WaitAndHandleInternalRexxError("ANALYSIS CHKMODE", 20 * 60))
            {
                AddOrUpdateStageLog(null, "Failed.", false);
                return false;
            }
            else
                AddOrUpdateStageLog(null, "Done.", false);
            //string chkmodeerror = "";
            ////if (ana.WaitforString("Processing completed successfully;", 20 * 60, RegressionErrors.CHKMODE_ERRORS, out chkmodeerror) == 1)
            //if (ana.WaitforString("CHKMODE Processing Completed", 20 * 60, RegressionErrors.CHKMODE_ERRORS, out chkmodeerror) == 1)
            //{
            //    //if (!HandleError("CHKMODE EXECUTION failed.", ErrorTypes.NotifyandWait))
            //    if (!HandleError("CHKMODE EXECUTION failed.", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.INTERNAL_EXEC_ERROR))
            //    {
            //        AddOrUpdateStageLog(null, "Failed.", false);
            //        return false;
            //    }
            //    else
            //        AddOrUpdateStageLog(null, "Done.", false);
            //}
            AddOrUpdateStageLog(null, "Successful", false);
            ana.EnterCommand("ANALYSIS VTAPECUT ", 1);
            // ana.WaitforString("Ready;", 10);
            WaitAndHandleInternalRexxError("ANALYSIS VTAPECUT", 10);
            ana.EnterCommand("ANALYSIS CMMTXT", 1);
            //ana.WaitforString("Ready;", 10);
            WaitAndHandleInternalRexxError("ANALYSIS CMMTXT", 10);
            // ERASE PARSERR CASES before calling ANALYSIS RECREATE for the very first time. 
            ana.EnterCommand("ERASE PARSERR CASES A1", 1);

            ana.EnterCommand("ANALYSIS RECREATE -1", 1);
            WaitAndHandleInternalRexxError("ANALYSIS RECREATE -1", 60);
            // ana.WaitforString("Ready;", 60);
            //ana.WaitforString("Processing completed successfully;", 60);

            if (PerformDUMPSTAT)
            {
                ana.EnterCommand("DUMPSTAT -1 " + Anadata.BaseRunVpars + " " + Anadata.CodeRunVpars, 1);
                WaitAndHandleInternalRexxError("DUMPSTAT -1", 60);
                //ana.WaitforString("Ready;", 10);
                // ana.WaitforString("Processing completed successfully;", 10);
            }
            return true;
        }

        private List<TestCase> CompareTapes(List<TestCase> Testcases, List<Tape> tapes, string WE, int IndexofWE, string CodeVPARS, string BaseVpars, ref string TestcasesToRun, ref string DumpstoIsolate, ref bool PerformH14DEF, ref bool PerformDUMPSTAT, out bool result)
        {
            result = true;
            foreach (var tape in tapes)
            {
                string basetape, codetape;
                if (IndexofWE == 1)
                {
                    basetape = tape.TapeNumbers[0]; codetape = tape.TapeNumbers[1];
                    if (PerformH14DEF && tape.TapeType == "DTD")
                    {
                        ana.EnterCommand("ERASE H14DEF REPORT A1", 1);
                        ana.EnterCommand("H14DEF " + basetape + " " + codetape, 1);
                        ana.WaitforString("Ready", 3 * 60);
                    }
                }
                else
                {
                    basetape = tape.TapeNumbers[IndexofWE]; codetape = tape.TapeNumbers[IndexofWE - 1];
                    if (PerformH14DEF && tape.TapeType == "DTD")
                    {
                        ana.EnterCommand("ANALYSIS H14STATUS", 1);
                        if (ana.WaitforString("Pending H14 Mismatches - Perform H14DEF", 5) != 0)
                        {
                            ana.EnterCommand("ERASE H14DEF REPORT A1", 1);
                            ana.EnterCommand("H14DEF " + basetape + " " + codetape, 1);
                            ana.WaitforString("Ready", 3 * 60);
                        }
                        else
                            PerformH14DEF = false;
                    }
                }
                //Now the Compnew Logic
                ana.EnterCommand("ERASE COMPARE * A1", 1);
                if (basetape != "NA" && codetape != "NA")
                {
                    string compareresult = "";
                    if (TestcasesToRun == "None" && IndexofWE > 1)
                        goto SKIPCOMPARE;
                    //Start  of Compare
                    ana.EnterCommand("COMPNEW " + basetape + " " + codetape + " (QTP", 5);
                    if (ana.WaitforString("MsgNo Format  Dest   Srce  MTI", 10 * 60, RegressionErrors.CompareErrors, out compareresult) == 1)
                    {
                        if (compareresult == "PARSEM news and status")
                        {
                            ana.SendText(Keys3270.PF3);
                        }
                        else
                        {
                            if (compareresult == "No records to compare!")
                            {
                                goto SKIPCOMPARE;
                            }
                            if (!string.IsNullOrWhiteSpace(compareresult))
                            {
                                if (!HandleError("Compare not successful -->Error:" + getexacterrorfromscreen(compareresult), Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.TAPE_COMPARISON_ERROR))
                                {
                                    result = false;
                                    return Testcases;
                                }
                            }
                            //if (!HandleError("Compare not successful --> Taking More Than 10 minutes", ErrorTypes.NotifyandWait))
                            else if (!HandleError("Compare not successful --> Taking More Than 10 minutes", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.TAPE_COMPARISON_ERROR))
                            {
                                result = false;
                                return Testcases;
                            }
                        }
                    }
                    if (ana.WaitforString("MsgNo Format  Dest   Srce  MTI", 5) != 0)
                    {
                        ana.SendText(Keys3270.PF3);
                        ana.WaitforString("Ready;", 10);
                    }
                    ana.EnterCommand("ANALYSIS RECREATE " + (IndexofWE - 1) + (IndexofWE == 1 ? null : " " + (WE.ToUpper().Contains("SWITCH") ? WE.Replace(" ", "") : WE)), 2);
                    string recreateStatus = "";
                    if (ana.WaitforString("Mismatches successfully isolated:", 45 * 60, RegressionErrors.ANALYSIS_RECREATE_ERRORS, out recreateStatus) == 0)//tempfix to increase wait time from 20 to 45 mins
                    {

                        //Get the screen and process accordingly
                        WaitAndHandleInternalRexxError("ANALYSIS RECREATE " + (IndexofWE - 1), 20);
                        //ana.WaitforString("Ready;", 10);
                        //ana.WaitforString("Processing completed successfully;", 10);
                        //ana.Pause(2);
                        var screenlines = ana.GetLines(30);
                        //Now consider more than one line of testcases numbers
                        int mmrecisolatedinthisiteration = screenlines.IndexOf(screenlines.First(l => l.Contains("Mismatch Recreated/Isolated in this iteration:")));
                        int mmrectobeisolated = screenlines.IndexOf(screenlines.First(l => l.Contains("Mismatches Recreated (to be isolated):")));
                        int mmisolated = screenlines.IndexOf(screenlines.First(l => l.Contains("Mismatches successfully isolated:")));



                        // int startindex = screenlines.IndexOf(screenlines.First(l => l.Contains("Mismatches successfully isolated:")));



                        string recreatedinthisiterationmm = string.Concat(screenlines.GetRange(mmrecisolatedinthisiteration + 1, mmrectobeisolated - mmrecisolatedinthisiteration - 1).Select(l => l.Trim())).Trim();//screenlines[startindex + 1].Trim();

                        TestcasesToRun = string.Concat(screenlines.GetRange(mmrectobeisolated + 1, mmisolated - mmrectobeisolated - 1).Select(l => l.Trim())).Trim();//screenlines[startindex + 3].Trim();
                        TestcasesToRun = String.IsNullOrWhiteSpace(TestcasesToRun) ? "None" : TestcasesToRun;

                        // string overallisolatedmm = screenlines[startindex + 5].Trim();
                        if (!String.IsNullOrWhiteSpace(recreatedinthisiterationmm))
                        {
                            if (IndexofWE == 1)//First Compare
                                foreach (var item in recreatedinthisiterationmm.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                                {
                                    Testcases[Convert.ToInt16(item) - 1].Status[IndexofWE] = MMRecreateStatus.Mismatch_recreated.ToString();
                                    ana.EnterCommand("COPY " + Testcases[Convert.ToInt16(item) - 1].TestCaseName + " Z1 " + Testcases[Convert.ToInt16(item) - 1].TestCaseName + " A1(APPEND", 1);
                                }
                            else// More Iterations
                            {
                                foreach (var item in recreatedinthisiterationmm.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                                {
                                    if (TestcasesToRun.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Contains(item))
                                        Testcases[Convert.ToInt16(item) - 1].Status[IndexofWE] = MMRecreateStatus.Mismatch_Isolated_Partly.ToString();
                                    else
                                        Testcases[Convert.ToInt16(item) - 1].Status[IndexofWE] = MMRecreateStatus.Mismatch_Isolated_Fully.ToString();
                                }
                            }
                            //ana.EnterCommand("pipe literal COMPNEW " + basetape + " " + codetape + " (QTP | >> ANALYSIS LOG  A1", 1);
                            ana.EnterCommand("pipe literal COMPNEW " + basetape + " " + codetape + " (QTP | >> ANALYSIS LOG  Z1", 1);//Saumen022717
                            //Exceeding two lines of command. break the old command in two lines
                            //ana.EnterCommand("pipe literal ==> Mismatch Recreated/Isolated in this iteration: | >> ANALYSIS LOG  A1", 1);
                            ana.EnterCommand("pipe literal ==> Mismatch Recreated/Isolated in this iteration: | >> ANALYSIS LOG  Z1", 1);//Saumen022717
                            //Still thinking that the next command will not exceede 2 lines.
                            //ana.EnterCommand("pipe literal " + recreatedinthisiterationmm + " | >> ANALYSIS LOG  A1", 1);
                            ana.EnterCommand("pipe literal " + recreatedinthisiterationmm + " | >> ANALYSIS LOG  Z1", 1);//Saumen022717
                        }
                        else
                            ana.EnterCommand("SENDCMD " + CodeVPARS + " ZCP VTSET " + basetape + " KE 0", 2);
                    }
                    else
                    {
                        if (string.IsNullOrWhiteSpace(recreateStatus))
                        {
                            recreateStatus = "Timed-out(10 Minutes)";
                        }
                        if (recreateStatus == "Interesting Case")
                        {
                            //just log the errors
                            HandleError("Intreresting Case:Tapes-" + basetape + " " + codetape, ErrorTypes.LogOnly, ErrorGroup.NO_ERROR);
                        }
                        else
                        {
                            if (HandleError("ANALYSIS RECREATE : " + basetape + " " + codetape + " Error-" + recreateStatus, ErrorTypes.NotifyandAbort, ErrorGroup.ANALYSIS_EXECS_ERROR) == false)
                            {
                                result = false;
                                return Testcases;
                            }

                            //Handle Other errors here
                            if (IndexofWE > 1)
                                ana.EnterCommand("SENDCMD " + CodeVPARS + " ZCP VTSET " + basetape + " KE 0", 2);
                        }

                    }
                    //End of Compare
                    ////////////////////////////////// Anlysis Mask table //////////////////////////////////
                    if (IndexofWE - 1 == 0)
                    {
                        if (((App)App.Current).IsVIPTESTENGMember && Runsettings.IsRegularServerPath)
                        {
                            string analysisMaskArgs = Anadata.InstallDate.Replace("/", "").Substring(0, 4) + ' ' + Anadata.RegType + ' ' + Anadata.RunNumber;
                            ana.EnterCommand("ANALYSIS MASK WRITE " + analysisMaskArgs, 3);
                            WaitAndHandleInternalRexxError("ANALYSIS MASK WRITE", 2 * 60);
                        }
                        //if (ana.WaitforString("Processing completed successfully;", 60) == 0)
                        //if (ana.WaitforString("MASK TABLE Write processing completed", 60) == 0)
                        //{
                        //    //ErrorsInRun.InsertRange(0, ana.GetLines(50));
                        //    //ErrorsInRun.Insert(0, "Entered Command ==> ANALYSIS MASK WRITE " + Anadata.InstallDate.Replace("/", "").Substring(0, 4));
                        //    HandleError("Analysis Mask write has failed", ErrorTypes.NotifyAndLog, ErrorGroup.INTERNAL_EXEC_ERROR);              // log the error
                        //}
                    }
                ///////////////////////////////////////////////////////////////////////////////////////////

                SKIPCOMPARE:
                    //Now do the dump analysis only if tape=DTD
                    if (tape.TapeType == "DTD" && PerformDUMPSTAT)
                    {
                        ana.EnterCommand("DUMPSTAT " + (IndexofWE - 1) + (IndexofWE == 1 ? " " + BaseVpars + " " + CodeVPARS : " " + CodeVPARS + " " + WE), 1);
                        if (ana.WaitforString("Dumps Recreated/Isolated in this iteration:", 10, RegressionErrors.ANALYSIS_RECREATE_ERRORS, out recreateStatus) == 0)
                        {
                            //Get the screen and process accordingly
                            WaitAndHandleInternalRexxError("DUMPSTAT " + (IndexofWE - 1), 20);
                            //ana.WaitforString("Ready;", 5);
                            //ana.WaitforString("Processing completed successfully;", 5);
                            var screenlines = ana.GetLines(20);
                            int startindex = screenlines.IndexOf(screenlines.First(l => l.Contains("Dumps Recreated/Isolated in this iteration:")));

                            string recreatedinthisiterationmm = screenlines[startindex + 1].Trim();
                            DumpstoIsolate = screenlines[startindex + 3].Trim();
                            DumpstoIsolate = DumpstoIsolate == "" ? "None" : DumpstoIsolate;
                            string overallisolatedmm = screenlines[startindex + 5].Trim();
                            if (recreatedinthisiterationmm != "" || recreatedinthisiterationmm != "None")
                            {
                                if (IndexofWE == 1)//First Compare
                                    foreach (var item in recreatedinthisiterationmm.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                                    {
                                        Testcases[Convert.ToInt16(item) - 1].Status[IndexofWE] = DUMPRecreateStatus.Dump_recreated.ToString();
                                        ana.EnterCommand("COPY " + Testcases[Convert.ToInt16(item) - 1].TestCaseName + " Z1 " + Testcases[Convert.ToInt16(item) - 1].TestCaseName + " A1(APPEND", 1);
                                    }
                                else// More Iterations
                                {
                                    foreach (var item in recreatedinthisiterationmm.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                                    {
                                        if (DumpstoIsolate.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Contains(item))
                                            Testcases[Convert.ToInt16(item) - 1].Status[IndexofWE] = DUMPRecreateStatus.Dump_Isolated_Partly.ToString();
                                        else
                                            Testcases[Convert.ToInt16(item) - 1].Status[IndexofWE] = DUMPRecreateStatus.Dump_Isolated_Fully.ToString();
                                    }
                                    ana.EnterCommand("SENDCMD " + CodeVPARS + " ZCP VTSET " + basetape + " KE 3", 2);
                                }
                                //ana.EnterCommand("pipe literal ==> Dumps Recreated/Isolated in this iteration:" + recreatedinthisiterationmm + " | >> ANALYSIS LOG  A1", 1);
                                ana.EnterCommand("pipe literal ==> Dumps Recreated/Isolated in this iteration:" + recreatedinthisiterationmm + " | >> ANALYSIS LOG  Z1", 1);//Saumen022717
                            }
                            if (DumpstoIsolate == "None")
                                PerformDUMPSTAT = false;
                        }
                        else
                        {
                            if (IndexofWE == 1)
                                PerformDUMPSTAT = false;
                        }
                    }
                }
            }
            if ((TestcasesToRun != "" && TestcasesToRun != "None") || (DumpstoIsolate != "" && DumpstoIsolate != "None"))
            {
                ana.EnterCommand("ANALYSIS TAPE2CUT " + ((TestcasesToRun.Replace("None", "") + ",") + DumpstoIsolate.Replace("None", "")).Trim(','), 1);
                WaitAndHandleInternalRexxError("ANALYSIS TAPE2CUT", 10 * 60);//Saumen031417
            }
            return Testcases;
        }
        private List<Tape> CutLogTapes(string VPARSID, string Tapes2Cut, List<Tape> Tapes, int IndexofWE, out bool result)
        {
            ana.EnterCommand("SENDCMD " + VPARSID + " ZKTSK STOP", 1);

            ana.EnterCommand("ERASE TAPE LOG A1", 1);

            result = true;
            // List<Tape> modifiedlistoftapes = Tapes;
            foreach (Tape tape in Tapes)
            {
                if (!Tapes2Cut.Contains(tape.TapeType))
                    ana.EnterCommand("PIPE LITERAL " + tape.TapeType + ":NA| >> TAPE LOG A1", 1);
                else
                {
                    ana.WaitforString("Ready", 20);
                    ana.EnterCommand("TPFPROC CUT" + tape.TapeType + " " + VPARSID + " SCR(NODISPLAY", 1);
                    string tapecuttingstatus = "";
                    if (ana.WaitforString("Ready;", 5 * 60, RegressionErrors.TapecuttingErrors, out tapecuttingstatus) == 1)//Saumen021417
                    {
                        //////////// FETCH CUTXXX TPFLOG file for debugging ////////////////
                        string cutxxx_tpflog = "CUT" + tape.TapeType + " TPFLOG";
                        ana.ReceiveFile(System.IO.Path.Combine(Anadata.RegServer, cutxxx_tpflog + " Run " + IndexofWE), cutxxx_tpflog);

                        if (string.IsNullOrWhiteSpace(tapecuttingstatus))
                            tapecuttingstatus = "Timed-out(5 minutes)";//Saumen021417
                        if (!HandleError(tape.TapeType + " not cut properly. Error:" + getexacterrorfromscreen(tapecuttingstatus), Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.TAPE_CUTTING_ERROR))
                        {
                            result = false;
                            return Tapes;
                        }

                        //if (tapecuttingstatus == "")//Nothing found
                        //{
                        //    ana.EnterCommand("b", 1);
                        //    if (ana.WaitforString("Ready;", 2 * 60, new List<string>() { "NOTHING TO DUMP", "Ready(", "End of TPF Procedure:  RC=-" }, out tapecuttingstatus) == 1)
                        //    {
                        //        if (tapecuttingstatus != "NOTHING TO DUMP")
                        //        {
                        //            //if (!HandleError(tape.TapeType + " not cut properly. Error:" + tapecuttingstatus, ErrorTypes.NotifyandWait))
                        //            //if (!HandleError(tape.TapeType + " not cut properly. Error:" + tapecuttingstatus, Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.TAPE_CUTTING_ERROR))
                        //            if (!HandleError(tape.TapeType + " not cut properly. Error:" + tapecuttingstatus, Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.TAPE_CUTTING_ERROR))
                        //            {
                        //                result = false;
                        //                return Tapes;
                        //            }
                        //        }

                        //    }
                        //}
                        //else
                        //{
                        //    //if (!HandleError(tape.TapeType + " not cut properly.", ErrorTypes.NotifyandWait))
                        //    if (!HandleError(tape.TapeType + " not cut properly.", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.TAPE_CUTTING_ERROR))
                        //    {
                        //        result = false;
                        //        return Tapes;
                        //    }
                        //}
                    }
                    //else
                    //{
                    ana.EnterCommand("REGP5VIP 4", 1);
                    int opt;
                    //For now implement only DTD/RSI/CSI
                    switch (tape.TapeType)
                    {
                        case "DTD":
                            opt = 4;
                            break;
                        case "RSI":
                            opt = 3;
                            break;
                        case "CSI":
                            opt = 1;
                            break;
                        default:
                            opt = 4; //Use DTD by default for Now
                            break;
                    }
                    ana.EnterCommand(opt + " " + VPARSID, 1, false);
                    if (ana.WaitforString("Tape Log Append Complete", 10) == 0)
                    {
                        //if (!HandleError(tape.TapeType + " not cut properly.", ErrorTypes.NotifyandWait))
                        if (!HandleError(tape.TapeType + " not cut properly.", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.TAPE_CUTTING_ERROR))
                        {
                            result = false;
                            return Tapes;
                        }
                    }
                    //}
                }
            }
            ana.EnterCommand("ANALYSIS COPYTAPE", 2);
            string receivedtapes = ana.GetLines(2, 2).FirstOrDefault().Trim();
            if (receivedtapes != null && receivedtapes.Trim() != "")//&& receivedtapes.Contains(';')
            {

                var splittedtapes = receivedtapes.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries).ToList();
                for (int i = 0; i < splittedtapes.Count; i++)
                {
                    Tapes[i].TapeNumbers[IndexofWE] = splittedtapes[i];
                }
                //foreach (var item in splittedtapes)
                //    Tapes[splittedtapes.IndexOf(item)].TapeNumbers[IndexofWE] = item;

                string ALibTapes = String.Join(" ", splittedtapes.Select(tapeNum => tapeNum.Trim().ToUpper())
                                                        .Where(tapeNum => tapeNum.First() == 'A')
                                                        .ToArray());

                string DLibTapes = String.Join(" ", splittedtapes.Select(tapeNum => tapeNum.Trim().ToUpper())
                                                        .Where(tapeNum => tapeNum.First() == 'D')
                                                        .ToArray());

                ana.EnterCommand("Sendcmd " + VPARSID + " ZCP VTSET " + ALibTapes + " KE 2", 1);
                if (!string.IsNullOrEmpty(DLibTapes))
                    ana.EnterCommand("Sendcmd " + VPARSID + " ZCP VTSET " + DLibTapes + " KE 2", 1);

                ana.EnterCommand("Sendcmd " + VPARSID + " ZKTSK STOP", 1);
            }

            return Tapes;
        }
        private bool RunTestCase(TestCase testcase, string VPARS, int timeoutseconds = 5 * 60)
        {
            bool result = true;
            //if (testcase.ExecutionMode == "DRB")
            //{
            //    //if (runmodes == null || !runmodes.Contains("DRB"))
            //    //    runmodes += testcase.ExecutionMode;
            //    ana.EnterCommand("FTPDRB " + VPARS + " " + testcase.TestCaseName + " Z1", 5);
            //    //Handle FTPDRB error for transaction not found case.
            //    if (ana.WaitforString("not found", 55) != 0)
            //        return true;
            //    ana.EnterCommand("SENDCMD " + VPARS + " ZKIJM ST CL 20150805", 2);
            //}
            //else
            {
                for (int tryc = 0; tryc < 3; tryc++)
                {
                    if (testcase.ExecutionMode == "ADVICE_RET")
                        ana.EnterCommand("PARSNEW " + testcase.TestCaseName + "(SEND", 2);
                    else
                        ana.EnterCommand("PARSNEW " + testcase.TestCaseName + " Z1 (SEND", 2);
                    if (ana.WaitforString("PARSEM Message Sending Options", 30) != 0)
                        break;
                    if (tryc == 2)
                    {
                        //Handle Error Here 
                        return false;
                    }
                }
                ana.SetFieldValue("ZDSID=", "Z");
                ana.Pause(1);
                ana.SendText(Keys3270.PF5);
                string runstatus = "";
                List<string> tcrunerrors = RegressionErrors.BucketRunErrors;
                tcrunerrors.Add("End of file, rc 0");
                if (ana.WaitforString("Message sending cancelled via STOP command", timeoutseconds, tcrunerrors, out runstatus) == 1)
                {
                    if (!runstatus.Equals("End of file, rc 0", StringComparison.CurrentCultureIgnoreCase))
                    {
                        //HandleError("Bucket run is taking too long, more than " + (int)timeoutseconds / 60 + " minutes", ErrorTypes.NotifyandWait);
                        HandleError("Bucket run is taking too long, more than " + (int)timeoutseconds / 60 + " minutes", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyAndLog : ErrorTypes.NotifyandWait, ErrorGroup.BUCKET_EXECUTION_TIMEOUT);
                        return false;
                    }
                }
                ana.WaitforString("Ready", 20);
                if (testcase.ExecutionMode == "STIP:ATR")
                    ana.Pause(20);

            }
            return result;
        }
        private bool Fallback(string WE, string VPARSID, string specialFB)
        {

            if (WE.ToUpper().Contains("SYS_DATE"))
            {
                try
                {
                    ana.EnterCommand("ANALYSIS FALLBACK SYS_DATE " + VPARSID + " 11.00.00 " + DateTime.ParseExact(Runsettings.BaserunSystemDate, "MM/dd/yyyy", null).ToString("MM/dd/yy"), 2);
                }
                catch (Exception)
                {
                    return false;
                }
            }
            else if (WE.ToUpper().Contains("SWITCH"))
            {
                ana.EnterCommand("ANALYSIS FALLBACK " + WE.Replace(' ', '-') + " " + VPARSID, 2);
            }
            else
            {
                ana.EnterCommand("ANALYSIS FALLBACK " + WE + " " + VPARSID, 2);
            }
            if (!WaitAndHandleInternalRexxError("ANALYSIS FALLBACK " + WE, 6 * 60))
            {
                return false;
            }
            //string fallbackstatus = "";
            ////if (ana.WaitforString("Processing completed successfully;", 300, RegressionErrors.FallbackErrors, out fallbackstatus, 0, false) == 1)
            //if (ana.WaitforString("WE Fallback Completed", 300, RegressionErrors.FallbackErrors, out fallbackstatus, 0, false) == 1)
            //{
            //    if (fallbackstatus == "Global Fallback Completed" || fallbackstatus == "Switch status changed")
            //    {
            //        //Fallback Successful
            //    }
            //    else//Handle Fallback Errors
            //    {
            //        return false;
            //    }

            //}
            else
            {
                if (specialFB != "NA")
                    ana.EnterCommand("TPFZMS " + VPARSID + " " + specialFB, 20);
                //ana.EnterCommand("PIPE LITERAL Fallback complete: " + WE + " | >> ANALYSIS LOG  A1", 1);
                ana.EnterCommand("PIPE LITERAL Fallback complete: " + WE + " | >> ANALYSIS LOG  Z1", 1);//Saumen022717
            }
            return true;
        }

        private bool SubmitAndTrackSetup(string SetupFile, string systemdate, bool forcefully_Logoff = false, int jobSchedulingAttempts = 5, int jobCompletionTime = 2 * 60 * 60)
        {
            string regexForDateTime = @"[0-1][0-9][./][0-3][0-9][./][0-9]{2}\s[0-2][0-9]\:[0-5][0-9]\:[0-5][0-9]";

            string regexForJobId = @"JOB[0-9]+";

            string regexForVMId = @"\w{3,9}";

            AddOrUpdateStageLog("Submit Setup:" + SetupFile.ToUpper() + " $TTVDATA", "Running...", true);           //Saumen082516

            Regex logonByRegex = new Regex(@"\s*(?<AutoregId>\b\w+\b)(\s+BY\s+)?(?<LoginId>\b\w+\b)?\s*", RegexOptions.IgnoreCase);
            string VMID = logonByRegex.Match(Anadata.VMId).Groups["AutoregId"].Value;

            //////////////////////////// Try Submitting the setup //////////////////////////////
            List<string> screen = new List<string>();
            bool Retry = false;
            DateTime ScheduledJobDateTime = new DateTime();
            do
            {
                /////////////////////////////////////// SET VTOD DATE ////////////////////////////////////
                ana.EnterCommand("SET VTOD DATE " + systemdate + " TIME 10:52:00", VMCommandTimeOut);
                ana.EnterCommand("I CMS", VMCommandTimeOut);
                ana.SendText(Keys3270.Enter);
                ana.WaitforString("Ready;", 2);
                //ana.EnterCommand("GET TESTCASE", VMCommandTimeOut);
                //GGIRDHAR030717 - Test Framework Enhancement
                if (InputFile.TestRun)
                {
                    ana.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
                }
                //GGIRDHAR030717 - Test Framework Enhancement
                ana.EnterCommand("GET VIPQAAUT", VMCommandTimeOut);//Saumen021417
                ana.EnterCommand("ERASE TESTKEYS CONTROL A1", VMCommandTimeOut);
                //////////////////////// Submit setup ////////////////////////
                ana.WaitforString("Ready", 2);
                //Saumen032817
                ana.EnterCommand("TPFSETUP " + SetupFile + " $TTVDATA A1 ( SUBMIT", 2);
                int loopcount = 0;
                while (ana.WaitforString("Ready", 10 * 60) == 0)//Saumen032917
                {
                    loopcount++;
                    ana.EnterCommand("B", 2);
                    if (loopcount >= 300)
                    {
                        HandleError("Job file NOT submitted properly", ErrorTypes.NotifyandAbort, ErrorGroup.TPFSETUP_ERROR);//Saumen031517
                    }
                }
                loopcount = 0;
                //ana.WaitforString("Ready", 60);
                ////// Now check the screen /////
                //screen.Clear();
                //do
                //{
                //    ana.Pause(1);
                screen.AddRange(ana.GetLines(99));//Saumen032917
                //    ana.SendText(Keys3270.Clear);
                //} while (!screen.Any(ln => ln.Contains("Ready")));
                //Saumen032817

                screen.RemoveAll(ln => ln.Contains("* MSG FROM") || ln.Contains("RDR FILE"));          // remove improper lines

                // Job file submitted                                                   
                // OR PRODD18 PRODD48 PRODD51 Not logged off
                string lineOfInterest = screen[(screen.LastIndexOf(screen.Last(ln => !String.IsNullOrWhiteSpace(ln) && ln.Contains("Ready"))/*index of the last line with Ready*/ ) - 1)];

                if (lineOfInterest.Contains("Job file submitted"))
                {
                    AddOrUpdateStageLog(null, lineOfInterest.Trim(), false);                                        //Saumen082516

                    /*File TTECH VPARSREQ A1 sent to TTECHTSM at RSVM3 on 03/24/16 10:47:22*/
                    string lineOfJob = screen[(screen.LastIndexOf(screen.Last(ln => !String.IsNullOrWhiteSpace(ln) && ln.Contains("Ready"))/*index of the last line with Ready*/ ) - 2)];

                    Regex regexForJobLine = new Regex("\bFile\b[w ]+\bsent\bto\b[wd ]+\bon\b" + regexForDateTime, RegexOptions.IgnoreCase);

                    //string lineOfJob = screen.SingleOrDefault(ln => regexForJobLine.IsMatch(ln));

                    if (lineOfJob != null && Regex.Match(lineOfJob, regexForDateTime).Success)
                    {
                        ScheduledJobDateTime = DateTime.ParseExact(Regex.Match(lineOfJob, regexForDateTime).Value, @"MM/dd/yy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                        Retry = false;
                    }
                    else
                        Retry = true;
                }
                else if (lineOfInterest.Contains("Not logged off") && forcefully_Logoff)
                {
                    // log off vpars
                    AddOrUpdateStageLog(null, "Logging of " + lineOfInterest.Replace("Not logged off", ""), false);

                    foreach (string vpars in lineOfInterest.Replace("Not logged off", "").Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        //Saumen031017
                        ana.EnterCommand("TPFOPR " + vpars + " ZCYCL 1052", 2);
                        ana.EnterCommand("TPFOPR " + vpars + " ZDSYS", 2);
                        int max_try = 0;
                        while (ana.WaitforString("IN 1052", 60) == 0 && max_try <= 5)
                        {
                            ana.EnterCommand("TPFOPR " + vpars + " ZDSYS", 2);
                            max_try++;
                        }
                        //Saumen031017
                        ana.EnterCommand("TPFOPR " + vpars + " ZCP LOG", 1);
                        ana.WaitforString("not open (no longer open)", 60);
                        ana.WaitforString("Ready", 60);
                    }
                    Retry = true;
                }
                else
                {
                    AddOrUpdateStageLog(null, lineOfInterest.Trim(), false);                                        //Saumen082516
                    Retry = HandleError(lineOfInterest + " You can fix it and retry by pressing yes", Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.TPFSETUP_ERROR);
                    //Retry = HandleError(lineOfInterest + " You can fix it and retry by pressing yes", ErrorTypes.NotifyandWait);
                    if (Retry == false)
                        return false;
                }

            } while (Retry);

            ///////////////////////////////////////// Get JOB ID ///////////////////////////////////////////////////
            string job_id = null; // to find

            // try with an interval of 60 seconds
            for (int i = 0; i < jobSchedulingAttempts && String.IsNullOrWhiteSpace(job_id); i++)
            {
                ana.Pause(60);

                screen.Clear();

                ////////////// Method 1 //////////////////
                /*
                ana.EnterCommand("TPFJOBS (TYPE ", 1);
                do
                {
                    ana.Pause(1);
                    screen.AddRange(ana.GetLines(99));
                    ana.SendText(Keys3270.Clear);
                }
                while (!screen.Any(ln => !String.IsNullOrWhiteSpace(ln) && ln.Contains("Ready")));
                */
                //////////////////// Method 2 ////////////////////
                ana.EnterCommand("TPFJOBS", 1);
                ana.WaitforString("TPFJOBS: Jobs scheduled on", 20);
                ana.SendText(Keys3270.Enter);
                ana.WaitforString("TPFJOBS: Jobs scheduled on", 20);
                screen.AddRange(ana.GetLines(99));
                ana.SendText(Keys3270.PF3);
                ana.WaitforString("Ready", 20);
                //////////////////////////////////////////////////

                string regexForJobLine = "\\s" + regexForDateTime + "\\s" + regexForJobId + "\\s" + regexForVMId + "\\s";


                string jobLine = screen.Where(ln => Regex.Match(ln, regexForJobLine, RegexOptions.IgnoreCase).Success)
                                           .Select(ln => Regex.Match(ln, regexForJobLine, RegexOptions.IgnoreCase).Value)
                                           .SingleOrDefault(jobInfo => jobInfo.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[3].Equals(VMID, StringComparison.InvariantCultureIgnoreCase)           // SAME vm ID
                                                             && DateTime.ParseExact(Regex.Match(jobInfo, regexForDateTime, RegexOptions.IgnoreCase).Value.Replace('.', '/'), @"MM/dd/yy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) >= ScheduledJobDateTime);    // job after the scheduled datetime

                job_id = jobLine != null ? Regex.Match(jobLine, regexForJobId, RegexOptions.IgnoreCase).Value : null;

            }

            if (String.IsNullOrWhiteSpace(job_id))
            {
                AddOrUpdateStageLog(null, " Unable to get Job id: retrying", false);                                //Saumen082516

                return jobSchedulingAttempts == 0 ? false : SubmitAndTrackSetup(SetupFile, systemdate, forcefully_Logoff, jobSchedulingAttempts / 2, jobCompletionTime);
            }

            //////////////////////// keep querying the job id //////////////////////
            IDictionary<string, string> tpfJobsData = new Dictionary<string, string>();
            for (int i = 0; i < jobCompletionTime / 60; i++)
            {
                screen.Clear();
                ana.EnterCommand("TPFJOBS * " + job_id + " " + VMID + " ( JOBSTAT", VMCommandTimeOut);
                ana.WaitforString("Ready", 5);
                screen.AddRange(ana.GetLines(99));

                screen.RemoveAll(ln => ln.Contains("* MSG FROM") || ln.Contains("RDR FILE") || ln.Contains("Ready") || ln.Contains("TPFJOBS"));          // remove improper lines

                tpfJobsData.Clear();
                tpfJobsData = screen.Where(ln => !String.IsNullOrWhiteSpace(ln) && ln.Split(':').Length > 1)
                                                                 .ToDictionary(
                                                                 ln => ln.Split(new char[] { ':' }, 2, StringSplitOptions.RemoveEmptyEntries)[0].Trim().ToUpper(),
                                                                 ln => ln.Split(new char[] { ':' }, 2, StringSplitOptions.RemoveEmptyEntries)[1].Trim());

                if (tpfJobsData.ContainsKey("STATUS"))
                    AddOrUpdateStageLog(null, tpfJobsData["STATUS"], false);


                if (tpfJobsData.ContainsKey("STATUS") && tpfJobsData["STATUS"].Contains("Job ended rc"))
                    break;

                ana.Pause(60);              //  A normal wait time
            }

            if (tpfJobsData.ContainsKey("STATUS") && (tpfJobsData["STATUS"].Contains("*") || tpfJobsData["STATUS"].Contains("-")))
            {
                AddOrUpdateStageLog(null, tpfJobsData["STATUS"], false);

                //return HandleError("TPFSETUP STATUS : " + tpfJobsData["STATUS"], ErrorTypes.NotifyandWait);
                return HandleError("TPFSETUP STATUS : " + tpfJobsData["STATUS"], Anadata.IsSchedulerAnalysis ? ErrorTypes.NotifyandAbort : ErrorTypes.NotifyandWait, ErrorGroup.TPFSETUP_ERROR);
                // error handling
            }


            ana.WaitforString("Ready;", 10);
            ana.EnterCommand("SET VTOD SYSTEM", VMCommandTimeOut);
            ana.EnterCommand("I CMS", VMCommandTimeOut);
            ana.SendText(Keys3270.Clear);

            AddOrUpdateStageLog(null, "Successful.", false);

            return true;
        }

        /// <summary>
        /// Logs in by using the specified string in VMid and also updates the login string aptly
        /// </summary>
        /// <param name="VMId">Logon String</param>
        /// <param name="password">Password</param>
        /// <returns>true on Success and false on failure</returns>
        private bool Login(ref string VMId, string password)
        {
            ana.WaitforString("USERID   ===>", 30);
            ana.EnterCommand(Keys3270.Clear, 2);
            ana.EnterCommand("LOGON " + VMId, 3);
            Match preLoginMatch = ana.WaitForRegex(new Regex(@"(?<LoginSuccess>Ready)|(?<Reconnected>RECONNECTED\s+AT)|(?<IncorrectPassword>\bLOGON\s+unsuccessful--incorrect\s+password\b)"), 1, false);
            ana.EnterCommand(password, 1, false, true);
            Match loginMatch = ana.WaitForRegex(new Regex(@"(?<LoginSuccess>(\bReady\b)|(\bLOGON\s+AT\s+\b))|(?<Reconnected>\bRECONNECTED\s+AT\b)|(?<IncorrectPassword>\bLOGON\s+unsuccessful--incorrect\s+password\b)"), 5);

            Regex logonByRegex = new Regex(@"\s*(?<AutoregId>\b\w+\b)(\s+BY\s+)?(?<LoginId>\b\w+\b)?\s*", RegexOptions.IgnoreCase);

            if (loginMatch.Success && !preLoginMatch.Success)
            {
                if (loginMatch.Groups["LoginSuccess"].Success)
                {
                    ////////////// Login Success ///////////////
                    ana.EnterCommand("ID", 1);

                    VMId = logonByRegex.Match(VMId).Groups["AutoregId"].Value;
                    return true;
                }
                else if (loginMatch.Groups["Reconnected"].Success)
                {
                    /////////////// RECONNECTED AT //////////////////
                    ana.SendText(Keys3270.PA1);
                    ana.SendText("I CMS" + Keys3270.Enter);
                    ana.Pause(3);
                    ana.SendText(Keys3270.Enter);
                    ana.WaitforString("Ready;", 10);

                    VMId = logonByRegex.Match(VMId).Groups["AutoregId"].Value;
                    return true;
                }
                else if (loginMatch.Groups["IncorrectPassword"].Success)
                {
                    ///////////// Incorrect Password //////////////
                    return false;
                }
            }
            return false;
        }

        string HSM_PRODD77 = null;                                                                                  //Saumen090116

        private bool AttachHSM(string VPARS, string hsmunit)
        {
            if (hsmunit == "NA")
                return true;
            bool Result = false;
            //ana.EnterCommand("GET TESTCASE", 2);
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                ana.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            ana.EnterCommand("GET VIPQAAUT", 2);//Saumen021417
            ReserveHSM("1", "DETACH");                                                                              //Saumen082916
            HSM_PRODD77 = "DETACHED";                                                                               //Saumen090116
            ana.EnterCommand("SENDCMD " + VPARS + " ZCP Q " + string.Join(" ", App.HSMUNITS.Where(h => h != "NA")), VMCommandTimeOut);
            if (ana.WaitforString("FREE", 10) > 0)
            {

                var freehsmline = ana.GetLines(50).FirstOrDefault(l => l.Contains("FREE"));
                ana.WaitforString("Ready;", 10);
                if (freehsmline != null)
                {
                    string hsmtoattach = freehsmline.Substring(freehsmline.IndexOf("FREE") - 5, 4).Substring(1);
                    ana.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZCP ATT " + hsmtoattach + " * |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                    ana.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZUVSM ON " + hsmtoattach + " |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                    ana.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZQCSM STOP |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                    ana.EnterCommand("PIPE CMS TPFOPR " + VPARS + " ZUVSM SETQ 99 |>> PRODREGG SUMMARY A1", 1);
                    Result = true;
                }
                else
                {
                    Result = false;
                    ana.EnterCommand("PIPE LITERAL No Free HSM found |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                }
                ana.WaitforString("Ready;", 10);
            }
            return Result;
            //if (hsmunit == "NA")
            //    return true;
            //bool Result = false;
            //ana.EnterCommand("TPFOPR " + VPARS + " ZCP Q " + hsmunit, VMCommandTimeOut);
            //var freehsmlines = ana.GetLines(50).Where(l => l.Contains("FREE"));
            //if (freehsmlines.Count() != 0)
            //{
            //    string hsmtoattach = freehsmlines.First();
            //    hsmtoattach = hsmtoattach.Substring(hsmtoattach.IndexOf("FREE") - 5, 4).Substring(1);//TAPE 094C FREE    , TAPE 094D FREE 
            //    ana.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZCP ATT " + hsmtoattach + " *", VMCommandTimeOut);
            //    ana.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZUVSM ON " + hsmtoattach + "", VMCommandTimeOut);
            //    ana.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZQCSM STOP", VMCommandTimeOut);
            //    if (ana.WaitforString("Ready;", 5) > 0)
            //        Result = true;
            //}
            //else
            //{
            //    foreach (var item in App.HSMUNITS.Where(h => h != "NA" && h != hsmunit))
            //    {
            //        ana.EnterCommand("TPFOPR " + VPARS + " ZCP Q " + item, VMCommandTimeOut);
            //        freehsmlines = ana.GetLines(50).Where(l => l.Contains("FREE"));
            //        if (freehsmlines.Count() != 0)
            //        {
            //            string hsmtoattach = freehsmlines.First();
            //            hsmtoattach = hsmtoattach.Substring(hsmtoattach.IndexOf("FREE") - 5, 4).Substring(1);//TAPE 094C FREE    , TAPE 094D FREE 
            //            ana.EnterCommand("PIPE CMS TPFOPR " + VPARS + " ZCP ATT " + hsmtoattach + " *", VMCommandTimeOut);
            //            ana.EnterCommand("PIPE CMS TPFOPR " + VPARS + " ZUVSM ON " + hsmtoattach + " ", VMCommandTimeOut);
            //            ana.EnterCommand("PIPE CMS TPFOPR " + VPARS + " ZQCSM STOP ", VMCommandTimeOut);
            //            if (ana.WaitforString("Ready;", 5) > 0)
            //            {
            //                Result = true;
            //                break;
            //            }
            //        }
            //        Result = false;
            //    }

            //}
            //return Result;
        }

        #region Create Table
        private void CreateResultTable(AnalysisData anadata, TestData testdata)
        {
            string tmphtmlresult = null; string htmlresult = null;
            SaveTapes(anadata.RegServer, testdata.Tapes);

            try
            {
                htmlresult += System.IO.File.ReadAllText(anadata.RegServer + "\\Mail.html");
            }
            catch (Exception)
            {
                htmlresult = "";
                tmphtmlresult = style() + "\n<body>\n";
            }

            List<string> IsolatedDumpsMismatches = new List<string>();
            List<string> IsolatedTestcaseFields = new List<string>();
            try
            {
                //DUMPDISPLAYCHANGE-uncomment to fallback
                // IsolatedDumpsMismatches.AddRange(System.IO.File.ReadAllLines(System.IO.Path.Combine(anadata.WorkingFolderPath, "Dump Status.txt")).Where(l => l.Contains("- I    -")).Select(d => d.Insert(d.IndexOf('-') + 1, " DUMP ") + " - DTD     - N      - Run2only"));//|| l.Contains("- R    -");
                //DUMPDISPLAYCHANGE-comment next for each to fallback
                foreach (var item in System.IO.File.ReadAllLines(System.IO.Path.Combine(anadata.RegServer, "Dump Status.txt")))
                {
                    if (item.Contains("- I    -"))
                    {
                        IsolatedDumpsMismatches.Add(item.Insert(item.IndexOf('-') + 1, " DUMP ") + " - DTD     - N      - Run2only");
                    }
                    else if (item.Contains("- N    -"))
                    {
                        IsolatedDumpsMismatches.Add(item.Insert(item.IndexOf('-') + 1, " DUMP ") + " - DTD     - N      - Not Recreated");
                    }
                    else if (item.Contains("- R    -"))
                    {
                        IsolatedDumpsMismatches.Add(item.Insert(item.IndexOf('-') + 1, " DUMP ") + " - DTD     - N      - Not Isolated");
                    }
                    else if (item.Contains("- Q    -"))
                    {
                        IsolatedDumpsMismatches.Add(item.Insert(item.IndexOf('-') + 1, " DUMP ") + " - DTD     - N      - Transaction Not Found");
                    }
                    else if (item.Contains("- B    -"))
                    {
                        IsolatedDumpsMismatches.Add(item.Insert(item.IndexOf('-') + 1, " DUMP ") + " - DTD     - N      - Baserun Dump");
                    }
                }
            }
            catch (Exception)
            { }
            try
            {
                IsolatedDumpsMismatches.AddRange(System.IO.File.ReadAllLines(System.IO.Path.Combine(Anadata.RegServer, "Recreate Status.txt")).Where(l => l.Contains("- I    -")));//|| l.Contains("- R    -")
            }
            catch (Exception)
            { }

            try
            {
                IsolatedTestcaseFields = System.IO.File.ReadAllLines(System.IO.Path.Combine(Anadata.RegServer, "MSGFLD LIST.txt")).Where(l => l != null && l != "").ToList();
            }
            catch (Exception)
            { }



            //if (IsolatedDumpsMismatches.Count() != 0)
            {
                List<ResultData> IsolatedTestcases = new List<ResultData>();

                foreach (var item in IsolatedDumpsMismatches)
                {
                    var splitted = item.Split(new string[] { " - " }, StringSplitOptions.None);
                    int tcid = Convert.ToInt16(splitted[0].Trim().Replace("TC.", ""));
                    string we = splitted[3].Trim().Replace("SWITCH", "SWITCH ");
                    //// Need to bypass duplicate Field Values, If any testcase contains the whole keyvalue pair it should not report
                    if (IsolatedTestcases.Any(itcs => itcs.FieldValues.Contains(new KeyValuePair<string, string>(splitted[1].Trim(), splitted[6].Trim()))))
                        continue;
                    ResultData resdata = IsolatedTestcases.FirstOrDefault(tc => tc.TestcaseId == tcid && tc.ReasonForMismatch == we);

                    if (resdata == null)//Doesnot exist
                    {
                        resdata = new ResultData();
                        resdata.TestcaseId = tcid; resdata.ReasonForMismatch = we; resdata.FieldValues = new Dictionary<string, string>() { { splitted[1].Trim(), splitted[6].Trim() } };
                        IsolatedTestcases.Add(resdata);
                    }
                    else //Already Exist, Just add field values
                    {
                        resdata.FieldValues.Add(splitted[1].Trim(), splitted[6].Trim());
                        //Update the element
                        IsolatedTestcases[IsolatedTestcases.IndexOf(IsolatedTestcases.First(tc => tc.TestcaseId == tcid && tc.ReasonForMismatch == we))] = resdata;
                        continue;
                    }
                    // Now add the transaction related fields.
                    var thistestcasefields = IsolatedTestcaseFields.FirstOrDefault(t => t.Contains("TC." + tcid + " ")); //Add a space after the TCID, otherwise it will take TC.11 as TC.1
                    string MTI = "NA", MCC = "NA", PROCCODE = "NA";
                    if (thistestcasefields != null)
                    {
                        try
                        {
                            var splittedfields = thistestcasefields.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                            MTI = splittedfields[1].Replace("MTI-", "").Replace("MTIC", "NA");
                            PROCCODE = splittedfields[2].Replace("F3.1-", "").Replace("PROC", "NA");
                            MCC = splittedfields[3].Replace("F18-", "").Replace("MCC", "NA");
                        }
                        catch (Exception)
                        { }
                    }
                    resdata.MTI = (MTI == "" || MTI == null) ? "NA" : MTI.Replace("m:", null);
                    resdata.PROC = (PROCCODE == "" || PROCCODE == null) ? "NA" : PROCCODE;
                    resdata.MCC = (MCC == "" || MCC == null) ? "NA" : MCC;
                    //End of adding txn fields
                }
                //// Sorting the WEs
                IsolatedTestcases = IsolatedTestcases.OrderBy(r => r.ReasonForMismatch).Where(r => !r.ReasonForMismatch.Contains("SYS_DATE")).ToList();
                //Now create the observation table
                List<Observation> observations = CreateObservationsForTracking(IsolatedTestcases, testdata);

                //We need to Upload the issues here and get the Responses Back. Response will contain link to the issue and its status.
                //Dictionary<link,Status>, Status=Status,Resolution

                //Activate Later
                Dictionary<string, string> LinkstoObservations = POSTObservationsInBulk(serializer.Serialize(observations)); //new Dictionary<string, string>();//

                List<int> isolatedDumpTCNums = new List<int>();
                #region dump reporting
                try
                {
                    Regex dumpStatLineRegex = new Regex(@"(?<Test_Case>\w{2}\.\d\d*)\s+-\s+(?<Program>\w+)?\s+(?<DUMP>\w{3}-\w+)\s+-\s+(?<Status>R|I|B|N|Q)\s+-\s*(?<WE_SWITCH_GLOBAL>\w*:\w*|\w*)"); //Consider  GLB:TAPE/WE001234/NA

                    List<string> dumpsUniqueFile = new List<string>();

                    if (File.Exists(System.IO.Path.Combine(anadata.RegServer, "DUMPS_UNIQUE.txt")))
                    {
                        dumpsUniqueFile.AddRange(File.ReadAllLines(System.IO.Path.Combine(anadata.RegServer, "DUMPS_UNIQUE.txt")));
                    }


                    if (File.Exists(System.IO.Path.Combine(anadata.RegServer, "DUMP Status.txt"))
                        && File.ReadAllLines(System.IO.Path.Combine(anadata.RegServer, "DUMP Status.txt")).Any(ln => dumpStatLineRegex.IsMatch(ln))
                        )
                    {
                        ///////////////////// Dump Reporting //////////////////////////

                        IList<string> headerRow = new List<string>(new string[] { "OBS #", "WE/Switch/Global", "RTN", "MTY", "ISO F3.1", "MCC", "Execution Mode", "Dump", "Program", "TSDUMP VPARS", "STAGE", "Status", "Test Case", "VM id", "DTD", "RSI", "CSI" });

                        IList<IList<string>> otherRows = new List<IList<string>>();

                        int obsNum = 1;
                        foreach (Match dumpLineMatch in File.ReadAllLines(System.IO.Path.Combine(anadata.RegServer, "DUMP Status.txt"))
                                                                        .Where(ln => dumpStatLineRegex.IsMatch(ln))
                                                                        .Select(validLn => dumpStatLineRegex.Match(validLn)))
                        {
                            IDictionary<string, string> eachRow = new Dictionary<string, string>();

                            string defaultValue = "NA";
                            foreach (string hdr in headerRow)
                                eachRow[hdr] = defaultValue;

                            eachRow["OBS #"] = obsNum.ToString();
                            obsNum += 1;
                            // TO DO parse dumps unique file to get VM id
                            eachRow["VM id"] = anadata.VMId;

                            eachRow["WE/Switch/Global"] = dumpLineMatch.Groups["WE_SWITCH_GLOBAL"].Value;

                            int tcNum = Convert.ToInt32(Regex.Match(dumpLineMatch.Groups["Test_Case"].Value, @"\d+").Value);
                            eachRow["Test Case"] = testdata != null && testdata.TestCases.Count >= tcNum ? testdata.TestCases[tcNum - 1].TestCaseName : defaultValue;
                            eachRow["Program"] = dumpLineMatch.Groups["Program"].Value;
                            eachRow["Execution Mode"] = testdata != null && testdata.TestCases.Count >= tcNum ? testdata.TestCases[tcNum - 1].ExecutionMode : defaultValue;

                            // link for the dump file
                            eachRow["Dump"] = @"<a href=""" + System.IO.Path.Combine(anadata.RegServer, eachRow["Test Case"].Replace(' ', '_') + "_Z1.txt") + @""">" + dumpLineMatch.Groups["DUMP"].Value + @"</a>";
                            try
                            {
                                eachRow["MTY"] = IsolatedTestcases.FirstOrDefault(tc => tc.TestcaseId == tcNum).MTI;
                                eachRow["MCC"] = IsolatedTestcases.FirstOrDefault(tc => tc.TestcaseId == tcNum).MCC;
                                eachRow["ISO F3.1"] = IsolatedTestcases.FirstOrDefault(tc => tc.TestcaseId == tcNum).PROC;
                            }
                            catch (Exception)
                            {
                            }

                            eachRow["DTD"] = String.Empty;
                            eachRow["RSI"] = String.Empty;
                            eachRow["CSI"] = String.Empty;
                            ///////////// TSDUMP VPARS /////////////
                            //5 OPR-UDEB190 IDT4 IDT4 OBJ-idt4 0000086E LOADSET-BASE : PRODD11 : Stage-During FTPVIP and CUPLOAD
                            string uniqueDumpLine = dumpsUniqueFile.FirstOrDefault(ln => ln.Contains(dumpLineMatch.Groups["DUMP"].Value) && ln.Contains(dumpLineMatch.Groups["Program"].Value));

                            var linesplit = uniqueDumpLine != null ? uniqueDumpLine.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries) : new List<string>().ToArray();
                            eachRow["TSDUMP VPARS"] = linesplit.Length > 1 ? linesplit[1] : defaultValue;

                            eachRow["STAGE"] = linesplit.Length > 2 ? linesplit[2] : defaultValue;
                            //eachRow["TSDUMP VPARS"] = uniqueDumpLine != null ? uniqueDumpLine.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries)[1] : defaultValue;

                            switch (dumpLineMatch.Groups["Status"].Value)
                            {
                                case "R":
                                    //eachRow["Status"] = "No Trxn found/observed during System IPL";
                                    eachRow["Status"] = "Recreated but not Isolated";
                                    eachRow["WE/Switch/Global"] = "TBF";
                                    isolatedDumpTCNums.Add(tcNum);
                                    break;
                                case "N":
                                    eachRow["Status"] = "Not Recreated";
                                    eachRow["WE/Switch/Global"] = defaultValue;
                                    isolatedDumpTCNums.Add(tcNum);
                                    break;
                                case "B":
                                    eachRow["Status"] = "Baserun Dump";
                                    eachRow["WE/Switch/Global"] = "Base System";
                                    isolatedDumpTCNums.Add(tcNum);
                                    break;
                                case "Q":
                                    eachRow["Test Case"] = "No Transaction found";
                                    eachRow["Status"] = "Could not be analyzed";
                                    eachRow["WE/Switch/Global"] = defaultValue;
                                    isolatedDumpTCNums.Add(tcNum);
                                    break;
                                case "I":
                                    int weindex = WELIST.IndexOf(eachRow["WE/Switch/Global"]);
                                    eachRow["Status"] = "Isolated";
                                    eachRow["RTN"] = observations.FirstOrDefault(obs => obs.WE.Equals(eachRow["WE/Switch/Global"], StringComparison.InvariantCultureIgnoreCase)).RTN;
                                    eachRow["DTD"] = testdata.Tapes.Exists(t => t.TapeType == "DTD") ? testdata.Tapes.First(t => t.TapeType == "DTD").TapeNumbers[weindex] : String.Empty;
                                    eachRow["RSI"] = testdata.Tapes.Exists(t => t.TapeType == "RSI") ? testdata.Tapes.First(t => t.TapeType == "RSI").TapeNumbers[weindex] : String.Empty;
                                    eachRow["CSI"] = testdata.Tapes.Exists(t => t.TapeType == "CSI") ? testdata.Tapes.First(t => t.TapeType == "CSI").TapeNumbers[weindex] : String.Empty;
                                    isolatedDumpTCNums.Add(tcNum);
                                    break;
                                default:
                                    eachRow["Status"] = "NA";
                                    eachRow["Test Case"] = defaultValue;
                                    eachRow["Execution Mode"] = defaultValue;
                                    break;
                            }

                            var listOfRow = eachRow.OrderBy(entry => headerRow.IndexOf(entry.Key))
                                                    .Select(cell => cell.Value)
                                                    .ToList();
                            otherRows.Add(listOfRow);
                        }
                        // ordering according to the we number
                        otherRows = otherRows.OrderByDescending(eachRow => eachRow.ElementAt(headerRow.IndexOf("WE/Switch/Global"))).ToList();

                        obsNum = 1;
                        // re assign the obs numbers 
                        foreach (List<string> row in otherRows)
                        {
                            row[headerRow.IndexOf("OBS #")] = obsNum.ToString();
                            obsNum += 1;
                        }
                        //
                        tmphtmlresult += createHTMLTable("Following Dumps were observed in this run:", headerRow, otherRows);

                    }
                    else
                        tmphtmlresult += "<p><b>No new Dumps observed.</b></p>\n";
                }
                catch (Exception)
                {

                }
                #endregion


                if (IsolatedTestcases.Count(t => !isolatedDumpTCNums.Any(tcNum => t.TestcaseId == tcNum)) > 0)
                {
                    //Create the table Header here
                    tmphtmlresult += "<h4>Following Mismatches were observed in this run:<br><br></h4>\n";
                    tmphtmlresult += "<table>\n<tr>\n<th>OBS #</th><th>WE/Switch/Global</th><th>RTN</th><th>Type</th><th>MTY</th><th>ISO F3.1</th><th>MCC</th><th>Execution Mode</th>" +
                        "<th style=\"padding:0px\"><table><th style=\"width:80px\">Field</th><th style=\"width:150px;\">Baserun Value</th><th style=\"width:150px\">Coderun Values</th></table></th>" +
                        "<th>Test Case</th><th>VM Id</th><th>DTD</th><th>RSI</th><th>CSI</th>"; //\n</tr>\n" //<th>Status</th><th>Link</th>

                    /* BMOLYNEA011917 */
                    tmphtmlresult += "<th>Obs Ticket#</th><th>Obs Status</th>";
                    tmphtmlresult += "\n</tr>\n";
                    /* END BMOLYNEA011917 */

                    int MMObs = 1;
                    foreach (var item in IsolatedTestcases)
                    {
                        if (!isolatedDumpTCNums.Any(tcNum => item.TestcaseId == tcNum))                        //remove dumps
                        {
                            Observation obs = observations.ElementAtOrDefault(IsolatedTestcases.IndexOf(item));

                            KeyValuePair<string, string> linktoobs = LinkstoObservations.ElementAtOrDefault(IsolatedTestcases.IndexOf(item));
                            //BMOLYNEA013017
                            tmphtmlresult += PopulateTCtoTable(MMObs, item, testdata, anadata.VMId, obs, linktoobs, Runsettings);
                            ++MMObs;
                        }
                    }

                    tmphtmlresult += "</table>\n<br><br><br>";
                }
                else
                {
                    tmphtmlresult += "<p><b>No new Mismatches observed.</b></p><br>\n";
                }

            }
            //
            //BMOLYNEA011917
            //Saumen012017
            //tmphtmlresult += "<i><b>" + "<a href=\"" + @"http://myteams/sites/vipqa/Shared%20Documents/User%20Guides/JIRA_Dev_Doc_v1.0.pdf" + "\">" + "Jira Developer Responsibilities Documentation" + "</a></b></i><br>\n";
            tmphtmlresult += "<i><b>" + "<a href=\"" + @"http://myteams/sites/vipqa/Shared%20Documents/User%20Guides/JIRA_Dev_Doc.pdf" + "\">" + "Jira Developer Responsibilities Documentation" + "</a></b></i><br>\n";
            //Saumen012017
            //
            tmphtmlresult += @"<hr></body>";

            //
            int h4index = htmlresult.IndexOf("<h4>");
            if (h4index > 0)
            {
                htmlresult = htmlresult.Insert(h4index, tmphtmlresult);
            }
            else
                htmlresult = tmphtmlresult;


            Outlook.Application oApp;
            Outlook.MailItem oMsg;
            Outlook.Recipients oRecips;
            Outlook.Recipient oRecip;
            //
            try
            {
                System.IO.File.WriteAllText(anadata.RegServer + "\\Analysis Result.html", htmlresult);
                oApp = new Outlook.Application();
                oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                oMsg.HTMLBody = htmlresult;
                oMsg.Subject = (Runsettings.VIPS.Where(v => v.VPARS != "").Count() + " VIP " + Runsettings.RegType)
                    .Replace("1 VIP 1VIP", "1VIP") + " Regression for " + Runsettings.InstallDate + " install " +
                    ((String.IsNullOrWhiteSpace(Runsettings.SwitchActivationInfo) || Runsettings.SwitchActivationInfo.Equals("N/A", StringComparison.CurrentCultureIgnoreCase)) ? null : Runsettings.SwitchActivationInfo + " Switch Activated")
                    + "(" + Runsettings.RunNumber + ")";
                oRecips = (Outlook.Recipients)oMsg.Recipients;
                oRecip = (Outlook.Recipient)oRecips.Add(anadata.Email);
                oRecip.Resolve();
                oMsg.SaveAs(anadata.RegServer + "\\Analysis Result.msg", Outlook.OlSaveAsType.olMSG);
                ((Outlook._MailItem)oMsg).Send();
            }
            catch (Exception ex)
            {
                HandleError("Mail generation error:" + ex.Message, ErrorTypes.LogOnly, ErrorGroup.COM_ERROR);
            }
            finally
            {
                oRecip = null;
                oRecips = null;
                oMsg = null;
                oApp = null;
            }
        }

        /// <summary>
        /// Creates a Dump Status table from the Dump Status file
        /// </summary>
        /// <param name="regServerPath"></param>
        /// <param name="VMId"></param>
        /// <returns>Returns html string of the table</returns>
        public static string createHTMLTable(string tableHeader, string filePath, Regex regexToParse, GroupEvaluator groupEvaluator)
        {
            System.IO.StringWriter strWriter = new System.IO.StringWriter();
            Web.HtmlTextWriter html = new Web.HtmlTextWriter(strWriter, "\t");


            if (!File.Exists(filePath))
                return strWriter.ToString();

            if (!File.ReadAllLines(filePath).Any(ln => regexToParse.IsMatch(ln)))
                return strWriter.ToString();


            html.RenderBeginTag(Web.HtmlTextWriterTag.Html);
            html.RenderBeginTag(Web.HtmlTextWriterTag.Body);
            {
                html.AddAttribute(Web.HtmlTextWriterAttribute.Class, tableHeader.Replace(" ", ""));
                html.RenderBeginTag(Web.HtmlTextWriterTag.Div);

                html.RenderBeginTag(Web.HtmlTextWriterTag.H4); html.Write(tableHeader); html.RenderEndTag();

                html.RenderBeginTag(Web.HtmlTextWriterTag.Table);

                html.RenderBeginTag(Web.HtmlTextWriterTag.Thead);
                html.RenderBeginTag(Web.HtmlTextWriterTag.Tr);

                foreach (string groupName in regexToParse.GetGroupNames().Where((g, i) => i > 0))
                {
                    html.RenderBeginTag(Web.HtmlTextWriterTag.Th); html.Write(groupName.Replace('_', ' ')); html.RenderEndTag();
                }

                html.RenderEndTag(); //tr
                html.RenderEndTag();//thead

                foreach (Match lineMatch in System.IO.File.ReadLines(filePath)
                                                              .Where(ln => regexToParse.IsMatch(ln))
                                                              .Select(ln => regexToParse.Match(ln))
                                                                )
                {

                    html.RenderBeginTag(Web.HtmlTextWriterTag.Tr);
                    foreach (string groupName in regexToParse.GetGroupNames().Where((g, i) => i > 0))
                    {
                        html.RenderBeginTag(Web.HtmlTextWriterTag.Td); html.Write(groupEvaluator(lineMatch, groupName)); html.RenderEndTag();
                    }
                    html.RenderEndTag(); //tr
                }

                html.RenderEndTag();//table
                html.RenderEndTag(); //div
            }

            html.RenderEndTag();//body
            html.RenderEndTag();//html

            return strWriter.ToString();
        }
        /// <summary>
        /// Creates and HTML table from the provided Lists
        /// </summary>
        /// <param name="tableHeader"></param>
        /// <param name="headerRow"></param>
        /// <param name="otherRows"></param>
        /// <returns></returns>
        public static string createHTMLTable(string tableHeader, IList<string> headerRow, IList<IList<string>> otherRows)
        {
            System.IO.StringWriter strWriter = new System.IO.StringWriter();
            Web.HtmlTextWriter html = new Web.HtmlTextWriter(strWriter, "\t");

            ///////////// Check for valid rows and headers //////////////////
            if (otherRows.Any(eachRow => eachRow.Count != headerRow.Count))
                return strWriter.ToString();

            html.RenderBeginTag(Web.HtmlTextWriterTag.Html);
            html.RenderBeginTag(Web.HtmlTextWriterTag.Body);
            {
                html.AddAttribute(Web.HtmlTextWriterAttribute.Class, tableHeader.Replace(" ", ""));
                html.RenderBeginTag(Web.HtmlTextWriterTag.Div);

                html.RenderBeginTag(Web.HtmlTextWriterTag.H4); html.Write(tableHeader); html.RenderEndTag();

                html.RenderBeginTag(Web.HtmlTextWriterTag.Table);

                html.RenderBeginTag(Web.HtmlTextWriterTag.Thead);
                html.RenderBeginTag(Web.HtmlTextWriterTag.Tr);

                foreach (string headerName in headerRow)
                {
                    html.RenderBeginTag(Web.HtmlTextWriterTag.Th); html.Write(headerName); html.RenderEndTag();
                }

                html.RenderEndTag(); //tr
                html.RenderEndTag();//thead

                foreach (IList<string> eachRow in otherRows)
                {

                    html.RenderBeginTag(Web.HtmlTextWriterTag.Tr);
                    foreach (string eachCell in eachRow)
                    {
                        html.RenderBeginTag(Web.HtmlTextWriterTag.Td); html.Write(eachCell); html.RenderEndTag();
                    }
                    html.RenderEndTag(); //tr
                }

                html.RenderEndTag();//table
                html.RenderEndTag(); //div
            }

            html.RenderEndTag();//body
            html.RenderEndTag();//html

            return strWriter.ToString();
        }

        private Dictionary<string, string> POSTObservationsInBulk(string jsontopost)
        {
            return new Dictionary<string, string>(); //Bypass Issue Tracker, This is not deployed in windows 10 machines
            HttpWebRequest request = WebRequest.Create(App.IssueTrackerAPIPath + "batch") as HttpWebRequest;
            try
            {
                request.UseDefaultCredentials = true;
                request.Proxy = null;
                request.Method = "POST";
                request.ContentType = "application/json;ext=bulk";
                using (Stream reqstream = request.GetRequestStream())
                {
                    var byteArray = Encoding.UTF8.GetBytes(jsontopost);
                    reqstream.Write(byteArray, 0, byteArray.Length);
                }
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    if (response.StatusCode == HttpStatusCode.Created)
                    {
                        using (var sr = new StreamReader(response.GetResponseStream()))
                        {
                            string jsonstring = sr.ReadToEnd();
                            return (Dictionary<string, string>)serializer.Deserialize(jsonstring, typeof(Dictionary<string, string>));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                HandleError("Observation upload error:" + ex.Message, ErrorTypes.NotifyAndLog, ErrorGroup.NOT_CLASSIFIED_ERROR);
            }
            return new Dictionary<string, string>();
        }

        private List<Observation> CreateObservationsForTracking(List<ResultData> IsolatedTestcases, TestData testdata)
        {
            List<Observation> Obslist = new List<Observation>();
            List<WERTNDEVS> wertndevs = new List<WERTNDEVS>();
            if (Anadata.SwitchActivationInfo != "N/A" && Anadata.SwitchActivationInfo != null)
            {
                foreach (var item in System.IO.File.ReadAllLines(Path.Combine(Anadata.RegServer, "FallbackScript.txt")))
                {
                    if (item != null && item[0] != '*' && item.Length > 15)
                    {
                        string we = "SWITCH " + item.ToUpper().Replace("ZKSWT", "").Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0];
                        string rtn = item.ToUpper().Replace("ZKSWT", "").Replace("RTN-", "R-").Replace("OFF", "").Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[1].Replace("R-", "");
                        wertndevs.Add(new WERTNDEVS() { WE = we, RTN = rtn });
                    }
                }
            }
            else
            {
                Excel.Application xlapp = null; Excel.Workbook xlworkbook = null; Excel.Worksheet xlsheet = null;
                try
                {
                    xlapp = new Excel.Application();
                    xlworkbook = xlapp.Workbooks.Open(Anadata.RegServer + "\\WELIST.xls");
                    xlsheet = xlworkbook.Worksheets[1];

                    foreach (Excel.Range row in xlsheet.UsedRange.Rows)
                    {
                        string wenumber = (row.Columns[1].Text as string);
                        if (wenumber.Contains("WE"))
                        {
                            // Devs=Owner,DevLead,DEVs
                            wertndevs.Add(new WERTNDEVS() { WE = wenumber, RTN = row.Columns[9].Text, DEVS = row.Columns[5].Text + "," + row.Columns[12].Text + "," + row.Columns[13].Text });
                        }
                    }

                }
                catch (Exception ex)
                {
                    HandleError("WE List read error:" + ex.Message, ErrorTypes.LogOnly, ErrorGroup.SYSTEM_PROBLEM);
                }
                finally
                {
                    xlsheet = null;
                    if (xlworkbook != null)
                        xlworkbook.Close();
                    xlworkbook = null;
                    xlapp.Quit();
                    if (xlapp != null)
                        xlapp = null;
                }
            }
            foreach (var item in IsolatedTestcases)
            {
                Observation obs = new Observation();
                var thistestcasedetails = testdata.TestCases.Where((tc, index) => item.TestcaseId == index + 1).First();
                var thiswedetails = wertndevs.FirstOrDefault(w => w.WE == item.ReasonForMismatch);
                obs.InstallDate = DateTime.SpecifyKind(DateTime.ParseExact(Anadata.InstallDate, "MM/dd/yyyy", null), DateTimeKind.Utc);
                obs.IssueType = "Regression";
                obs.ReportedBy = Environment.UserName;
                obs.RTN = thiswedetails != null ? thiswedetails.RTN : "807648";
                obs.Devs = thiswedetails != null ? FormatDevs(thiswedetails.DEVS) : null;
                //For Global Mismatch Hardcode Developers : Manto, James <jmanto@visa.com>, Seshappan, Bagirathi <BSeshapp@visa.com>
                if (App.ALLGLOBALS.Any(g => item.ReasonForMismatch.Contains(g)))
                    obs.Devs = "jmanto,BSeshapp";
                obs.RunDetails = Anadata.RegType + " " + Anadata.RunNumber;
                obs.Status = "Open";
                obs.SubmitDate = DateTime.UtcNow;
                obs.Summary = (item.FieldValues.Keys.Any(k => k.ToUpper().Contains("DUMP ")) ? item.FieldValues.First().Key : "Mismatch in " +
                    (thistestcasedetails.Tape2Cut == "DTD" ? "ISO fields" : "UMF fields")) + (item.ReasonForMismatch == "NA" ? "(could not be isolated)" : " due to " + item.ReasonForMismatch);
                obs.WE = item.ReasonForMismatch;

                obs.Tags = thistestcasedetails.Tape2Cut;
                if (item.FieldValues.Keys.Any(k => k.ToUpper().Contains("DUMP ")))
                    obs.Tags += ",Dump";
                if (item.FieldValues.Keys.Any(k => k.Contains("H14")))
                    obs.Tags += ",Reject";
                //Custom1 Will contain the data for finding the issue by fields.
                obs.Custom1 = string.Concat(item.FieldValues.Select(fv => fv.Key.PadRight(24) + fv.Value + Environment.NewLine));
                obs.Description = "Field                   Mismatch" + Environment.NewLine;
                obs.Description += obs.Custom1 + Environment.NewLine;
                obs.Description += "Execution Mode: " + thistestcasedetails.ExecutionMode + Environment.NewLine;
                obs.Description += "MTI-" + item.MTI + " ;ISO F3.1-" + item.PROC + " ;MCC-" + item.MCC + Environment.NewLine;
                obs.Description += "Test Case: " + thistestcasedetails.TestCaseName + " available in " + Anadata.VMId + Environment.NewLine;
                string dtd = null, rsi = null, csi = null;
                try
                {
                    dtd = testdata.Tapes.Exists(t => t.TapeType == "DTD") ? testdata.Tapes.First(t => t.TapeType == "DTD").TapeNumbers[WELIST.IndexOf(item.ReasonForMismatch)] : "        ";
                    rsi = testdata.Tapes.Exists(t => t.TapeType == "RSI") ? testdata.Tapes.First(t => t.TapeType == "RSI").TapeNumbers[WELIST.IndexOf(item.ReasonForMismatch)] : "        ";
                    csi = testdata.Tapes.Exists(t => t.TapeType == "CSI") ? testdata.Tapes.First(t => t.TapeType == "CSI").TapeNumbers[WELIST.IndexOf(item.ReasonForMismatch)] : "        ";

                }
                catch (Exception)
                {
                }
                obs.Description += "Tapes: DTD-" + (dtd == null ? "        " : dtd.PadRight(8)) + "; RSI-" + (rsi == null ? "        " : rsi.PadRight(8)) + "; CSI-" + (csi == null ? "        " : csi.PadRight(8));

                Obslist.Add(obs);
            }
            return Obslist;
        }

        private string FormatDevs(string devs) ///anup(test)
        {
            if (devs == null)
                return null;
            while (devs.IndexOf('(') > 0)
            {
                int start = devs.IndexOf('(');     //
                int end = devs.IndexOf(')');
                devs = devs.Remove(start, end - start + 1);
            }
            //devs = devs.Trim(',').Replace(" ",null);
            devs = string.Concat(devs.Split(',').Distinct().Select(d => d + ",")).Trim(',').Replace(" ", null);
            return (devs != "" ? devs : null);
        }

        private void SaveTapes(string server, List<Tape> tapes)
        {
            List<string> tapelist = new List<string>() { "Record                        DTD       RSI       CSI       " };
            foreach (var we in WELIST)
            {
                string tmpstr = we.PadRight(30, ' ');
                string dtd = (tapes.Exists(t => t.TapeType == "DTD") ? tapes.First(t => t.TapeType == "DTD").TapeNumbers[WELIST.IndexOf(we)] : null);
                string rsi = (tapes.Exists(t => t.TapeType == "RSI") ? tapes.First(t => t.TapeType == "RSI").TapeNumbers[WELIST.IndexOf(we)] : null);
                string csi = (tapes.Exists(t => t.TapeType == "CSI") ? tapes.First(t => t.TapeType == "CSI").TapeNumbers[WELIST.IndexOf(we)] : null);
                tmpstr += (dtd == null ? "" : dtd).PadRight(10, ' ');
                tmpstr += (rsi == null ? "" : rsi).PadRight(10, ' ');
                tmpstr += (csi == null ? "" : csi).PadRight(10, ' ');
                tapelist.Add(tmpstr);
            }
            try
            {
                System.IO.File.WriteAllLines(server + "\\Analysis Tapes.txt", tapelist);
            }
            catch (Exception ex)
            {
                HandleError("Tape save error:" + ex.Message, ErrorTypes.LogOnly, ErrorGroup.SYSTEM_PROBLEM);

            }
        }

        //BMOLYNEA013017
        private string PopulateTCtoTable(int index, ResultData resdata, TestData testdata, string VMID, Observation obs, KeyValuePair<string, string> linktoobs, RunSettings RunSett)
        {
            JiraJson.FilePath(RunSett.CoderunServer);//BMOLYNEA033017
            JiraJson.WriteLog("Entered PopulateTCtoTable Method\n");//BMOLYNEA033017

            //<th>DTD</th><th>RSI</th><th>CSI</th></tr>
            int weindex = WELIST.IndexOf(resdata.ReasonForMismatch);
            string DTD = testdata.Tapes.Exists(t => t.TapeType == "DTD") ?
                testdata.Tapes.First(t => t.TapeType == "DTD").TapeNumbers[weindex] : null;
            string RSI = testdata.Tapes.Exists(t => t.TapeType == "RSI") ?
                testdata.Tapes.First(t => t.TapeType == "RSI").TapeNumbers[weindex] : null;
            string CSI = testdata.Tapes.Exists(t => t.TapeType == "CSI") ?
                testdata.Tapes.First(t => t.TapeType == "CSI").TapeNumbers[weindex] : null;
            string RTN = obs != null ? obs.RTN : null;
            string link = !linktoobs.Equals(default(KeyValuePair<string, string>)) ? linktoobs.Key.Replace(App.IssueTrackerAPIPath, App.IssueTrackerViewPath) : null;//Create ViewLink in App
            string status = !linktoobs.Equals(default(KeyValuePair<string, string>)) ? linktoobs.Value.Split(',')[1] : null;
            status = (link == null) ? "Error!" : (status == null ? "Open" : status);
            // string colorstyle = index % 2 != 0 ? "style=\"background-color:lightcyan\"" : null;

            //BMOLYNEA013017
            JiraJson.RegSubject = (RunSett.VIPS.Where(v => v.VPARS != "").Count() + " VIP " + RunSett.RegType) + " Regression for " + RunSett.InstallDate + " install " + (String.IsNullOrWhiteSpace(RunSett.SwitchActivationInfo) || RunSett.SwitchActivationInfo.Equals("N/A", StringComparison.CurrentCultureIgnoreCase) ? null : RunSett.SwitchActivationInfo + " Switch Activated") + "(" + RunSett.RunNumber + ")";
            JiraJson.WriteLog(string.Format("RegSubject: {0}\n", JiraJson.RegSubject));//BMOLYNEA033017

            /* BMOLYNEA012717 */
            JiraRegression.RegDescription("MTI: " + resdata.MTI + "\n" + "ISO_F3.1: " + resdata.PROC + "\n" + "MCC: " + resdata.MCC + "\n" + "Execution_Mode:" + testdata.TestCases[resdata.TestcaseId - 1].ExecutionMode.Replace("STIP:", "") + "\n");
            /* BMOLYNEA012717 END */

            string result = "<tr>\n<td>" + index + "</td><td>" + resdata.ReasonForMismatch + "</td><td>" + RTN + "</td><td>" +
                testdata.TestCases[resdata.TestcaseId - 1].Tape2Cut + "</td><td>" + resdata.MTI + "</td><td>" + resdata.PROC + "</td><td>" + resdata.MCC + "</td><td>" +
                testdata.TestCases[resdata.TestcaseId - 1].ExecutionMode.Replace("STIP:", "") + "</td><td style=\"padding:0px\">\n" + createFieldValueTable(resdata.FieldValues) + "\n</td><td>" + testdata.TestCases[resdata.TestcaseId - 1].TestCaseName + "</td><td>" +
                VMID + "</td><td>" + DTD + "</td><td>" + RSI + "</td><td>" + CSI + "</td>"; //\n</tr>\n";//<td>"+status+"</td><td><a href=\""+link+"\">Response</a></td>

            /* BMOLYNEA011917 */
            try
            {
                JiraRegression.RegDescription("Test_Case: " + testdata.TestCases[resdata.TestcaseId - 1].TestCaseName + "\n" + "VM ID:" + VMID + "\n" + "DTD: " + DTD + "\n" + "RSI: " + RSI + "\n" + "CSI: " + CSI);
                //GGIRDHAR030717 - Test Framework Enhancement
                if (InputFile.TestRun)
                {
                    JiraRegression.JiraMessage(resdata.ReasonForMismatch, RTN, DateTime.Parse(Anadata.InstallDate).ToString(), true);//GGIRDHAR030717
                }
                //GGIRDHAR030717 - Test Framework Enhancement
                else
                {
                    JiraRegression.JiraMessage(resdata.ReasonForMismatch, RTN, DateTime.Parse(Anadata.InstallDate).ToString(), false);
                }
                //GGIRDHAR030717 JiraRegression.JiraMessage(resdata.ReasonForMismatch, RTN, DateTime.Parse(Anadata.InstallDate).ToString());
                //JiraRegression.JiraMessage(resdata.ReasonForMismatch.Replace("SWITCH ", "SW"), RTN, DateTime.Parse(Anadata.InstallDate).ToString(), false); //BMOLYNEA030617
                result += "<td> <a href=\"" + @"https://issues/browse/" + JiraJson.key + "\">" + JiraJson.key + "</a></td><td><b>" + JiraJson.status + "</b></td>";
            }
            catch (Exception e)
            {
                JiraJson.WriteLog(string.Format("ARCHES JiraMessage Exception: {0}\n", e));//BMOLYNEA033017
            }
            result += "</tr>\n";
            /* BMOLYNEA011917 END */

            JiraJson.WriteLog("Results Complete");//BMOLYNEA033017

            return result;
        }

        private string createFieldValueTable(Dictionary<string, string> fieldvalues)
        {
            string result = "<table>\n";
            foreach (var item in fieldvalues)
            {
                //Parse baserun and coderun values
                string baserun = null; string coderun = null;
                if (item.Value.ToUpper().Contains("RUN1ONLY"))
                    baserun = item.Value.Replace(item.Key + "_", "").Replace(item.Key, ""); //F2240_Run1only (0003)  
                else if (item.Value.ToUpper().Contains("NOT IN CODE RUN"))
                    baserun = item.Value.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0];
                else if (item.Value.ToUpper().Contains("RUN2ONLY"))
                    coderun = item.Value.Replace(item.Key + "_", "").Replace(item.Key, ""); //F2240_Run2only (0003)  
                else if (item.Value.ToUpper().Contains("NOT IN BASE RUN"))
                    coderun = item.Value.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0];
                else
                {
                    int x = item.Value.IndexOf("(");
                    if (x >= 0)
                    {
                        var tmp = item.Value.Substring(x + 1).Replace(")", "").Replace("(", "");
                        var splitted = tmp.Replace(item.Key, "").Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                        baserun = splitted[0];
                        coderun = splitted.Count() > 1 ? splitted[1] : ""; /// This will happen only if any 1 of the fields are completely spaces 
                    }
                    else
                    {
                        // var tmp = item.Value.IndexOf("(") >= 0 ? item.Value.Substring(item.Value.IndexOf("(") + 1).Replace(")", "") : item.Value;
                        var splitted = item.Value.Replace(item.Key, "").Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                        baserun = splitted[0];
                        coderun = splitted.Count() > 1 ? splitted[1] : ""; /// This will happen only if any 1 of the fields are completely spaces 
                    }
                }

                result += "<tr>\n<td style=\"width:80px;border-color: #F0F0F0\">" + item.Key + "</td><td style=\"width:150px;word-wrap: break-word;border-color: #F0F0F0\">" + baserun + "</td><td style=\"width:150px;word-wrap: break-word;border-color: #F0F0F0\">" + coderun + "</td>\n</tr>\n";

                /* BMOLYNEA020117 */
                try
                {
                    JiraRegression.RegDescription("Field " + item.Key + "- Baserun=" + baserun + "and Coderun=" + coderun + "\n");
                }
                catch { }
                /* BMOLYNEA020117 END */
            }
            result += "</table>\n";
            return result;
        }

        protected string style()
        {
            return
                @"<head>
                    <style>

                        body {
                            font-family:Calibri
                        }

                        h5, h4, h3, h2, h1 {
                            text-decoration: underline;
                        }

                        table {
                            border-collapse: collapse;
                         }

                        table, th, td {
                             border: 1px solid black;
                         }
                        td {
                            background-color: LightCyan;
                        }                         
                        th {
                            background-color: LightYellow;
                        }
                        tr.head{
                            background-color: LightGray;
                        }
                        p{
                            font-family:Calibri
                        }
                    </style>
                </head>";
        }
        #endregion

        #region Other Functions
        private void AddOrUpdateStageLog(string Stage, string Status, bool newStage, bool updateScheduler = true)
        {
            try
            {

                if (newStage)
                {
                    Application.Current.Dispatcher.Invoke(
                            () => _AnaStages.Insert(0, new RegStage() { Stage = Stage, StartAt = DateTime.Now.ToString("MM/dd/yy HH:mm:ss"), Status = Status })
                        );
                }
                else
                {
                    Application.Current.Dispatcher.Invoke(() => _AnaStages.First().EndAt = DateTime.Now.ToString("MM/dd/yy HH:mm:ss"));
                }

                // Stage Status Update
                Application.Current.Dispatcher.Invoke(() => _AnaStages.First().Status = Status);

            }
            catch (Exception ex)
            {
                System.IO.File.WriteAllText(System.IO.Path.Combine(Runsettings.CoderunServer, ex.GetHashCode() + ".Exception"), ex.ToString());
            }
            finally
            {// Updates to flat file

                if (updateScheduler)
                { //update new stage to RegressionOutputFile
                    new Thread(() => InputFile.UpdateStatus(App.InputObj, _AnaStages.First().Stage + '\t' + _AnaStages.First().Status)).Start();
                }
                // logs in RunStatus.txt
                new Thread(() => UpdateStagestofile()).Start();
            }


            //try
            //{
            //    Application.Current.Dispatcher.Invoke((Action)(() =>
            //    {
            //        if (addnew)
            //        {
            //            _AnaStages.Insert(0, new RegStage() { Stage = Stage, StartAt = DateTime.Now.ToString("MM/dd/yy HH:mm:ss"), Status = Status });
            //            ///update start stage status to file
            //            (new Thread(() => { InputFile.UpdateStatus(App.InputObj, _AnaStages.First().Stage + '\t' + _AnaStages.First().Status); })).Start();
            //        }
            //        _AnaStages.First().Status = Status;
            //        if (!addnew)
            //        {
            //            _AnaStages.First().EndAt = DateTime.Now.ToString("MM/dd/yy HH:mm:ss");
            //            ///update end stage status to file
            //            (new Thread(() => { InputFile.UpdateStatus(App.InputObj, _AnaStages.First().Stage + '\t' + _AnaStages.First().Status); })).Start();
            //        }
            //        //UpdateStagestofile();
            //        (new Thread(UpdateStagestofile)).Start();

            //    }));
            //}
            //catch { };
        }
        void UpdateStagestofile()
        {
            if (Anadata.RegServer != "")
            {
                try
                {
                    System.IO.File.WriteAllLines(Anadata.RegServer + @"\AnalysisStatus.txt", _AnaStages.Select(s => s.Stage.PadRight(50) + s.StartAt.PadRight(20) + s.Status.PadRight(50) + s.EndAt.PadRight(20) + s.TimeTaken.PadRight(10)));

                }
                catch (Exception)
                {
                }
            }
        }
        #endregion


        #region ErrorHandle
        /// <summary>
        /// Return a true if you want continue else return false. 
        /// LogOnly-Return True
        /// NotifyOnly-Return True
        /// NotifyandAbort-Return False
        /// NotifyandWait-Returns True/False based on dialog result
        /// </summary>
        /// <param name="errorstring"></param>
        /// <param name="errortype"></param>
        /// <returns></returns>
        /// /*
        bool HandleError(string errorstring, ErrorTypes errortype, ErrorGroup ERRGRP = ErrorGroup.NOT_CLASSIFIED_ERROR, string subject = null, string emailid = null, bool attacherrorfile = true)
        {
            try
            {
                ana.SendText(Keys3270.Reset, false, false);
            }
            catch { }
            if (errortype != ErrorTypes.NotifyOnly)
            {
                ErrorsInRun.Insert(0, DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + "==> " + errorstring);
                System.IO.File.WriteAllLines(Anadata.RegServer + "\\AnalysisErrors.txt", ErrorsInRun);
            }
            try
            {
                if (ERRGRP != ErrorGroup.NO_ERROR)
                {
                    //Add error to ErrorDB csv file
                    //MM/dd/yyyy hh:mm:ss tt,"Error text",ErrorGroup
                    System.IO.File.AppendAllLines(App.RegressionErrorDBfile,
                        new string[] { DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + ",\""
                            + errorstring.Replace("\"", null) + "\","
                            + ERRGRP.ToString()+"," +
                            (Runsettings != null ?  Runsettings.InstallDate + "," + Runsettings.RegType + "," + Runsettings.RunNumber+","+(Anadata.IsSchedulerAnalysis?"Scheduler Analysis,":"UI Analysis,")+"\""+Runsettings.CoderunServer+"\"," : ",,,,,,")
                            +errortype.ToString() });
                }
            }
            catch
            { }
            try
            {
                // Store the screenshot file into coderun server
                System.IO.File.Copy(ana.screenshotfile, System.IO.Path.Combine(Anadata.RegServer, System.IO.Path.GetFileName(ana.screenshotfile)), true);
                //System.IO.File.Delete(ana.screenshotfile);
            }
            catch (Exception) { }
            if (errortype != ErrorTypes.LogOnly)
            {
                new Thread(() =>
                {
                    Outlook.Application oApp; Outlook.MailItem oMsg; Outlook.Recipients oRecips; Outlook.Recipient oRecip;
                    try
                    {
                        if (errortype != ErrorTypes.LogandWait)
                        {
                            oApp = new Outlook.Application();
                            oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                            oRecips = (Outlook.Recipients)oMsg.Recipients;
                            if (emailid == null)
                                oRecip = (Outlook.Recipient)oRecips.Add(Anadata.Email + "@visa.com");
                            else
                                oRecip = (Outlook.Recipient)oRecips.Add(emailid + "@visa.com");
                            oRecip.Resolve();
                            if (subject == null)
                                oMsg.Subject = "ARCHES error: " + (Runsettings.VIPS.Where(v => v.VPARS != "" && v.VPARS != null).Count() + " VIP ") + Runsettings.RegType + " Regression for " + Runsettings.InstallDate + " install " + (Runsettings.SwitchActivationInfo != "N/A" ? Runsettings.SwitchActivationInfo + " Switch Activated " : null) + "(" + Runsettings.RunNumber + ") " + "- Error => " + errorstring;
                            else
                                oMsg.Subject = subject;
                            oMsg.BodyFormat = Outlook.OlBodyFormat.olFormatPlain;
                            oMsg.Body = Anadata.RegServer;
                            if (attacherrorfile)
                            {
                                oMsg.Body += "\nPlease review the errors from attached file.\nAuto generated from QACT";
                                oMsg.Attachments.Add(Anadata.RegServer + "\\AnalysisErrors.txt");
                            }
                            else
                                oMsg.Body += "\nAuto generated from QACT";

                            ((Outlook._MailItem)oMsg).Send();
                        }

                    }
                    catch (Exception)
                    {

                    }
                    finally
                    {
                        oApp = null; oMsg = null; oRecip = null; oRecips = null;
                    }

                }).Start();

                if (errortype == ErrorTypes.NotifyandAbort)
                {
                    if (Anadata.IsSchedulerAnalysis)
                        ErrorAbort();
                    return false;
                }
                else if (errortype == ErrorTypes.NotifyandWait || errortype == ErrorTypes.LogandWait)
                    if (MessageBox.Show("Press Yes to Continue, No to Abort\nError encountered:\n" + errorstring, "Regression Window - " + ana.SessionShortName, MessageBoxButton.YesNo, MessageBoxImage.Error, MessageBoxResult.Yes) == MessageBoxResult.No)
                        return false;
            }
            return true;
        }
        string getexacterrorfromscreen(string errorkey)
        {
            try
            {
                var tmp = ana.GetLines(80).FirstOrDefault(l => l.ToUpper().Contains(errorkey.ToUpper()));
                if (tmp == null)
                    return errorkey;
                else
                    return tmp.Trim();
            }
            catch (Exception)
            {
                return errorkey;
            }
        }
        public void ErrorAbort()
        {
            if (IsLoggedon)
            {
                //Finishing Analysis
                try
                {
                    //Do a Page up +I cms
                    ana.SendText(Keys3270.PA1);
                    ana.EnterCommand("I CMS");
                    ana.SendText(Keys3270.Enter);
                    ana.WaitforString("Ready", 10);
                    debugdtd(Anadata.CodeRunVpars);//Saumen021417
                    UploadAnalysisFiles();//Saumen020617
                    UploadRexxErrorLog();
                    LogOffVpars(new List<string> { Anadata.BaseRunVpars, Anadata.CodeRunVpars });
                    if (HSM_PRODD77 == "DETACHED")                                                                  //Saumen090116
                    {
                        ReserveHSM("2", "ATTACH");                                                                  //Saumen082916
                    }
                }
                catch { }

                try
                {
                    LogOffCMS();//Saumen020917
                }
                catch { }
            }
            //Most probably scheduler version is trying to call logoff and all of them again
            //and that is creating the VM is not accepting inputs error.
            //What I'm doing is to unsubscribe the event in case of error abort
            this.OnAnalysisCompleted -= Scheduler_OnAnalysisCompleted;
            ana.DisconnectSession();
            App.InputObj.State = InputFile.Status.ARCHES_COMPLETED;
            AddOrUpdateStageLog("Error", "Aborted", true, updateScheduler: false);                                  //Saumen082416
            InputFile.UpdateStatus(App.InputObj, _AnaStages.ElementAt(2).Stage + '\t' + _AnaStages.ElementAt(2).Status + " Error : Aborted");//Saumen092816
            // Close QACT
            AddOrUpdateStageLog("Error", "Aborted", true);                                                          //Saumen082416
            if (Application.Current != null)
                Application.Current.Dispatcher.Invoke(() =>
                {
                    try
                    {
                        Application.Current.Shutdown(-1);
                        IsIdle = true;
                    }
                    catch
                    {
                        Environment.Exit(-1);
                    }

                });
        }
        #endregion

        //Saumen082916
        private void ReserveHSM(string noofhsm, string option)
        {
            //ana.EnterCommand("GET TESTCASE", 2);                                                                    //Saumen090816
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                ana.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            ana.EnterCommand("GET VIPQAAUT", 2);//Saumen021417
            ana.EnterCommand("RESHSM " + noofhsm + " " + option, 2);
            if (ana.WaitforString("Processing completed successfully", 5) == 0)
            {
                if (ana.WaitforString("PRODD77 is LOGGED OFF", 5) != 0)
                {
                    ana.EnterCommand("PIPE LITERAL PRODD77 is LOGGED OFF |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                }
                else
                {
                    ana.EnterCommand("PIPE LITERAL HSM could not be " + option + "ED to/from PRODD77 |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
                }
            }
            else
            {
                ana.EnterCommand("PIPE LITERAL " + noofhsm + " HSM successfully " + option + "ED to/from PRODD77 |>> PRODREGG SUMMARY A1", VMCommandTimeOut);
            }
        }
        //Saumen082916
        //Saumen020917
        /// <summary>
        /// Logs of the logged in CMS by enetering "LOG"
        /// </summary>
        public void LogOffCMS()
        {
            // LOGGING OFF
            //reg.EnterCommand("LOGOFF", 3);                                                                          //Saumen082316
            //reg.WaitforString("z/VM ONLINE", 15);
            UpdateUsingFile();//Saumen020917
            ana.EnterCommand("LOGOFF", 1);
            ana.WaitforString("z/VM ONLINE", 30, false);
            ana.DisconnectSession();//Saumen020917
        }
        /// <summary>
        /// Updates the Using.json file at "\\fileshareocw\viptestmbrsupapp\TestTools&Automation\Automation_Files\Using.json".
        /// This file contains the usage of all Prodd ids, QATs and Autoreg ids. 
        /// </summary>
        private void UpdateUsingFile()
        {
            if (!((App)App.Current).IsVIPTESTENGMember)
                return;
            //ana.EnterCommand("GET TESTCASE", 1);
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                ana.EnterCommand("GET VIPTETST", VMCommandTimeOut);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            ana.EnterCommand("GET VIPQAAUT", 1);//Saumen021417
            ana.EnterCommand("USING AUTOREG", 1);
            //Ready; T=0.04/0.05 11:54:45
            ana.WaitForRegex(new Regex("Ready"), 20);

            string tmpFilePath = System.IO.Path.GetTempFileName();
            ana.ReceiveFile(tmpFilePath, "USAGE TEXT A1");

            Using UsingObj = new Using(tmpFilePath);
            UsingObj.StoreAsJSON();

            System.IO.File.Delete(tmpFilePath);
        }
        //Saumen020917

        //Saumen021417
        private void debugdtd(string VPARSID)
        {
            try
            {
                ana.EnterCommand("HX", 2);
                ana.EnterCommand("B", 2);
                ana.WaitforString("Ready", 2 * 60);
                ana.EnterCommand("TPFPROC CUTDTD " + VPARSID + " SCR(NODISPLAY", 2);
                ana.WaitforString("Ready", 5 * 60);
                ana.EnterCommand("PIPE < CUTDTD TPFPLOG A1|locate /DTD Tapenumbers/ |TAKE 1|strip|specs w3-* 1|preface literal DEBUG DTD: |join|>> PROGRESS LISTING A1", 2);
            }
            catch (Exception)
            {
            }
        }
        //Saumen021417
    }
    class ResultData
    {
        public int TestcaseId { get; set; }
        public string ReasonForMismatch { get; set; }
        public Dictionary<string, string> FieldValues { get; set; }
        public string PROC { get; set; }
        public string MTI { get; set; }
        public string MCC { get; set; }
    }
    class WERTNDEVS
    {
        public string WE { get; set; }
        public string RTN { get; set; }
        public string DEVS { get; set; }
    }
}


// ***************************************************************************************
//                                  Change Log
// ***************************************************************************************
// Date       - Name            - Description                               - Label
// ***************************************************************************************
// 03/30/2017 - Brandon         - Jira piece logging added                  - BMOLYNEA033017
//              Molyneaux
// 03/07/2017 - Brandon         - Added calling method to open JIRA ticket  - BMOLYNEA030717
//              Molyneaux         TBF items
// 03/01/2017 - Gaurav Girdhar  - Test Framework Enhancement                - GGIRDHAR030717
//                                All the access will be from VIPTETST      - GGIRDHAR030717
// 01/19/2017 - Brandon         - Added Jira Integration back to the code   - BMOLYNEA011917
//              Molyneaux         Added link to developer responsibility 
//                                document
//                                Added Columns for Obs Ticket # and Obs 
//                                Status
//                                Added putting the subject of the email
//                                as part of the summary in the JIRA ticket
// 09/28/2016 - Saumen Biswas   - Added the last error step description in  - Saumen092816
//                                regression output text
// 09/08/2016 - Saumen Biswas   - Added 'GET TESTCASE' before calling       - Saumen090816
//                                'RESHSM'
// 09/01/2016 - Saumen Biswas   - Added check before attaching HSM back to  - Saumen090116
//                                PRODD77
// 08/29/2016 - Saumen Biswas   - Added call to RESHSM EXEC to reserve HSMs - Saumen082916
// 08/25/2016 - Saumen Biswas   - More updates in the regression output     - Saumen082516
//                                status text
// 08/24/2016 - Saumen Biswas   - Updated regression output file status to  - Saumen082416
//                                show the last step for error aborted
// ***************************************************************************************
