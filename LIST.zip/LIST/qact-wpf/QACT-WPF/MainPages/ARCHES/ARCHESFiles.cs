﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;

namespace QACT_WPF
{
    class ARCHESFiles
    {
        public static bool CreateAndTransferSetups(AnalysisData anadata)
        {
            //
            List<string> filestoTransfer = new List<string>();

            var sainfo = anadata.SwitchActivationInfo != "N/A" && anadata.SwitchActivationInfo != null ? ",SA" : null;
            try
            {
                //Create Baserun setup

                string baserunargs =
                "ISETUP USESERV NOCLICK NOEDIT CMS=" + anadata.VMId + " PWD=" + anadata.VMPassword +
                " SYS=" + anadata.BaserunInstallDate.Substring(0, 5) + " RUN=" + anadata.RegType +
                " FILE=" + "BASERUN" + " GLB=" + DateTime.ParseExact(anadata.Capture, "MMdd", null).ToString("MM/dd")
                + " VIPB=" + anadata.BaseRunVpars;

                //Invoke Baserun setup hare
                filestoTransfer.AddRange(CreateSetup(baserunargs, App.TSUFileServer));//anadata.WorkingFolderPath + "\\tsu.txt"
                if (App.InputObj != null)
                {   // For AUTOMATED REGression use regression setup
                    //////////////////////////// THIS SETUP ASSUMES THAT THE ZBURZ FILES ARE ALREADY PRESENT IN THE REGRESSION CMS ////////////////////////////////////
                    List<string> CodeRunSetupFromRegression = CreateCodeSetup(File.ReadAllLines(System.IO.Path.Combine(anadata.RegServer, "setup-coderun.txt"), Encoding.Default), anadata.CodeRunVpars);

                    string CoderunFilePath = System.IO.Path.Combine(App.LocalSetupStoreFolder, "CODERUN.$TTVDATA");
                    System.IO.File.Delete(CoderunFilePath);
                    System.IO.File.WriteAllLines(CoderunFilePath, CodeRunSetupFromRegression);
                    filestoTransfer.Add(Path.GetFileName(CoderunFilePath));
                }
                else
                {
                    // CreateCoderun Setup for Manual Regression 
                    // Using the TSU
                    string coderunargs =
                        "ISETUP USESERV NOCLICK NOEDIT CMS=" + anadata.VMId + " PWD=" + anadata.VMPassword +
                        " SYS=" + anadata.InstallDate.Substring(0, 5) + " RUN=" + anadata.RegType + sainfo +
                        " FILE=" + "CODERUN" + " GLB=" + DateTime.ParseExact(anadata.Capture, "MMdd", null).ToString("MM/dd")
                        + " VIPB=" + anadata.CodeRunVpars;
                    filestoTransfer.AddRange(CreateSetup(coderunargs, App.TSUFileServer)); //anadata.WorkingFolderPath + "\\tsu.txt"
                }

                ///////////////////////////////////// transfer files to VM /////////////////////
                foreach (var file in filestoTransfer)
                {
                    try
                    {
                        File.Copy(Path.Combine(App.LocalSetupStoreFolder, file), Path.Combine(anadata.RegServer, file),true);
                    }
                    catch { }
                    FTPUpload(Path.Combine(App.LocalSetupStoreFolder, file), file.Replace(".", " "), anadata.VMId, anadata.VMPassword, false);
                }
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                File.Copy(App.TSUFileServer, Path.Combine(anadata.RegServer, "TSU_Analysis.txt"), true);
            }

            return true;
        }
        static List<string> CreateSetup(string arg, string tsuserver)
        {
            List<string> filenames = new List<string>();
            var oldcmdlineargs = App.CMDLINEARGS;
            var oldTSUserver = App.TSUFileServer;
            App.CMDLINEARGS = arg.Split(' ').ToList();
            App.TSUFileServer = tsuserver;
            iSetup isetup = null;

            if (Application.Current != null)
                Application.Current.Dispatcher.Invoke((Action)(() =>
                {
                    isetup = new iSetup(getlist: true);
                }));
            for (int i = 0; i < 5; i++)
            {
                Thread.Sleep(1000);
                if ((Application.Current as App).Status.Contains("File List returned to caller.") || (isetup.CurrentError != null))
                    break;
                if (i == 4)
                {
                    isetup.CurrentError = "Timed out.";
                }
            }
            App.CMDLINEARGS = oldcmdlineargs;
            App.TSUFileServer = oldTSUserver;
            return isetup.FilestoTransfer;

        }
        public static string UploadOtherfiles(AnalysisData anadata)//H14DEF,FLBK,SAVETAPE
        {
            //Must Implement FTP due to Error in File Upload.

            string Result = null;
            //try
            //{
            //    if (!System.IO.Directory.Exists(anadata.WorkingFolderPath))
            //        System.IO.Directory.CreateDirectory(anadata.WorkingFolderPath);
            //    System.IO.File.Copy(anadata.RegServer + "\\H14DEF.TXT", anadata.WorkingFolderPath + "_H14DEF.TXT", true);
            //}
            //catch (FileNotFoundException)
            //{
            //    System.IO.File.Delete(anadata.WorkingFolderPath + "_H14DEF.TXT");
            //}
            try
            {
                List<string> savatape = new List<string>() { anadata.MM_Fltype, anadata.RegBucket };
                savatape.Add(System.IO.File.ReadAllLines(anadata.RegServer + "\\logtapes-baserun.txt").FirstOrDefault(l => l.Contains("DTD:")).Replace("DTD:", "").Replace("Time-out", "").Replace("Error", "").Trim());
                savatape.Add(System.IO.File.ReadAllLines(anadata.RegServer + "\\logtapes-coderun.txt").FirstOrDefault(l => l.Contains("DTD:")).Replace("DTD:", "").Replace("Time-out", "").Replace("Error", "").Trim());
                System.IO.File.WriteAllLines(anadata.RegServer + "\\SAVETAPE.TEXT", savatape);
            }
            catch (Exception)
            { }
            try
            {
                FTPUpload(anadata.RegServer + "\\H14DEF.TXT", "H14DEF.TXT", anadata.VMId, anadata.VMPassword, false);
                FTPUpload(anadata.RegServer + "\\SAVETAPE.TEXT", "SAVETAPE.TEXT", anadata.VMId, anadata.VMPassword);
                //Download the Fallback script from WEB app
                if (anadata.SwitchActivationInfo == "N/A")
                {
                    using (WebClientEx webclient = new WebClientEx())
                    {
                        var Loginpage = webclient.DownloadString("http://pslimsapp.visa.com/slims/login");
                        var Logindata = new NameValueCollection
                        {
                            { "username", App.SliMSID},
                            { "password", App.SliMSPWD },
                            {"_csrf",Loginpage.Substring(Loginpage.IndexOf("_csrf")+ 14, 36)}
                        };
                        //Login
                        var loginresp = webclient.UploadValues("http://pslimsapp.visa.com/slims/login", Logindata);
                        if (!System.IO.File.Exists(anadata.FallbackPath))
                        {
                            CommonClass.ChangeStatus("Downloading fallback script ...", 0, 1, true);
                            if (System.IO.File.Exists(anadata.RegServer + "\\FallbackScript.txt"))
                                System.IO.File.Delete(anadata.RegServer + "\\FallbackScript.txt");
                            var Data = webclient.DownloadData(@"http://pslimsapp.visa.com/slims/report?type=svfallback&format=txt&dates=" + DateTime.ParseExact(anadata.InstallDate, "MM/dd/yyyy", null).ToString("yyyy-MM-dd"));
                            System.IO.File.WriteAllText(anadata.RegServer + "\\FallbackScript.txt", Encoding.Default.GetString(Data).Replace("\r", null).Replace("\n", Environment.NewLine));
                        }
                        else
                            System.IO.File.Copy(anadata.FallbackPath, anadata.RegServer + "\\FallbackScript.txt", true);
                        anadata.FallbackPath = anadata.RegServer + "\\FallbackScript.txt";
                        if (System.IO.File.Exists(anadata.RegServer + "\\WELIST.xls"))
                            System.IO.File.Delete(anadata.RegServer + "\\WELIST.xls");
                        CommonClass.ChangeStatus("Downloading simple WE list ...", 0, 1, true);
                        webclient.DownloadFile(@"http://pslimsapp.visa.com/slims/report?type=simple-we-list&format=xls&dates=" + DateTime.ParseExact(anadata.InstallDate, "MM/dd/yyyy", null).ToString("yyyy-MM-dd")
                            , anadata.RegServer + "\\WELIST.xls");
                        CommonClass.ChangeStatus("Ready.", 0, 0, false);
                    }
                }
                else
                {
                    //if (QACTSwitches.IsSwitchActive(2))
                    //{
                    try
                    {
                        string tmppath = Path.GetTempFileName();
                        //Read current TSU and determine the first Switch Activated ZBURZ
                        //Naming convention RELYY_XX e.g OCT16_28
                        string firstzburz = null;
                        var systemfromTSU = System.IO.File.ReadAllLines(App.TSUFileServer).Select(l => l.ToUpper());
                        systemfromTSU = systemfromTSU.SkipWhile(l => !(l.Contains("A/B/C") && l.Contains("INSTALL") && l.Contains(anadata.InstallDate.Substring(0, 5))));
                        systemfromTSU = systemfromTSU.TakeWhile(l => !l.Contains("ENTER ZKSET APSD1F"));
                        if (systemfromTSU != null && systemfromTSU.Count() > 0)
                        {
                            //Now find the first SA ZBURZ
                            var firstsazburzline = systemfromTSU.FirstOrDefault(l => l.Contains(anadata.SwitchActivationInfo) && l.Contains("DURING-") && l.Contains("SA") && l.Contains("ZBURZ"));
                            if (firstsazburzline != null)
                                firstzburz = firstsazburzline.Split(' ').FirstOrDefault(w => w.Contains(anadata.SwitchActivationInfo));
                            if (firstzburz == null)
                                throw new InvalidDataException("SA ZBURZ is not found from TSU");
                        }
                        //
                        try
                        {
                            FTPDownload(tmppath, firstzburz + ".ZBURZ", "VIPQAAUT/BY/SAUBISWC", DateTime.Now.ToString("MMMyyyy"));
                        }
                        catch (Exception)
                        {
                            FTPDownload(tmppath, firstzburz + ".ZBURZ", "VIPQAAUT/BY/SAUBISWC", DateTime.Now.AddMonths(-1).ToString("MMMyyyy"));
                        }
                        if (File.Exists(tmppath))
                        {
                            var safallbackscript = new List<string>();
                            File.ReadAllLines(tmppath).Select(l => l.ToUpper()).Where(l => l.Contains(" ON ") && !l.Contains("*") && l.Contains("ZKSWT")).ToList()
                                .ForEach((l) =>
                                {
                                    var swtnoregex = new Regex(@"ZKSWT\s+(?<SWTNO>\d+)?");
                                    if (swtnoregex.IsMatch(l))
                                    {
                                        var swtno = swtnoregex.Match(l).Groups["SWTNO"];
                                        if (swtno.Success)
                                        {
                                            safallbackscript.Add("*- SWITCH-" + swtno.Value);
                                            safallbackscript.Add(l.Replace("ON", "OFF"));
                                            safallbackscript.Add("*---------------------");
                                        }
                                    }
                                });
                            if (safallbackscript.Count > 0)
                            {
                                File.WriteAllLines(anadata.RegServer + "\\FallbackScript.txt", safallbackscript);
                                anadata.FallbackPath = anadata.RegServer + "\\FallbackScript.txt";
                            }
                            else
                                return "Switch Activated fallback script has no switch information.";
                            try
                            {
                                File.Delete(tmppath);
                            }
                            catch { };
                        }
                    }
                    catch (Exception ex)
                    {
                        return ex.Message;
                    }
                    /*}
                    else
                    {
                        anadata.FallbackPath = App.SAFallbackFolder + "\\" + anadata.SwitchActivationInfo + ".ZBURZ";
                        File.Copy(anadata.FallbackPath, anadata.RegServer + "\\FallbackScript.txt", true);
                    }*/
                }

                //
                FTPUpload(anadata.FallbackPath, "FLBK.SCRIPT", anadata.VMId, anadata.VMPassword);
                Result = null;
            }
            catch (InvalidOperationException ex)
            {
                Result = ex.Message.Replace("\n", null);
            }
            return Result;
        }
        private static void FTPUpload(string PCfilePath, string serverfilename, string cmsid, string pwd, bool exceptiononfailure = true)
        {

            FtpWebRequest request;
            Uri VM3Uri = new Uri(@"ftp://vm3.visa.com/");

            try
            {
                if (cmsid.ToLower().Contains(" by "))       // for a logon by user id
                {
                    //request = (FtpWebRequest)WebRequest.Create(@"ftp://vm3.visa.com/autoreg1.192/" + serverfilename);
                    ///////// complete remote file path, in case of autoregs

                    Uri autoregRemoteFileURI = new Uri(VM3Uri, cmsid.ToLower().Split(new string[] { " by " }, StringSplitOptions.RemoveEmptyEntries)[0].Trim() + ".291/" + serverfilename);

                    request = (FtpWebRequest)WebRequest.Create(autoregRemoteFileURI);
                    ///////////// ftp login id
                    cmsid = cmsid.ToLower().Split(new string[] { " by " }, StringSplitOptions.RemoveEmptyEntries)[1];
                }
                else
                    request = (FtpWebRequest)WebRequest.Create(new Uri(VM3Uri, serverfilename));


                request.Credentials = new NetworkCredential(cmsid, pwd);
                request.Proxy = null;
                //request.Proxy = WebRequest.GetSystemWebProxy();
                request.KeepAlive = false;
                if (!System.IO.File.Exists(PCfilePath) || System.IO.File.ReadAllBytes(PCfilePath).Length == 0)
                {
                    request.Method = WebRequestMethods.Ftp.DeleteFile;
                    request.GetResponse();
                }
                else
                {
                    request.Method = WebRequestMethods.Ftp.UploadFile;
                    request.UseBinary = false;
                    using (StreamReader sourceStream = new StreamReader(PCfilePath))
                    {
                        byte[] fileContents = Encoding.Default.GetBytes(sourceStream.ReadToEnd());
                        request.ContentLength = fileContents.Length;
                        using (Stream requestStream = request.GetRequestStream())
                        {
                            try
                            {
                                requestStream.Write(fileContents, 0, fileContents.Length);
                            }
                            catch (Exception ex)
                            {
                                //Close the stream so that the file is not locked.
                                sourceStream.Close();
                                sourceStream.Dispose();
                                throw ex;
                            }

                        }
                    }
                }
            }
            //More specific error
            catch (WebException e)
            {
                String status = ((FtpWebResponse)e.Response).StatusDescription;
                if (exceptiononfailure)
                    throw new InvalidOperationException(status);
            }
            catch (Exception Ex)
            {
                if (exceptiononfailure)
                    throw new InvalidOperationException(Ex.Message);
            }

        }

        private static void FTPDownload(string PCfilePath, string serverfilename, string cmsid, string pwd, bool exceptiononfailure = true, bool isBinary = false)
        {

            FtpWebRequest request;
            Uri VM3Uri = new Uri(@"ftp://vm3.visa.com/");
            try
            {
                request = (FtpWebRequest)WebRequest.Create(new Uri(VM3Uri, serverfilename));
                request.Credentials = new NetworkCredential(cmsid, pwd);
                request.Proxy = null;
                request.KeepAlive = false;
                request.UseBinary = isBinary;
                request.Method = WebRequestMethods.Ftp.DownloadFile;
                var resp = request.GetResponse();
                using (Stream responseStream = resp.GetResponseStream())
                {
                    try
                    {
                        StreamReader reader = new StreamReader(responseStream);
                        File.WriteAllText(PCfilePath, reader.ReadToEnd());
                    }
                    catch (Exception ex)
                    {
                        responseStream.Close(); responseStream.Dispose();
                        throw ex;
                    }

                }
            }
            //More specific error
            catch (WebException e)
            {
                String status = ((FtpWebResponse)e.Response).StatusDescription;
                if (exceptiononfailure)
                    throw new InvalidOperationException(status.Trim());
            }
            catch (Exception Ex)
            {
                if (exceptiononfailure)
                    throw new InvalidOperationException(Ex.Message);
            }

        }
        private static List<string> CreateCodeSetup(string[] alllines, string vparsid)
        {
            List<string> newsetup = new List<string>();
            bool systemnamefound = false;
            string systemname = "DEFAULTNAME";

            foreach (var line in alllines)
            {
                string line2add = String.Empty;

                if (line.ToUpper().Contains("J.VPARSTYPES") && !systemnamefound)
                {
                    string[] tmparray = line.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var item in tmparray)
                    {
                        if (item.ToUpper().Contains("11B"))
                        {
                            systemname = item;
                            line2add = "J.VPARStypes  " + item;
                            systemnamefound = true;
                            newsetup.Add(line2add);
                            break;
                        }
                    }
                    if (systemnamefound)
                    {
                        continue;
                    }
                }
                else if (systemnamefound && line.ToUpper().Contains("H." + systemname + ".USERIDS"))
                {
                    string[] tmparray = line.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                    line2add = "H." + systemname + ".Userids " + vparsid;
                }
                else if (systemnamefound && line.ToUpper().Contains("H." + systemname + ".VDBNAME"))
                {
                    string[] tmparray = line.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                    line2add = "H." + systemname + ".VDBName " + "24";
                }
                else if (line.ToUpper().Contains("IS3,VPC*ALL") && line.Contains(systemname))
                {
                    line2add = line.Replace("IS3,VPC*ALL", "IS1,VPC*ALL");
                }
                else if (line.ToUpper().Contains("J.OPTIONS") || line.ToCharArray().First() == '*')
                {
                    line2add = line;
                }
                else if (line.ToUpper().Contains(".DOZMS") && (line.ToUpper().Contains("PROD") ||
                    line.ToUpper().Contains("MINI") || line.ToUpper().Contains("SOAP") ||
                    line.ToUpper().Contains("DRB") || line.ToUpper().Contains("BADD") ||
                    line.ToUpper().Contains("STIP") || line.ToUpper().Contains("TKN") || line.ToUpper().Contains("ECIP") || line.ToUpper().Contains("NCC") || line.ToUpper().Contains("PCR9371I")))
                {
                    continue;
                }

                else if (systemnamefound && !line.Contains(systemname))
                {
                    continue;
                }

                else
                {
                    line2add = line;
                }
                if (line.ToUpper().Contains(".DOZMS"))
                {
                    string zburzname = line.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[1].Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries)[0];
                    if (zburzname.Contains("QA") || zburzname.Contains("BASE"))
                    {
                        //files_to_get.Add(zburzname + ".ZBURZ");
                    }

                }
                newsetup.Add(line2add);
            }
            return newsetup;
        }

    }
}
