﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for SystemMaster.xaml
    /// </summary>
    public partial class SystemMaster : Page, INotifyPropertyChanged
    {
        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        bool IsSysteminNorm = false;
        public ObservableCollection<VIP> ObsAllVIP { get { return this._ObsAllVIP; } set { _ObsAllVIP = value; NotifyPropertyChanged("OBSALLVIP"); } }
        ObservableCollection<VIP> _ObsAllVIP = new ObservableCollection<VIP>();
        string _InstallDate;
        public string InstallDate
        {
            get { return _InstallDate; }
            set
            {
                if (value != null)
                    _InstallDate = DateTime.Parse(value).ToString("MM/dd/yyyy");
                else
                    _InstallDate = null;
                NotifyPropertyChanged("InstallDate");
            }
        }
        string _GlobalCapture = "";
        public string GlobalCapture { get { return _GlobalCapture; } set { _GlobalCapture = value; NotifyPropertyChanged("GlobalCapture"); } }
        string _SystemType = "QA";
        public string SystemType { get { return _SystemType; } set { _SystemType = value; PopulateVIPs(SystemType); NotifyPropertyChanged("SystemType"); } }
        string _DDRFrom = "";
        public string DDRFrom { get { return _DDRFrom; } set { _DDRFrom = value; NotifyPropertyChanged("DDRFrom"); } }
        string _DDRTo = "";
        public string DDRTo { get { return _DDRTo; } set { _DDRTo = value; NotifyPropertyChanged("DDRTo"); } }
        string _PZTLD = "PZTLD";
        public string PZTLD { get { return _PZTLD; } set { _PZTLD = value; NotifyPropertyChanged("PZTLD"); } }
        bool _IsStartUpdate = false;
        public bool IsStartUpdate { get { return _IsStartUpdate; } set { _IsStartUpdate = value; NotifyPropertyChanged("IsStartUpdate"); } }
        private string _PrimaryCMSID = "XXXX";

        public string PrimaryCMSID
        {
            get { return _PrimaryCMSID; }
            set { _PrimaryCMSID = value; NotifyPropertyChanged("PrimaryCMSID"); }
        }

        string PrimaryCMSPassword;
        ObservableCollection<string> _Script = new ObservableCollection<string>();
        public ObservableCollection<string> Script { get { return this._Script; } set { this._Script = value; NotifyPropertyChanged("Script"); } }
        BackgroundWorker scriptworker = new BackgroundWorker();
        void _Script_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            Script = _Script;
        }
        Dictionary<string, string> TLDTapes = new Dictionary<string, string>();
        public SystemMaster()
        {
            InitializeComponent();
            _Script.CollectionChanged += _Script_CollectionChanged;
            scriptworker.DoWork += scriptworker_DoWork;
            scriptworker.RunWorkerCompleted += scriptworker_RunWorkerCompleted;
            GetPassedParams();
            PopulateVIPs(SystemType);
        }
        private void GetPassedParams()
        {
            if (App.CMDLINEARGS.Count > 0 && App.CMDLINEARGS[0].Equals("MULTISYS", StringComparison.InvariantCultureIgnoreCase))
            {
                //Use GLB=MMDD TYPE=QA/NATV/BASEZ/PZ DATE=MM/DD/YYYY
                var dictn = App.CMDLINEARGS.Skip(1).Select(a => a.ToUpper().Split('=')).ToDictionary(k => k[0], v => v.Length > 1 ? v[1] : null);
                InstallDate = dictn.ContainsKey("DATE") ? dictn["DATE"] : _InstallDate;
                GlobalCapture = dictn.ContainsKey("GLB") ? dictn["GLB"] : _GlobalCapture;
                SystemType = dictn.ContainsKey("TYPE") ? dictn["TYPE"] : _SystemType;
            }
        }

        public SystemMaster(string installdate, string capture, string type)
        {
            InitializeComponent();
            _Script.CollectionChanged += _Script_CollectionChanged;
            InstallDate = installdate;
            GlobalCapture = capture;
            PopulateVIPs(SystemType);
        }
        private void PopulateVIPs(string type)
        {
            // SystemtoUpdate = type;
            _ObsAllVIP.Clear();
            foreach (var vicid in App.ALLVIPS)
            {
                VIP tempvip = new VIP() { VIPNAME = "VIP" + vicid };
                if (type.ToUpper() == "BASEZ")
                {
                    tempvip.VPARS = "BB41" + vicid;
                    tempvip.IsEnabled = true;
                }
                else if (type.ToUpper() == "NATV")
                {
                    tempvip.VPARS = (vicid == "A" || vicid == "C") ? "NN41" + vicid : "";
                    tempvip.IsEnabled = (vicid == "A" || vicid == "C") ? true : false;
                }
                else if (type.ToUpper() == "PZ")
                {
                    tempvip.VPARS = "PP41" + vicid;
                    tempvip.IsEnabled = true;
                }
                else
                {
                    tempvip.VPARS = "QAP0" + (App.ALLVIPS.ToList().IndexOf(vicid) + 1);
                    tempvip.IsEnabled = true;
                }
                _ObsAllVIP.Add(tempvip);
            }
        }

        private void btnstart_Click(object sender, RoutedEventArgs e)
        {
            //
            return;
            //
            PrimaryCMSPassword = pwdPCMS.Password;
            if (string.IsNullOrWhiteSpace(PrimaryCMSID) || string.IsNullOrWhiteSpace(PrimaryCMSPassword))
            {
                MessageBox.Show("Primary CMS ID and Password Required");
                return;
            }
            grpbox.IsEnabled = false;
            scriptworker.RunWorkerAsync();
        }

        void scriptworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            CommonClass.ChangeStatus(e.Result.ToString(), 0, 0, false);
            grpbox.IsEnabled = true;
        }

        void scriptworker_DoWork(object sender, DoWorkEventArgs e)
        {
            Script.Clear();
            string ScriptFileStartInstallDate = null;
            List<string> OldWEList = new List<string>();
            try
            {
                CommonClass.ChangeStatus("Selecting systems...", 0, 1, true);
                FindDDRInfo(InstallDate, SystemType);
                IsSysteminNorm = false;
                Bringup_Rename_Rta(DDRFrom.Replace("X", null), DDRTo.Replace("X", null), SystemType);
                if (SystemType != "PZ")
                {
                    //If System is not PZ then only we'll Apply Script+Globals
                    List<string> NotfoundinDB = new List<string>();
                    CommonClass.ChangeStatus("Generating script template...", 0, 1, true);
                    _Script.Add("*--------- Add old changes from TSU ---------*");
                    AddZCommands(GetOldChangesfromTSU(DDRFrom, ref ScriptFileStartInstallDate, ref OldWEList), ref IsSysteminNorm, ref _Script, ref NotfoundinDB, ref TLDTapes);
                    _Script.Add("*--------- Download and add " + InstallDate + " Install Script from SLiMS ---------*");
                    DownloadScript(InstallDate);
                    AddZCommands(System.IO.File.ReadAllLines(App.LocalSupervisionFolder + "\\InstallScript_" + InstallDate.Replace("/", "_") + ".txt").ToList(), ref IsSysteminNorm, ref _Script, ref NotfoundinDB, ref TLDTapes);
                    if (NotfoundinDB.Count > 0)
                    {
                        System.IO.File.WriteAllLines(App.LocalSupervisionFolder + "\\NotInDB_" + InstallDate.Replace("/", "_") + ".txt", NotfoundinDB);
                    }
                    else
                        System.IO.File.Delete(App.LocalSupervisionFolder + "\\NotInDB_" + InstallDate.Replace("/", "_") + ".txt");
                }
                CommonClass.ChangeStatus("Checking for global chnages...", 0, 1, true);
                Global thisinstallglobal = GetGlobal(InstallDate, GlobalCapture);
                if (thisinstallglobal != null)
                {
                    //appliedglobal
                    var testsystemstatus = System.IO.File.ReadAllLines(App.TestSystemStatusServer);
                    var oldsys = testsystemstatus.First(l => l.Substring(0, l.IndexOf(',')) == DDRFrom);
                    var splitted = oldsys.Split(',');
                    if (thisinstallglobal.DCS != "" && splitted[5] != thisinstallglobal.DCS)
                        ApplyGlobal("DCS", thisinstallglobal.DCS);
                    if (thisinstallglobal.BMX != "" && splitted[6] != thisinstallglobal.BMX)
                        ApplyGlobal("BMX", thisinstallglobal.BMX);
                    if (thisinstallglobal.NWK != "" && splitted[7] != thisinstallglobal.NWK)
                        ApplyGlobal("NWK", thisinstallglobal.NWK);
                    if (thisinstallglobal.CFG != "" && splitted[8] != thisinstallglobal.CFG)
                        ApplyGlobal("CFG", thisinstallglobal.CFG);
                    if (thisinstallglobal.FXT != "" && splitted[9] != thisinstallglobal.FXT)
                        ApplyGlobal("FXT", thisinstallglobal.FXT);
                }
                ApplyMiscCommands(SystemType);
                CommonClass.ChangeStatus("Creating text scripts...", 0, 1, true);
                //We can do this operation in parallel. Why use sequential?
                Parallel.ForEach(ObsAllVIP.Where(v => v.IsEnabled), (vip) => CreateFile(vip));
                //foreach (var vip in ObsAllVIP.Where(v => v.IsEnabled))
                //    CreateFile(vip);
                //Populate All SYSUP Windows.
                //
                e.Result = "Text scripts generated.";
                if (IsStartUpdate)
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        StartUpdate();
                    });
                    e.Result += "System update started.";
                }

                //Prepare Script file
                try
                {
                    CommonClass.ChangeStatus("Prepare Excel Script...", 0, 1, true);
                    GenerateScriptFile(ScriptFileStartInstallDate, OldWEList, thisinstallglobal);
                    e.Result += "Excel script prepared.";
                }
                catch (Exception ex)
                {
                    e.Result += "Excel script failed.";
                }
            }
            catch (Exception ex)
            {
                e.Result = ex.Message;
            }

        }
        #region Generate Script
        private void GenerateScriptFile(string scriptFileStartInstallDate, List<string> oldWEList, Global thisinstallglobal)
        {
            try
            {
                //Download Script from SliMS
                if (TSU.GetSliMsFiles(DateTime.Parse(scriptFileStartInstallDate), DateTime.Parse(InstallDate), false) == null)
                {
                    CommonClass.ChangeStatus("Download and edit QA Script file...", 0, 1, true);
                    string SlimsScriptPath = App.TempFolder + "sv_Script.xls";
                    //Parse the downloaded script to object
                    List<SampleWE> weFromQAInstall = WeExtract(SlimsScriptPath, oldWEList, InstallDate);
                    //
                    System.IO.File.Delete(SlimsScriptPath);
                    //Download QA script from sharepoint
                    string QAScriptPath = TSU.GetScriptfromSharePoint();
                    //Update existing QA script and copy to desktop Supervision folder
                    UpdateScript(QAScriptPath, weFromQAInstall, thisinstallglobal);
                    //copy the file to desktop supervision folder.
                    System.IO.File.Copy(QAScriptPath, System.IO.Path.Combine(App.LocalSupervisionFolder, "QA_Script_File.xlsx"), true);
                    System.IO.File.Delete(QAScriptPath);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        List<SampleWE> WeExtract(string path, List<string> workEffort, string date)
        {
            Excel.Application xlApp = null; Excel.Workbook xlWorkBook = null; Excel.Worksheet xlWorkSheet = null;
            List<SampleWE> weList = new List<SampleWE>();
            try
            {
                xlApp = new Excel.Application();
                xlApp.Visible = false;
                xlWorkBook = xlApp.Workbooks.Open(path);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];
                weList.Add(new SampleWE()
                {
                    WE = "WEs",
                    Appl = "APPL",
                    LoadDate = "Load date & Group",
                    Deccription = "WE Descriptions",
                    Owner = "Owner",
                    Status = "Current Status",
                    LoadState = "System Load State",
                    Type = "Type",
                    RTN = "RTN",
                    Vtape = "VTAPE",
                    PreRequsite = "Dependency / Pre-requisite",
                    InstallComm = "Install Commands",
                    FallbackComm = "Fallback Commands",
                });

                foreach (Excel.Range row in xlWorkSheet.UsedRange.Rows)
                {
                    string weNumber = (row.Columns[1].Text as string);
                    string installDate = (row.Columns[3].Text as string);
                    if (workEffort.Contains(weNumber) || installDate.Contains(date))
                    {
                        weList.Add(new SampleWE()
                        {
                            WE = row.Columns[1].Text,
                            Appl = row.Columns[2].Text,
                            LoadDate = row.Columns[3].Text,
                            Deccription = row.Columns[4].Text,
                            Owner = row.Columns[5].Text,
                            Status = row.Columns[6].Text,
                            LoadState = row.Columns[7].Text,
                            Type = row.Columns[8].Text,
                            RTN = row.Columns[9].Text,
                            Vtape = row.Columns[10].Text,
                            PreRequsite = row.Columns[11].Text,
                            InstallComm = row.Columns[12].Text,
                            FallbackComm = row.Columns[13].Text,
                        });
                    }
                }
                xlWorkBook.Close(false);
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            finally
            {
                ExcelDispose(ref xlApp, ref xlWorkBook, ref xlWorkSheet);
            }
            return weList;
        }

        private static void ExcelDispose(ref Excel.Application xlApp, ref Excel.Workbook xlWorkBook, ref Excel.Worksheet xlWorkSheet)
        {
            if (xlWorkBook != null) { xlWorkBook = null; }
            if (xlApp != null) { xlApp.Quit(); }
            //release all memory - stop EXCEL.exe from hanging around.
            if (xlWorkBook != null) { System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkBook); }
            if (xlWorkSheet != null) { System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkSheet); }
            if (xlApp != null) { System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp); }
            xlWorkBook = null;
            xlWorkSheet = null;
            xlApp = null;
            GC.Collect();
        }

        public void UpdateScript(string path, List<SampleWE> weFromQAInstall, Global thisinstallglobal)
        {
            Excel.Application xlApp = null; Excel.Workbook xlWorkBook = null; Excel.Worksheet xlWorkSheet = null;
            try
            {
                xlApp = new Excel.Application();
                xlApp.Visible = false;
                xlWorkBook = xlApp.Workbooks.Open(path);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];
                Excel.Range xlRange = (Excel.Range)xlWorkSheet.Columns[1];
                int lastRow = 0;

                Excel.Style style = xlWorkBook.Styles.Add("WERowStyle");
                style.WrapText = true;
                style.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
                style.VerticalAlignment = Excel.XlVAlign.xlVAlignTop;

                //"End of " + InstallDate + " script"
                Excel.Range findInstallStart = xlWorkSheet.Cells.Find(InstallDate + " INSTALL", Type.Missing, Excel.XlFindLookIn.xlValues, Excel.XlLookAt.xlPart, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext, false, false, false);

                if (findInstallStart != null)
                {
                    lastRow = findInstallStart.Row - 1;
                    Excel.Range findInstallEnd = xlWorkSheet.Cells.Find("End of " + InstallDate + " script", findInstallStart, Excel.XlFindLookIn.xlValues, Excel.XlLookAt.xlPart, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext, false, false, false);
                    if (findInstallEnd == null)
                    {
                        findInstallEnd = xlWorkSheet.Cells.Find("FXT", findInstallStart, Excel.XlFindLookIn.xlValues, Excel.XlLookAt.xlPart, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext, false, false, false);
                    }
                    Excel.Range installStartRange = xlWorkSheet.Cells[findInstallStart.Row - 1, findInstallStart.CurrentRegion.EntireColumn.Count];
                    Excel.Range installEndRange = xlWorkSheet.Cells[findInstallEnd.Row, findInstallEnd.CurrentRegion.EntireColumn.Count];
                    Excel.Range installRange = (Excel.Range)xlWorkSheet.get_Range(installStartRange, installEndRange);
                    installRange.EntireRow.Delete();
                }
                else
                {
                    lastRow = xlWorkSheet.UsedRange.Rows.Count + 3;
                }

                //Update Header
                int hdrrow = lastRow;
                InsertRowAndClearFormatting(xlWorkSheet, lastRow);
                xlWorkSheet.Cells[lastRow, 1].Value2 = DDRTo + " system (" + InstallDate + " INSTALL)";
                (xlWorkSheet.Rows[lastRow] as Excel.Range).EntireRow.Interior.Color = Excel.XlRgbColor.rgbGreen;
                (xlWorkSheet.Rows[lastRow] as Excel.Range).EntireRow.Font.Bold = true;
                InsertRowAndClearFormatting(xlWorkSheet, ++lastRow);
                xlWorkSheet.Cells[lastRow, 1].Value2 = "DDR From:";
                xlWorkSheet.Cells[lastRow, 2].Value2 = DDRFrom;
                InsertRowAndClearFormatting(xlWorkSheet, ++lastRow);
                (xlWorkSheet.Rows[lastRow] as Excel.Range).EntireRow.Style = "WERowStyle";
                xlWorkSheet.Cells[lastRow, 1].Value2 = "Updated On:";
                xlWorkSheet.Cells[lastRow, 2].Value2 = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss");
                // Insert a blank line
                InsertRowAndClearFormatting(xlWorkSheet, ++lastRow);



                // Update with WEs
                foreach (var item in weFromQAInstall)
                {
                    InsertRowAndClearFormatting(xlWorkSheet, ++lastRow);
                    (xlWorkSheet.Rows[lastRow] as Excel.Range).EntireRow.Style = "WERowStyle";
                    xlWorkSheet.Cells[lastRow, 1].Value2 = item.WE;
                    xlWorkSheet.Cells[lastRow, 2].Value2 = item.Appl;
                    xlWorkSheet.Cells[lastRow, 3].Value2 = item.LoadDate;
                    xlWorkSheet.Cells[lastRow, 4].Value2 = item.Deccription;
                    xlWorkSheet.Cells[lastRow, 5].Value2 = item.Owner;
                    xlWorkSheet.Cells[lastRow, 6].Value2 = item.Status;
                    xlWorkSheet.Cells[lastRow, 7].Value2 = item.LoadState;
                    xlWorkSheet.Cells[lastRow, 8].Value2 = item.Type;
                    xlWorkSheet.Cells[lastRow, 9].Value2 = item.RTN;
                    xlWorkSheet.Cells[lastRow, 10].Value2 = item.Vtape;
                    xlWorkSheet.Cells[lastRow, 11].Value2 = item.PreRequsite;
                    xlWorkSheet.Cells[lastRow, 12].Value2 = item.InstallComm;
                    xlWorkSheet.Cells[lastRow, 13].Value2 = item.FallbackComm;
                }

                // Insert a blank line
                InsertRowAndClearFormatting(xlWorkSheet, ++lastRow);
                //Update Trailer
                InsertRowAndClearFormatting(xlWorkSheet, ++lastRow);
                xlWorkSheet.Cells[lastRow, 1].Value2 = "Globals";
                xlWorkSheet.Cells[lastRow, 2].Value2 = thisinstallglobal.Capture;
                InsertRowAndClearFormatting(xlWorkSheet, ++lastRow);
                xlWorkSheet.Cells[lastRow, 1].Value2 = "DCS";
                xlWorkSheet.Cells[lastRow, 2].Value2 = thisinstallglobal.DCS;
                InsertRowAndClearFormatting(xlWorkSheet, ++lastRow);
                xlWorkSheet.Cells[lastRow, 1].Value2 = "BMX";
                xlWorkSheet.Cells[lastRow, 2].Value2 = thisinstallglobal.BMX;
                InsertRowAndClearFormatting(xlWorkSheet, ++lastRow);
                xlWorkSheet.Cells[lastRow, 1].Value2 = "NWK";
                xlWorkSheet.Cells[lastRow, 2].Value2 = thisinstallglobal.NWK;
                InsertRowAndClearFormatting(xlWorkSheet, ++lastRow);
                xlWorkSheet.Cells[lastRow, 1].Value2 = "CFG";
                xlWorkSheet.Cells[lastRow, 2].Value2 = thisinstallglobal.CFG;
                InsertRowAndClearFormatting(xlWorkSheet, ++lastRow);
                xlWorkSheet.Cells[lastRow, 1].Value2 = "FXT";
                xlWorkSheet.Cells[lastRow, 2].Value2 = thisinstallglobal.FXT;
                InsertRowAndClearFormatting(xlWorkSheet, ++lastRow);
                xlWorkSheet.Cells[++lastRow, 1].Value2 = "End of " + InstallDate + " script";
                (xlWorkSheet.Rows[lastRow] as Excel.Range).EntireRow.Interior.Color = Excel.XlRgbColor.rgbCoral;
                Excel.Range publishrange = xlWorkSheet.Range["A" + hdrrow + ":M" + lastRow];

                publishrange.FormatConditions.Add(Excel.XlFormatConditionType.xlExpression,Type.Missing,"=LEN(TRIM(A" + hdrrow + "))>0");
                Excel.Borders border = publishrange.FormatConditions[1].Borders;
                border.LineStyle= Excel.XlLineStyle.xlContinuous;

                xlWorkBook.PublishObjects.Add(Excel.XlSourceType.xlSourceRange, System.IO.Path.Combine(App.LocalSupervisionFolder, DDRTo + ".html"), xlWorkSheet.Name, publishrange.Address, Excel.XlHtmlType.xlHtmlStatic, DDRTo, DDRTo + " : " + InstallDate + " Install").Publish(true);
                xlWorkBook.Close(true);
            }

            catch (Exception ex)
            {
                xlWorkBook.Close(false);
                throw ex;
            }
            finally
            {
                ExcelDispose(ref xlApp, ref xlWorkBook, ref xlWorkSheet);
            }
        }

        private static void InsertRowAndClearFormatting(Excel.Worksheet xlWorkSheet, int lastRow)
        {
            (xlWorkSheet.Rows[lastRow] as Excel.Range).EntireRow.Insert(Excel.XlInsertShiftDirection.xlShiftDown);
            (xlWorkSheet.Rows[lastRow] as Excel.Range).EntireRow.ClearFormats();
        }

        public struct SampleWE
        {
            public string WE { get; set; }
            public string Appl { get; set; }
            public string LoadDate { get; set; }
            public string Deccription { get; set; }
            public string Owner { get; set; }
            public string Status { get; set; }
            public string LoadState { get; set; }
            public string Type { get; set; }
            public string RTN { get; set; }
            public string Vtape { get; set; }
            public string PreRequsite { get; set; }
            public string InstallComm { get; set; }
            public string FallbackComm { get; set; }
        }

        #endregion

        private void StartUpdate()
        {
            //Start SYSUP-A
            if (MainWindow.sysupa == null)
                MainWindow.sysupa = new SystemUpdate("A") { Width = 970, Height = 600 };
            if (MainWindow.sysupa.IsIdle && ObsAllVIP.First(v => v.VIPNAME == "VIPA").IsEnabled)
            {
                MainWindow.sysupa.SystemUpdateData.Systems = DDRTo.Replace("X", "A");
                MainWindow.sysupa.btnStart_Click(null, null);
            }
            else if (!MainWindow.sysupa.IsIdle)
            {
                MessageBox.Show("Cannot use System update Window-A because its not idle.", "System update start error!");
                ObsAllVIP.First(v => v.VIPNAME == "VIPA").IsEnabled = false;
            }
            //Start SYSUP-B
            if (MainWindow.sysupb == null)
                MainWindow.sysupb = new SystemUpdate("B") { Width = 970, Height = 600 };
            if (MainWindow.sysupb.IsIdle && ObsAllVIP.First(v => v.VIPNAME == "VIPB").IsEnabled)
            {
                MainWindow.sysupb.SystemUpdateData.Systems = DDRTo.Replace("X", "B");
                MainWindow.sysupb.btnStart_Click(null, null);
            }
            else if (!MainWindow.sysupb.IsIdle)
            {
                MessageBox.Show("Cannot use System update Window-B because its not idle.", "System update start error!");
                ObsAllVIP.First(v => v.VIPNAME == "VIPB").IsEnabled = false;
            }
            //Start SYSUP-C
            if (MainWindow.sysupc == null)
                MainWindow.sysupc = new SystemUpdate("C") { Width = 970, Height = 600 };
            if (MainWindow.sysupc.IsIdle && ObsAllVIP.First(v => v.VIPNAME == "VIPC").IsEnabled)
            {
                MainWindow.sysupc.SystemUpdateData.Systems = DDRTo.Replace("X", "C");
                MainWindow.sysupc.btnStart_Click(null, null);
            }
            else if (!MainWindow.sysupc.IsIdle)
            {
                MessageBox.Show("Cannot use System update Window-C because its not idle.", "System update start error!");
                ObsAllVIP.First(v => v.VIPNAME == "VIPC").IsEnabled = false;
            }
            //Start SYSUP-E
            if (MainWindow.sysupe == null)
                MainWindow.sysupe = new SystemUpdate("E") { Width = 970, Height = 600 };
            if (MainWindow.sysupe.IsIdle && ObsAllVIP.First(v => v.VIPNAME == "VIPE").IsEnabled)
            {
                MainWindow.sysupe.SystemUpdateData.Systems = DDRTo.Replace("X", "E");
                MainWindow.sysupe.btnStart_Click(null, null);
            }
            else if (!MainWindow.sysupe.IsIdle)
            {
                MessageBox.Show("Cannot use System update Window-E because its not idle.", "System update start error!");
                ObsAllVIP.First(v => v.VIPNAME == "VIPE").IsEnabled = false;
            }
            //Start SYSUP-F
            if (MainWindow.sysupf == null)
                MainWindow.sysupf = new SystemUpdate("F") { Width = 970, Height = 600 };
            if (MainWindow.sysupf.IsIdle && ObsAllVIP.First(v => v.VIPNAME == "VIPF").IsEnabled)
            {
                MainWindow.sysupf.SystemUpdateData.Systems = DDRTo.Replace("X", "F");
                MainWindow.sysupf.btnStart_Click(null, null);
            }
            else if (!MainWindow.sysupf.IsIdle)
            {
                MessageBox.Show("Cannot use System update Window-F because its not idle.", "System update start error!");
                ObsAllVIP.First(v => v.VIPNAME == "VIPF").IsEnabled = false;
            }
        }
        private void CreateFile(VIP vip)
        {
            string VIPNAME = vip.VIPNAME.Replace("VIP", "");
            string filepath = App.LocalSupervisionFolder + "\\" + DDRTo.Replace("X", null) + VIPNAME + ".txt"; ;
            if (!System.IO.Directory.Exists(App.LocalSupervisionFolder))
            {
                System.IO.Directory.CreateDirectory(App.LocalSupervisionFolder);
            }
            if (System.IO.File.Exists(filepath))
            {
                System.IO.File.Delete(filepath);
            }

            string firstline = DDRFrom.Replace("X", null) + VIPNAME + "||" + vip.VPARS + "||" + PrimaryCMSID + "||" + getHexString(PrimaryCMSPassword) + "||" + DateTime.Parse(InstallDate).ToString("MM/dd/yy") + "||VIPTestSystemSupp@visa.com";

            System.IO.File.AppendAllLines(filepath, new string[] { firstline });

            bool HFDLOAD = _Script.Where(s => s.ToUpper().Contains("ZUHFD RECEIVE") || s.ToUpper().Contains("ZUHFD INSTALL")).Count() > 0 ? true : false;
            foreach (var line in _Script)
            {
                string tmpline = line.Replace("VIPXT", "VIP" + VIPNAME + "T").Replace("11X", "11" + VIPNAME).Replace("NATVX", "NATV" + VIPNAME).Replace("CPUID X", "CPUID " + VIPNAME);
                if (!HFDLOAD)
                {
                    if (SystemType == "NATV")
                        tmpline = tmpline.Replace("QATnn", "QATnn IPADDR NONE");
                    tmpline = tmpline.Replace("OSA-OSA1PRIV ACTIVATED", "RESTART COMPLETED- 1052 STATE");
                }
                tmpline = tmpline.Replace("QATnn", ((vip.QAT == "" || vip.QAT == null) ? "24" : vip.QAT)).Replace("EEEE", EBCEDIC(VIPNAME));
                try
                {
                    if (tmpline.Contains("QATLDTAPE"))
                    {
                        tmpline = tmpline.Replace("QATLDTAPE", TLDTapes[SystemType == "NATV" ? "NATV" + VIPNAME : "VIP" + VIPNAME]);//TLDTapes object holds TLD tapes
                    }

                }
                catch (Exception)
                {

                }

                if (SystemType == "NATV")
                {
                    if (VIPNAME == "A")
                    {
                        tmpline = tmpline.Replace("CP IPL 4000", "CP IPL D000").Replace("CP I 4000", "CP I D000");
                    }
                    else if (VIPNAME == "C")
                    {
                        tmpline = tmpline.Replace("CP IPL 4000", "CP IPL D100").Replace("CP I 4000", "CP I D100");
                    }
                }
                if (tmpline != "")
                {
                    System.IO.File.AppendAllLines(filepath, new string[] { tmpline });
                }
            }
            if (_Script[Script.Count - 1] != ".END")
            {
                System.IO.File.AppendAllLines(filepath, new string[] { ".END" });
            }
        }
        private string getHexString(string asciisrc)
        {
            return string.Concat(System.Text.Encoding.ASCII.GetBytes(asciisrc).Select(b => b.ToString("X2")).ToArray());
        }
        private void Bringup_Rename_Rta(string source, string dest, string systemtype)
        {
            _Script.Clear();
            _Script.Add("*--------- Bringup, Rename and Mount RTA ---------*");
            if (systemtype == "BASEZ")
            {
                source = "VIPXT";
            }
            string zafil = (EBCEDIC(dest) + "EEEE" + "4040404040404040404040").Substring(0, 18);
            _Script.Add("VPSETUP " + dest + "X VDB QATnn||120||To clear your VDB and continue, enter Clear,||To exit VPSETUP, enter Quit,");
            _Script.Add("CLEAR||30||VPSETUP completed successfully.");
            _Script.Add("CP IPL 4000||600||OSA-OSA1PRIV ACTIVATED");

            if (dest != "PZ11" && dest != "BASEZ11" && dest != "NATV")
            {
                _Script.Add("ZDFIL 4C00000E 604||10||" + source);
                _Script.Add("ZAFIL 4C00000E 604 " + zafil + "||10||" + dest + "X");
                _Script.Add("ZDFIL 4C00000E 604||10||" + dest + "X");
                _Script.Add("ZDSYS||10||" + source);
                _Script.Add("ZDSID||10||" + dest + "X");
                //_Script.Add("ZUODF DIR ALL||10||TOT=    0");
                _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
            }
            _Script.Add("ZCP VTM 34F SCR||10||mounted on 034F");
            _Script.Add("ZTMNT RTA 34F SO||10||TMNT BSS    TAPE RTA MOUNTED ON DEVICE 034F");
            _Script.Add("ZTPSW RTA||10||Updating RTA Tape History for tape");
            _Script.Add("ZUKP4 CONS A||10|| Selected option active");
            if (systemtype == "NATV")
            {
                _Script.Add("ZULDR ACC " + DateTime.Now.ToString("MMddyy") + "||1200||NO MORE LOADSETS EXIST TO BE ACCEPTED");
                _Script.Add("ZOLDR DISP ALL||10||NO LOADSETS EXIST");
                _Script.Add("ZOLDR RECLAIM||10||RECLAIM COMPLETED");
                _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
            }
            else if (systemtype == "PZ")
            {
                _Script.Add("ZULDR ACC " + DateTime.Now.ToString("MMddyy") + "||1200||NO MORE LOADSETS EXIST TO BE ACCEPTED");
                _Script.Add("ZOLDR DISP ALL||10||NO LOADSETS EXIST");
                _Script.Add("ZOLDR RECLAIM||10||RECLAIM COMPLETED");
                _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
                _Script.Add("ZIMAG DISP ALL||5||END OF ZIMAG DISPLAY");
                _Script.Add("ZUMAG IMAG TPF0X TPF0Y||300||ZUMAG processing completed");
                _Script.Add("ZDSYS||300||COPY FROM TPF0X TO TPF0Y COMPLETE");
                _Script.Add("ZDECB IN||10||END OF DISPLAY");
                _Script.Add("ZCP VTRUN 348||10||0348 is not ready||unloaded from 0348");
                _Script.Add("ZCP VTM 348 " + PZTLD + "||10||mounted on 0348");
                _Script.Add("ZTMNT TLD 348 AI BP||10||ADDING TLD TAPE HISTORY ITEM");
                _Script.Add("ZPOOL 1052 UP||10||TO2 CYCLED UP");
                _Script.Add("ZTPLD TPF0Y TLD||1800||LOAD COMPLETE");
                _Script.Add("ZIMAG ENA TPF0Y||10||IMAGE TPF0Y ENABLED");
                _Script.Add("ZCP I 4000 CL||10||SELECT IMAGE+");
                _Script.Add("I||10||SPECIFY IMAGE NAME+");
                _Script.Add("TPF0Y||180||RESTART COMPLETED- 1052 STATE||TRST BSS    MOUNT RTA TAPE");
                _Script.Add("ZIMAG PRI TPF0Y||10||TPF0Y HAS BEEN DEFINED AS THE PRIMARY IMAGE");
                _Script.Add("ZIMAG DISA TPF0X||10||IMAGE TPF0X DISABLED");
                _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
            }
            //Script = _Script;
        }
        private string EBCEDIC(string dest)
        {
            return string.Concat(System.Text.Encoding.GetEncoding("IBM037").GetBytes(dest).Select(b => b.ToString("X2")).ToArray());
        }
        private void DownloadScript(string installdate)
        {
            CommonClass.ChangeStatus("Downloading files from SLiMS...", 0, 1, true);
            using (WebClientEx webclient = new WebClientEx())
            {
                try
                {
                    var Loginpage = webclient.DownloadString("http://pslimsapp.visa.com/slims/login");
                    var Logindata = new NameValueCollection
                        {
                            { "username", App.SliMSID},
                            { "password", App.SliMSPWD },
                            {"_csrf",Loginpage.Substring(Loginpage.IndexOf("_csrf")+ 14, 36)}
                        };
                    //Login
                    var loginresp = webclient.UploadValues("http://pslimsapp.visa.com/slims/login", Logindata);
                    var Data = webclient.DownloadData(@"http://pslimsapp.visa.com/slims/report?type=supervision&format=txt&dates=" + DateTime.ParseExact(installdate, "MM/dd/yyyy", null).ToString("yyyy-MM-dd"));
                    System.IO.File.WriteAllText(App.LocalSupervisionFolder + "\\InstallScript_" + installdate.Replace("/", "_") + ".txt", Encoding.Default.GetString(Data).Replace("\r", null).Replace("\n", Environment.NewLine));
                    //System.IO.File.Delete(App.LocalSupervisionFolder + "\\InstallScript_" + installdate.Replace("/", "_") + ".xls");
                    //webclient.DownloadFile(@"http://pslimsapp.visa.com/slims/report?type=qa-install&format=xls&dates=" + DateTime.ParseExact(installdate, "MM/dd/yyyy", null).ToString("yyyy-MM-dd"), App.LocalSupervisionFolder + "\\InstallScript_" + installdate.Replace("/", "_") + ".xls");
                }
                catch (Exception ex)
                {
                    CommonClass.ChangeStatus("Error in downloading files.", 0, 0, false);
                    throw ex;
                }
            }
            CommonClass.ChangeStatus("Ready.", 0, 0, false);
        }
        private void FindDDRInfo(string installdate, string systemtype)
        {
            DDRFrom = DDRTo = "";
            if (systemtype == "BASEZ")
            {
                DDRFrom = DDRTo = "BASEZ11X";
                return;
            }
            else if (systemtype == "PZ")
            {
                DDRFrom = "BASEZ11X"; DDRTo = "PZ11X";
                return;
            }
            else if (systemtype == "NATV")
            {
                DDRFrom = DDRTo = "NATVX";
                return;
            }
            //Only for QA systems
            DateTime dtinstalldate = DateTime.ParseExact(installdate, "MM/dd/yyyy", null);
            List<SystemInfo> SystemInfos = System.IO.File.ReadAllLines(App.TestSystemStatusServer).Where(s => !s.Contains("System Name") && s.Length >= 20)
                .Select(s =>
                    new Func<string, SystemInfo>((l) =>
                {
                    var splitted = l.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                    return new SystemInfo() { Name = splitted[0], Installdate = DateTime.Parse(splitted[1]), UpdateTime = DateTime.Parse(splitted[2]) };
                })(s)).Where(s => s.Name != "PZ11X" && s.Name != "NATV").ToList();//Remove PZ and NATV from List we need BASEZ to determine old systems; 
            SystemInfos.Add(new SystemInfo() { Name = "TBF", Installdate = dtinstalldate });
            SystemInfos = SystemInfos.OrderByDescending(s => s.Installdate).ToList();
            DDRFrom = "BASEZ11X";
            try
            {
                //DDR From is Last updated system with previous Install Date
                var previousInstalldate = SystemInfos.SkipWhile(s => s.Installdate >= dtinstalldate).First().Installdate;
                DDRFrom = SystemInfos.Where(s => s.Installdate == previousInstalldate).OrderByDescending(s => s.UpdateTime).First().Name;
            }
            catch (Exception) { }
            try
            {
                var olderthanbasez = SystemInfos.Where(s => s.Installdate <= (SystemInfos.FirstOrDefault(f => f.Name == "BASEZ11X").Installdate) && s.Name != "TBF" && !App.RestrictedSystems.Any(q => s.Name.Contains(q))); //Remove restricted systems from DDRTo
                if (olderthanbasez.Count() > 1)
                {
                    //If anythind older than BASEZ use that
                    DDRTo = olderthanbasez.OrderByDescending(s => s.UpdateTime).Last().Name;
                    return;
                }
                var grpbyinstalldate = SystemInfos.Where(s => s.Name != "TBF" && !App.RestrictedSystems.Any(q => s.Name.Contains(q))).GroupBy(s => s.Installdate); ////Remove restricted systems from DDRTo
                foreach (var grp in grpbyinstalldate)
                {
                    //If any Install date has more than 1 system use Older one. Try to use the last load date first.
                    if (grp.Count() > 1)
                    {
                        DDRTo = grp.OrderByDescending(s => s.UpdateTime).Last().Name;
                        return;
                    }
                }
            }
            catch (Exception)
            {

            }

        }
        private class SystemInfo
        {
            public string Name { get; set; }
            public DateTime Installdate { get; set; }
            public DateTime UpdateTime { get; set; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="loaddate">Load Date in MM/dd format</param>
        /// <returns></returns>
        private List<string> GetOldChangesfromTSU(string ddrfrom, ref string ScriptFileStartInstallDate, ref List<string> OldWEList)
        {
            try
            {
                //BASEZ11x A/B/C/E/F - 09/11 Install (06/14 CAPTURE)
                //
                //Deactivate Mod 11, enter ZKSET APSD1F
                //Take the TSU of the DDRFrom System
                var DDRFromTSU = System.IO.File.ReadAllLines(App.TSUFileServer)
                    .SkipWhile(l => !(l.ToUpper().Contains(ddrfrom) && l.ToUpper().Contains("A/B/C") && l.ToUpper().Contains("INSTALL"))).TakeWhile(l => !l.ToUpper().Contains("ENTER ZKSET APSD1F"));
                //More fine tune..
                /*
                 * 
                 * 
                    [Incorporate following 09/11 Install Changes]
                    [Incorporate following 09/18 Install Changes]
                    ZCYCL NORM
                    Replace WE015483 with A08575             [09/18/16,LS2 - Inactive/Norm, Gr-11]
                    Reload WE015486 with A02301              [09/18/16,LS3 - Active/Norm  , Gr-21]
                    Reload WE015233 with A01018              [09/18/16,LS3 - Active/Norm  , Gr-24]
                    Replace WE015247 with A06107             [09/18/16,LS3 - Active/Norm  , Gr-25]
                    Reload WE015417 with A10205              [09/18/16,LS3 - Active/Norm  , Gr-29]
                    [Incorporate following 09/25 Install Changes]
                 * 
                 * 
                 * 
                 */
                var sectiontoapplyinupdate = DDRFromTSU.SkipWhile(t => !(t.ToUpper().Contains("[INCORPORATE FOLLOWING") && t.ToUpper().Contains("INSTALL CHANGES]")))
                    .TakeWhile(t => !t.Contains("[Incorporate Extra commands from TSU Request Entry]"));
                ScriptFileStartInstallDate = sectiontoapplyinupdate.TakeWhile(l => !l.Contains("WE0")).LastOrDefault(l => l.ToUpper().Contains("[INCORPORATE FOLLOWING"));
                //sectiontoapplyinupdate=sectiontoapplyinupdate.Where(t => !t.ToUpper().Contains("[INCORPORATE FOLLOWING"));
                ScriptFileStartInstallDate = ScriptFileStartInstallDate == null ? InstallDate : ScriptFileStartInstallDate.Replace("[Incorporate following", null).Replace("Install Changes]", null).Trim();
                OldWEList = sectiontoapplyinupdate.Where(l => l.Contains("WE0")).Select(l => iSetup.ParseWE(l)).Distinct().ToList();
                return BuildScriptFromTSUSection(sectiontoapplyinupdate.Where(t => !t.ToUpper().Contains("[INCORPORATE FOLLOWING")).ToList());
            }
            catch (Exception)
            {
            }
            return new List<string>();
        }

        public static List<string> BuildScriptFromTSUSection(List<string> listtoapply)
        {
            List<string> FinalListToAdd = new List<string>();
            foreach (var item in listtoapply)
            {
                List<string> Toadd = TryOLDRLoad(item);
                if (Toadd != null)
                {
                    FinalListToAdd.AddRange(Toadd);
                    continue;
                }
                string zcyclcmd = TryZCYCL(item);
                if (zcyclcmd != null)
                {
                    FinalListToAdd.Add(zcyclcmd);
                    continue;
                }
                //Try for DEACT and DEL
                if (item.ToUpper().Contains("DEACTIVATE") && item.ToUpper().Contains("DELETE"))
                {
                    string wenumber = iSetup.ParseWE(item);
                    FinalListToAdd.Add("ZOLDR DEACT " + wenumber);
                    FinalListToAdd.Add("ZOLDR DEL " + wenumber);
                    continue;
                }
                //Rest must be Z commands (As per TSU)
                if (item.ToUpper().Contains("Z"))
                {
                    try
                    {
                        string zcmd = iSetup.ParseZCMD(item);
                        if (!string.IsNullOrWhiteSpace(zcmd))
                        {
                            FinalListToAdd.Add(zcmd);
                        }
                    }
                    catch { }
                }
            }
            return FinalListToAdd;
        }
        static List<string> TryOLDRLoad(string line)
        {
            List<string> Toadd = null;
            string Vtape = iSetup.ParseVtape(line);
            string WeNo = iSetup.ParseWE(line);
            if (string.IsNullOrWhiteSpace(Vtape) || string.IsNullOrWhiteSpace(WeNo))
                return Toadd;
            var action = App.VALIDLOADS.FirstOrDefault(l => line.ToUpper().Contains(l.ToUpper()));
            if (action != null)
            {
                Toadd = new List<string>();
                Toadd.Add("ZOLDR DISP L " + WeNo);
                Toadd.Add("ZOLDR DEACT " + WeNo);
                Toadd.Add("ZOLDR DEL " + WeNo);
                Toadd.Add("ZTOFF OLD");
                Toadd.Add("ZCP VTRUN 34C");
                Toadd.Add("ZCP VTM 34C " + Vtape);
                Toadd.Add("ZTMNT OLD 34C AI BP");
                Toadd.Add("ZOLDR LOAD OLD NODEBUG");
                Toadd.Add("ZCP VTRUN 34C");
                Toadd.Add("ZOLDR DISP L " + WeNo);
                Toadd.Add("ZOLDR ACT " + WeNo);
                Toadd.Add("ZOLDR DISP L " + WeNo);
            }
            return Toadd;

        }
        static string TryZCYCL(string line)
        {
            string toapply = null;
            if (line.ToUpper().Contains("ZRIPL"))
                toapply = "ZRIPL";
            else if (line.ToUpper().Contains("ZCYCL NORM") || line.ToUpper().Contains("ZCYCLN"))
                toapply = "ZCYCL NORM";
            else if (line.ToUpper().Contains("ZCYCL 1052") || line.ToUpper().Contains("ZCYCLT"))
                toapply = "ZCYCL 1052";
            return toapply;
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            BackgroundWorker bwdb = new BackgroundWorker();
            bwdb.DoWork += bwdb_DoWork;
            bwdb.RunWorkerCompleted += bwdb_RunWorkerCompleted;
            CommonClass.ChangeStatus("Getting Database from server...", 0, 1, true);
            bwdb.RunWorkerAsync();
        }
        void bwdb_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            CommonClass.ChangeStatus(e.Result.ToString(), 0, 0, false);
            if (e.Result.ToString() == "Database retrieved successfully.")
            {
                grpbox.BorderBrush = new SolidColorBrush(Colors.Green);
                if (App.CMDLINEARGS.Count > 0 && App.CMDLINEARGS[0].Equals("MULTISYS", StringComparison.InvariantCultureIgnoreCase))
                {
                    grpbox.IsEnabled = false;
                    scriptworker.RunWorkerAsync();
                }
            }
            else
                grpbox.BorderBrush = new SolidColorBrush(Colors.Red);
        }
        void bwdb_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                S2S.DataBaseItems.Clear();
                string[] AllText = System.IO.File.ReadAllText(App.S2SDatabaseServer).Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
                foreach (var item in AllText.Where(t => t != ""))
                {
                    DataItem tmpdata = new DataItem() { ResponseTime = 5 };
                    string[] splitted = item.Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries);
                    tmpdata.CMD = splitted[0].Trim();
                    tmpdata.ResponseTime = Convert.ToInt16(splitted[1]);
                    tmpdata.Response_1 = splitted.Count() > 2 ? splitted[2].Trim() : "";
                    tmpdata.Response_2 = splitted.Count() > 3 ? splitted[3].Trim() : "";
                    tmpdata.Response_3 = splitted.Count() > 4 ? splitted[4].Trim() : "";
                    S2S.DataBaseItems.Add(tmpdata);
                }
                e.Result = "Database retrieved successfully.";
            }
            catch (Exception ex)
            {
                S2S.DataBaseItems.Clear();
                e.Result = "Couldn't get Database properly." + ex.Message;
            }
        }
        public void AddZCommands(List<string> ZCommands, ref bool IsSystemInNorm, ref ObservableCollection<string> _Script, ref List<string> NotfoundinDB, ref Dictionary<string, string> tldtapes)
        {
            ZCommands = ZCommands.Where(l => !string.IsNullOrWhiteSpace(l) && l.ToCharArray()[0] != '*').Select(l => l.Trim()).ToList();
            foreach (var Zcmd in ZCommands)
            {
                //Now Special items for TLD Settings; these are most priority items check them first
                if (Zcmd.ToUpper().Equals("ACCEPT PREVIOUS LOADS", StringComparison.InvariantCultureIgnoreCase))
                {
                    ChangeState(ref IsSystemInNorm, false, ref _Script);// ZCYCL 1052
                    _Script.Add("ZULDR ACC " + DateTime.UtcNow.AddDays(2).ToString("MMddyy") + "||1200||NO MORE LOADSETS EXIST TO BE ACCEPTED");
                    _Script.Add("ZOLDR DISP ALL||10||NO LOADSETS EXIST");
                    _Script.Add("ZOLDR RECLAIM||10||RECLAIM COMPLETED");
                    _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
                }
                else if (Zcmd.ToUpper().Equals("COPY OLD IMAGE TO NEW IMAGE", StringComparison.InvariantCultureIgnoreCase))
                {
                    _Script.Add("ZIMAG DISP ALL||5||END OF ZIMAG DISPLAY");
                    _Script.Add("ZUMAG IMAG TPF0X TPF0Y||300||ZUMAG processing completed");
                    _Script.Add("ZDSYS||300||COPY FROM TPF0X TO TPF0Y COMPLETE");
                    _Script.Add("ZDECB IN||10||END OF DISPLAY");
                }
                else if (Zcmd.ToUpper().Equals("MOVE ALL KEYPOINTS", StringComparison.InvariantCultureIgnoreCase))
                {
                    _Script.Add("ZIMAG KEYPT DELETE KPT ALL CPU ALL||15||KEYPOINTS REMOVED FROM THE BACKUP AREA");
                    _Script.Add("ZIMAG KEYPT MOVE TPF0Y KPT ALL CPU ALL||10||ZIMAG KEYPT CONTINUE - OR - ZIMAG KEYPT ABORT");
                    _Script.Add("ZIMAG K C||40||THE FOLLOWING PROCESSORS MUST BE IPLED");
                }
                else if (Zcmd.ToUpper().Equals("IPL SYSTEM WITH NEW IMAGE", StringComparison.InvariantCultureIgnoreCase))
                {
                    _Script.Add("ZCP I 4000 CL||10||SELECT IMAGE+");
                    _Script.Add("I||10||SPECIFY IMAGE NAME+");
                    _Script.Add("TPF0Y||180||RESTART COMPLETED- 1052 STATE||TRST BSS    MOUNT RTA TAPE");
                }
                else if (Zcmd.ToUpper().Equals("CHANGE PRIMARY IMAGE", StringComparison.InvariantCultureIgnoreCase))
                {
                    ChangeState(ref IsSystemInNorm, false, ref _Script);// ZCYCL 1052
                    _Script.Add("ZIMAG PRI TPF0Y||10||TPF0Y HAS BEEN DEFINED AS THE PRIMARY IMAGE");
                    _Script.Add("ZIMAG DISA TPF0X||10||IMAGE TPF0X DISABLED");
                    _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
                }
                else if (Zcmd.ToUpper().Contains("LOAD TLD TAPES"))
                {
                    // Parse TLD Tapes here
                    var tmp = string.Join(null, Zcmd.ToUpper().Split(new string[] { "LOAD TLD TAPES", ":" }, StringSplitOptions.RemoveEmptyEntries));
                    TLDTapes = new Dictionary<string, string>();
                    TLDTapes = tmp.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Select(l => l.Trim())
                        .ToDictionary(a => a.Split(new string[] { "-" }, StringSplitOptions.RemoveEmptyEntries)[0], a => a.Split(new string[] { "-" }, StringSplitOptions.RemoveEmptyEntries)[1]);
                    _Script.Add("ZCP VTRUN 348||10||0348 is not ready||unloaded from 0348");
                    _Script.Add("ZCP VTM 348 QATLDTAPE||10||mounted on 0348");
                    _Script.Add("ZTMNT TLD 348 AI||10||ADDING TLD TAPE HISTORY ITEM");
                    _Script.Add("ZTPLD TPF0Y TLD NODEBUG||1800||LOAD COMPLETE");
                    _Script.Add("ZIMAG ENA TPF0Y||10||IMAGE TPF0Y ENABLED");
                }
                else if (Zcmd.ToUpper() == "ZCYCL NORM")
                {
                    ChangeState(ref IsSystemInNorm, true, ref _Script);
                }
                else if (Zcmd.ToUpper() == "ZCYCL 1052")
                {
                    ChangeState(ref IsSystemInNorm, false, ref _Script);
                }
                else if (Zcmd.ToUpper().Contains("ZCP I 4000"))
                {
                    _Script.Add("ZCP I 4000 CL||300||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized"); IsSystemInNorm = false; continue;
                }
                else if (Zcmd.ToUpper() == "ZRIPL")
                {
                    _Script.Add("ZRIPL||240||VLS Monitoring DB restart completed||RESTART COMPLETED- 1052 STATE||SSL Shared Context Table Initialized");
                }
                else
                {
                    DataItem matchedcommand = S2S.DataBaseItems.FirstOrDefault(dbitm =>
                        dbitm.CMD.ToUpper().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).All(s =>
                            Zcmd.ToUpper().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).Any(z => z.Trim() == s.Trim())));
                    if (matchedcommand != null)
                        _Script.Add((Zcmd + "||" + matchedcommand.ResponseTime + "||" + matchedcommand.Response_1 + "||" + matchedcommand.Response_2 + "||" + matchedcommand.Response_3).Trim('|'));
                    else
                    {
                        //Add not in found list 
                        NotfoundinDB.Add(Zcmd);
                        //Add with default wait time
                        _Script.Add(Zcmd + "||10");
                    }

                }
            }
        }

        private void ApplyMiscCommands(string systemtype)
        {
            _Script.Add("*--------- Apply miscellaneous commands and unmount RTA ---------*");
            ChangeState(ref IsSysteminNorm, true, ref _Script);
            if (systemtype != "NATV")
            {
                if (systemtype == "QA" || systemtype == "BASEZ")
                {
                    _Script.Add("ZRPDU CREATE NOSWITCH||10||END DISPLAY||PDU CA RELEASE ITEMS ALL PROCESSED");
                    _Script.Add("ZDUPD S||10|| ZDUPD A - TO ABORT");
                    _Script.Add("ZDUPD C||10||END OF DISPLAY");
                    _Script.Add("ZMQSC START QMGR||10||MANAGER ALREADY STARTED");
                    _Script.Add("ZURTD SET SERVICE-OFF||10||Service control switch now OFF");
                    _Script.Add("ZUMQD ALTER SYSLOG-OFF||10||SysLog Logging deactivated");
                    _Script.Add("ZINET ALTER SERVER-DBUG ACT-OPER||10||END OF DISPLAY");
                    _Script.Add("ZUAAA SET RUNMODE-VCMS||10||VCMS scoring run mode already set");
                    _Script.Add("ZKVLS SET AVM-OFF PFM-OFF MDM-OFF NAPEAK-OFF EOD-OFF KEYP-ON GL-ON||10|| Successful - PFM SET to OFF, was OFF");
                    _Script.Add("ZQTTM ECHO OFF||10||AUTO ECHO OFF");
                }
                _Script.Add("ZKENC MAXTRACE 9999||10||UPDATES ARE COMPLETE");
                _Script.Add("ZPSTC STA 808801 SIGN ON||10||SIGN-ON BIT ALREADY ON");
                _Script.Add("ZQSTC STA 808801 SIGN ON||10||SIGN-ON BIT ALREADY ON");
                _Script.Add("ZKTIM 06.00.00 04/10/81||10||TIME IS NOW  06.00.00 04/10/81");
                _Script.Add("ZQADP ADVC MAX||10||Advice-count parameter set in ZQADP File||TMS pending list empty||Auto TMS pending processing begun");
                _Script.Add("ZQADP START||600||ZQADP process is ended||-------------------------------------");
            }
            ChangeState(ref IsSysteminNorm, false, ref _Script);
            _Script.Add("ZCP IPL 4000 CL||300||RESTART COMPLETED- 1052 STATE");
            // _Script.Add("ZUODF DIR ALL||10||TOT=    0");
            _Script.Add("ZUODF INIT||10||ODF data base initialization complete");
            _Script.Add("ZQEOD||10||SMS audit successfully closed on CPC");
            // _Script.Add("ZUODF DIR ALL||10||TOT=    0");
            _Script.Add("ZUKP4 CONS I||10||Selected option inactive");
            if (systemtype == "NATV")
            {
                _Script.Add("ZCP VTM 340 DUMMY||5");
            }
            _Script.Add("ZTMNT RTA 340 SO");
            _Script.Add("ZTPSW RTA");
            _Script.Add("ZCP VTRUN 34F||10||unloaded from 034F||034F is not ready");
            if (systemtype != "NATV")
            {
                _Script.Add("ZTTCP INACT ALL||10||COMPLETED");
                _Script.Add("ZOSAE DELETE OSA-OSA1PRIV||10||DELETED");
            }
            else
            {
                /*
                 zttcp inact locips
    zttcp change defip-10.203.223.190
    zttcp change defip-10.203.223.189
    zosae delete osa-osa1priv

                 */
                _Script.Add("zttcp inact locips||5");
                _Script.Add("zttcp change defip-10.203.223.190||5");
                _Script.Add("zttcp change defip-10.203.223.189||5");
                _Script.Add("zosae delete osa-osa1priv||5");
            }
            _Script.Add(".END");
        }
        Global GetGlobal(string installdate, string capture)
        {
            Excel.Application xlapp = null;
            Global tempglobal = null;
            try
            {
                //System.IO.File.Copy(App.QAGlobalServer, App.TempFolder + "temp_global.xlsx", true);

                xlapp = new Excel.Application();
                xlapp.DisplayAlerts = false;
                Excel.Workbook xlworkbook = xlapp.Workbooks.Open(CommonClass.GetQAGlobalFromSharepoint(), Type.Missing, true, true);
                Excel.Worksheet xlsheet = xlworkbook.Worksheets[1]; ///Check the first Sheet
                int row = 1;
                int loaddatecol = 0;
                DateTime loaddate = DateTime.Parse(installdate);
                //check max 30 rows
                for (int i = 1; i < 30; i++)
                {
                    var tmptxt = ((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Replace("/", null);
                    if (tmptxt.Contains("PROD DATA") && tmptxt.Contains(capture))
                    {
                        tempglobal = new Global() { Capture = capture + " Capture:" + ((xlsheet.Cells[row, 2] as Excel.Range).Text as string) };
                        break;
                    }
                    row++;
                }
                if (tempglobal == null)
                    throw new ArgumentNullException();
                else
                {
                    //Check first 20 columns for Load date
                    for (int col = 1; col <= 20; col++)
                    {
                        string celltext = ((xlsheet.Cells[row + 1, col] as Excel.Range).Text as string).ToUpper();
                        if (celltext == "" || celltext == null || celltext.Contains("DATA"))
                            continue;
                        else if (celltext.Contains("BASELINE"))
                        {
                            loaddatecol = col;
                            continue;
                        }
                        else
                        {
                            int mnthdiff = loaddate.Month - Convert.ToInt16(celltext.Split('/')[0]);
                            int yr = loaddate.Year;
                            if (mnthdiff <= -6)
                                yr = yr - 1;

                            if ((DateTime.ParseExact(celltext + "/" + yr, "MM/dd/yyyy", null) <= loaddate))
                            {
                                loaddatecol = col;
                            }
                            else
                                break;
                        }
                    }
                    if (loaddatecol == 0)
                        return null;
                    do
                    {
                        row++;
                        string celltext = ((xlsheet.Cells[row, 1] as Excel.Range).Text as string).ToUpper();
                        if (celltext.Contains("DCS"))
                        {
                            //check all columns from 2nd column
                            for (int i = loaddatecol; i >= 2; i--)
                            {
                                if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                {
                                    tempglobal.DCS = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                    break;
                                }
                            }
                        }
                        else if (celltext.Contains("BMX"))
                        {
                            for (int i = loaddatecol; i >= 2; i--)
                            {
                                if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                {
                                    tempglobal.BMX = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                    break;
                                }
                            }
                        }
                        else if (celltext.Contains("NWK"))
                        {
                            for (int i = loaddatecol; i >= 2; i--)
                            {
                                if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                {
                                    tempglobal.NWK = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                    break;
                                }
                            }
                        }
                        else if (celltext.Contains("CFG"))
                        {
                            for (int i = loaddatecol; i >= 2; i--)
                            {
                                if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                {
                                    tempglobal.CFG = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                    break;
                                }
                            }
                        }
                        else if (celltext.Contains("FXT"))
                        {
                            for (int i = loaddatecol; i >= 2; i--)
                            {
                                if (((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim() != "")
                                {
                                    tempglobal.FXT = ((xlsheet.Cells[row, i] as Excel.Range).Text as string).Trim();
                                    break;
                                }
                            }
                            break;
                        }
                        else if (celltext.Contains("CONFIG") || celltext.Contains("RSI") || celltext.Contains("SUBSCRIBER") || celltext.Contains("MVV"))
                        {
                            break;
                        }
                    } while (row <= 30);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Global File Parse Error!", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            finally
            {

                if (xlapp != null)
                {
                    xlapp.Quit();
                }

            }
            return tempglobal;
        }
        private void ApplyGlobal(string glbtype, string vtape)
        {
            _Script.Add("*--------- Load " + glbtype + " Global with " + vtape + " ---------*");
            switch (glbtype)
            {
                case "DCS":
                case "BMX":
                case "NWK":
                case "CFG":
                    ChangeState(ref IsSysteminNorm, false, ref _Script);
                    _Script.Add("ZTOFF SDF||10||BSS    TAPE SDF NOT MOUNTED");
                    _Script.Add("ZCP VTRUN 347||10||0347 is not ready||unloaded from 0347");
                    _Script.Add("ZCP VTM 347 " + vtape + "||10||" + vtape + " mounted on 0347 Ldisk");
                    _Script.Add("ZTMNT SDF 347 AI BP||10||TAPE SDF MOUNTED ON DEVICE 0347");
                    _Script.Add("ZQTBL " + glbtype + " LOAD BPALL||180||Updating SDF Tape History for tape " + vtape + " removed from 347");
                    _Script.Add("ZCP VTRUN 347||10||unloaded from 0347||0347 is not ready");
                    break;
                case "FXT":
                    ChangeState(ref IsSysteminNorm, true, ref _Script);
                    _Script.Add("ZCP VTRUN 347||10||0347 is not ready||unloaded from 0347");
                    _Script.Add("ZDECB IN||10");
                    _Script.Add("ZCP VTM 347 " + vtape + "||10||" + vtape + " mounted on 0347 Ldisk");
                    _Script.Add("ZTMNT FXT 347 AI BP||10||TAPE FXT MOUNTED ON DEVICE 0347");
                    _Script.Add("ZKFXT LOAD BPALL||60||Updating FXT Tape History for tape " + vtape + " removed from 347");
                    _Script.Add("ZCP VTRUN 347||10||unloaded from 0347||0347 is not ready");
                    break;
                default:
                    break;
            }
        }
        public static void ChangeState(ref bool currentstate, bool requiredstate, ref ObservableCollection<string> _Script)
        {
            if (currentstate == requiredstate)
                return;
            else
            {
                currentstate = requiredstate;
                if (requiredstate == true)
                {
                    _Script.Add("ZCYCL NORM||90"); _Script.Add("ZDSYS||10||THE SYSTEM IS IN NORM STATE"); _Script.Add("ZUDIS @SPAUS||5||000  00");
                }
                else
                {
                    _Script.Add("ZCYCL 1052||60"); _Script.Add("ZDSYS||10||THE SYSTEM IS IN 1052 STATE"); _Script.Add("ZUDIS @SPAUS||5||000  01");
                }
            }
        }

    }
}
