﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace QACT_WPF
{
    /// <summary>
    /// Interaction logic for SystemUpdate.xaml
    /// </summary>Required in:
    /// 
    /// Changes 
    public partial class SystemUpdate : Page, INotifyPropertyChanged
    {
        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        UpdateData _SystemUpdateData = new UpdateData();
        public UpdateData SystemUpdateData { get { return _SystemUpdateData; } set { _SystemUpdateData = value; NotifyPropertyChanged("SystemUpdateData"); } }
        bool _IsIdle = true;
        public bool IsIdle { get { return _IsIdle; } set { _IsIdle = true; NotifyPropertyChanged("IsActive"); } }
        Thread UpdateThread;
        string ShortSession;

        HLLAPI sys;
        //public string ShortSessionName { get; set; }
        public SystemUpdate(string shortsession)
        {
            InitializeComponent();
            txtTitle.Text = "System Update - " + shortsession;
            ShortSession = shortsession;
            sys = new HLLAPI(ShortSession, false, "SYSUP");
        }

        public void btnStart_Click(object sender, RoutedEventArgs e)
        {
            if (btnStart.Content.ToString() == "Start")
            {
                if (string.IsNullOrWhiteSpace(SystemUpdateData.Systems))
                {
                    MessageBox.Show("No system provided.", "System Update window " + sys.SessionShortName, MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                if (UpdateThread == null)
                    UpdateThread = new Thread(DoUpdate);
                try
                {
                    UpdateThread.Start();
                    btnStart.Content = "Pause";
                    txtsystems.IsReadOnly = true;
                }
                catch (Exception)
                { }
            }
            else if (btnStart.Content.ToString() == "Pause")
            {
                try
                {
                    UpdateThread.Suspend();
                    btnStart.Content = "Resume";
                }
                catch (Exception)
                { }

                // IsIdle = true;
            }
            else if (btnStart.Content.ToString() == "Resume")
            {
                try
                {
                    UpdateThread.Resume();
                    btnStart.Content = "Pause";
                }
                catch (Exception)
                { }

                //IsIdle = true;
            }

        }
        [System.Runtime.ExceptionServices.HandleProcessCorruptedStateExceptionsAttribute()]
        void DoUpdate()
        {
            IsIdle = false;
            //Update Process will go here
            SystemUpdateData.Systems = SystemUpdateData.Systems.Replace(",", " ").Replace(";", " ");
            try
            {
                //Update all systems.
                List<string> SystemupdateResults = new List<string>();

                foreach (string systemtoupdate in SystemUpdateData.Systems.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries))
                {
                    DateTime starttime = DateTime.UtcNow;
                    string RTATAPE = null, TLDTAPE = null;
                    GlobalSet Globals = new GlobalSet();
                    if (!System.IO.File.Exists(App.LocalSupervisionFolder + "\\" + systemtoupdate + ".txt"))
                    {
                        if (MessageBox.Show("Script not found for " + systemtoupdate + "\nDo you want to continue to next system?", "System Update window " + sys.SessionShortName, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                            continue;
                        else
                        {
                            goto FINISH;
                        }
                    }
                    var filecontent = System.IO.File.ReadAllLines(App.LocalSupervisionFolder + "\\" + systemtoupdate + ".txt");
                    SystemUpdateData.DDRTo = System.IO.Path.GetFileNameWithoutExtension(App.LocalSupervisionFolder + "\\" + systemtoupdate + ".txt").ToUpper();
                    var splitted = filecontent[0].Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries);
                    SystemUpdateData.DDRFrom = splitted[0];
                    SystemUpdateData.QAP = splitted[1];
                    SystemUpdateData.PrimaryCMSId = splitted[2];
                    //Use Base64 encoded Password from this version.
                    //splitted[3] will contain base64 encoded password
                    // var xxx = Convert.ToBase64String(Encoding.ASCII.GetBytes("FEB2016"));
                    SystemUpdateData.Paswword = Encoding.ASCII.GetString(ByteFromHexString(splitted[3]));

                    SystemUpdateData.LoadDate = splitted[4];
                    //Clear old commands

                    SystemUpdateData.Email = splitted[5];

                    this.Dispatcher.Invoke(() =>
                    {
                        SystemUpdateData.UpdateCommands.Clear();
                        SystemUpdateData.Progress = 0;
                    });
                    //Populate the list of commands to be applied
                    foreach (var line in filecontent.Skip(1).Where(l => l[0] != '*' && l != ".END"))
                    {
                        var splitted1 = line.Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries);
                        UpdateCommand cmd = new UpdateCommand() { Command = splitted1[0] };
                        cmd.Delay = splitted1.Length > 1 ? Convert.ToInt16(splitted1[1]) : cmd.Delay;
                        cmd.Resp1 = splitted1.Length > 2 ? splitted1[2] : null;
                        cmd.Resp2 = splitted1.Length > 3 ? splitted1[3] : null;
                        cmd.Resp3 = splitted1.Length > 4 ? splitted1[4] : null;
                        this.Dispatcher.Invoke(() =>
                        {
                            SystemUpdateData.UpdateCommands.Add(cmd);
                        }
                        );

                    }
                    sys = new HLLAPI(ShortSession, true, "SYSUP");
                    sys.ShowWindow(true);
                    if (sys.ConnectSession() == 0)
                    {
                        sys.ShowWindow(false); //Hide window by default
                        if (!LogonBy(SystemUpdateData.QAP, SystemUpdateData.PrimaryCMSId, SystemUpdateData.Paswword))
                            goto FINISH;
                        if (SystemUpdateData.SystemType == SystemTypes.NATV)
                        {
                            sys.EnterCommand("DEF STOR 10G", 5);
                            sys.EnterCommand("I CMS", 5);
                            sys.SendText(Keys3270.Enter);
                            sys.Pause(1);
                        }
                        else
                        {
                            if (!StartDDR())
                            {
                                if (!HandleError("DDR process could not be started in 40 minutes for " + systemtoupdate, ErrorTypes.NotifyandWait))
                                    break;
                            }
                            //Now wait for DDR completion
                            if (!CheckDDRCompletion())
                            {
                                if (!HandleError("DDR was not completed in 60 minutes for " + systemtoupdate, ErrorTypes.NotifyandWait))
                                    break;
                            }
                            //Now Logon again
                            LogonBy(SystemUpdateData.QAP, SystemUpdateData.PrimaryCMSId, SystemUpdateData.Paswword);
                        }
                        //Find Previous applied Globals
                        Globals = FindPreviousGlobals();
                        //Purge all reader before starting...
                        sys.EnterCommand("CP PURGE RDR ALL", 1);
                        //Get Rid of all IPSERV warning messages
                        sys.EnterCommand("SET WNG OFF", 1);
                        sys.EnterCommand("REACCESS", 2);
                        //Now Do the main update Process from the file
                        if (DoMainUpdate(ref Globals, ref RTATAPE, ref TLDTAPE))
                        {
                            //Now Close the system if system update is complete
                            CloseSystem(TLDTAPE, Globals);
                            var elapsed = (DateTime.UtcNow - starttime);
                            SystemupdateResults.Add(SystemUpdateData.DDRTo + " was updated in " + elapsed.Hours + " hours " + elapsed.Minutes + " minutes. RTA: " + RTATAPE);
                        }
                        else
                            break;
                        //
                        sys.DisconnectSession();
                        try
                        {
                            System.IO.File.Copy(sys.screenshotfile, System.IO.Path.Combine(App.LocalSupervisionFolder, SystemUpdateData.DDRTo + "_LOG.txt"), true);
                            System.IO.File.Delete(sys.screenshotfile);
                        }
                        catch { }
                    }
                }
                SystemUpdateData.UpdateSuccessful = true;
            FINISH:
                IsIdle = true;
                string status = null;
                if (SystemupdateResults.Count > 0)
                {
                    status = string.Join(Environment.NewLine, SystemupdateResults.ToArray());
                    MessageBox.Show(string.Concat(SystemupdateResults.Select(r => r + "\n")).Trim(), "System Update window-" + sys.SessionShortName);
                    //HandleError("System Update window-" + sys.SessionShortName + " : Status", ErrorTypes.NotifyOnly, status);
                }


            }
            catch (ThreadAbortException)
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sorry! Exception:" + ex.Message, "SYSUP-" + sys.SessionShortName);
            }
            finally
            {
                //Finishing Regression
                IsIdle = true;
                try
                {
                    sys.DisconnectSession();
                }
                catch { }

                try
                {
                    UpdateThread.Abort();
                }
                catch (Exception)
                {

                }
                //Update process ends here
                this.Dispatcher.Invoke(() =>
                {
                    btnStart.Content = "Start";
                    txtsystems.IsReadOnly = false;
                });
                UpdateThread = null;
            }
        }

        private void CloseSystem(string TLDTAPE, GlobalSet Globals)
        {
            sys.SendText(Keys3270.PA1);
            sys.EnterCommand("VPCLOSE", 1);
            sys.WaitforString("VPARS database is closed", 30);
            sys.EnterCommand("I CMS", 1);
            sys.SendText(Keys3270.Enter);
            sys.Pause(2);
            sys.EnterCommand("VPSETUP " + SystemUpdateData.DDRTo + " MW", 2);
            sys.SendText(Keys3270.PF3);
            sys.WaitforString("VPSETUP completed successfully.", 10);
            sys.EnterCommand("I CMS", 1);
            sys.SendText(Keys3270.Enter);
            sys.Pause(2);
            try
            {
                var tmpfile = System.IO.Path.GetTempFileName();
                sys.ReceiveFile(tmpfile, SystemUpdateData.DDRTo + " STATUS  A1");
                List<string> newfilecontent = new List<string>();
                string gmtdate = DateTime.UtcNow.ToString("MM/dd/yy");
                foreach (var line in System.IO.File.ReadAllLines(tmpfile).Where(l => l != null && !string.IsNullOrWhiteSpace(l) && l.Length >= 2))
                {
                    if (line.Contains("Production Load Date:"))
                        newfilecontent.Add(" |   Production Load Date: " + SystemUpdateData.LoadDate + "                                       |");
                    else if (line.Contains("Last update was on"))
                        newfilecontent.Add(" |   Last update was on " + gmtdate + " If your VPARS database was               |");
                    else if (line.Contains(gmtdate + " - "))
                    {
                        switch (SystemUpdateData.SystemType)
                        {
                            case SystemTypes.QASYS:
                                newfilecontent.Add(" | " + gmtdate + " - DDR " + SystemUpdateData.DDRFrom.PadRight(8) + "/" + SystemUpdateData.DDRTo.PadRight(8) + ".Applied " + SystemUpdateData.LoadDate.Substring(0, 5) + " Install changes         |");
                                break;
                            case SystemTypes.BASEZ:
                                newfilecontent.Add(" | " + gmtdate + " - Applied " + SystemUpdateData.LoadDate.Substring(0, 5) + " Install Changes                               |");
                                break;
                            case SystemTypes.PZ:
                                newfilecontent.Add(" | " + gmtdate + " - DDR FROM BASEZ11x/PZ11x + TLD " + TLDTAPE + "+ Preloads(If any)      |");
                                break;
                            case SystemTypes.NATV:
                                newfilecontent.Add(" | " + gmtdate + " - Applied " + SystemUpdateData.LoadDate.Substring(0, 5) + " Install Changes                               |");
                                break;
                            default:
                                break;
                        }
                    }
                    else if (line.Contains("DCS"))
                        newfilecontent.Add(" | DCS " + Globals.DCS + "                                                             |");
                    else if (line.Contains("BMX"))
                        newfilecontent.Add(" | BMX " + Globals.BMX + "                                                             |");
                    else if (line.Contains("NWK"))
                        newfilecontent.Add(" | NWK " + Globals.NWK + "                                                             |");
                    else if (line.Contains("CFG"))
                        newfilecontent.Add(" | CFG " + Globals.CFG + "                                                             |");
                    else if (line.Contains("FXT"))
                        newfilecontent.Add(" | FXT " + Globals.FXT + "                                                             |");
                    else
                        newfilecontent.Add(line);
                }
                System.IO.File.WriteAllLines(tmpfile, newfilecontent);
                sys.SendFile(tmpfile, SystemUpdateData.DDRTo + " STATUS A1");
                System.IO.File.Delete(tmpfile);
                sys.Pause(5);
                sys.EnterCommand("CHGSTAT " + SystemUpdateData.DDRTo, 5);
                sys.EnterCommand("I CMS", 1);
                sys.SendText(Keys3270.Enter);
                sys.Pause(2);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Status changing failed." + ex.Message, "SYSUP-" + sys.SessionShortName);
            }
            sys.EnterCommand("VPUTIL MOVE", 5);
            string moveerror = null;
            if (sys.WaitforString("Ready;", 45 * 60, new List<string>() { "Ready(" }, out moveerror) == 0)
            {
                sys.EnterCommand("LOGOFF", 15);
            }
            else
            {
                if (!HandleError("VPUTIL MOVE is not completed in System Update window - " + sys.SessionShortName, ErrorTypes.NotifyandWait))
                    return;
            }
        }

        private bool DoMainUpdate(ref GlobalSet Globals, ref string RTATAPE, ref string TLDTAPE)
        {
            List<UpdateCommand> NoResponse = new List<UpdateCommand>();
            //sys.EnterCommand("CP PURGE RDR ALL",1);
            string srcimg = "TPF0X", destimg = "TPF0Y", KPA = "KPA";
            string systemrenamecommand = null;
            for (int i = 0; i < SystemUpdateData.UpdateCommands.Count; i++)
            {
                /*STEPS for general commands
                 * Send clear screen
                 * Wait for 2-seconds to clear the screen (if any MORE/HOLDING APPEARS)
                 * Enter the command
                 * Wait for defined time in the command
                 * 
                 * 
                 */


                string thiscommand = SystemUpdateData.UpdateCommands[i].Command;
                //we need to send I for image selection and TPF0Y to specific location

                if (thiscommand == "I")
                {
                    sys.SetFieldValue("SELECT IMAGE", "I");
                    sys.SendText(Keys3270.Enter);
                }
                else if (thiscommand == "TPF0Y")
                {
                    sys.SetFieldValue("SPECIFY IMAGE NAME", destimg);
                    sys.SendText(Keys3270.Enter);
                }
                else
                {
                    sys.SendText(Keys3270.Clear);
                    //This will just clear screen for two seconds
                    sys.WaitforString("Dummy string only. This will just do clear screen for the duration (if required)", 2);
                    //Before entering the command replace specific items
                    thiscommand = thiscommand.Replace("TPF0X", srcimg).Replace("TPF0Y", destimg).Replace("ZAFIL xxxxxxxx", "ZAFIL " + KPA);
                    // sys.EnterCommand(thiscommand.Replace("@", Keys3270.AT), 1, thiscommand == "I" ? false : true);
                    sys.EnterCommand(thiscommand.Replace("@", Keys3270.AT), 1, false);
                }
                string response = null;
                if (thiscommand.Contains("ZAFIL 4C00000E 604 "))
                {
                    systemrenamecommand = thiscommand;
                }

                SystemUpdateData.CurrentCommand.Command = thiscommand;
                SystemUpdateData.CurrentCommand.Resp1 = SystemUpdateData.UpdateCommands[i].Resp1 != null ? SystemUpdateData.UpdateCommands[i].Resp1.Replace("TPF0X", srcimg).Replace("TPF0Y", destimg) : null;
                SystemUpdateData.CurrentCommand.Resp2 = SystemUpdateData.UpdateCommands[i].Resp2 != null ? SystemUpdateData.UpdateCommands[i].Resp2.Replace("TPF0X", srcimg).Replace("TPF0Y", destimg) : null;
                SystemUpdateData.CurrentCommand.Resp3 = SystemUpdateData.UpdateCommands[i].Resp3 != null ? SystemUpdateData.UpdateCommands[i].Resp3.Replace("TPF0X", srcimg).Replace("TPF0Y", destimg) : null;
                SystemUpdateData.CurrentCommand.Delay = SystemUpdateData.UpdateCommands[i].Delay;
                //Scroll the List View to current item
                this.Dispatcher.Invoke(() =>
                {
                    lstboxcommands.SelectedItem = SystemUpdateData.UpdateCommands[i];

                    lstboxcommands.ScrollIntoView(SystemUpdateData.UpdateCommands[i]);
                }
                );
                if (sys.WaitforString(new List<string>() { SystemUpdateData.CurrentCommand.Resp1, SystemUpdateData.CurrentCommand.Resp2, SystemUpdateData.CurrentCommand.Resp3 }, SystemUpdateData.CurrentCommand.Delay, out response) == 0)
                {
                    //Response found
                    if (response != null) //If we were expecting any response
                    {
                        if (thiscommand == "ZQTBL DCS LOAD BPALL")
                            Globals.DCS = response.Split(' ')[6];
                        else if (thiscommand == "ZQTBL BMX LOAD BPALL")
                            Globals.BMX = response.Split(' ')[6];
                        else if (thiscommand == "ZQTBL NWK LOAD BPALL")
                            Globals.NWK = response.Split(' ')[6];
                        else if (thiscommand == "ZQTBL CFG LOAD BPALL")
                            Globals.CFG = response.Split(' ')[6];
                        else if (thiscommand == "ZKFXT LOAD BPALL")
                            Globals.FXT = response.Split(' ')[6];
                        if (thiscommand.Contains("ZCP VTM 348"))
                            TLDTAPE = thiscommand.Replace("ZCP VTM 348", "").Trim();

                        //Get the TPF0X and TPF0Y for TLD process, and KPA for NATV, get the RTATAPE
                        if (thiscommand == "ZIMAG DISP ALL" || thiscommand == "ZDKAT KPA" || thiscommand == "ZCP VTRUN 34F")
                        {
                            //Get the screen here
                            var screen = sys.GetLines(20);
                            if (response == "END OF ZIMAG DISPLAY")
                            {
                                srcimg = screen.FirstOrDefault(l => l.Contains("PRIMARY"));
                                srcimg = srcimg != null ? srcimg.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0] : null;
                                destimg = screen.FirstOrDefault(l => l.Contains("DISABLED") && !l.Contains("TPF01"));
                                destimg = destimg != null ? destimg.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)[0] : null;
                            }
                            if (response == "KEYPT A  FILE ADDRESS")
                            {
                                KPA = screen.FirstOrDefault(l => l.Contains("KEYPT A  FILE ADDRESS"));
                                KPA = KPA != null ? KPA.Replace("KEYPT A  FILE ADDRESS", null).Trim() : null;
                            }
                            if (response == "unloaded from 034F")
                            {
                                RTATAPE = screen.FirstOrDefault(l => l.Contains("unloaded from 034F"));
                                RTATAPE = RTATAPE != null ? RTATAPE.Replace("unloaded from 034F", null).Trim() : null;
                            }
                        }
                        //Initialize source and destination image once image disable command is applied
                        if (thiscommand.Contains("ZIMAG DISA"))
                            srcimg = destimg = null;

                        #region Special Case When TLD LOAD Is waiting for RTA Tape mount
                        if (response == "TRST BSS    MOUNT RTA TAPE")
                        {
                            try
                            {
                                sys.EnterCommand("ZTVAR A 340-F", 1);
                                sys.WaitforString("END OF DISPLAY", 20);
                                sys.EnterCommand("ZTMNT RTA 340 BP", 5);
                                if (sys.WaitforString("ZRSTT REP", 60) != 0)
                                {
                                    sys.EnterCommand("ZRSTT REP", 5);
                                    if (sys.WaitforString("TIME OF DAY CLOCK LOCAL STANDARD TIME", 60) != 0)
                                    {
                                        var tmpscr = sys.GetLines(50);
                                        if (tmpscr != null)
                                        {
                                            var timeline = tmpscr.FirstOrDefault(t => t.Contains("TIME:") && t.Contains("DATE:"));
                                            if (timeline != null)
                                            {
                                                Regex todregex = new Regex(@"TIME:\s+(?<TOD>\d+.\d+).\d+\s+DATE:");
                                                if (todregex.IsMatch(timeline))
                                                {
                                                    sys.EnterCommand("ZATIM " + todregex.Match(timeline).Groups["TOD"].Value.Replace(".", null) + " TOD GOOD", 5);
                                                }
                                            }
                                        }
                                    }
                                }
                                sys.WaitforString("RESTART COMPLETED- 1052 STATE", 180);
                                // Most probably we need to rename the systems again
                                sys.WaitforString("Dummy string only. This will just do clear screen for the duration (if required)", 2);
                                if (systemrenamecommand != null)
                                    sys.EnterCommand(systemrenamecommand, 1);

                            }
                            catch (Exception)
                            {

                            }

                        }
                        #endregion
                    }
                }
                else
                {
                    bool iserrorresolved = false;
                    #region Handle ZKSWT errors
                    /* if Command is ON- Target Display Create it programmatically
                     * 0121     SCHEDULED 07/17/16 10.00.00     807648  QACT
                     * if Command is OFF- Target
                     * 0121     RESERVED 07/17/16 10.00.00     807648  QACT
                     * Find OLD display
                     * 0121     RESERVED  05/17/15 10.00.00     812345  TEST
                     * 
                     * Now Call Switch Compare Module Methods
                     * 
                     * */
                    if (thiscommand.ToUpper().Contains("ZKSWT") && (thiscommand.ToUpper().Contains("ON") || thiscommand.ToUpper().Contains("OFF") || thiscommand.ToUpper().Contains("MOD")))
                    {
                        try
                        {
                            //First try to get the switch Number
                            var splitted = thiscommand.ToUpper().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).ToList();
                            var swtno = splitted[splitted.IndexOf("ZKSWT") + 1];
                            var rtn = splitted.First(s => s.Contains("R-") || s.Contains("RTN-")).Replace("RTN-", null).Replace("R-", null);
                            //We need the current display
                            sys.EnterCommand("ZKSWT " + swtno + " DISP", 1);
                            if (sys.WaitforString("SWITCH   STATUS    DATE     TIME", 5) != 0)
                            {
                                //Get the next line
                                var swtdisp = sys.GetLines(40).SkipWhile(s => !s.Contains("SWITCH   STATUS    DATE     TIME")).Skip(1).First().Trim();
                                ZKSWT curswt = SwitchCompare.GetZKSWT(swtdisp);
                                ZKSWT targetswt = new ZKSWT
                                {
                                    SwitchNumber = swtno,
                                    RTN = rtn,
                                    Lead = (rtn != curswt.RTN ? "QACT" : curswt.Lead),
                                    ActivationDate = ((rtn != curswt.RTN || string.IsNullOrWhiteSpace(curswt.ActivationDate)) ? SystemUpdateData.LoadDate.Replace("/", ".") + " 00.00.00" : curswt.ActivationDate)
                                };
                                if (thiscommand.ToUpper().Contains("ON"))
                                {
                                    targetswt.StatusIndex = 3; targetswt.Status = "ATCIVE";
                                }
                                else if (thiscommand.ToUpper().Contains("OFF") || thiscommand.ToUpper().Contains("MOD"))
                                {
                                    targetswt.StatusIndex = 2; targetswt.Status = "RESERVED";
                                    var date = splitted.FirstOrDefault(s => s.Contains("DATE-"));
                                    var time = splitted.FirstOrDefault(s => s.Contains("TIME-"));
                                    //Mod Command Might have Date time mentioned. Used them when available
                                    targetswt.ActivationDate = (date == null ? null : date.Replace("DATE-", null)) + (time == null ? null : time.Replace("TIME-", " "));
                                }
                                else
                                    targetswt = curswt;
                                foreach (var item in SwitchCompare.GetModificationCommands(targetswt, curswt))
                                {
                                    //Apply commands returned from the Switch compare module
                                    sys.EnterCommand(item, 1);
                                    //Just wait and do clear screen if required
                                    sys.WaitforString("Dummy string only. This will just do clear screen for the duration (if required)", 2);
                                }
                                if (sys.WaitforString(new List<string>() { SystemUpdateData.CurrentCommand.Resp1, SystemUpdateData.CurrentCommand.Resp2, SystemUpdateData.CurrentCommand.Resp3 }, SystemUpdateData.CurrentCommand.Delay, out response) == 0)
                                {
                                    iserrorresolved = true;
                                }

                            }

                        }
                        catch { }
                    }
                    #endregion
                    //Now Handle BP option. IF BP is failed apply the only AI command: For FXT
                    else if (thiscommand == "ZTMNT FXT 347 AI BP")
                    {
                        sys.EnterCommand("ZTMNT FXT 347 AI", 1);
                        if (sys.WaitforString(new List<string>() { SystemUpdateData.CurrentCommand.Resp1, SystemUpdateData.CurrentCommand.Resp2, SystemUpdateData.CurrentCommand.Resp3 }, SystemUpdateData.CurrentCommand.Delay, out response) == 0)
                            iserrorresolved = true;
                        //Just wait and do clear screen if required
                        //sys.WaitforString("Dummy string only. This will just do clear screen for the duration (if required)", 2);
                    }
                    else if (thiscommand.Contains("ZUHFD RECEIVE"))
                    {
                        sys.EnterCommand(thiscommand, 1);
                        if (sys.WaitforString(new List<string>() { SystemUpdateData.CurrentCommand.Resp1, SystemUpdateData.CurrentCommand.Resp2, SystemUpdateData.CurrentCommand.Resp3 }, SystemUpdateData.CurrentCommand.Delay, out response) == 0)
                            iserrorresolved = true;
                    }
                    //Response not found....Hnadle those here
                    if (!iserrorresolved && !HandleError(thiscommand + " did not got proper response in System Update window - " + sys.SessionShortName, ErrorTypes.NotifyandWait))
                        return false;

                }
                //SystemUpdateData.PreviousCommand = thiscommand;
                //SystemUpdateData.PreviousResponse = response;
                ChangeCurrentCommandToPreviuosCommandAndResponse(response);
                SystemUpdateData.Progress = i;
                //SystemUpdateData.CurrentCommand = (i == SystemUpdateData.UpdateCommands.Count - 1) ? null : SystemUpdateData.UpdateCommands[i + 1];



            }
            return true;
        }

        private GlobalSet FindPreviousGlobals()
        {
            GlobalSet globals = new GlobalSet();
            sys.EnterCommand("GETD VM3:BASEONE.VPSETUP", 2);
            var tmpfile = System.IO.Path.GetTempFileName();
            sys.ReceiveFile(tmpfile, SystemUpdateData.DDRFrom + " STATUS  F");
            //Now Parse the Files for globals
            foreach (var line in System.IO.File.ReadAllLines(tmpfile).Where(l => l != null))
            {
                var splitted = line.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                if (splitted.Length >= 3)
                {
                    if (line.Contains("DCS"))
                        globals.DCS = splitted[2];
                    else if (line.Contains("BMX"))
                        globals.BMX = splitted[2];
                    else if (line.Contains("NWK"))
                        globals.NWK = splitted[2];
                    else if (line.Contains("CFG"))
                        globals.CFG = splitted[2];
                    else if (line.Contains("FXT"))
                        globals.FXT = splitted[2];
                }
            }
            try
            {
                System.IO.File.Delete(tmpfile);
            }
            catch { }

            return globals;

        }

        private bool CheckDDRCompletion()
        {
            //Wait max 60 minutes and check ddr status in every 1 minute
            bool IsDDRcomplete = false;
            SystemUpdateData.CurrentCommand = new UpdateCommand("MSG " + SystemUpdateData.QAP, resp1: SystemUpdateData.QAP + " not logged on", delay: 60 * 60);
            for (int i = 0; i < 60; i++)
            {
                sys.EnterCommand("MSG " + SystemUpdateData.QAP, 5);
                if (sys.WaitforString(SystemUpdateData.QAP + " not logged on", 5) == 0)
                {
                    sys.Pause(50);
                }
                else
                {
                    IsDDRcomplete = true;
                    ChangeCurrentCommandToPreviuosCommandAndResponse(SystemUpdateData.QAP + " not logged on");
                    sys.EnterCommand("DISC", 20);
                    break;
                }
            }
            return IsDDRcomplete;
        }

        private bool StartDDR()
        {
            sys.EnterCommand("REACCESS", 1);
            sys.EnterCommand("SPOOL CONS START *", 1);
            //SystemUpdateData.PreviousCommand = "COPYTPF " + SystemUpdateData.DDRFrom + " " + SystemUpdateData.DDRTo.Replace("BASEZ11", "BKPBZ11");
            SystemUpdateData.CurrentCommand = new UpdateCommand("COPYTPF " + SystemUpdateData.DDRFrom + " " + SystemUpdateData.DDRTo.Replace("BASEZ11", "BKPBZ11"), resp1: "Do you want to continue?", delay: 40 * 60);
            //sys.EnterCommand(SystemUpdateData.PreviousCommand, 1);
            sys.EnterCommand(SystemUpdateData.CurrentCommand.Command, 1);
            sys.WaitforString("To accept this, press enter", 10);
            sys.SendText(Keys3270.Enter);
            //Wait maximum 40 minutes for DDR confirmation)
            if (sys.WaitforString("Do you want to continue?", 40 * 60) != 0)
            {
                //SystemUpdateData.PreviousResponse = "Do you want to continue?";
                ChangeCurrentCommandToPreviuosCommandAndResponse("Do you want to continue?");
                sys.EnterCommand("Y", 20);
                return true;
            }
            else
                return false;
        }
        private bool LogonBy(string QAPID, string userid, string Password)
        {
            bool Result = false;
            if (sys.WaitforString("COMMAND  ===>", 30) == 0)
            {
                Result = false;
                return Result;
            }
            string resp = "";
            if (sys.SetFieldValue("COMMAND  ===>", "L " + QAPID + " BY " + userid + " HERE") == 0)
            {
                sys.SendText(Keys3270.Enter);
                //SystemUpdateData.PreviousCommand = "L " + QAPID + " BY " + userid + " HERE";
                SystemUpdateData.CurrentCommand = new UpdateCommand("L " + QAPID + " BY " + userid + " HERE", resp1: "Ready;", resp2: "Command Complete", delay: 10);
                if (sys.WaitforString("Enter logon password:", 10) != 0)
                {
                    sys.SendText(Password + Keys3270.Enter, true);
                    if (sys.WaitforString("Ready;", 30, RegressionErrors.LogonErrors.Concat(new List<string>() { "Command complete" }).ToList(), out resp) == 1)
                    {
                        if (resp == "RECONNECTED AT")
                        {
                            sys.SendText(Keys3270.PA1);
                            sys.SendText("I CMS" + Keys3270.Enter);
                            sys.Pause(3);
                            sys.SendText(Keys3270.Enter);
                            if (sys.WaitforString("Ready;", 10) != 0)
                                Result = true;
                        }
                        if (resp == "Command complete")
                        {
                            Result = true;
                            sys.SendText(Keys3270.Enter);
                        }
                    }
                    else
                        Result = true;
                }
            }
            if (Result)
            {
                ChangeCurrentCommandToPreviuosCommandAndResponse(resp);
            }
            return Result;
        }

        private void btnshowhide_Click(object sender, RoutedEventArgs e)
        {
            if (btnshowhide.Content.ToString() == "Show Attachmate Window")
            {
                sys.ShowWindow(true);
                btnshowhide.Content = "Hide Attachmate Window";
            }
            else if (btnshowhide.Content.ToString() == "Hide Attachmate Window")
            {
                sys.ShowWindow(false);
                btnshowhide.Content = "Show Attachmate Window";
            }
        }
        static byte[] ByteFromHexString(string hexstring)
        {
            return Enumerable.Range(0, hexstring.Length)
                     .Where(x => x % 2 == 0)
                     .Select(x => Convert.ToByte(hexstring.Substring(x, 2), 16))
                     .ToArray();
        }

        void ChangeCurrentCommandToPreviuosCommandAndResponse(string response)
        {
            SystemUpdateData.PreviousCommand = SystemUpdateData.CurrentCommand.Command;
            SystemUpdateData.PreviousResponse = response;
            SystemUpdateData.CurrentCommand = new UpdateCommand();
        }
        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            if (UpdateThread == null)
                return;
            if (MessageBox.Show("Do you really want to stop ongoing System Update?", "Stop System update?", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No) == MessageBoxResult.No)
                return;
            try
            {
                if (UpdateThread.ThreadState == ThreadState.Suspended)
                {
                    UpdateThread.Resume();
                }
                UpdateThread.Abort();
                IsIdle = true;
                UpdateThread = null;
                this.Dispatcher.Invoke(() =>
                {
                    btnStart.Content = "Start";
                    txtsystems.IsReadOnly = false;
                });
            }
            catch (Exception)
            {

            }
        }
        bool HandleError(string errorstring, ErrorTypes errortype, string subject = null, string emailid = null, bool attacherrorfile = false)
        {
            sys.SendText(Keys3270.Reset);
            if (errortype != ErrorTypes.NotifyOnly)
            {
                //  ErrorsInRun.Insert(0, DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + "==> " + errorstring);

                //  System.IO.File.WriteAllLines(Runsettings.CoderunServer + @"\RunErrors.txt", ErrorsInRun);
            }
            try
            {
                // Store the screenshot file into coderun server
                //  System.IO.File.Copy(sys.screenshotfile, System.IO.Path.Combine(Runsettings.CoderunServer, System.IO.Path.GetFileName(sys.screenshotfile)), true);
            }
            catch (Exception) { }

            if (errortype != ErrorTypes.LogOnly)
            {
                //Outlook.Application oApp; Outlook.MailItem oMsg; Outlook.Recipients oRecips; Outlook.Recipient oRecip;
                try
                {
                    if (errortype != ErrorTypes.LogandWait)
                    {
                        //Don't Send Email as of now

                        //oApp = new Outlook.Application();
                        //oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                        //oRecips = (Outlook.Recipients)oMsg.Recipients;
                        //if (emailid == null)
                        //    oRecip = (Outlook.Recipient)oRecips.Add(SystemUpdateData.Email);//Runsettings.email + "@visa.com"
                        //else
                        //    oRecip = (Outlook.Recipient)oRecips.Add(emailid);
                        //oRecip.Resolve();
                        //if (subject == null)
                        //    oMsg.Subject = "System update error" + "- Error => " + errorstring;
                        //else
                        //    oMsg.Subject = subject;
                        //oMsg.BodyFormat = Outlook.OlBodyFormat.olFormatPlain;
                        //if (attacherrorfile)
                        //{
                        //    oMsg.Body = "Please review the errors from attached file.\n\nAuto generated from QACT";
                        //    //oMsg.Attachments.Add(Runsettings.CoderunServer + @"\RunErrors.txt");
                        //}
                        //else
                        //    oMsg.Body = "Auto generated from QACT";

                        //((Outlook._MailItem)oMsg).Send();
                    }

                }
                catch (Exception)
                {

                }
                finally
                {
                    //oApp = null; oMsg = null; oRecip = null; oRecips = null;
                }
                if (errortype == ErrorTypes.NotifyandAbort)
                    return false;
                else if (errortype == ErrorTypes.NotifyandWait || errortype == ErrorTypes.LogandWait)
                {
                    if (MessageBox.Show("Press Yes to Continue, No to Abort\nError encountered:\n" + errorstring, "System Update Window - " + sys.SessionShortName, MessageBoxButton.YesNo, MessageBoxImage.Error, MessageBoxResult.Yes) == MessageBoxResult.No)
                        return false;
                }
            }
            return true;
        }

        private void btnregcompletedialog_Click(object sender, RoutedEventArgs e)
        {
            SystemUpdateData.UpdateSuccessful = false;
        }
    }

    public class UpdateData : INotifyPropertyChanged
    {
        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        private bool _UpdateSuccessful = false;

        public bool UpdateSuccessful
        {
            get { return _UpdateSuccessful; }
            set { _UpdateSuccessful = value; NotifyPropertyChanged("UpdateSuccessful"); }
        }
        string _Systems = "";
        public string Systems { get { return _Systems.ToUpper(); } set { _Systems = value.ToUpper(); NotifyPropertyChanged("Systems"); } }
        string _DDRFrom = "";
        public string DDRFrom { get { return _DDRFrom.ToUpper(); } set { _DDRFrom = value.ToUpper(); NotifyPropertyChanged("DDRFrom"); } }
        string _DDRTo = "";
        public string DDRTo { get { return _DDRTo.ToUpper(); } set { _DDRTo = value.ToUpper(); changesystemtype(); NotifyPropertyChanged("DDRTo"); } }
        string _QAP = "";
        public string QAP { get { return _QAP.ToUpper(); } set { _QAP = value.ToUpper(); NotifyPropertyChanged("QAP"); } }
        string _LoadDate = "";
        public string LoadDate { get { return _LoadDate.ToUpper(); } set { _LoadDate = value.ToUpper(); NotifyPropertyChanged("LoadDate"); } }
        string _Email = "";
        public string Email { get { return _Email; } set { _Email = value; NotifyPropertyChanged("Email"); } }
        string _PreviousCommand;
        public string PreviousCommand { get { return _PreviousCommand; } set { _PreviousCommand = value; NotifyPropertyChanged("PreviousCommand"); } }
        string _PreviousResponse;
        public string PreviousResponse { get { return _PreviousResponse; } set { _PreviousResponse = value; NotifyPropertyChanged("PreviousResponse"); } }
        UpdateCommand _CurrentCommand;
        public UpdateCommand CurrentCommand { get { return _CurrentCommand; } set { _CurrentCommand = value; NotifyPropertyChanged("CurrentCommand"); } }
        ObservableCollection<UpdateCommand> _UpdateCommands = new ObservableCollection<UpdateCommand>();
        public ObservableCollection<UpdateCommand> UpdateCommands { get { return _UpdateCommands; } set { _UpdateCommands = value; NotifyPropertyChanged("UpdateCommands"); } }
        public string Paswword { get; set; }
        public string PrimaryCMSId { get; set; }
        public string Status { get; set; }
        int _Progress = 0;
        public int Progress { get { return _Progress; } set { _Progress = value; NotifyPropertyChanged("Progress"); } }
        SystemTypes _SystemType = SystemTypes.QASYS;
        public SystemTypes SystemType { get { return _SystemType; } set { _SystemType = value; } }
        void changesystemtype()
        {
            if (DDRTo != null && DDRTo.Length > 4)
            {
                if (DDRTo.Substring(0, 4) == "NATV")
                    SystemType = SystemTypes.NATV;
                else if (DDRTo.Substring(0, 2) == "PZ")
                    SystemType = SystemTypes.PZ;
                else if (DDRTo.Substring(0, 4) == "BASE")
                    SystemType = SystemTypes.BASEZ;
                else
                    SystemType = SystemTypes.QASYS;
            }

        }
    }
    public class UpdateCommand : INotifyPropertyChanged
    {
        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        public UpdateCommand()
        {
        }
        public UpdateCommand(string command, string resp1 = null, string resp2 = null, string resp3 = null, int delay = 0)
        {
            Command = command; Resp1 = resp1; Resp2 = resp2; Resp3 = resp3; Delay = delay;
        }
        string _Command;
        public string Command { get { return _Command; } set { _Command = value; NotifyPropertyChanged("Command"); } }
        string _Resp1;
        public string Resp1 { get { return _Resp1; } set { _Resp1 = value; NotifyPropertyChanged("Resp1"); } }
        string _Resp2;
        public string Resp2 { get { return _Resp2; } set { _Resp2 = value; NotifyPropertyChanged("Resp2"); } }
        string _Resp3;
        public string Resp3 { get { return _Resp3; } set { _Resp3 = value; NotifyPropertyChanged("Resp3"); } }
        int _Delay = 5;
        public int Delay { get { return _Delay; } set { _Delay = value; NotifyPropertyChanged("Delay"); } }
    }
    public enum SystemTypes
    {
        QASYS,
        BASEZ,
        PZ,
        NATV
    }
}
