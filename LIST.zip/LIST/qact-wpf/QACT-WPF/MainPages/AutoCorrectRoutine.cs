﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Threading;
using System.Collections.ObjectModel;
using Microsoft.Win32;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.InteropServices;

namespace QACT_WPF
{
    public interface IAutoCorrect
    {
        bool AutoCorrectRoute();

    }

    public class TPFSetup_NewConn : IAutoCorrect
    {

        public HLLAPI auto_reg;
        public RunSettings runSettt;
        public string vpars = null;

        public TPFSetup_NewConn() { }
        public TPFSetup_NewConn(HLLAPI VM_wnd, RunSettings runSett)
        {
            auto_reg = VM_wnd;
            runSettt = runSett;
        }

        //public string ex1_param1;
        public bool AutoCorrectRoute()
        {
            vpars = String.Join(" ", runSettt.VIPS
                                                    .Where(vic => !String.IsNullOrWhiteSpace(vic.VPARS))
                                                    .Select(vic => vic.VPARS).ToList());

            //MessageBox.Show(vpars);

            if (vpars != null)

                auto_reg.EnterCommand("TPFPROC NEWCONN " + vpars, 600);
            if (auto_reg.WaitforString("RC=0", 600) == 0)
                return false;
            else
                return true;

        }
    }


}
