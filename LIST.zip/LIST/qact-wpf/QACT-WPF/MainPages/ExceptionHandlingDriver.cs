﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Threading;
using System.Collections.ObjectModel;
using Microsoft.Win32;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.InteropServices;

namespace QACT_WPF
{
    public class ExceptionHandlingDriver : INotifyPropertyChanged
    {
        //Implement InotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        private static readonly string Passphrase = App.Passphrase;
        List<string> ErrorsInRun = new List<string>();
        private HLLAPI VM_wnd;
        public RunSettings runSett;
        public readonly DateTime BaseInstalldate;
        bool AttemptedAutoCorrectFlag;
        bool SuccessfulAutoCorrectFlag;
        bool _isIdle = true;
        public bool IsIdle { get { return _isIdle; } set { _isIdle = value; NotifyPropertyChanged("IsIdle"); } }
        bool IsLoggedon = false;
        string HSM_PRODD77 = null;
        #region events
        public delegate bool ErrorEventHandler(string errorTag, string errorDesc, ErrorTypes errType);
        public event ErrorEventHandler OnError;

        public delegate void StageEventHandler(string stageTag, string status, bool isNewStage);
        public event StageEventHandler OnStageUpdate;
        private string lastStage = String.Empty;


        public event EventHandler OnCompletion;
        #endregion

        public ExceptionHandlingDriver(HLLAPI VM_wnd, RunSettings runSett)
        {
            this.VM_wnd = VM_wnd;
            this.runSett = runSett;


        }


        //################################################################################################################
        // AutoCorrect Routine Drivers:

        // AutoCorrect driver for all Exceptions



        public bool HandleErrorwithAutoCorrect(string errorstring, string errortype, string ERRGRP, IAutoCorrect ExObj)
        {
            AttemptedAutoCorrectFlag = true;
            if (ExObj.AutoCorrectRoute())
            {
                SuccessfulAutoCorrectFlag = true;
                // Log Exceptions in Error DB CSV file including the two new AutoCorrect indicators
                //Console.WriteLine("From HandleErrorwithAutoCorrect:: Error DB CSV file --> Error Text==>{0}  ErrorType==>{1}  AutoCorrectAttempted==>{2}  AutoCorrectSuccessful==>{3} ", errorstring, errortype, AttemptedAutoCorrectFlag, SuccessfulAutoCorrectFlag);  // Log Error in the Error DB csv file
                return true;
            }
            // Else continue with the current processing
            else
                return newHandleError("Regression", "New Conn During TPFSETUP", ErrorTypes.NotifyandAbort, ErrorGroup.TPFSETUP_ERROR);
        }


        public void LogOffCMS()
        {
            // LOGGING OFF
            //reg.EnterCommand("LOGOFF", 3);                                                                          
            //reg.WaitforString("z/VM ONLINE", 15);
            UpdateUsingFile();//Saumen020917
            VM_wnd.EnterCommand("LOGOFF", 1);
            VM_wnd.WaitforString("z/VM ONLINE", 30, false);
            VM_wnd.DisconnectSession();//Saumen020917
        }
        private void UpdateUsingFile()
        {
            VM_wnd.EnterCommand("GET VIPQAAUT", 1);
            VM_wnd.EnterCommand("USING AUTOREG", 1);
            //Ready; T=0.04/0.05 11:54:45
            VM_wnd.WaitForRegex(new Regex("Ready"), 20);

            string tmpFilePath = System.IO.Path.GetTempFileName();
            VM_wnd.ReceiveFile(tmpFilePath, "USAGE TEXT A1");

            Using UsingObj = new Using(tmpFilePath);
            UsingObj.StoreAsJSON();

            System.IO.File.Delete(tmpFilePath);
        }
        private void UploadRexxErrorLog()
        {
            if (IsLoggedon)
            {

                try
                {
                    string tmpfilepath = Path.GetTempFileName();
                    VM_wnd.ReceiveFile(tmpfilepath, "QACTREXX ERRLOG   A1");
                    File.Copy(tmpfilepath, Path.Combine(runSett.CoderunServer, "QACTREXX_ERRLOG_regression.txt"), true);
                    if (!File.Exists(Path.Combine(App.AutomationFiles, "QACTREXX_ERRLOG_regression.txt")))
                        File.WriteAllLines(Path.Combine(App.AutomationFiles, "QACTREXX_ERRLOG_regression.txt"), File.ReadAllLines(tmpfilepath));
                    else
                        File.AppendAllLines(Path.Combine(App.AutomationFiles, "QACTREXX_ERRLOG_regression.txt"), new List<string>() { new string('-', 100), runSett.CoderunServer, new string('-', 100) }.Concat(File.ReadAllLines(tmpfilepath)));
                    File.Delete(tmpfilepath);
                }
                catch { };
            }
        }
        public void LogOffAllVPARS(IList<QACT_WPF.VIP> VICs)
        {
            foreach (VIP vic in VICs.Where(v => !String.IsNullOrWhiteSpace(v.VPARS)))
            {
                VM_wnd.EnterCommand("TPFOPR " + vic.VPARS + " ZCYCL 1052", 20);
                VM_wnd.EnterCommand("TPFOPR " + vic.VPARS + " ZCP LOG", 1);
                VM_wnd.WaitforString("not open (no longer open)", 20);
                VM_wnd.WaitforString("Ready", 60);
            }
        }
        private void ReserveHSM(string noofhsm, string option)
        {
            VM_wnd.EnterCommand("GET VIPQAAUT", 2);
            VM_wnd.EnterCommand("RESHSM " + noofhsm + " " + option, 2);
            if (VM_wnd.WaitforString("Processing completed successfully", 5) == 0)
            {
                if (VM_wnd.WaitforString("PRODD77 is LOGGED OFF", 5) != 0)
                {
                    VM_wnd.EnterCommand("PIPE LITERAL PRODD77 is LOGGED OFF |>> PRODREGG SUMMARY A1", 2);
                }
                else
                {
                    VM_wnd.EnterCommand("PIPE LITERAL HSM could not be " + option + "ED to/from PRODD77 |>> PRODREGG SUMMARY A1", 2);
                }
            }
            else
            {
                VM_wnd.EnterCommand("PIPE LITERAL " + noofhsm + " HSM successfully " + option + "ED to/from PRODD77 |>> PRODREGG SUMMARY A1", 2);
            }
        }
        private void Completed()
        {
            if (OnCompletion != null)
                OnCompletion(this, EventArgs.Empty);
        }
        private void StageUpdate(string stage, string stageDesc, bool addNew)
        {
            stage = (string.IsNullOrWhiteSpace(stage) ? lastStage : stage);

            if (OnStageUpdate != null)
                OnStageUpdate(stage, stageDesc, addNew);

            lastStage = stage;
        }
        public void ErrorAbort()
        {
            //Finishing Regression
            if (IsLoggedon)
            {
                try
                {
                    //Do a Page up +I cms
                    VM_wnd.SendText(Keys3270.PA1);
                    VM_wnd.EnterCommand("I CMS");
                    VM_wnd.SendText(Keys3270.Enter);
                    VM_wnd.WaitforString("Ready", 10);
                    //Upload RexxErrlog
                    UploadRexxErrorLog();
                    //
                    LogOffAllVPARS(runSett.VIPS.Where(v => !String.IsNullOrWhiteSpace(v.VPARS)).ToList());
                    if (HSM_PRODD77 == "DETACHED")                                                                  
                    {
                        if (runSett.RegType != "DRB")
                        {
                            if (runSett.RegType == "DURBIN" || runSett.RegType == "ECIP" || runSett.RegType == "UNBALANCED" || runSett.RegType == "PRODD" || runSett.RegType == "TOKEN")
                            {
                                ReserveHSM("9", "ATTACH");
                            }
                            else
                            {
                                ReserveHSM("5", "ATTACH");
                            }
                        }
                    }
                }
                catch { }

                try
                {
                    LogOffCMS();
                }
                catch { }
            }
            //Remove the handler before aborting.
            Completed();
            VM_wnd.DisconnectSession();

            App.InputObj.State = InputFile.Status.REGRESSION_COMPLETED;
            StageUpdate("Error", "Abort", true);
            InputFile.UpdateStatus(App.InputObj, "Error : Aborted");

            // Close QACT
            if (Application.Current != null)
                Application.Current.Dispatcher.Invoke(() =>
                {
                    try
                    {
                        Application.Current.Shutdown(-1);
                        IsIdle = true;//Saumen021317
                    }
                    catch
                    {
                        Environment.Exit(-1);
                    }

                });
        }
        public bool newHandleError(string modeOfReg, string errorstring, ErrorTypes errortype, ErrorGroup ERRGRP = ErrorGroup.NOT_CLASSIFIED_ERROR, string subject = null, string emailid = null, bool attacherrorfile = true)  //SKD02212017 - Another string type variable has been defined to understand the mode of Regression eg Regression run or Analysis
        {
            //Replace notify type in Scheduler run during call
            //For Notify and Abort rather than Notify and wait
            //Runsettings.IsSchedulerRun?ErrorTypes.NotifyandAbort:ErrorTypes.NotifyandWait
            //For Notify and Log rather than notify and wait
            //Runsettings.IsSchedulerRun?ErrorTypes.NotifyAndLog:ErrorTypes.NotifyandWait
            try
            {
                VM_wnd.SendText(Keys3270.Reset, false, false);
            }
            catch { }
            if (errortype != ErrorTypes.NotifyOnly)
            {
                ErrorsInRun.Insert(0, DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + "==> " + errorstring);

                if (modeOfReg == "Regression" || modeOfReg != "Analysis")      //SKD02212017 --- Check if mode of Regression is "Regression Run"
                {
                    System.IO.File.WriteAllLines(runSett.CoderunServer + @"\RunErrors.txt", ErrorsInRun);
                }
                else if (modeOfReg == "Analysis")
                {
                    System.IO.File.WriteAllLines(runSett.CoderunServer + "\\AnalysisErrors.txt", ErrorsInRun);  //SKD02212017 --- Check if mode of Regression is "Analysis"
                }

            }
            try
            {


                if (ERRGRP != ErrorGroup.NO_ERROR)
                {
                    if (modeOfReg == "Regression")                     //SKD02212017 -- Check if mode of Regression is "Regression Run"
                    {

                        //Add error to ErrorDB csv file
                        //MM/dd/yyyy hh:mm:ss tt,"Error text",ErrorGroup
                        System.IO.File.AppendAllLines(App.RegressionErrorDBfile,
                            new string[] { DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + ",\""
                            + errorstring.Replace("\"", null) + "\","
                            + ERRGRP.ToString()+"," +
                            (runSett != null ?  runSett.InstallDate + "," + runSett.RegType + "," + runSett.RunNumber+","+(runSett.IsSchedulerRun?"Scheduler Run,":"UI Run,")+"\""+runSett.CoderunServer+"\"," : ",,,,,,")
                            +errortype.ToString() });
                    }
                    else if (modeOfReg == "Analysis")                                       //SKD02212017 --- Check if mode of Regression is "Analysis"
                    {
                        System.IO.File.AppendAllLines(App.RegressionErrorDBfile,
                            new string[] { DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + ",\""
                            + errorstring.Replace("\"", null) + "\","
                            + ERRGRP.ToString()+"," +
                            (runSett != null ?  runSett.InstallDate + "," + runSett.RegType + "," + runSett.RunNumber+","+(runSett.IsSchedulerRun?"Scheduler Analysis,":"UI Analysis,")+"\""+runSett.CoderunServer+"\"," : ",,,,,,")
                            +errortype.ToString() });
                    }
                    else if (modeOfReg == "Unhandled Error")
                    {
                        System.IO.File.AppendAllLines(App.RegressionErrorDBfile,
                        new string[] { DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + ",\""
                            + errorstring.Replace("\"", null) + "\","
                            + ERRGRP.ToString()+"," +
                            (runSett != null ?  runSett.InstallDate + "," + runSett.RegType + "," + runSett.RunNumber+","+"\""+runSett.CoderunServer+"\"," : ",,,,,,")
                            +errortype.ToString() });

                    }

                }

            }
            catch
            { }
            try
            {
                if (modeOfReg == "Regression" || modeOfReg != "Analysis")
                {
                    // Store the screenshot file into coderun server
                    System.IO.File.Copy(VM_wnd.screenshotfile, System.IO.Path.Combine(runSett.CoderunServer, System.IO.Path.GetFileName(VM_wnd.screenshotfile)), true);    //SKD02212017 -- Check if mode of Regression is "Regression Run"
                    //  System.IO.File.Delete(reg.screenshotfile);
                }
                if (modeOfReg == "Analysis")
                {
                    System.IO.File.Copy(VM_wnd.screenshotfile, System.IO.Path.Combine(runSett.CoderunServer, System.IO.Path.GetFileName(VM_wnd.screenshotfile)), true);   //SKD02212017 --- Check if mode of Regression is "Analysis"
                    //System.IO.File.Delete(ana.screenshotfile);
                }

            }
            catch { }

            if (errortype != ErrorTypes.LogOnly)
            {
                new Thread(() =>
                {

                    Outlook.Application oApp; Outlook.MailItem oMsg; Outlook.Recipients oRecips; Outlook.Recipient oRecip;
                    try
                    {
                        if (errortype != ErrorTypes.LogandWait)
                        {
                            oApp = new Outlook.Application();
                            oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                            oRecips = (Outlook.Recipients)oMsg.Recipients;
                            if (emailid == null)
                                if (modeOfReg == "Regression")
                                {
                                    oRecip = (Outlook.Recipient)oRecips.Add(runSett.email + "@visa.com"); //SKD02212017 -- Check if mode of Regression is "Regression Run"

                                }
                            if (modeOfReg == "Analysis")
                            {
                                oRecip = (Outlook.Recipient)oRecips.Add(runSett.email + "@visa.com");      //SKD02212017 -- Check if mode of Regression is "Analysis"
                            }
                            else
                                oRecip = (Outlook.Recipient)oRecips.Add(runSett.email + "@visa.com");
                            oRecip.Resolve();
                            if (subject == null)
                                if (modeOfReg == "Regression")
                                {
                                    oMsg.Subject = (runSett.VIPS.Where(v => v.VPARS != "" && v.VPARS != null).Count() + " VIP ").Replace("0 VIP ", "") + runSett.RegType + " Regression for " + runSett.InstallDate + " install (" + runSett.RunNumber + ") " + "- Error => " + errorstring;      //SKD02212017 --- Check the type of Regession ie "Regression Run"
                                }
                            if (modeOfReg == "Analysis")
                            {
                                oMsg.Subject = "ARCHES error: " + (runSett.VIPS.Where(v => v.VPARS != "" && v.VPARS != null).Count() + " VIP ") + runSett.RegType + " Regression for " + runSett.InstallDate + " install " + (runSett.SwitchActivationInfo != "N/A" ? runSett.SwitchActivationInfo + " Switch Activated " : null) + "(" + runSett.RunNumber + ") " + "- Error => " + errorstring;   //SKD02212017 --- Check the type of Regession ie "Regression Run"
                            }

                            else
                                oMsg.Subject = subject;
                            oMsg.BodyFormat = Outlook.OlBodyFormat.olFormatPlain;

                            if (modeOfReg == "Regression")                                 //SKD02212017 -- Check if mode of Regression is "Regression Run"
                            {
                                oMsg.Body = runSett.CoderunServer;
                            }
                            if (modeOfReg == "Analysis")
                            {
                                oMsg.Body = runSett.CoderunServer;                    ////SKD02212017 -- Check if mode of Regression is "Analysis"
                            }
                            if (attacherrorfile)
                            {
                                oMsg.Body += "\nPlease review the errors from attached file.\nAuto generated from QACT";
                                if (modeOfReg == "Regression")
                                {
                                    oMsg.Attachments.Add(runSett.CoderunServer + @"\RunErrors.txt");     //SKD02212017 -- Check if mode of Regression is "Regression"
                                }
                                if (modeOfReg == "Analysis")
                                {
                                    oMsg.Attachments.Add(runSett.CoderunServer + "\\AnalysisErrors.txt");       //SKD02212017 -- Check if mode of Regression is "Analysis"
                                }
                            }
                            else
                                oMsg.Body += "\nAuto generated from QACT";

                            ((Outlook._MailItem)oMsg).Send();
                        }

                    }
                    catch (Exception)
                    {

                    }
                    finally
                    {
                        oApp = null; oMsg = null; oRecip = null; oRecips = null;
                        if (oRecip != null || oRecips != null || oMsg != null || oApp != null)
                        {
                            try
                            {
                                Marshal.ReleaseComObject(oRecip);
                                oRecip = null;
                                Marshal.ReleaseComObject(oMsg);
                                oMsg = null;
                                Marshal.ReleaseComObject(oRecips);
                                oRecips = null;
                                Marshal.ReleaseComObject(oApp);
                                oApp = null;
                            }
                            catch (Exception)
                            {
                                oRecip = null;
                                oRecips = null;
                                oMsg = null;
                                oApp = null;
                            }
                            finally
                            {
                                GC.Collect();
                            }
                        }
                    }

                }).Start();

                if (errortype == ErrorTypes.NotifyandAbort)
                {
                    if (modeOfReg == "Regression")
                    {
                        ErrorAbort();
                        return false;
                    }
                    if (modeOfReg == "Analysis")
                    {

                        ErrorAbort();
                        return false;
                    }
                    else
                    {
                        System.IO.File.AppendAllLines(App.RegressionErrorDBfile,
                           new string[] { DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + ",\""
                            + errorstring.Replace("\"", null) + "\","
                            + ERRGRP.ToString()+"," +
                            (runSett != null ?  runSett.InstallDate + "," + runSett.RegType + "," + runSett.RunNumber+","+(runSett.IsSchedulerRun?"Scheduler Analysis,":"UI Analysis,")+"\""+runSett.CoderunServer+"\"," : ",,,,,,")
                            +errortype.ToString() });

                    }

                }
                else if (errortype == ErrorTypes.NotifyandWait || errortype == ErrorTypes.LogandWait)
                {
                    if (MessageBox.Show("Press Yes to Continue, No to Abort\nError encountered:\n" + errorstring, "Regression Window - " + VM_wnd.SessionShortName, MessageBoxButton.YesNo, MessageBoxImage.Error, MessageBoxResult.Yes) == MessageBoxResult.No)
                        return false;
                }
            }
            return true;
        }


    }
}