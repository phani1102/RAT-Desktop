﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using QACT_WPF;
using System.Net;
using Excel = Microsoft.Office.Interop.Excel;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Web.UI;
using System.Threading;
using System.Runtime.InteropServices;
using System.Windows;
using System.IO;
using System.ComponentModel;

namespace LoadNightTesting
{
    public class LoadNightProcess
    {
        //Saumen021317
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        //Saumen021317
        /// <summary>
        /// HLLAPI object for communication with VM
        /// </summary>
        private HLLAPI VM_wnd;
        List<string> ErrorsInRun = new List<string>();//Saumen020717 : to send using email
        /// <summary>
        /// contains a list of files to FTP
        /// </summary>
        public List<FTPVIPFile> FTPFileList = new List<FTPVIPFile>();
        /// <summary>
        /// Settings for this run
        /// </summary>
        public RunSettings runSett;
        /// <summary>
        /// WE install list 
        /// </summary>
        public WELogs WEInstallData = null;
        /// <summary>
        /// Regex to Parse dumpLines
        /// </summary>
        public static
            Regex dumpLineRegex = new Regex(@"\s*(?'dump_id'\d+)\s+                             
                                                (?'dump_number'[\w-\d]+)\s+
                                                (?'program'[\w\d]*)\s*
                                                (?'dump_details'(?:.(?!:))*)
                                                \s*:\s*(?'vpars'[\w\d]+)
                                                ", RegexOptions.IgnorePatternWhitespace | RegexOptions.IgnoreCase | RegexOptions.Compiled);


        /// <summary>
        /// Load Date of the WEs to install
        /// </summary>
        public readonly DateTime BaseInstalldate;
        bool IsLoggedon = false;//Saumen020717 : to send using email
        //Saumen021317
        bool _isIdle = true;
        public bool IsIdle { get { return _isIdle; } set { _isIdle = value; NotifyPropertyChanged("IsIdle"); } }
        //Saumen021317
        #region events
        public delegate bool ErrorEventHandler(string errorTag, string errorDesc, ErrorTypes errType);
        public event ErrorEventHandler OnError;

        public delegate void StageEventHandler(string stageTag, string status, bool isNewStage);
        public event StageEventHandler OnStageUpdate;
        private string lastStage = String.Empty;

        public event EventHandler OnCompletion;
        //public delegate void LoadNightCompletedHandler();//Saumen021717
        //public event LoadNightCompletedHandler OnLoadNightCompleted;//Saumen021717
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="VM_wnd"></param>
        /// <param name="runSett"></param>
        /// <param name="WEData"></param>
        public LoadNightProcess(HLLAPI VM_wnd, RunSettings runSett, DateTime baseInstallDate)
        {
            this.VM_wnd = VM_wnd;
            this.runSett = runSett;
            BaseInstalldate = baseInstallDate;
        }

        /// <summary>
        /// starts the entire LodNightTesting process
        /// </summary>
        /// <param name="startFromInstallOrder"></param>
        public void Run(int startInstallOrder = -1)
        {
            //this.OnLoadNightCompleted += Scheduler_OnLoadNightCompleted;//Saumen021717
            VM_wnd.ConnectSession();
            VM_wnd.ShowWindow(true);

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //////////////////////////////////////////////////////////////// CMS Login //////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            string id = runSett.VMID;
            if (Login(ref id, runSett.VMPWD))
            {
                StageUpdate("LOGIN", "Started");
                runSett.VMID = id;
                StageUpdate("LOGIN", "Successful");
                IsLoggedon = true;//Saumen021717
                UpdateUsingFile();
            }
            else
            {
                StageUpdate("LOGIN failed", "Aborted");//Saumen020817
                //ErrorEvent("Aborted", "Unsuccessful", ErrorTypes.NotifyandAbort);//Saumen020917
                HandleError("Login failed : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.NOT_CLASSIFIED_ERROR);//Saumen020817
                return;
            }

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //////////////////////////////////////////////////// Create and transfer setup //////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (startInstallOrder < 0 && !runSett.IsSkipSetup)
            {
                try
                {
                    CreateAndTransferSetup();
                    //Saumen020717 : to send using email
                    //string emailsubject = "I will be using " + string.Concat(runSett.VIPS.Where(v => v.VPARS != "").Select(v => v.VPARS + ",")).TrimEnd(',')
                    //    + " " + string.Concat(runSett.VIPS.Where(v => v.QAT != "").Select(q => q.QAT + ",")).TrimEnd(',') + " for " + DateTime.ParseExact(runSett.InstallDate, @"MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture).AddDays(7).ToString(@"MM/dd/yyyy") + " install " + runSett.RegType + " Regression(" + runSett.RunNumber + ").";//Saumen031117
                    string emailsubject = "I will be using " + string.Concat(runSett.VIPS.Where(v => v.VPARS != "").Select(v => v.VPARS + ",")).TrimEnd(',')
                        + " " + string.Concat(runSett.VIPS.Where(v => v.QAT != "").Select(q => q.QAT + ",")).TrimEnd(',') + " for " + DateTime.ParseExact(runSett.InstallDate, @"MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture).ToString(@"MM/dd/yyyy") + " install " + runSett.RegType + " Regression(" + runSett.RunNumber + ").";//Saumen032817

                    HandleError(emailsubject, ErrorTypes.NotifyOnly, ErrorGroup.NO_ERROR, emailsubject, "QA-VIP-Support", false);
                    //Saumen020717
                }
                catch (Exception ex)
                {
                    StageUpdate("Create & transfer setup failed", "Aborted");//Saumen020817
                    System.IO.File.WriteAllText(System.IO.Path.Combine(runSett.CoderunServer, ex.GetHashCode() + ".Exception"), ex.ToString());
                    //ErrorEvent("Aborted", ex.Message, ErrorTypes.NotifyandAbort);//Saumen020917
                    HandleError("Setup creation failed : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.SETUP_CREATION_ERROR);//Saumen020717 : to send using email
                    return;
                }
            }

            GetVPARSNames();                    // gets the VPARS details from the setup file             

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////// TRANSFER FILES INTO CMS //////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            try
            {
                TransferFilesToCMS();
                //StageUpdate("Install Script Validation", "Running... ", true);
                //WEInstallData.ValidateInstallScript();
                //StageUpdate("Install Script Validation", "Successful", false);
            }
            catch (Exception ex)
            {
                StageUpdate("Transfer file to CMS failed", "Aborted");//Saumen020817
                System.IO.File.WriteAllText(System.IO.Path.Combine(runSett.CoderunServer, ex.GetHashCode() + ".Exception"), ex.ToString());
                //ErrorEvent("Aborted", ex.Message, ErrorTypes.NotifyandAbort);//Saumen020917
                HandleError("Transfer file to CMS failed : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.FTP_ERROR);//Saumen020817
                return;
            }
            finally
            {
                var tmp = runSett.VMPWD;
                runSett.VMPWD = Crypto.Encrypt(runSett.VMPWD, App.Passphrase);
                runSett.StoreAsJsonFile(System.IO.Path.Combine(runSett.CoderunServer, "RunSettings.json"));
                runSett.VMPWD = tmp;
                WEInstallData.StoreAsJsonFile(System.IO.Path.Combine(runSett.CoderunServer, "WELogs.json"));
            }

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //////////////////////////////////////////////////// IPL A 5 VIP system  ////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (runSett.IsSkipSetup == false)
            {
                try
                {
                    SubmitAndTrackSetup(runSett);
                    // ATTACH HSMs
                    runSett.VIPS
                            .Where(v => !String.IsNullOrWhiteSpace(v.VPARS))
                            .ToList()
                            .ForEach(vip => AttachHSM(vip.VPARS, runSett.HSMUnit));
                }
                catch (System.InvalidOperationException setupEx)
                {
                    StageUpdate("Setup failed", "Aborted");//Saumen020817
                    System.IO.File.WriteAllText(System.IO.Path.Combine(runSett.CoderunServer, setupEx.GetHashCode() + ".Exception"), setupEx.ToString());
                    //ErrorEvent("Aborted", setupEx.Message, ErrorTypes.NotifyandAbort);//Saumen020917
                    HandleError("Setup failed : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.TPFSETUP_ERROR);//Saumen020817
                    return;
                }
            }

            GetTempDisks();

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////// Load NIght iterations (LDNITE EXEC) //////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            try
            {
                var vipB = runSett.VIPS.First(vip => vip.VIPNAME.Equals("VIPB", StringComparison.InvariantCultureIgnoreCase));
                ZCPVPQ(vipB.VPARS); //GGIRDHAR020817 - Get System Usage
                // For baseline system
                if (startInstallOrder <= 0)
                {
                    EraseOldFiles();
                    FTPFiles();
                    RunTxnsAndCompare(WEInstallData.WEInstallList.Single(we => we.WEState.Equals("BASE", StringComparison.InvariantCultureIgnoreCase)));
                    ZCPVPQ(vipB.VPARS); //GGIRDHAR020817 - Get System Usage
                }

                // 1052 WEs
                if (WEInstallData.WEInstallList.Count(we => we.WEState.Contains("1052") && we.WEInstallOrder >= startInstallOrder) > 0)   // i.e if there are any 1052 WEs
                {
                    WEData common1052WE = new WEData(1, "1052WE", WEInstallData.WEInstallList.First(we => we.WEState.Contains("1052")).WEState);

                    //Apply ‘ZKSWC DROP’ before loading any WE marked as services ‘Inactive’.
                    ZKSWC(vipB.VPARS, "DROP");

                    // install all 1052 WEs at once 
                    bool isWEInstalled = InstallWE(common1052WE);

                    //Apply ‘ZKSWC RESUME’ after the load is complete.
                    ZKSWC(vipB.VPARS, "RESUME");

                    if (isWEInstalled)  // Run txns only if the WE is installed successfully
                    {
                        FTPFiles();

                        ZCPVPQ(vipB.VPARS); //GGIRDHAR020817 - Get System Usage

                        RunTxnsAndCompare(common1052WE);

                        ZCPVPQ(vipB.VPARS); //GGIRDHAR020817 - Get System Usage

                        WEInstallData.WEInstallList
                                            .AsParallel()
                                            .Where(we => we.WEState.Contains("1052"))
                                            .ForAll(_1052WE => { _1052WE.Tapes = common1052WE.Tapes; });
                    }
                }

                // for each Norm WE
                //foreach (WEData NormWE in WEInstallData.WEInstallList.Where(w => w.WEState.Contains("NORM") && w.WEInstallOrder >= startInstallOrder))
                foreach (WEData NormWE in WEInstallData.WEInstallList.Where(w => w.WEState.ToUpper().Contains("NORM") && w.WEInstallOrder >= startInstallOrder)) //fall forward :: added the commit 2df9a717718 (Fix fro Load Night's NORM WE identification) back to fix VIPENG-1109
                {
                    if (NormWE.WEState.ToUpper().Contains("INACTIVE"))
                        ZKSWC(vipB.VPARS, "DROP");

                    bool isWEInstalled = InstallWE(NormWE);

                    if (NormWE.WEState.ToUpper().Contains("INACTIVE"))
                        ZKSWC(vipB.VPARS, "RESUME");

                    if (isWEInstalled)  // Run txns only if the WE is installed successfully
                    {
                        FTPFiles();
                        ZCPVPQ(vipB.VPARS); //GGIRDHAR020817 - Get System Usage
                        RunTxnsAndCompare(NormWE);
                        ZCPVPQ(vipB.VPARS); //GGIRDHAR020817 - Get System Usage
                    }
                }

                // for each Global Load
                //foreach (WEData global in WEInstallData.WEInstallList.Where(w => w.WEState.Contains("GLOBAL LOAD") && w.WEInstallOrder >= startInstallOrder))
                foreach (WEData global in WEInstallData.WEInstallList.Where(w => w.WEState.ToUpper().Contains("GLOBAL LOAD") && w.WEInstallOrder >= startInstallOrder)) //fall forward :: added the commit 2df9a717718 (Fix fro Load Night's NORM WE identification) back to fix VIPENG-1109
                {
                    bool isGlobalInstalled = InstallWE(global);
                    if (isGlobalInstalled)  // Run txns only if the Global is loaded successfully
                    {
                        FTPFiles();
                        ZCPVPQ(vipB.VPARS); //GGIRDHAR020817 - Get System Usage
                        RunTxnsAndCompare(global);
                        ZCPVPQ(vipB.VPARS); //GGIRDHAR020817 - Get System Usage
                    }
                }
            }
            catch (System.InvalidOperationException ex)
            {
                StageUpdate("Load night process failed", "Aborted");//Saumen020817
                System.IO.File.WriteAllText(System.IO.Path.Combine(runSett.CoderunServer, ex.GetHashCode() + ".Exception"), ex.ToString());
                //ErrorEvent("Aborted", ex.Message, ErrorTypes.NotifyandAbort);//Saumen020917
                HandleError("LOAD_NIGHT process failed : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.NOT_CLASSIFIED_ERROR);//Saumen020817
                return;
            }
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //////////////////////////////////////////////////// Report Generation //////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            try
            {
                GetVMFiles();
                File.Create(Path.Combine(runSett.CoderunServer, ".CanBeUsedAsBaseRun")).Dispose();//Saumen021317
                GenerateReport();
                File.Create(Path.Combine(runSett.CoderunServer, ".ResultCanBeDistributed")).Dispose();//Saumen021317
            }
            catch (Exception ex)
            {
                StageUpdate("Report generation failed", "Aborted");//Saumen020817
                System.IO.File.WriteAllText(System.IO.Path.Combine(runSett.CoderunServer, ex.GetHashCode() + ".Exception"), ex.ToString());
                //ErrorEvent("Report Generation Error", ex.Message, ErrorTypes.NotifyandAbort);//Saumen020917
                HandleError("Report generation failed : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.NOT_CLASSIFIED_ERROR);//Saumen020817
            }
            finally
            {
                WEInstallData.StoreAsJsonFile(System.IO.Path.Combine(runSett.CoderunServer, "WELogs.json"));
            }

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////// Send Email ////////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            try
            {
                StageUpdate("Mail generation", "Running...", true);
                sendMail();
                StageUpdate("Mail generation", "Successful", false);
            }
            catch (Exception ex)
            {
                System.IO.File.WriteAllText(System.IO.Path.Combine(runSett.CoderunServer, ex.GetHashCode() + ".Exception"), ex.ToString());
                StageUpdate("Mail generation failed", "Aborted", false);
                //ErrorEvent("Mail Sending", ex.Message, ErrorTypes.NotifyandAbort);//Saumen020917
                HandleError("Mail generation failed : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.COM_ERROR);//Saumen020817
            }

            // VM_wnd.DisconnectSession();

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////// Completed ////////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            //Saumen021517
            UploadRexxErrorLog();
            LogOffAllVPARS(runSett.VIPS.Where(v => !String.IsNullOrWhiteSpace(v.VPARS)).ToList());
            if (HSM_PRODD77 == "DETACHED")
            {
                if (runSett.RegType != "DRB")
                {
                    //Saumen030317
                    //if (runSett.RegType == "DURBIN" || runSett.RegType == "ECIP" || runSett.RegType == "UNBALANCED" || runSett.RegType == "PRODD" || runSett.RegType == "TOKEN")
                    //{
                    //Saumen030317
                    ReserveHSM("9", "ATTACH");
                    //Saumen030317
                    //}
                    //else
                    //{
                    //    ReserveHSM("5", "ATTACH");
                    //}
                    //Saumen030317
                }
            }
            LogOffCMS();
            Completed();
            //this.OnLoadNightCompleted -= Scheduler_OnLoadNightCompleted;//Saumen021717
            //Saumen021717
            // Fire the Load Night completed event
            //if (OnLoadNightCompleted != null)
            //    OnLoadNightCompleted();
            App.InputObj = null;
            IsIdle = true;
            //Saumen021717

            VM_wnd.DisconnectSession();
            //Saumen021517

            //Saumen021317
            App.InputObj.State = InputFile.Status.REGRESSION_COMPLETED;
            StageUpdate("Successful", "Complete", true);
            InputFile.UpdateStatus(App.InputObj, "Successfully Completed");//Saumen092816
            //Saumen021317

            //Saumen020917: Close QACT
            if (Application.Current != null)
                Application.Current.Dispatcher.Invoke(() =>
                {
                    try
                    {
                        Application.Current.Shutdown(-1);
                        IsIdle = true;//Saumen021317
                    }
                    catch
                    {
                        Environment.Exit(-1);
                    }

                });
            //Saumen020917
        }

        private void CreateAndTransferSetup()
        {
            string currStage = "Create and transfer setup for, " + BaseInstalldate.ToString(@"MM/dd/yyyy");
            StageUpdate(currStage, "Started");

            try
            {
                runSett.VIPS = new List<VIP>();
                App.ALLVIPS.ToList().ForEach(vicId => runSett.VIPS.Add(new VIP() { VIPNAME = "VIP" + vicId }));

                ////////////////// create and transfer the setup for BaseInstallDate //////////////////////////
                string codeInstallDate = runSett.InstallDate;
                runSett.InstallDate = BaseInstalldate.ToString(@"MM/dd/yyyy");  // set the Base Install date for the setup file to be created 
                StageUpdate(currStage, "Running...");
                string errString = QACT_WPF.RegSettings.CreateandTransferSetup(runSett, VM_wnd);
                runSett.InstallDate = codeInstallDate;                          // reset the Install date

                if (!String.IsNullOrEmpty(errString))                           // On some error
                {
                    StageUpdate("Create & Transfer setup failed", "Aborted");//Saumen020817
                                                           //throw new Exception(errString);
                    HandleError("Create & transfer setup failed.", ErrorTypes.NotifyandAbort, ErrorGroup.SETUP_CREATION_ERROR);//Saumen020817
                }
            }
            catch (Exception ex)
            {
                StageUpdate(currStage, "Create & transfer setup failed : Aborted" + ex.Message);
                //ErrorEvent(currStage, ex.Message, ErrorTypes.NotifyandAbort);//Saumen020917
                //throw ex;
                HandleError("Create & transfer setup failed : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.SETUP_CREATION_ERROR);//Saumen020817
            }

            StageUpdate(currStage, "Successful");
        }

        private void EraseOldFiles()
        {
            VM_wnd.EnterCommand("ERASE LDNITE UNIDUMPS A1");
            VM_wnd.EnterCommand("ERASE LDNITE DUMPS A1");
            VM_wnd.EnterCommand("ERASE LDNITE TAPES A1");
            VM_wnd.EnterCommand("ERASE LDNITE LOG A1");
        }

        private void GenerateReport()
        {
            string stage = "GenerateReport";

            Regex runContents = new Regex(@"(?'run_line'RUN\s*(?'run_num'\d+))         # matches RUN 0
                                            (?'run_contents'(?:(?:.|\s)(?!RUN))*)      # matches lines or whitespace between two runs
                                           ",
                                           RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace | RegexOptions.Multiline | RegexOptions.Compiled);

            // parse tapes
            if (System.IO.File.Exists(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_TAPES-coderun.txt")))
            {
                //RUN0
                //DTD:A0999,A0999,A0999,A0999,A0999
                //RSI:A0999,A0999,A0999,A0999,A0999
                //CSI:A0999,A0999,A0999,A0999,A0999
                //RUN1
                //DTD:A0999,A0999,A0999,A0999,A0999
                //RSI:A0999,A0999,A0999,A0999,A0999
                //CSI:A0999,A0999,A0999,A0999,A0999

                foreach (Match runContentsMatch in runContents.Matches(System.IO.File.ReadAllText(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_TAPES-coderun.txt"))))
                {
                    int run_num = Convert.ToInt32(runContentsMatch.Groups["run_num"].Value);

                    runContentsMatch.Groups["run_contents"].Value.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries)
                                                            .AsParallel()
                                                            .Where(ln => ln.Contains(':'))
                                                            .ForAll((ln) =>
                                                                WEInstallData.WEInstallList
                                                                            .AsParallel()
                                                                             .Where(we => we.WEInstallOrder == run_num || (we.WEState.Contains("1052") && run_num == 1))
                                                                             .ForAll(we => we.Tapes[ln.Split(':')[0].ToUpper().Trim()] = ln.Split(':')[1].ToUpper().Trim())
                                                            );
                }
            }
            else
            {
                //ErrorEvent(stage, System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_TAPES-coderun.txt") + " file not found", ErrorTypes.LogOnly);//Saumen020917
                HandleError("LDNITE_TAPES-coderun.txt not found", ErrorTypes.LogOnly, ErrorGroup.FTP_ERROR);//Saumen020817
            }

            // parse and compare dumps
            if (System.IO.File.Exists(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_UNIDUMPS-coderun.txt")))
            {
                //RUN0
                //RUN11
                //RUN12
                //RUN13
                //RUN14
                //RUN15
                //ID DUMP_Details : VPARS_ID
                //0 OPR-UDEB281 KET2 KET2 OBJ-ket2 00000228 LOADSET-BASE : PRODD13
                //0 SNP-U00C00246 EIVC : PRODD15
                //RUN2
                //ID DUMP_Details : VPARS_ID
                //0 OPR-UDEB281 KET2 KET2 OBJ-ket2 00000228 LOADSET-BASE : PRODD13
                //0 SNP-U00C00246 EIVC : PRODD15
                //RUN3
                //ID DUMP_Details : VPARS_ID
                //0 OPR-UDEB281 KET2 KET2 OBJ-ket2 00000228 LOADSET-BASE : PRODD13
                //0 SNP-U00C00246 EIVC : PRODD15

                MatchCollection knownDumps = Regex.Matches(System.IO.File.ReadAllText(App.KnownDumpsServer),
                                                                @"(?'program'[\w-\d]+)\s+(?'dump_number'[\w-\d]*)\s+\s*-\s*(?'dump_comments'.*)");

                // Make sure there is no dump data present in the WEInstallList
                WEInstallData.WEInstallList
                                .AsParallel()
                                .ForAll(we => we.NewDumpsFound.Clear());

                foreach (Match runContentsMatch in runContents.Matches(System.IO.File.ReadAllText(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_UNIDUMPS-coderun.txt"))))
                {
                    int run_num = Convert.ToInt32(runContentsMatch.Groups["run_num"].Value);
                    // Add dump details line by line here
                    runContentsMatch.Groups["run_contents"].Value
                                                            .Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries)
                                                            .AsParallel()
                                                            .Where(ln => dumpLineRegex.IsMatch(ln))
                                                            .ForAll(dumpLine =>
                                                            {
                                                                Match currDump = dumpLineRegex.Match(dumpLine);

                                                                //remove known dumps
                                                                if (knownDumps.Cast<Match>()
                                                                                .Any(eachKnownDump =>
                                                                                        eachKnownDump.Groups["dump_number"].Value.Equals(currDump.Groups["dump_number"].Value)
                                                                                        && eachKnownDump.Groups["program"].Value.Equals(currDump.Groups["program"].Value)
                                                                                        || String.IsNullOrWhiteSpace(currDump.Groups["program"].Value)
                                                                                        && eachKnownDump.Groups["program"].Value.Equals(currDump.Groups["dump_number"].Value)
                                                                                    )
                                                                    )
                                                                    return;

                                                                // compare with previous dumps
                                                                if (run_num > 0
                                                                     && WEInstallData.WEInstallList
                                                                                    .AsParallel()
                                                                                    .Where(we => we.WEInstallOrder < run_num)
                                                                                    .Any(prevWE => prevWE.NewDumpsFound
                                                                                                         .Select(prevDump => dumpLineRegex.Match(prevDump))
                                                                                                         .Any(prevDump =>
                                                                                                             prevDump.Groups["dump_number"].Value.Equals(currDump.Groups["dump_number"].Value)
                                                                                                             && prevDump.Groups["program"].Value.Equals(currDump.Groups["program"].Value)
                                                                                                            ))
                                                                    )
                                                                    return;

                                                                // Now Add the dump line
                                                                WEInstallData.WEInstallList
                                                                            .AsParallel()
                                                                            .Where(we => we.WEInstallOrder == run_num || (we.WEState.Contains("1052") && run_num == 1))
                                                                            .ForAll(we => we.NewDumpsFound.Add(String.Copy(dumpLine)));
                                                            });
                }
            }
            else
            {
                //ErrorEvent(stage, System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_UNIDUMPS-coderun.txt") + " file not found", ErrorTypes.LogOnly);//Saumen020917
                HandleError("LDNITE_UNIDUMPS-coderun.txt not found", ErrorTypes.LogOnly, ErrorGroup.FTP_ERROR);//Saumen020817
            }
            // parse Status
            if (!System.IO.File.Exists(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_STATUS-coderun.txt")))
            {
                //Saumen020817
                //    throw new NotImplementedException();
                //}
                //else
                //{
                //Saumen020817
                //ErrorEvent(stage, System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_STATUS-coderun.txt") + " file not found", ErrorTypes.LogOnly);//Saumen020917
                HandleError("LDNITE_STATUS-coderun.txt not found", ErrorTypes.LogOnly, ErrorGroup.FTP_ERROR);//Saumen020817
            }

            // create LDNITE_PROGRESS
            try
            {
                List<string> ldnite_progress = new List<string>();
                string format = @"{0,-20} {1,-40} {2,-9} {3,-7} {4,-7} {5,-7}";
                ldnite_progress.Add(String.Format(format, "Record", "Dumps", "VPARS", "DTD", "RSI", "CSI"));

                WEInstallData.WEInstallList
                                .OrderBy(we => we.WEInstallOrder)
                                .ToList()
                                .ForEach(we =>
                                {
                                    try
                                    {
                                        if (we.NewDumpsFound.Count <= 0)
                                            throw new Exception("No Dumps for " + we.WENumber);

                                        we.NewDumpsFound
                                            .Select(dump => dumpLineRegex.Match(dump))
                                            .ToList()
                                            .ForEach(dumpMatch =>
                                             {
                                                 string dumpNumber = dumpMatch.Groups["dump_number"].Value;
                                                 string dumpProg = dumpMatch.Groups["program"].Value;
                                                 string dumpVPARS = dumpMatch.Groups["vpars"].Value;

                                                 try
                                                 {
                                                     int dumpVparsIndex = runSett.VIPS.IndexOf(runSett.VIPS.First(vip => vip.VPARS == dumpVPARS));

                                                     string dtd = we.Tapes["DTD"].Split(',')[dumpVparsIndex];
                                                     string rsi = we.Tapes["RSI"].Split(',')[dumpVparsIndex];
                                                     string csi = we.Tapes["CSI"].Split(',')[dumpVparsIndex];
                                                     ldnite_progress.Add(String.Format(format, we.WENumber, dumpNumber + " from " + dumpProg, dumpVPARS, dtd, rsi, csi));
                                                 }
                                                 catch
                                                 {
                                                     ldnite_progress.Add(String.Format(format, we.WENumber, dumpNumber + " from " + dumpProg, dumpVPARS, "NA", "NA", "NA"));
                                                 }

                                             });
                                    }
                                    catch
                                    {
                                        ldnite_progress.Add(String.Format(format, we.WENumber, "No Dumps", "NA", "NA", "NA", "NA"));
                                    }
                                });
                System.IO.File.Delete(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_PROGRESS-coderun.txt"));
                System.IO.File.WriteAllLines(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_PROGRESS-coderun.txt"), ldnite_progress);
            }
            catch { }

        }

        private void sendMail()
        {

            string HTMLMail = String.Empty;

            string WELogsHTML = WEInstallData.createHTMLReport(runSett);

            try
            {
                OutlookEmail mailObj = new OutlookEmail(runSett);
                string mailContents = mailObj.CreateHTMLBody();
                HTMLMail = mailContents.Insert(mailContents.IndexOf(@"<h4>"), WELogsHTML);
            }
            catch (Exception ex)
            {
                HTMLMail = WELogsHTML;
                //throw ex;
                HandleError(ex.Message, ErrorTypes.LogOnly, ErrorGroup.COM_ERROR);//Saumen020817
            }
            finally
            {
                System.IO.File.WriteAllText(System.IO.Path.Combine(runSett.CoderunServer, "Mail.html"), HTMLMail);
            }

            //GGIRDHAR031717 string Subject = (runSett.VIPS.Where(v => v.VPARS != "").Count() + " VIP " + runSett.RegType) + " Regression for " + DateTime.ParseExact(runSett.InstallDate, @"MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture).AddDays(7).ToString(@"MM/dd/yyyy") + " install " + (String.IsNullOrWhiteSpace(runSett.SwitchActivationInfo) || runSett.SwitchActivationInfo.Equals("N/A", StringComparison.CurrentCultureIgnoreCase) ? null : runSett.SwitchActivationInfo + " Switch Activated") + "(" + runSett.RunNumber + ")";//Saumen031117
            string Subject = (runSett.VIPS.Where(v => v.VPARS != "").Count() + " VIP " + runSett.RegType) + " Regression for " + DateTime.ParseExact(runSett.InstallDate, @"MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture).ToString(@"MM/dd/yyyy") + " install " + (String.IsNullOrWhiteSpace(runSett.SwitchActivationInfo) || runSett.SwitchActivationInfo.Equals("N/A", StringComparison.CurrentCultureIgnoreCase) ? null : runSett.SwitchActivationInfo + " Switch Activated") + "(" + runSett.RunNumber + ")";//GGIRDHAR031717 - Remove Add 7 Days Logic
            string To = runSett.email;
            //////////////////////////////////////////// Create the Outlook application ////////////////////////////////////////
            Outlook.Application oApp = new Outlook.Application();
            //////////////////////////////////////////// Create a new mail item ////////////////////////////////////////////////
            Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

            ////////////////////////////////////////// Message HTMLBody ////////////////////////////////////////////////////////
            oMsg.HTMLBody = HTMLMail;

            ////////////////////////////////////////////// ADD ATTACHMENTs /////////////////////////////////////////////////////
            //files.ForEach( filePath => {
            //    oMsg.Attachments.Add(
            //            filePath
            //            , Outlook.OlAttachmentType.olByValue
            //            , oMsg.Body.Length + 1
            //            , System.IO.Path.GetFileName(filePath)
            //        );
            //});
            //String sDisplayName = "MyAttachment";
            //int iPosition = (int)oMsg.Body.Length + 1;
            //int iAttachType = (int)Outlook.OlAttachmentType.olByValue;
            ////now attached the file
            //Outlook.Attachment oAttach = oMsg.Attachments.Add(@"C:\\fileName.jpg", iAttachType, iPosition, sDisplayName);

            ////////////////////////////////////////////// Subject line /////////////////////////////////////////////////////
            oMsg.Subject = Subject;
            ///////////////////////////////////////////// Add recipients ///////////////////////////////////////////////////
            Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
            oRecips.Add(To);
            //Outlook.Recipient oRecip = 

            oRecips.ResolveAll();
            /////////////////////////////////////////////// Send Message ////////////////////////////////////////////////////
            oMsg.SaveAs(System.IO.Path.Combine(runSett.CoderunServer, "Mail.msg"));
            ((Outlook._MailItem)oMsg).Send();
        }

        private void GetVMFiles()
        {
            string currStage = "CMS_FILES_TRANSFER";

            StageUpdate(currStage, "Receiving : " + runSett.SetupFile + " $TTVDATA");
            // get setup file
            VM_wnd.ReceiveFile(System.IO.Path.Combine(runSett.CoderunServer, "setup-coderun.txt"), runSett.SetupFile + " $TTVDATA A1");
            StageUpdate(currStage, "Received : " + runSett.SetupFile + " $TTVDATA A1");

            StageUpdate(currStage, "Receiving : LDNITE TAPES A1");
            // get tapes
            VM_wnd.ReceiveFile(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_TAPES-coderun.txt"), "LDNITE TAPES A1");
            StageUpdate(currStage, "Received : LDNITE TAPES A1");


            StageUpdate(currStage, "Receiving : LDNITE DUMPS A1");
            // get dumps
            VM_wnd.ReceiveFile(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_DUMPS-coderun.txt"), "LDNITE DUMPS A1");
            StageUpdate(currStage, "Received : LDNITE DUMPS A1");


            StageUpdate(currStage, "Receiving : LDNITE STATUS A1");
            // GET status
            VM_wnd.ReceiveFile(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_STATUS-coderun.txt"), "LDNITE STATUS A1");
            StageUpdate(currStage, "Received : LDNITE STATUS A1");

            StageUpdate(currStage, "Receiving : LDNITE LOG A1");
            // get Log
            VM_wnd.ReceiveFile(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_LOG-coderun.txt"), "LDNITE LOG A1");
            StageUpdate(currStage, "Received : LDNITE LOG A1");

            StageUpdate(currStage, "Receiving : LDNITE UNIDUMPS A1");
            // get UNIDUMPS
            VM_wnd.ReceiveFile(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_UNIDUMPS-coderun.txt"), "LDNITE UNIDUMPS A1");
            StageUpdate(currStage, "Received : LDNITE UNIDUMPS A1");

            try
            {
                //get Dump Display
                dumpLineRegex.Matches(System.IO.File.ReadAllText(System.IO.Path.Combine(runSett.CoderunServer, "LDNITE_UNIDUMPS-coderun.txt")))
                                            .Cast<Match>()
                                            .Where(dumpMatch => !dumpMatch.Groups["vpars"].Value.Contains("VPARS_ID"))
                                            .Select(dumpMatch => "DUMP" + dumpMatch.Groups["dump_id"].Value + " " + dumpMatch.Groups["vpars"].Value)
                                            .Distinct()
                                            .ToList()
                                            .ForEach(VMFileName => VM_wnd.ReceiveFile(System.IO.Path.Combine(runSett.CoderunServer, VMFileName.Replace(" ", "_") + ".txt"), VMFileName + " Z1"));
            }
            catch { }


            StageUpdate(currStage, "Successful");

        }
        /// <summary>
        /// Transfers the install script and Load night initialization file (LDNITE INIT A1) to CMS id and also populates the WEInstallData
        /// </summary>
        private void TransferFilesToCMS()
        {
            string currStage = "TRANSFER_FILES";
            //////////////////////////////////////// LDNITE INIT A1 ///////////////////////////////////////////////
            string LDInitFilePath = System.IO.Path.Combine(runSett.CoderunServer, "LDNITE.INIT");

            // Create init file
            IList<string> initFileContents = new List<string>();

            foreach (VIP eachVIP in runSett.VIPS.Where(v => !String.IsNullOrWhiteSpace(v.VPARS)).OrderBy(v => v.VIPNAME))
                initFileContents.Add(eachVIP.VIPNAME + ':' + eachVIP.VPARS);

            initFileContents.Add("BUCKET:" + runSett.Bucket);

            // store init file
            System.IO.File.Delete(LDInitFilePath);
            System.IO.File.WriteAllLines(LDInitFilePath, initFileContents);


            StageUpdate(currStage, "Transfering : " + System.IO.Path.GetFileName(LDInitFilePath));
            // transfer file to CMS as LDNITE INIT A1
            VM_wnd.SendFile(LDInitFilePath, "LDNITE.INIT");
            StageUpdate(currStage, "Transfered : " + System.IO.Path.GetFileName(LDInitFilePath));

            //////////////////////////////////////// Slims install script ////////////////////////////////////////////
            string slimsInstallScriptPath = System.IO.Path.Combine(runSett.CoderunServer, "INSTALL.SCRIPT");
            string slimsSimpleWEListPath = System.IO.Path.Combine(runSett.CoderunServer, "WELIST.xls");

            if (!System.IO.File.Exists(slimsInstallScriptPath))
            {//Download the INSTALL script from SLIMs WEB app, if it doesn't exist
                StageUpdate(currStage, "Slims Install script : " + System.IO.Path.GetFileName(slimsInstallScriptPath), true);

                using (WebClient webclient = new WebClientEx())
                {
                    var Loginpage = webclient.DownloadString("http://pslimsapp.visa.com/slims/login");
                    var Logindata = new NameValueCollection
                        {
                            { "username", App.SliMSID},
                            { "password", App.SliMSPWD },
                            {"_csrf",Loginpage.Substring(Loginpage.IndexOf("_csrf")+ 14, 36)}
                        };
                    //Login
                    var loginresp = webclient.UploadValues("http://pslimsapp.visa.com/slims/login", Logindata);
                    var Data = webclient.DownloadData(@"http://pslimsapp.visa.com/slims/report?type=supervision&format=txt&dates=" + DateTime.ParseExact(runSett.InstallDate, "MM/dd/yyyy", null).ToString("yyyy-MM-dd"));
                    // store the install script
                    System.IO.File.Delete(slimsInstallScriptPath);
                    System.IO.File.WriteAllText(slimsInstallScriptPath, Encoding.Default.GetString(Data).Replace("\r", null).Replace("\n", Environment.NewLine));

                    System.IO.File.Delete(slimsSimpleWEListPath);
                    webclient.DownloadFile(@"http://pslimsapp.visa.com/slims/report?type=simple-we-list&format=xls&dates=" + DateTime.ParseExact(runSett.InstallDate, "MM/dd/yyyy", null).ToString("yyyy-MM-dd"), slimsSimpleWEListPath);
                }
            }
            else
            {
                StageUpdate(currStage, "User provided Install script : " + System.IO.Path.GetFileName(slimsInstallScriptPath), true);
            }

            ///////// APPEND GLOBALS TO INSTALL SCRIPT /////////////////////
            List<string> appendToInstallScript = new List<string>();
            appendToInstallScript.Add("*------------------ GLOBAL LOADS ---------------------");

            Dictionary<string, string> baseGlobals = getGlobals(DateTime.ParseExact(runSett.RegCapture, "MMdd", System.Globalization.CultureInfo.InvariantCulture), BaseInstalldate);
            List<string> globalLoadOrder = new List<string>(new string[] { "NWK", "DCS", "BMX", "CFG", "FXT" });

            List<string> newGlobalsToLoad = baseGlobals
                                                    .Where(glb => !runSett.Globals[glb.Key].Equals(glb.Value, StringComparison.InvariantCultureIgnoreCase))
                                                    .OrderBy(glb => globalLoadOrder.IndexOf(glb.Key))
                                                    .Select(glb => glb.Key + ':' + runSett.Globals[glb.Key])
                                                    .ToList<string>();

            appendToInstallScript.AddRange(newGlobalsToLoad.Select(ln => '*' + ln));                // prepend each line with *
            System.IO.File.AppendAllLines(slimsInstallScriptPath, appendToInstallScript);

            StageUpdate(currStage, "Transfering : " + System.IO.Path.GetFileName(slimsInstallScriptPath));
            // transfer file to CMS as INSTALL SCRIPT A1
            VM_wnd.SendFile(slimsInstallScriptPath, "INSTALL.SCRIPT");
            StageUpdate(currStage, "Transfered : " + System.IO.Path.GetFileName(slimsInstallScriptPath));

            /////////////////// initialize Data ////////////////////
            WEInstallData = new WELogs(slimsInstallScriptPath, slimsSimpleWEListPath);

            // add globals to install list
            newGlobalsToLoad.ForEach(glb => WEInstallData.WEInstallList.Add(new WEData(WEInstallData.WEInstallList.Count, glb, "GLOBAL LOAD")));

            StageUpdate(currStage, "Successful");
        }

        #region Load Night iteration
        /// <summary>
        /// Installs the WE as passed in the WE Name, by running a Rexx exec which executes commands from INSTALL SCRIPT A1
        /// </summary>
        /// <param name="WEName">work effort number as used in slims install script</param>
        /// <returns></returns>
        public bool InstallWE(WEData WEToInstall)
        {
            int waitTime = 17 * 60; // ~ 20 min

            string currStage = "INSTALL_WE : " + WEToInstall.WEInstallOrder + " of " + (WEInstallData.WEInstallList.Count - 1);
            StageUpdate(currStage, WEToInstall.WENumber + " Started");

            try
            {
                VM_wnd.EnterCommand("LDNITE INSTALL " + WEToInstall.WENumber);

                StageUpdate(currStage, WEToInstall.WENumber + " Running");

                //3.	Positive responses: 
                //<WE Name> INSTALL COMPLETED

                //4.	Negative responses: On the top of the screen, it will say:
                //LDNITE:<ERROR:message>:PROCESS ABORTED
                Regex outputRegex = new Regex(@"(?'Completed'\s*(?'WE_Name'((\w+\s*:)?\s*\w+)|\w+)\s+(INSTALL|LOAD)\s+COMPLETED\s*)|(?'Error'\s*LDNITE\s*:\s*(?'Err_Msg'ERROR\s*:\s*[\w\s]+)\s*:\s*PROCESS\s+ABORTED\s*)"
                                            , RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);

                Match outputMatch = VM_wnd.WaitForRegexEx(outputRegex, waitTime);

                if (outputMatch.Groups["Completed"].Success)
                {
                    StageUpdate(currStage, outputMatch.Groups["Completed"].Value.Trim());
                    return true;
                }
                else if (outputMatch.Groups["Error"].Success)
                {// ON Error 
                    bool isErrorOk = ErrorEvent(currStage, outputMatch.Groups["Error"].Value.Trim(), getErrorTypeLDNITE(outputMatch.Groups["Err_Msg"].Value));

                    StageUpdate(currStage, outputMatch.Groups["Error"].Value.Trim());
                    HandleError("LDNITE EXEC error : " + outputMatch.Groups["Error"].Value.Trim(), getErrorTypeLDNITE(outputMatch.Groups["Err_Msg"].Value), ErrorGroup.OTHER_INTERNAL_EXEC_ERROR);//Saumen031417

                    if (!isErrorOk)
                    {
                        //throw new System.InvalidOperationException(currStage + ':' + outputMatch.Groups["Error"].Value.Trim());
                        StageUpdate("LDNITE EXEC failed", "Aborted");//Saumen020817
                        HandleError("Unknown error from LDNITE EXEC : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.OTHER_INTERNAL_EXEC_ERROR);//Saumen031417
                    }
                }//Saumen031417
                else
                {
                    StageUpdate("LDNITE EXEC failed", "Aborted");//Saumen020817
                    //ErrorEvent(currStage, "Unexpected Scenario", ErrorTypes.NotifyandAbort);//Saumen020917
                    HandleError("Unknown error from LDNITE EXEC : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.OTHER_INTERNAL_EXEC_ERROR);//Saumen020817
                    return false;
                }
            }
            catch (RegexMatchTimeoutException)
            {
                //if (runSett.IsSchedulerRun)
                //    throw timeOutEx;

                StageUpdate(currStage, "LDNITE EXEC Timed Out");
                HandleError("LDNITE EXEC Timed out", ErrorTypes.NotifyAndLog, ErrorGroup.NOT_CLASSIFIED_ERROR);//Saumen020817
                // do hx: Saumen020817
                doHX();
                return ErrorEvent(currStage, "Timed Out", ErrorTypes.NotifyAndLog);
            }
            //catch (Exception e)
            //{
            //    ErrorEvent("Exception", e.Message, ErrorTypes.NotifyandAbort);
            //    return false;
            //}

            return false;
        }
        private ErrorTypes getErrorTypeLDNITE(string errMessage)
        {
            //Here are the current error codes I have defined in LDNITE EXEC:

            //    ERROR:010 INVALID LDNITE OPTION          
            //    ERROR:001 INSTALL SCRIPT NOT IN DISK A   
            //    ERROR:002 LDNITE INIT NOT IN DISK A      
            //    ERROR:103 OPTIMIZED CASES DOES NOT EXIST 
            //    ERROR:100 INVALID ITERATION NUMBER       
            //    ERROR:110 DISK Z NOT ACCESSIBLE          
            //    ERROR:200 INVALID INSTALL ARGUMENT       
            //    ERROR:220 WORK EFFORT DOES NOT EXIST       
            //    ERROR:231 VTAPE DOES NOT EXIST           
            //    ERROR:232 CANNOT HANDLE GLOBAL TYPE      

            //    For the next version, these are the changes I will put in:
            //    Change description of 220 from “WORK EFFORT DOES NOT EXIST” to “WE SCRIPT DOES NOT EXIST”.  
            //    Add “ERROR:221 SCRIPT ERROR ENCOUNTERED” to handle the errors we have currently identified during our Load Night test (i.e., “Command:”  and “Error: Switch”). 

            //Regards,
            //Janice

            int errCode = Convert.ToInt32("0" + Regex.Match(errMessage, @"\d+").Value);

            switch (errCode)
            {
                //Saumen031417
                case 200:   //ERROR:200 INVALID INSTALL ARGUMENT
                    return ErrorTypes.NotifyAndLog;
                case 220:   //ERROR:220 WORK EFFORT HAS EMPTY SCRIPT 
                    return ErrorTypes.NotifyAndLog;
                case 231:   //ERROR:231 VTAPE DOES NOT EXIST
                    return ErrorTypes.NotifyAndLog;
                case 232:   //ERROR:232 CANNOT HANDLE GLOBAL TYPE
                    return ErrorTypes.NotifyAndLog;
                //Saumen031417
                default:
                    return ErrorTypes.NotifyandAbort;
            }
        }
        /// <summary>
        /// FTPs CDB, Travel TAG & CardArt Metadata files once the system is up.
        /// </summary>
        /// <returns></returns>
        private void FTPFiles()
        {
            /////////// VIPB ////////////
            VIP vic_B = runSett.VIPS.SingleOrDefault(v => !String.IsNullOrWhiteSpace(v.VPARS) && v.VIPNAME.Contains("VIPB"));

            // FTP files
            runSett.FTPFiles
                .Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .ToList()
                .ForEach(fl =>
                {
                    try
                    {
                        VM_wnd.EnterCommand("FTPVIP " + vic_B.VPARS + ' ' + fl);
                        VM_wnd.WaitForRegexEx(new Regex("Ready"), 40);
                    }
                    catch (RegexMatchTimeoutException)
                    {
                        //ErrorEvent("FTPFILES", "FTPVIP " + vic_B.VPARS + ' ' + fl + "Timed Out", ErrorTypes.NotifyAndLog);//Saumen020917
                        HandleError("FTPFILES Timed out", ErrorTypes.NotifyAndLog, ErrorGroup.NOT_CLASSIFIED_ERROR);//Saumen020817
                        doHX();
                    }
                    catch (Exception)
                    {
                        //ErrorEvent("FTPFILES", e.Message, ErrorTypes.NotifyAndLog);//Saumen020917
                        HandleError("Error in FTP", ErrorTypes.NotifyAndLog, ErrorGroup.FTP_ERROR);//Saumen020817
                    }
                });

            // FTP CDB
            string cdbFile = "CDB" + runSett.RegCapture;
            try
            {
                VM_wnd.EnterCommand("FTPVIP " + vic_B.VPARS + ' ' + cdbFile);
                VM_wnd.WaitForRegexEx(new Regex("Ready"), 40);
            }
            catch (RegexMatchTimeoutException)
            {
                //ErrorEvent("FTPFILES", "FTPVIP " + vic_B.VPARS + ' ' + cdbFile + "Timed Out", ErrorTypes.NotifyAndLog);//Saumen020917
                HandleError("FTPFILES Timed out", ErrorTypes.NotifyAndLog, ErrorGroup.NOT_CLASSIFIED_ERROR);//Saumen020817
                doHX();
            }
            catch (Exception)
            {
                //if (runSett.IsSchedulerRun)//Saumen020817
                //    throw e;//Saumen020817

                //ErrorEvent("FTPFILES", e.Message, ErrorTypes.NotifyAndLog);//Saumen020917
                HandleError("Error in FTP", ErrorTypes.NotifyAndLog, ErrorGroup.FTP_ERROR);//Saumen020817
            }
            // init
            //if (FTPFileList.Count <= 0)
            //{
            //    Regex ZttcpDispRegex = new Regex(@"\s*(?<LOCAL_IP_ADDR>\d{1,3}\.\d{1,3}.\d{1,3}.\d{1,3})\s+(?<MPS>\d{1,4})\s+(?<REST>(N/A)|\w+)\s+(?'TRACE'\w+)\s+(?'TYPE'\w+)\s+(?'ACT'\w+)\s+(?'OSA_NAME'\w+)\s+(?<PRIM_DEFAULT>PRIM\s+DEFAULT)\s*", RegexOptions.IgnoreCase);                                             

            //        /////////// VIPB ////////////
            //        VIP vic_B = runSett.VIPS.SingleOrDefault(v => !String.IsNullOrWhiteSpace(v.VPARS) && v.VIPNAME.Contains("VIPB"));

            //        VM_wnd.EnterCommand("TPFOPR " + vic_B.VPARS + " ZTTCP DISP LOCIPS", 1);
            //        //tpfopr psatput2 zttcp display locips                                                    
            //        //TTCP0021I 11.08.01 LOCAL IP ADDRESS DISPLAY                                             
            //        //  LOCAL IP ADDR   MPS REST TRACE TYPE ACT OSA NAME ALT OSA   ON                         
            //        // --------------- ---- ---- ----- ---- --- -------- -------- ----                        
            //        // 127.000.000.001 3840  N/A  ALL  LOOP YES                                               
            //        //  10.203.228.121 1440  N/A  ALL  OSA  YES OSA1PRIV                                      
            //        //  10.203.223.121 1440  N/A  ALL  VIPA YES OSA1PRIV          PRIM  DEFAULT               
            //        //END OF DISPLAY                                                                          
            //        //Ready; T=0.01/0.01 08:39:47
            //        Match IP_Match = VM_wnd.WaitForRegex(ZttcpDispRegex, 3);
            //    IPAddress VIPB_IP = IPAddress.Parse(IP_Match.Groups["LOCAL_IP_ADDR"].Value.Replace(".0", "."));
            //    FTPFileList.Add(new FTPVIPFile(FTPVIPFile.FileTypes.Travel_TAG, "src Path", VIPB_IP));
            //}

            //FTPFileList.AsParallel().ForAll(file => file.FTPfile());

        }
        /// <summary>
        /// Executes a Rexx exec to run bucket, cut tapes, compare and check dumps by providing an apt iteration number
        /// </summary>
        /// <param name="currWE"></param>
        public bool RunTxnsAndCompare(WEData currWE)
        {
            int waitTime = 35 * 60;

            string currStage = "RunTxnsAndCompare : Run " + currWE.WEInstallOrder + " of " + (WEInstallData.WEInstallList.Count - 1);

            StageUpdate(currStage, "Started");

            try
            {
                VM_wnd.EnterCommand("LDNITE RUN " + currWE.WEInstallOrder);

                //3.	Positive responses: on top of the screen, it will say:
                //    RUN<iteration number> SUCCESSFULLY COMPLETED
                //4.	Negative responses: on top of the screen, it will say:
                //    LDNITE:<ERROR:message>:PROCESS ABORTED
                StageUpdate(currStage, "Running");

                Regex outputRegex = new Regex(@"(?'Completed'\s*RUN\s*(?'iteration'\d+)\s+SUCCESSFULLY\s+COMPLETED\s*)|(?'Error'\s*LDNITE\s*:\s*(?'Err_Msg'ERROR\s*:\s*[\w\s]+)\s*:\s*PROCESS\s+ABORTED\s*)"
                                                , RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);

                Match outputMatch = VM_wnd.WaitForRegexEx(outputRegex, waitTime);

                if (outputMatch.Groups["Completed"].Success)
                {
                    StageUpdate(currStage, outputMatch.Groups["Completed"].Value.Trim());
                    return true;
                }
                else if (outputMatch.Groups["Error"].Success)
                {// ON Error 
                    bool isErrorOk = ErrorEvent(currStage, outputMatch.Groups["Error"].Value.Trim(), getErrorTypeLDNITE(outputMatch.Groups["Err_Msg"].Value));

                    StageUpdate(currStage, outputMatch.Groups["Error"].Value.Trim());
                    HandleError("LDNITE EXEC error : " + outputMatch.Groups["Error"].Value.Trim(), getErrorTypeLDNITE(outputMatch.Groups["Err_Msg"].Value), ErrorGroup.OTHER_INTERNAL_EXEC_ERROR);//Saumen031417

                    if (!isErrorOk)
                    {
                        //throw new System.InvalidOperationException(currStage + ':' + outputMatch.Groups["Error"].Value.Trim());//Saumen020817
                        StageUpdate("LDNITE EXEC failed", "Aborted");//Saumen020817
                        HandleError("Unknown error from LDNITE EXEC : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.OTHER_INTERNAL_EXEC_ERROR);//Saumen031417
                    }
                }
                else
                {
                    StageUpdate("LDNITE EXEC failed", "Aborted");//Saumen020817
                    //ErrorEvent(currStage, "Unexpected Scenario", ErrorTypes.NotifyandAbort);//Saumen020917
                    HandleError("Unknown error from LDNITE EXEC : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.OTHER_INTERNAL_EXEC_ERROR);//Saumen020817
                    return false;
                }
            }
            catch (RegexMatchTimeoutException)
            {
                //if (runSett.IsSchedulerRun)//Saumen020817
                //    throw regEx;//Saumen020817

                StageUpdate(currStage, "LDNITE EXEC Timed Out");
                HandleError("LDNITE EXEC Timed out", ErrorTypes.NotifyAndLog, ErrorGroup.NOT_CLASSIFIED_ERROR);//Saumen020817
                doHX();//Saumen020817
                return ErrorEvent(currStage, "LDNITE EXEC Timed Out", ErrorTypes.NotifyAndLog);
            }
            //catch (Exception e)
            //{
            //    ErrorEvent(currStage + "_Exception", e.Message, ErrorTypes.NotifyandAbort);
            //    return false;
            //}
            finally
            {
                VM_wnd.EnterCommand("PIPE LITERAL RUN" + currWE.WEInstallOrder + " |>> LDNITE UNIDUMPS A1");
                VM_wnd.EnterCommand("ERASE UNIDUMPS TXT A1");
                ///////////// CHECK DUMPS using UNIDUMPS//////////////////
                UNIDUMPS(String.Join(" ", runSett.VIPS
                                                    .Where(vic => !String.IsNullOrWhiteSpace(vic.VPARS))
                                                    .Select(vic => vic.VPARS).ToList())
                        );
                VM_wnd.EnterCommand("PIPE < UNIDUMPS TXT A1 |>> LDNITE UNIDUMPS A1");

                VM_wnd.EnterCommand("DUMPDISP", 5);
                VM_wnd.WaitforString("Ready", 30);
            }

            return false;
        }
        #endregion

        #region other functions
        /// <summary>
        /// Submits a TPFSETUP file and tracks the progress of the submitted job
        /// </summary>
        /// <param name="sett">RunSettings object</param>
        /// <param name="forcefully_Logoff">on true forecefully logs off the VPARS in the setup file</param>
        /// <param name="jobSchedulingAttempts">number of times to check for job id in tpf jobs screen</param>
        /// <param name="jobCompletionTime">minutes to wait for IPLing to complete</param>
        /// <returns>true on success else false on failure</returns>
        private bool SubmitAndTrackSetup(RunSettings sett, bool forcefully_Logoff = false, int jobSchedulingAttempts = 15, int jobCompletionTime = 2 * 60 * 60)
        {

            string regexForDateTime = @"[0-1][0-9][./][0-3][0-9][./][0-9]{2}\s[0-2][0-9]\:[0-5][0-9]\:[0-5][0-9]";

            string regexForJobId = @"JOB[0-9]+";

            string regexForVMId = @"\w{3,9}";

            StageUpdate("Submit Setup (alt):" + sett.SetupFile.ToUpper() + " $TTVDATA", "Running...", true);

            Regex logonByRegex = new Regex(@"\s*(?<AutoregId>\b\w+\b)(\s+BY\s+)?(?<LoginId>\b\w+\b)?\s*", RegexOptions.IgnoreCase);
            sett.VMID = logonByRegex.Match(sett.VMID).Groups["AutoregId"].Value;
            //VM_wnd.EnterCommand("CP SET MSG OFF", 1);//Saumen031517
            //////////////////////////// Try Submitting the setup //////////////////////////////
            List<string> screen = new List<string>();
            bool Retry = false;
            DateTime ScheduledJobDateTime = new DateTime();
            do
            {
                /////////////////////////////////////// SET VTOD DATE ////////////////////////////////////
                VM_wnd.EnterCommand("SET VTOD DATE " + sett.SystemDate + " TIME 10:52:00");
                VM_wnd.EnterCommand("I CMS");
                VM_wnd.SendText(Keys3270.Enter);
                VM_wnd.WaitforString("Ready;", 2);
                //VM_wnd.EnterCommand("GET TESTCASE");
                //GGIRDHAR030717 - Test Framework Enhancement
                if (InputFile.TestRun)
                {
                    VM_wnd.EnterCommand("GET VIPTETST", 1);//GGIRDHAR030717
                }
                //GGIRDHAR030717 - Test Framework Enhancement
                VM_wnd.EnterCommand("GET VIPQAAUT");//Saumen021417
                VM_wnd.EnterCommand("ERASE TESTKEYS CONTROL A1");
                //////////////////////// Submit setup ////////////////////////
                VM_wnd.WaitforString("Ready", 2);
                //Saumen032817
                VM_wnd.EnterCommand("TPFSETUP " + sett.SetupFile + " $TTVDATA A1 ( SUBMIT", 2);
                int loopcount = 0;
                while (VM_wnd.WaitforString("Ready", 10 * 60) == 0)//Saumen032917
                {
                    loopcount++;
                    VM_wnd.EnterCommand("B", 2);
                    if (loopcount >= 300)
                    {
                        HandleError("Job file NOT submitted properly", ErrorTypes.NotifyandAbort, ErrorGroup.TPFSETUP_ERROR);//Saumen031517
                    }
                }
                loopcount = 0;
                //VM_wnd.WaitforString("Ready", 60);
                ////// Now check the screen /////
                //screen.Clear();
                //do
                //{
                //    VM_wnd.Pause(1);
                screen.AddRange(VM_wnd.GetLines(99));//Saumen032917
                //    VM_wnd.SendText(Keys3270.Clear);
                //} while (!screen.Any(ln => ln.Contains("Ready")));
                //Saumen032817

                screen.RemoveAll(ln => ln.Contains("* MSG FROM") || ln.Contains("RDR FILE"));          // remove improper lines

                // Job file submitted                                                   
                // OR PRODD18 PRODD48 PRODD51 Not logged off
                string lineOfInterest = screen[(screen.LastIndexOf(screen.Last(ln => !String.IsNullOrWhiteSpace(ln) && ln.Contains("Ready"))/*index of the last line with Ready*/ ) - 1)];

                if (lineOfInterest.Contains("Job file submitted"))
                {
                    StageUpdate("Submit Setup (alt):" + sett.SetupFile.ToUpper() + " $TTVDATA", lineOfInterest, false);

                    /*File TTECH VPARSREQ A1 sent to TTECHTSM at RSVM3 on 03/24/16 10:47:22*/
                    string lineOfJob = screen[(screen.LastIndexOf(screen.Last(ln => !String.IsNullOrWhiteSpace(ln) && ln.Contains("Ready"))/*index of the last line with Ready*/ ) - 2)];

                    Regex regexForJobLine = new Regex("\bFile\b[w ]+\bsent\bto\b[wd ]+\bon\b" + regexForDateTime, RegexOptions.IgnoreCase);

                    //string lineOfJob = screen.SingleOrDefault(ln => regexForJobLine.IsMatch(ln));

                    if (lineOfJob != null && Regex.Match(lineOfJob, regexForDateTime).Success)
                    {
                        ScheduledJobDateTime = DateTime.ParseExact(Regex.Match(lineOfJob, regexForDateTime).Value, @"MM/dd/yy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                        Retry = false;
                    }
                    else
                        Retry = true;
                }
                else if (lineOfInterest.Contains("Not logged off") && forcefully_Logoff)
                {
                    // log off vpars
                    StageUpdate("Submit Setup (alt):" + sett.SetupFile.ToUpper() + " $TTVDATA", "Logging of " + lineOfInterest.Replace("Not logged off", ""), false);

                    foreach (string vpars in lineOfInterest.Replace("Not logged off", "").Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        //Saumen031017
                        VM_wnd.EnterCommand("TPFOPR " + vpars + " ZCYCL 1052", 2);
                        VM_wnd.EnterCommand("TPFOPR " + vpars + " ZDSYS", 2);
                        int max_try = 0;
                        while (VM_wnd.WaitforString("IN 1052", 60) == 0 && max_try <= 5)
                        {
                            VM_wnd.EnterCommand("TPFOPR " + vpars + " ZDSYS", 2);
                            max_try++;
                        }
                        //Saumen031017
                        VM_wnd.EnterCommand("TPFOPR " + vpars + " ZCP LOG", 1);
                        VM_wnd.WaitforString("not open (no longer open)", 60);
                        VM_wnd.WaitforString("Ready", 60);
                    }
                    Retry = true;
                }
                else
                {
                    StageUpdate("TPFSETUP failed", "Aborted");//Saumen020817
                    HandleError("TPFSETUP failed", ErrorTypes.NotifyandAbort, ErrorGroup.TPFSETUP_ERROR);//Saumen020817
                    //Retry = ErrorEvent(lineOfInterest.Trim(), "\nYou can fix it and retry by pressing yes", ErrorTypes.NotifyandWait);
                    //if (Retry == false)
                    //    throw new System.InvalidOperationException("Submit Setup (alt):" + sett.SetupFile.ToUpper() + " $TTVDATA :" + lineOfInterest);
                    Retry = false;
                    //Saumen020817
                }

            } while (Retry);

            ///////////////////////////////////////// Get JOB ID ///////////////////////////////////////////////////
            string job_id = null; // to find
            //VM_wnd.EnterCommand("TPFJOBS", 1);
            //VM_wnd.WaitforString("TPFJOBS: Jobs scheduled on", 20);
            //// try with an interval of 60 seconds
            for (int i = 0; i < jobSchedulingAttempts && String.IsNullOrWhiteSpace(job_id); i++)
            {
                screen.Clear();

                //////////////////// Method 1 ////////////////////
                //Saumen032817
                VM_wnd.EnterCommand("pipe CMS TPFJOBS ( TYPE | LOCATE /" + sett.VMID + "/ | CONSOLE ", 2);
                int loopcount = 0;
                while (VM_wnd.WaitforString("Ready", 10 * 60) == 0)//Saumen032917
                {
                    loopcount++;
                    VM_wnd.EnterCommand("pipe CMS TPFJOBS ( TYPE | LOCATE /" + sett.VMID + "/ | CONSOLE ", 2);
                    if (loopcount >= 300)
                    {
                        HandleError("Unable to get JOb id from TPFJOBS", ErrorTypes.NotifyandAbort, ErrorGroup.TPFSETUP_ERROR);//Saumen031517
                    }
                }
                loopcount = 0;
                //do
                //{
                //    VM_wnd.Pause(1);
                screen.AddRange(VM_wnd.GetLines(99));//Saumen032917
                //    VM_wnd.SendText(Keys3270.Clear);
                //}
                //while (!screen.Any(ln => !String.IsNullOrWhiteSpace(ln) && ln.Contains("Ready")));
                //Saumen032817
                //////////////////////////////////////////////////

                ////////////////////// Method 2 ////////////////////
                //VM_wnd.SendText(Keys3270.Enter);
                //VM_wnd.WaitforString("TPFJOBS: Jobs scheduled on", 20);
                //screen.AddRange(VM_wnd.GetLines(99));
                ////////////////////////////////////////////////////

                string regexForJobLine = "\\s*" + regexForDateTime + "\\s" + regexForJobId + "\\s" + regexForVMId + "\\s";

                string jobLine = screen.Where(ln => Regex.Match(ln, regexForJobLine, RegexOptions.IgnoreCase).Success)
                                           .Select(ln => Regex.Match(ln, regexForJobLine, RegexOptions.IgnoreCase).Value)
                                           .SingleOrDefault(jobInfo => jobInfo.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[3].Equals(sett.VMID, StringComparison.InvariantCultureIgnoreCase)           // SAME vm ID
                                                             && DateTime.ParseExact(Regex.Match(jobInfo, regexForDateTime, RegexOptions.IgnoreCase).Value.Replace('.', '/'), @"MM/dd/yy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) >= ScheduledJobDateTime);    // job after the scheduled datetime

                job_id = jobLine != null ? Regex.Match(jobLine, regexForJobId, RegexOptions.IgnoreCase).Value : null;

                /// Take approx Date time in case of failure
                if (String.IsNullOrWhiteSpace(job_id) && i > 3)
                {
                    string approxJobLine = screen
                                                .Where(ln => Regex.Match(ln, regexForJobLine, RegexOptions.IgnoreCase).Success)
                                                .Select(ln => Regex.Match(ln, regexForJobLine, RegexOptions.IgnoreCase).Value)
                                                .OrderByDescending(jobInfo => DateTime.ParseExact(Regex.Match(jobInfo, regexForDateTime, RegexOptions.IgnoreCase).Value.Replace('.', '/'), @"MM/dd/yy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture))
                                                .FirstOrDefault(jobInfo => jobInfo.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[3].Equals(sett.VMID, StringComparison.InvariantCultureIgnoreCase)           // SAME vm ID
                                                                 && (DateTime.ParseExact(Regex.Match(jobInfo, regexForDateTime, RegexOptions.IgnoreCase).Value.Replace('.', '/'), @"MM/dd/yy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) - ScheduledJobDateTime).TotalSeconds <= 5.0d);

                    job_id = approxJobLine != null ? Regex.Match(approxJobLine, regexForJobId, RegexOptions.IgnoreCase).Value : null;
                }

                VM_wnd.Pause(60);
            }

            // Everything to get the job id has failed here
            if (String.IsNullOrWhiteSpace(job_id))
            {
                //throw new System.InvalidOperationException("TPFJOBS:Unable to get JOb id from TPFJOBS");
                StageUpdate("Get JOb id from TPFJOBS failed", "Aborted");//Saumen020817
                HandleError("Get JOb id from TPFJOBS failed : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.TPFSETUP_ERROR);//Saumen020817
            }
            //////////////////////// keep querying the job id //////////////////////
            IDictionary<string, string> tpfJobsData = new Dictionary<string, string>();
            for (int i = 0; i < jobCompletionTime / 60; i++)
            {
                screen.Clear();
                VM_wnd.EnterCommand("TPFJOBS * " + job_id + " " + sett.VMID + " ( JOBSTAT");
                VM_wnd.WaitforString("Ready", 5);
                screen.AddRange(VM_wnd.GetLines(99));

                screen.RemoveAll(ln => ln.Contains("* MSG FROM") || ln.Contains("RDR FILE") || ln.Contains("Ready") || ln.Contains("TPFJOBS"));          // remove improper lines

                tpfJobsData.Clear();
                tpfJobsData = screen.Where(ln => !String.IsNullOrWhiteSpace(ln) && ln.Split(':').Length > 1)
                                                                 .ToDictionary(
                                                                 ln => ln.Split(new char[] { ':' }, 2, StringSplitOptions.RemoveEmptyEntries)[0].Trim().ToUpper(),
                                                                 ln => ln.Split(new char[] { ':' }, 2, StringSplitOptions.RemoveEmptyEntries)[1].Trim());

                if (tpfJobsData.ContainsKey("STATUS"))
                    StageUpdate("TPFJOBS", tpfJobsData["STATUS"], false);


                if (tpfJobsData.ContainsKey("STATUS") && tpfJobsData["STATUS"].Contains("Job ended rc"))
                    break;

                VM_wnd.Pause(60);              //  A normal wait time
            }

            if (tpfJobsData.ContainsKey("STATUS") && (tpfJobsData["STATUS"].Contains("*") || tpfJobsData["STATUS"].Contains("-")))
            {
                StageUpdate("TPFJOBS", tpfJobsData["STATUS"], false);

                bool isOk = ErrorEvent("TPFJOBS STATUS :", tpfJobsData["STATUS"], ErrorTypes.NotifyAndLog);
                HandleError("TPFJOB completed with error", ErrorTypes.NotifyAndLog, ErrorGroup.TPFSETUP_ERROR);//Saumen020817
                if (!isOk)
                {
                    //throw new System.InvalidOperationException("TPFJOBS STATUS :" + tpfJobsData["STATUS"]);
                    StageUpdate("TPFJOBS failed", "Aborted");//Saumen020817
                    HandleError("Unknown error in TPFJOBS", ErrorTypes.NotifyandAbort, ErrorGroup.TPFSETUP_ERROR);//Saumen020817
                }
            }

            VM_wnd.WaitforString("Ready;", 10);
            VM_wnd.EnterCommand("SET VTOD SYSTEM");
            VM_wnd.EnterCommand("I CMS");
            VM_wnd.SendText(Keys3270.Clear);

            StageUpdate("TPFJOBS", "Successful.", false);

            return true;
        }
        /// <summary>
        /// Logs in by using the specified string in VMid and also updates the login string aptly
        /// </summary>
        /// <param name="VMId">Logon String</param>
        /// <param name="password">Password</param>
        /// <returns>true on Success and false on failure</returns>
        private bool Login(ref string VMId, string password)
        {
            VM_wnd.WaitforString("USERID   ===>", 30);
            VM_wnd.EnterCommand(Keys3270.Clear, 2);
            VM_wnd.EnterCommand("LOGON " + VMId, 3);
            Match preLoginMatch = VM_wnd.WaitForRegex(new Regex(@"(?<LoginSuccess>Ready)|(?<Reconnected>RECONNECTED\s+AT)|(?<IncorrectPassword>\bLOGON\s+unsuccessful--incorrect\s+password\b)"), 1, false);
            VM_wnd.EnterCommand(password, 1, false, true); // do not save password
            Match loginMatch = VM_wnd.WaitForRegex(new Regex(@"(?<LoginSuccess>(\bReady\b)|(\bLOGON\s+AT\s+\b))|(?<Reconnected>\bRECONNECTED\s+AT\b)|(?<IncorrectPassword>\bLOGON\s+unsuccessful--incorrect\s+password\b)"), 5);


            Regex logonByRegex = new Regex(@"\s*(?<AutoregId>\b\w+\b)(\s+BY\s+)?(?<LoginId>\b\w+\b)?\s*", RegexOptions.IgnoreCase);

            if (loginMatch.Success && !preLoginMatch.Success)
            {
                if (loginMatch.Groups["LoginSuccess"].Success)
                {
                    ////////////// Login Success ///////////////
                    VM_wnd.EnterCommand("ID", 1);

                    VMId = logonByRegex.Match(VMId).Groups["AutoregId"].Value;
                    return true;
                }
                else if (loginMatch.Groups["Reconnected"].Success)
                {
                    /////////////// RECONNECTED AT //////////////////
                    VM_wnd.SendText(Keys3270.PA1);
                    VM_wnd.SendText("I CMS" + Keys3270.Enter);
                    VM_wnd.Pause(3);
                    VM_wnd.SendText(Keys3270.Enter);
                    VM_wnd.WaitforString("Ready;", 10);

                    VMId = logonByRegex.Match(VMId).Groups["AutoregId"].Value;
                    return true;
                }
                else if (loginMatch.Groups["IncorrectPassword"].Success)
                {
                    ///////////// Incorrect Password //////////////
                    return false;
                }
            }
            return false;
        }
        /// <summary>
        /// Reipl and get testcase
        /// </summary>
        private void GetTempDisks()
        {
            VM_wnd.EnterCommand("REIPL 96M");
            VM_wnd.WaitforString("Ready;", 60);
            //VM_wnd.EnterCommand("GET TESTCASE");  //added Rakesh. Will be Removed
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                VM_wnd.EnterCommand("GET VIPTETST", 1);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            VM_wnd.EnterCommand("GET VIPQAAUT");//Saumen021417
            //VM_wnd.EnterCommand("GET TESTCASE");
            //if (runSett.RegType == "ECIP" || runSett.RegType == "UNBALANCED" || runSett.RegType == "TOKEN")
            //    VM_wnd.EnterCommand("GETD TEMP 1080CYL Z", 2);
            //else
            //VM_wnd.EnterCommand("GETD TEMP 540CYL Z", 2);
            VM_wnd.EnterCommand("GETD TEMP 1080CYL Z", 2);//Saumen022717
            VM_wnd.WaitforString("Ready;", 3);
            VM_wnd.EnterCommand("VMLINK TDATA 291", 2);
            VM_wnd.EnterCommand("VMLINK TDATA 292", 2);
        }
        /// <summary>
        /// Returns Globals for the specified capture and load date
        /// </summary>
        /// <param name="captureDate"></param>
        /// <param name="loaddate"></param>
        /// <returns></returns>
        public Dictionary<string, string> getGlobals(DateTime captureDate, DateTime loaddate)
        {
            Dictionary<string, string> Globals = new Dictionary<string, string>();

            Excel.Application xlapp = null; Excel.Workbook xlworkbook; Excel.Worksheet xlsheet;
            try
            {
                StageUpdate(null, "Globals for Capture : " + captureDate.ToString(@"MM/dd/yyyy") + " Install : " + loaddate.ToString(@"MM/dd/yyyy"));


                xlapp = new Excel.Application();
                xlapp.DisplayAlerts = false;
                xlworkbook = xlapp.Workbooks.Open(CommonClass.GetQAGlobalFromSharepoint(), Type.Missing, true, true);
                xlsheet = xlworkbook.Worksheets[1]; ///Check the first Sheet
                int row = 1;
                int loaddatecol = 0;
                //DateTime loaddate = DateTime.ParseExact(Runsettings.InstallDate, "MM/dd/yyyy", null);
                string capturedate = captureDate.ToString("MM/dd");
                while (row < 35 && !((xlsheet.Cells[row, 1] as Excel.Range).Text as string).Contains(capturedate))
                    row++;
                if (row != 35)
                {
                    for (int i = row + 1; i < row + 10; i++)
                    {
                        if (loaddatecol == 0)
                        {
                            for (int col = 1; col < 20; col++)
                            {
                                string celltext = ((xlsheet.Cells[i, col] as Excel.Range).Text as string).ToUpper().Trim();
                                if (celltext == "" || celltext == null || celltext.Contains("DATA"))
                                    continue;
                                else if (celltext.Contains("BASELINE"))
                                {
                                    loaddatecol = col;
                                    continue;
                                }
                                else
                                {

                                    int mnthdiff = loaddate.Month - Convert.ToInt16(celltext.Split('/')[0]);
                                    int yr = loaddate.Year;
                                    if (mnthdiff <= -6)
                                        yr = yr - 1;

                                    if ((DateTime.ParseExact(celltext + "/" + yr, "MM/dd/yyyy", null) <= loaddate))
                                    {
                                        loaddatecol = col;
                                    }
                                    else
                                        break;
                                }
                            }
                        }
                        if (loaddatecol == 0)
                            continue;
                        else
                        {
                            string celltext = ((xlsheet.Cells[i, 1] as Excel.Range).Text as string).ToUpper().Trim();
                            if (celltext.Contains("FILES") || celltext.Contains("CONFIG"))
                                break;
                            else if (celltext.Contains("GLOBALS") || celltext == "")
                                continue;
                            for (int col = loaddatecol; col >= 2; col--)
                            {
                                string celltext2 = ((xlsheet.Cells[i, col] as Excel.Range).Text as string).ToUpper().Trim();
                                if (celltext2 != "")
                                {
                                    switch (celltext)
                                    {
                                        case "DCS":
                                            Globals["DCS"] = celltext2;
                                            break;
                                        case "BMX":

                                            Globals["BMX"] = celltext2;
                                            break;
                                        case "NWK":

                                            Globals["NWK"] = celltext2;

                                            break;
                                        case "CFG":

                                            Globals["CFG"] = celltext2;

                                            break;
                                        case "FXT":
                                            Globals["FXT"] = celltext2;
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    //StageUpdate("Gettings globals from server", "Successful.");

                }
                else
                    //throw new IndexOutOfRangeException();
                    HandleError("Population of globals failed", ErrorTypes.NotifyAndLog, ErrorGroup.NOT_CLASSIFIED_ERROR);//Saumen020817

            }
            catch (Exception)
            {
                //release all memory - stop EXCEL.exe from hanging around.
                StageUpdate(null, "Capture : " + captureDate.ToString(@"MM/dd/yyyy") + ", Install : " + loaddate.ToString(@"MM/dd/yyyy") + " Failed : Aborted");
                // throw;
            }
            finally
            {


                xlsheet = null;
                xlworkbook = null;
                if (xlapp != null)
                {
                    xlapp.Quit();
                    xlapp = null;
                }
            }



            return Globals;
        }

        string HSM_PRODD77 = null;                                                                                  //Saumen090116

        /// <summary>
        /// Attaches an HSM an turns off the Simulator
        /// </summary>
        /// <param name="VPARS">VPARS to attach HSM to</param>
        /// <param name="hsmunit">HSM series</param>
        /// <returns></returns>
        private bool AttachHSM(string VPARS, string hsmunit)
        {
            if (hsmunit == "NA")
                return true;
            bool Result = false;
            ReserveHSM("1", "DETACH");                                                                              //Saumen082916
            HSM_PRODD77 = "DETACHED";                                                                               //Saumen090116
            VM_wnd.EnterCommand("SENDCMD " + VPARS + " ZCP Q " + hsmunit, 1);
            var freehsmlines = VM_wnd.GetLines(50).Where(l => l.Contains("FREE"));
            if (freehsmlines.Count() != 0)
            {
                string hsmtoattach = freehsmlines.First();
                hsmtoattach = hsmtoattach.Substring(hsmtoattach.IndexOf("FREE") - 5, 4).Substring(1);//TAPE 094C FREE    , TAPE 094D FREE 
                VM_wnd.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZCP ATT " + hsmtoattach + " * |>> PRODREGG SUMMARY A1", 1);
                VM_wnd.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZUVSM ON " + hsmtoattach + " |>> PRODREGG SUMMARY A1", 1);
                VM_wnd.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZQCSM STOP |>> PRODREGG SUMMARY A1", 1);
                if (VM_wnd.WaitforString("Ready;", 5) > 0)
                    Result = true;
            }
            else
            {
                VM_wnd.EnterCommand("PIPE LITERAL Preferred HSM series not Free |>> PRODREGG SUMMARY A1", 1);
                foreach (var item in App.HSMUNITS.Where(h => h != "NA" && h != hsmunit))
                {
                    VM_wnd.EnterCommand("SENDCMD " + VPARS + " ZCP Q " + item, 1);
                    freehsmlines = VM_wnd.GetLines(50).Where(l => l.Contains("FREE"));
                    if (freehsmlines.Count() != 0)
                    {
                        string hsmtoattach = freehsmlines.First();
                        hsmtoattach = hsmtoattach.Substring(hsmtoattach.IndexOf("FREE") - 5, 4).Substring(1);//TAPE 094C FREE    , TAPE 094D FREE 
                        VM_wnd.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZCP ATT " + hsmtoattach + " * |>> PRODREGG SUMMARY A1", 1);
                        VM_wnd.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZUVSM ON " + hsmtoattach + " |>> PRODREGG SUMMARY A1", 1);
                        VM_wnd.EnterCommand("PIPE CMS SENDCMD " + VPARS + " ZQCSM STOP |>> PRODREGG SUMMARY A1", 1);
                        if (VM_wnd.WaitforString("Ready;", 5) > 0)
                        {
                            Result = true;
                            break;
                        }
                    }
                    Result = false;
                    VM_wnd.EnterCommand("PIPE LITERAL No Free HSM found |>> PRODREGG SUMMARY A1", 1);
                }

            }
            VM_wnd.EnterCommand("PIPE CMS TPFOPR " + VPARS + " ZUVSM SETQ 99 |>> PRODREGG SUMMARY A1", 1);
            return Result;
        }
        /// <summary>
        /// gets VPARS details from the setup file
        /// </summary>
        /// <returns></returns>
        private bool GetVPARSNames()
        {
            string currStage = "GET_VPARS";
            //Here Parse the Vpars names from the setup file itself.. we'll remove VPARS UI Later
            StageUpdate(currStage, "From : " + runSett.SetupFile + "  $TTVDATA");

            runSett.VIPS = new List<VIP>();
            foreach (var vicid in App.ALLVIPS)
            {
                VIP tempvip = new VIP() { VIPNAME = "VIP" + vicid };
                runSett.VIPS.Add(tempvip);
            }

            VM_wnd.EnterCommand("PIPE < " + runSett.SetupFile + " $TTVDATA A1 | XLATE UPPER | LOCATE /.USERIDS/ | NLOCATE /*H./ | CONSOLE ", 5);
            List<string> userids = new List<string>();
            userids = VM_wnd.GetLines(10).Where(l => l.Contains(".USERIDS ") && !l.Contains("PIPE"))
                .Select(l => "VIP" + l.Substring(l.IndexOf(".USERID") - 1).Replace(".USERIDS", "")).ToList();

            foreach (VIP vip in runSett.VIPS)
            {
                string vparsfromsetup = userids.FirstOrDefault(u => u.Contains(vip.VIPNAME));
                if (vparsfromsetup != null)
                {
                    vip.VPARS = vparsfromsetup.Substring(4).ToUpper().Trim();
                }
                else
                    vip.VPARS = String.Empty;
            }

            if (userids.Count() == 0)
            {
                //ErrorEvent("Please check the setup file", "No VPARS found from it", ErrorTypes.NotifyandAbort);//Saumen020917
                StageUpdate(currStage, "No VPARS found in setup file : Aborted");
                //ErrorEvent(currStage, "No VPARS found from " + runSett.SetupFile + " $TTVDATA", ErrorTypes.NotifyandAbort);//Saumen020917
                HandleError("No VPARS found from " + runSett.SetupFile + " $TTVDATA : Aborted", ErrorTypes.NotifyandAbort, ErrorGroup.SETUP_CREATION_ERROR);//Saumen020817
                return false;
            }

            StageUpdate(currStage, "Successful");
            return true;
        }
        /// <summary>
        /// Updates the using file, for autoregs
        /// </summary>
        private void UpdateUsingFile()
        {
            //VM_wnd.EnterCommand("GET TESTCASE", 1);
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                VM_wnd.EnterCommand("GET VIPTETST", 1);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            VM_wnd.EnterCommand("GET VIPQAAUT", 1);//Saumen021417
            VM_wnd.EnterCommand("USING AUTOREG", 1);
            //Ready; T=0.04/0.05 11:54:45
            VM_wnd.WaitForRegex(new Regex("Ready"), 20);

            string tmpFilePath = System.IO.Path.GetTempFileName();
            VM_wnd.ReceiveFile(tmpFilePath, "USAGE TEXT A1");

            Using UsingObj = new Using(tmpFilePath);
            UsingObj.StoreAsJSON();

            System.IO.File.Delete(tmpFilePath);
        }
        /// <summary>
        /// checks for unique dumps on all vparses and then stores them in UNIDUMPS TXT A1
        /// </summary>
        /// <param name="Vparses">space separated string of vparse to check dumps in</param>
        private void UNIDUMPS(string Vparses)
        {
            try
            {
                VM_wnd.EnterCommand("UNIDUMP " + Vparses);
                Match unidumps_out = VM_wnd.WaitForRegexEx(new Regex(@"(?'completed'Ready;)|(?'error'Ready\()", RegexOptions.IgnoreCase), 20 * 60);

                if (unidumps_out.Groups["completed"].Success)
                    return;
                else if (unidumps_out.Groups["error"].Success)
                {
                    //ErrorEvent("UNIDUMPS " + Vparses, ": Execution failed", ErrorTypes.NotifyAndLog);//Saumen020917
                    HandleError("UNIDUMPS Execution failed", ErrorTypes.NotifyAndLog, ErrorGroup.UNIDUMPS_ERROR);//Saumen020817
                    return;
                }
            }
            catch (RegexMatchTimeoutException)
            {
                doHX();
                //ErrorEvent("UNIDUMPS " + Vparses, ": Execution timeout, did HX", ErrorTypes.NotifyAndLog);//Saumen020917
                HandleError("UNIDUMPS Execution timed out", ErrorTypes.NotifyAndLog, ErrorGroup.UNIDUMPS_ERROR);//Saumen020817
                return;
            }
            catch (Exception)
            {
                //ErrorEvent("UNIDUMPS " + Vparses, ": EXEC timeout, and HX failure", ErrorTypes.NotifyAndLog);//Saumen020917
                HandleError("UNIDUMPS Execution failed", ErrorTypes.NotifyAndLog, ErrorGroup.UNIDUMPS_ERROR);//Saumen020817
            }
        }
        /// <summary>
        /// halts the execution of any exec and ensures that the VM_wnd is at Ready screen\, throws an Exception
        /// </summary>
        private void doHX()
        {
            //Saumen020817
            VM_wnd.EnterCommand("HX", 2);
            //VM_wnd.WaitForRegexEx(new Regex(@"CMS|Ready"), 5);
            VM_wnd.EnterCommand("B", 2);
            VM_wnd.WaitForRegexEx(new Regex(@"Ready;"), 60);
            //Saumen020817
        }
        #endregion

        #region fire events
        /// <summary>
        /// Fires the error event
        /// </summary>
        /// <param name="errorTag"></param>
        /// <param name="errorDesc"></param>
        private bool ErrorEvent(string errorTag, string errorDesc, ErrorTypes errType)
        {
            bool result = true;
            if (OnError != null)
                result &= OnError(errorTag, errorDesc, errType);

            return result;
        }
        /// <summary>
        /// Fires the Stage event
        /// </summary>
        /// <param name="errorTag"></param>
        /// <param name="stageDesc"></param>
        private void StageUpdate(string stage, string stageDesc)
        {
            stage = string.IsNullOrWhiteSpace(stage) ? String.Empty : stage;

            StageUpdate(stage, stageDesc, !lastStage.Equals(stage, StringComparison.InvariantCultureIgnoreCase));
            lastStage = stage;
        }

        private void Completed()
        {
            if (OnCompletion != null)
                OnCompletion(this, EventArgs.Empty);
        }

        private void StageUpdate(string stage, string stageDesc, bool addNew)
        {
            stage = (string.IsNullOrWhiteSpace(stage) ? lastStage : stage);

            if (OnStageUpdate != null)
                OnStageUpdate(stage, stageDesc, addNew);

            lastStage = stage;
        }

        #endregion

        //Saumen082916
        private void ReserveHSM(string noofhsm, string option)
        {
            //VM_wnd.EnterCommand("GET TESTCASE", 2);                                                                 //Saumen090816
            //GGIRDHAR030717 - Test Framework Enhancement
            if (InputFile.TestRun)
            {
                VM_wnd.EnterCommand("GET VIPTETST", 1);//GGIRDHAR030717
            }
            //GGIRDHAR030717 - Test Framework Enhancement
            VM_wnd.EnterCommand("GET VIPQAAUT", 2);//Saumen021417
            VM_wnd.EnterCommand("RESHSM " + noofhsm + " " + option, 2);
            if (VM_wnd.WaitforString("Processing completed successfully", 5) == 0)
            {
                if (VM_wnd.WaitforString("PRODD77 is LOGGED OFF", 5) != 0)
                {
                    VM_wnd.EnterCommand("PIPE LITERAL PRODD77 is LOGGED OFF |>> PRODREGG SUMMARY A1", 2);
                }
                else
                {
                    VM_wnd.EnterCommand("PIPE LITERAL HSM could not be " + option + "ED to/from PRODD77 |>> PRODREGG SUMMARY A1", 2);
                }
            }
            else
            {
                VM_wnd.EnterCommand("PIPE LITERAL " + noofhsm + " HSM successfully " + option + "ED to/from PRODD77 |>> PRODREGG SUMMARY A1", 2);
            }
        }
        //Saumen082916
        
        /// <summary>
        /// Applys the command ZKSWC <vpars> <option> on the specified VPARs using the SENDCMD EXEC and waits for 1 minute without expecting any specific output. Corresponding output is logged in LDNITE LOG A1
        /// </summary>
        /// <param name="vpars">vpars to apply the ZKSWC command</param>
        /// <param name="option">options for ZKSWC command</param>
        private void ZKSWC(string vpars, string option)
        {
            VM_wnd.EnterCommand("PIPE CMS SENDCMD " + vpars + " ZKSWC " + option + " (NODISPLAY |>> LDNITE LOG A1", 1 * 60);
        }
        //Saumen020717 : to send using email
        /// <summary>
        /// Return a true if you want continue else return false. 
        /// LogOnly-Return True
        /// NotifyOnly-Return True
        /// NotifyandAbort-Return False
        /// NotifyandWait-Returns True/False based on dialog result
        /// </summary>
        /// <param name="errorstring"></param>
        /// <param name="errortype"></param>
        /// <returns></returns>
        bool HandleError(string errorstring, ErrorTypes errortype, ErrorGroup ERRGRP = ErrorGroup.NOT_CLASSIFIED_ERROR, string subject = null, string emailid = null, bool attacherrorfile = true)
        {
            //Replace notify type in Scheduler run during call
            //For Notify and Abort rather than Notify and wait
            //Runsettings.IsSchedulerRun?ErrorTypes.NotifyandAbort:ErrorTypes.NotifyandWait
            //For Notify and Log rather than notify and wait
            //Runsettings.IsSchedulerRun?ErrorTypes.NotifyAndLog:ErrorTypes.NotifyandWait
            try
            {
                VM_wnd.SendText(Keys3270.Reset, false, false);
            }
            catch { }
            if (errortype != ErrorTypes.NotifyOnly)
            {
                ErrorsInRun.Insert(0, DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + "==> " + errorstring);
                System.IO.File.WriteAllLines(runSett.CoderunServer + @"\RunErrors.txt", ErrorsInRun);
            }
            try
            {
                if (ERRGRP != ErrorGroup.NO_ERROR)
                {
                    //Add error to ErrorDB csv file
                    //MM/dd/yyyy hh:mm:ss tt,"Error text",ErrorGroup
                    System.IO.File.AppendAllLines(App.RegressionErrorDBfile,
                        new string[] { DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + ",\""
                            + errorstring.Replace("\"", null) + "\","
                            + ERRGRP.ToString()+"," +
                            (runSett != null ?  runSett.InstallDate + "," + runSett.RegType + "," + runSett.RunNumber+","+(runSett.IsSchedulerRun?"Scheduler Run,":"UI Run,")+"\""+runSett.CoderunServer+"\"," : ",,,,,,")
                            +errortype.ToString() });
                }
            }
            catch
            { }
            try
            {
                // Store the screenshot file into coderun server
                System.IO.File.Copy(VM_wnd.screenshotfile, System.IO.Path.Combine(runSett.CoderunServer, System.IO.Path.GetFileName(VM_wnd.screenshotfile)), true);
                //  System.IO.File.Delete(reg.screenshotfile);
            }
            catch { }

            if (errortype != ErrorTypes.LogOnly)
            {
                new Thread(() =>
                {

                    Outlook.Application oApp; Outlook.MailItem oMsg; Outlook.Recipients oRecips; Outlook.Recipient oRecip;
                    try
                    {
                        if (errortype != ErrorTypes.LogandWait)
                        {
                            oApp = new Outlook.Application();
                            oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                            oRecips = (Outlook.Recipients)oMsg.Recipients;
                            if (emailid == null)
                                oRecip = (Outlook.Recipient)oRecips.Add(runSett.email + "@visa.com");
                            else
                                oRecip = (Outlook.Recipient)oRecips.Add(emailid + "@visa.com");
                            oRecip.Resolve();
                            if (subject == null)
                                //oMsg.Subject = (runSett.VIPS.Where(v => v.VPARS != "" && v.VPARS != null).Count() + " VIP ").Replace("0 VIP ", "") + runSett.RegType + " Regression for " + DateTime.ParseExact(runSett.InstallDate, @"MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture).AddDays(7).ToString(@"MM/dd/yyyy") + " install (" + runSett.RunNumber + ") " + "- Error => " + errorstring;//Saumen031117
                                oMsg.Subject = (runSett.VIPS.Where(v => v.VPARS != "" && v.VPARS != null).Count() + " VIP ").Replace("0 VIP ", "") + runSett.RegType + " Regression for " + DateTime.ParseExact(runSett.InstallDate, @"MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture).ToString(@"MM/dd/yyyy") + " install (" + runSett.RunNumber + ") " + "- Error => " + errorstring;//Saumen032817
                            else
                                oMsg.Subject = subject;
                            oMsg.BodyFormat = Outlook.OlBodyFormat.olFormatPlain;
                            oMsg.Body = runSett.CoderunServer;
                            if (attacherrorfile)
                            {
                                oMsg.Body += "\nPlease review the errors from attached file.\nAuto generated from QACT";
                                oMsg.Attachments.Add(runSett.CoderunServer + @"\RunErrors.txt");
                            }
                            else
                                oMsg.Body += "\nAuto generated from QACT";

                            ((Outlook._MailItem)oMsg).Send();
                        }

                    }
                    catch (Exception)
                    {

                    }
                    finally
                    {
                        oApp = null; oMsg = null; oRecip = null; oRecips = null;
                        //GGIRDHAR 01/23/2017 - Introduce GC for Outlook Object. The Entire Block Below takes care of disposing the Outlook Objects.
                        // GGIRDHAR - The Block starts here
                        if (oRecip != null || oRecips != null || oMsg != null || oApp != null)
                        {
                            try
                            {
                                Marshal.ReleaseComObject(oRecip);
                                oRecip = null;
                                Marshal.ReleaseComObject(oMsg);
                                oMsg = null;
                                Marshal.ReleaseComObject(oRecips);
                                oRecips = null;
                                Marshal.ReleaseComObject(oApp);
                                oApp = null;
                            }
                            catch (Exception)
                            {
                                oRecip = null;
                                oRecips = null;
                                oMsg = null;
                                oApp = null;
                            }
                            finally
                            {
                                GC.Collect();
                            }
                        }
                        // GGIRDHAR - The Block ends here
                    }

                }).Start();

                //if (Runsettings.IsSchedulerRun && (errortype == ErrorTypes.NotifyandWait || errortype == ErrorTypes.LogandWait || errortype == ErrorTypes.NotifyandAbort))
                //{/////////// Abort QACT only for scheduler only ////////////////////
                //    ErrorAbort();
                //    return false;
                //}
                if (errortype == ErrorTypes.NotifyandAbort)
                {
                    //if (runSett.IsSchedulerRun)//Saumen021717
                    ErrorAbort();
                    return false;
                }
                else if (errortype == ErrorTypes.NotifyandWait || errortype == ErrorTypes.LogandWait)
                {
                    if (MessageBox.Show("Press Yes to Continue, No to Abort\nError encountered:\n" + errorstring, "Regression Window - " + VM_wnd.SessionShortName, MessageBoxButton.YesNo, MessageBoxImage.Error, MessageBoxResult.Yes) == MessageBoxResult.No)
                        return false;
                }
            }
            return true;
        }
        /// <summary>
        /// Closes QACT by releasing all the resources in the order VPARS-->CMS-->HLLAPI 
        /// </summary>
        public void ErrorAbort()
        {
            //Finishing Regression
            if (IsLoggedon)
            {
                try
                {
                    //Do a Page up +I cms
                    VM_wnd.SendText(Keys3270.PA1);
                    VM_wnd.EnterCommand("I CMS");
                    VM_wnd.SendText(Keys3270.Enter);
                    VM_wnd.WaitforString("Ready", 10);
                    //Upload RexxErrlog
                    UploadRexxErrorLog();
                    //
                    LogOffAllVPARS(runSett.VIPS.Where(v => !String.IsNullOrWhiteSpace(v.VPARS)).ToList());
                    if (HSM_PRODD77 == "DETACHED")                                                                  //Saumen090116
                    {
                        //Saumen082916
                        if (runSett.RegType != "DRB")
                        {
                            //Saumen030317
                            //if (runSett.RegType == "DURBIN" || runSett.RegType == "ECIP" || runSett.RegType == "UNBALANCED" || runSett.RegType == "PRODD" || runSett.RegType == "TOKEN")
                            //{
                            //Saumen030317
                            ReserveHSM("9", "ATTACH");
                            //Saumen030317
                            //}
                            //else
                            //{
                            //    ReserveHSM("5", "ATTACH");
                            //}
                            //Saumen030317
                        }
                        //Saumen082916
                    }
                }
                catch { }

                try
                {
                    LogOffCMS();
                }
                catch { }
            }
            //Remove the handler before aborting.
            Completed();
            //this.OnLoadNightCompleted -= Scheduler_OnLoadNightCompleted;//Saumen021717
            VM_wnd.DisconnectSession();

            App.InputObj.State = InputFile.Status.REGRESSION_COMPLETED;
            StageUpdate("Error", "Abort", true);//Saumen021317
            InputFile.UpdateStatus(App.InputObj, "Error : Aborted");//Saumen092816

            // Close QACT
            if (Application.Current != null)
                Application.Current.Dispatcher.Invoke(() =>
                {
                    try
                    {
                        Application.Current.Shutdown(-1);
                        IsIdle = true;//Saumen021317
                    }
                    catch
                    {
                        Environment.Exit(-1);
                    }

                });
        }
        private void UploadRexxErrorLog()
        {
            if (IsLoggedon)
            {

                try
                {
                    string tmpfilepath = Path.GetTempFileName();
                    VM_wnd.ReceiveFile(tmpfilepath, "QACTREXX ERRLOG   A1");
                    File.Copy(tmpfilepath, Path.Combine(runSett.CoderunServer, "QACTREXX_ERRLOG_regression.txt"), true);
                    if (!File.Exists(Path.Combine(App.AutomationFiles, "QACTREXX_ERRLOG_regression.txt")))
                        File.WriteAllLines(Path.Combine(App.AutomationFiles, "QACTREXX_ERRLOG_regression.txt"), File.ReadAllLines(tmpfilepath));
                    else
                        File.AppendAllLines(Path.Combine(App.AutomationFiles, "QACTREXX_ERRLOG_regression.txt"), new List<string>() { new string('-', 100), runSett.CoderunServer, new string('-', 100) }.Concat(File.ReadAllLines(tmpfilepath)));
                    File.Delete(tmpfilepath);
                }
                catch { };
            }
        }
        /// <summary>
        /// Logs of all the given VICs by using "TPFOPR <VPARS> ZCP LOG"
        /// </summary>
        /// <param name="VICs">List of all the VICs to log off</param>
        public void LogOffAllVPARS(IList<QACT_WPF.VIP> VICs)
        {
            foreach (VIP vic in VICs.Where(v => !String.IsNullOrWhiteSpace(v.VPARS)))
            {
                //Saumen031017
                VM_wnd.EnterCommand("TPFOPR " + vic.VPARS + " ZCYCL 1052", 2);
                VM_wnd.EnterCommand("TPFOPR " + vic.VPARS + " ZDSYS", 2);
                int max_try = 0;
                while (VM_wnd.WaitforString("IN 1052", 60) == 0 && max_try <= 5)
                {
                    VM_wnd.EnterCommand("TPFOPR " + vic.VPARS + " ZDSYS", 2);
                    max_try++;
                }
                //Saumen031017
                VM_wnd.EnterCommand("TPFOPR " + vic.VPARS + " ZCP LOG", 1);
                VM_wnd.WaitforString("not open (no longer open)", 20);
                VM_wnd.WaitforString("Ready", 60);
            }
        }
        /// <summary>
        /// Logs of the logged in CMS by enetering "LOG"
        /// </summary>
        public void LogOffCMS()
        {
            // LOGGING OFF
            //reg.EnterCommand("LOGOFF", 3);                                                                          //Saumen082316
            //reg.WaitforString("z/VM ONLINE", 15);
            UpdateUsingFile();//Saumen020917
            VM_wnd.EnterCommand("LOGOFF", 1);
            VM_wnd.WaitforString("z/VM ONLINE", 30, false);
            VM_wnd.DisconnectSession();//Saumen020917
        }
        //Saumen020717
        //GGIRDHAR020817
        /// <summary>
        /// Applys the command ZCP VPQ on the specified VPARs using the SENDCMD EXEC and waits for 1 minute without expecting any specific output. Corresponding output is logged in LDNITE LOG A1
        /// </summary>
        /// <param name="vpars">vpars to apply the ZCP VPQ command</param>
        private void ZCPVPQ(string vpars)
        {
            VM_wnd.EnterCommand("PIPE CMS SENDCMD " + vpars + " ZCP VPQ " + " (NODISPLAY |>> LDNITE LOG A1", 1 * 60);
        }

        //Saumen021717
        //void Scheduler_OnLoadNightCompleted()
        //{
        //    // Log off VPARSes
        //    LogOffAllVPARS(runSett.VIPS.Where(v => !String.IsNullOrWhiteSpace(v.VPARS)).ToList());
        //    if (HSM_PRODD77 == "DETACHED")                                                                  //Saumen090116
        //    {
        //        //Saumen082916
        //        if (runSett.RegType != "DRB")
        //        {
        //            if (runSett.RegType == "DURBIN" || runSett.RegType == "ECIP" || runSett.RegType == "UNBALANCED" || runSett.RegType == "PRODD" || runSett.RegType == "TOKEN")
        //            {
        //                ReserveHSM("9", "ATTACH");
        //            }
        //            else
        //            {
        //                ReserveHSM("5", "ATTACH");
        //            }
        //        }
        //        //Saumen082916
        //    }
        //    // Log off CMS
        //    LogOffCMS();//Saumen020917
        //    // Update Status
        //    App.InputObj.State = InputFile.Status.REGRESSION_COMPLETED;
        //    InputFile.UpdateStatus(App.InputObj, "Error : Aborted");//Saumen092816

        //    // Close QACT
        //    if (Application.Current != null)
        //        Application.Current.Dispatcher.Invoke(() =>
        //        {
        //            try
        //            {
        //                Application.Current.Shutdown(-1);
        //                IsIdle = true;
        //            }
        //            catch
        //            {
        //                Environment.Exit(-1);
        //            }

        //        });
        //}
        //Saumen021717
    }
}


// ***************************************************************************************
//                                  Change Log
// ***************************************************************************************
// Date       - Name            - Description                               - Label
// ***************************************************************************************
// 02/08/2017 - Gaurav Girdhar  - Added 'ZCP VPQ' before and after every    - GGIRDHAR020817
//                                operation in the process to keep a check on
//                                system usage.
// 09/08/2016 - Saumen Biswas   - Added 'GET TESTCASE' before calling       - Saumen090816
//                                'RESHSM'
// 08/29/2016 - Saumen Biswas   - Aded call to RESHSM EXEC to reserve HSMs  - Saumen082916
// ***************************************************************************************
