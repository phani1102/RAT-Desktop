﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
    public class SimpleWEList
    {
        public static List<SampleWE> ParseSimpleWEList(string excelPath)
        {
            Excel.Application xlapp = null; Excel.Workbook xlworkbook = null; Excel.Worksheet xlsheet = null;
            List<SampleWE> SampleWEs = new List<SampleWE>();
            try
            {
                xlapp = new Excel.Application();
                xlworkbook = xlapp.Workbooks.Open(excelPath);
                xlsheet = xlworkbook.Worksheets[1];

                foreach (Excel.Range row in xlsheet.UsedRange.Rows)
                {
                    string wenumber = (row.Columns[1].Text as string);
                    if (wenumber.Contains("WE"))
                    {
                        SampleWEs.Add(new SampleWE()
                        {
                            WE = wenumber,
                            WEType = row.Columns[2].Text,
                            LoadDate = row.Columns[3].Text,
                            ProjectName = row.Columns[4].Text,
                            Owner = row.Columns[5].Text,
                            State = row.Columns[6].Text,
                            LoadState = row.Columns[7].Text,
                            LoadType = row.Columns[8].Text,
                            RTN = row.Columns[9].Text,
                            VTAPE = row.Columns[10].Text,
                            DebugVtape = row.Columns[11].Text,
                            LeadDevelopers = row.Columns[12].Text,
                            Developers = row.Columns[13].Text
                        });
                    }
                }

            }
            catch (Exception )
            {

            }
            finally
            {
                xlsheet = null;
                if (xlworkbook != null)
                    xlworkbook.Close();
                xlworkbook = null;
                xlapp.Quit();
                if (xlapp != null)
                    xlapp = null;
            }
            return SampleWEs;
        }
    }
    public struct SampleWE
    {
        public string WE { get; set; }
        public string WEType { get; set; }
        public string LoadDate { get; set; }
        public string ProjectName { get; set; }
        public string Owner { get; set; }
        public string State { get; set; }
        public string LoadState { get; set; }
        public string LoadType { get; set; }
        public string RTN { get; set; }
        public string VTAPE { get; set; }
        public string DebugVtape { get; set; }
        public string LeadDevelopers { get; set; }
        public string Developers { get; set; }
    }

