﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.Specialized;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Text.RegularExpressions;
using System.Web.UI;
using QACT_WPF;

namespace LoadNightTesting
{
    public class WEData
    {
        /// <summary>
        /// WE install order according to the SLIMS install script
        /// </summary>
        public int WEInstallOrder;
        /// <summary>
        /// WENumber as used in the SLIMS install script
        /// </summary>
        public string WENumber;
        /// <summary>
        /// State in which WE has to be installed
        /// </summary>
        //public string WEState { BASE = 0, _1052, NORM_INACTIVE, NORM_ACTIVE, GLOBAL_LOAD };
        public string WEState;
        /// <summary>
        /// stores comma separated tapenumbers keyed by their tape type
        /// </summary>
        public IDictionary<string, string> Tapes = new Dictionary<string, string>();
        /// <summary>
        /// A list of mismatches for this WE, initiallly empty
        /// </summary>
        public List<MismatchData> WEMMList = new List<MismatchData>();
        /// <summary>
        /// Contains a list of new dumps occured for this WE, after excluding the known dumps
        /// </summary>
        public List<String> NewDumpsFound = new List<string>();

        public WEData()
        {
            WENumber = null;
            WEInstallOrder = -1;
            WEState = "NONE";
        }

        /// <summary>
        /// initializes a single WE
        /// </summary>
        /// <param name="installOrder"></param>
        /// <param name="WEName"></param>
        /// <param name="installState"></param>
        public WEData(int installOrder, string WEName, string installState)
            : this()
        {
            this.WEInstallOrder = installOrder;
            this.WENumber = String.Copy(WEName);
            this.WEState = installState;
        }
    }
    public class WELogs
    {
        /// <summary>
        /// List of all the WEs obtained by parsing the Slims install script
        /// </summary>
        public List<WEData> WEInstallList = new List<WEData>();
        public string SlimsSimpleWEListPath = String.Empty;
        public string SlimsInstallScriptPath = String.Empty;
        private List<SampleWE> simpleWEList = null;
        public WELogs()
        {

        }

        public WELogs(string slimsInstallScriptPath, string slimsSimpleWEListPath)
            : this()
        {
            this.SlimsInstallScriptPath = slimsInstallScriptPath;
            this.SlimsSimpleWEListPath = slimsSimpleWEListPath;
            WEInstallList = new List<WEData>();
            /// add baseline WE data at install order 0
            WEInstallList.Add(new WEData(0, "BASELINE", "BASE"));

            SimpleWEList.ParseSimpleWEList(SlimsSimpleWEListPath)
                        //.ForEach(simpleWE => WEInstallList.Add(new WEData(WEInstallList.Count, simpleWE.WE, simpleWE.State)));
                        .ForEach(simpleWE => WEInstallList.Add(new WEData(WEInstallList.Count, simpleWE.WE, simpleWE.LoadState))); //fall forward :: added the commit 4611440ca58 (Load Night: Bug fix in Load Night, WE Load State) back to fix VIPENG-1109

            //// populate WE data by parsing slims install script

            //WEData.WEState currSystemState = WEData.WEState.NORM;
            //int currInstallOrder = 0;
            ////*--------------- WORK EFFORT WE014830 ----------------
            //Regex WELineRegex = new Regex(@"\s*\*-+\s*WORK\s+EFFORT\s+(?<WENumber>\w+)\s*-+\s*", RegexOptions.IgnoreCase);
            //// *---
            //Regex endOfWE = new Regex(@"\s*\*-+\s*");
            //// ZCYCL 1052
            //Regex ZCYCL_1052 = new Regex(@"\s*ZCYCL\s+1052\s*", RegexOptions.IgnoreCase);
            //// ZCYCL NORM
            //Regex ZCYCL_NORM = new Regex(@"\s*ZCYCL\s+NORM\s*", RegexOptions.IgnoreCase);
            //// ZOLDR ACT WE014830
            //Regex ZOLDR_ACT = new Regex(@"\s*ZOLDR\s+ACT\s+(?<WENumber>\w+)\s*", RegexOptions.IgnoreCase);

            //string[] slimsInstallScript = System.IO.File.ReadAllLines(slimsInstallScriptPath);

            //for (int ln = 0; ln < slimsInstallScript.Length; ln++)
            //{
            //    if (WELineRegex.IsMatch(slimsInstallScript[ln]))
            //    {
            //        string WENumber = WELineRegex.Match(slimsInstallScript[ln]).Groups["WENumber"].Value;
            //        WEData.WEState WEactvState = WEData.WEState.BASE;

            //        // WE install script;
            //        for (ln++; ln < slimsInstallScript.Length; ln++)
            //        {
            //            if (ZCYCL_1052.IsMatch(slimsInstallScript[ln]))
            //                currSystemState = WEData.WEState._1052;

            //            else if (ZCYCL_NORM.IsMatch(slimsInstallScript[ln]))
            //                currSystemState = WEData.WEState.NORM;

            //            else if (ZOLDR_ACT.IsMatch(slimsInstallScript[ln]))
            //                WEactvState = currSystemState;

            //            else if (endOfWE.IsMatch(slimsInstallScript[ln]))
            //                break;
            //        }
            //        // end of script
            //        currInstallOrder += 1;
            //        WEInstallList.Add(new WEData(currInstallOrder, WENumber, (WEactvState == WEData.WEState.BASE ? currSystemState : WEactvState)));

            //    }
            //    else if (ZCYCL_1052.IsMatch(slimsInstallScript[ln]))
            //        currSystemState = WEData.WEState._1052;

            //    else if (ZCYCL_NORM.IsMatch(slimsInstallScript[ln]))
            //        currSystemState = WEData.WEState.NORM;
            //}
        }

        #region HTML
        public string createHTMLReport(RunSettings runSett)
        {
            System.IO.StringWriter strWriter = new System.IO.StringWriter();
            HtmlTextWriter html = new System.Web.UI.HtmlTextWriter(strWriter, "\t");

            html.RenderBeginTag(HtmlTextWriterTag.Html);
            html.RenderBeginTag(HtmlTextWriterTag.Head);
            getHTMLStyleElement(html);
            html.RenderEndTag();    // head

            // Try reading the simple WE list
            try
            {
                simpleWEList = SimpleWEList.ParseSimpleWEList(SlimsSimpleWEListPath);
            }
            catch
            {
                simpleWEList = null; // unable to read WEList
            }

            html.RenderBeginTag(HtmlTextWriterTag.Body);

            createDumpsTable(runSett, html);

            createMMTable(html);

            html.RenderEndTag();    // Body
            html.RenderEndTag();    // html

            return strWriter.ToString();
        }
        /// <summary>
        /// Gets the style element
        /// </summary>
        /// <param name="html"></param>
        /// <returns>style element</returns>
        public static string getHTMLStyleElement(HtmlTextWriter html = null)
        {
            if (html == null)
            {
                html = new HtmlTextWriter(new System.IO.StringWriter(), "\t");
            }

            html.RenderBeginTag(HtmlTextWriterTag.Style);
            html.Write(@"
                        body {
                            font-family:Calibri
                        }

                        h5, h4, h3, h2, h1 {
                            text-decoration: underline;
                        }

                        table {
                            border-collapse: collapse;
                         }

                        table, th, td {
                             border: 1px solid black;
                         }
                         
                        th {
                            background-color: LightYellow;
                        }
                        td {
                            background-color:  LightCyan;
                        }
                        tr.head{
                            background-color: LightGray;
                        }
                        p{
                            font-family:Calibri
                        }
                        ");
            html.RenderEndTag(); // style

            return html.ToString();
        }

        private void createDumpsTable(RunSettings runSett, HtmlTextWriter html)
        {
            if (!WEInstallList.Any(we => we.NewDumpsFound.Count > 0 && !we.WEState.Equals("BASE", StringComparison.InvariantCultureIgnoreCase)))
            {
                html.RenderBeginTag(HtmlTextWriterTag.H4); html.Write("No Dumps were observed in this run:"); html.RenderEndTag();
                return;
            }

            html.RenderBeginTag(HtmlTextWriterTag.H4); html.Write("Following Dumps were observed in this run:"); html.RenderEndTag();

            List<string> header = new List<string>(new string[] { "OBS #", "WE/Switch/Global", "RTN", "Installation State", "Dump", "Program", "TSDUMP VPARS" });

            List<string> tapesHdr = null;
            try
            {
                tapesHdr = WEInstallList
                                .Where(we => we.NewDumpsFound.Count > 0)
                                .OrderByDescending(we => we.Tapes.Count)
                                .First().Tapes.Keys.ToList();
            }
            catch
            {
                tapesHdr = new List<string>(new string[] { "DTD", "RSI", "CSI" });
            }

            header.AddRange(tapesHdr);

            html.RenderBeginTag(HtmlTextWriterTag.Table);
            ///////////////// table header row ///////////////////
            html.RenderBeginTag(HtmlTextWriterTag.Thead);
            header.ForEach(h =>
            {
                html.RenderBeginTag(HtmlTextWriterTag.Th);
                html.Write(h);
                html.RenderEndTag();
            });
            html.RenderEndTag();    //thead

            int obsNo = 1;
            ////////////////// table rows ///////////////////////
            WEInstallList
                .Where(we => !we.WEState.Equals("BASE", StringComparison.InvariantCultureIgnoreCase))
                .Where(we => we.NewDumpsFound.Count > 0)
                .OrderBy(we => we.WENumber)
                .ToList()
                .ForEach(we =>
                {

                    string RTN = String.Empty;
                    try
                    {
                        RTN = simpleWEList.First(w => w.WE == we.WENumber).RTN;
                    }
                    catch
                    {
                        RTN = "NA";
                    }

                    we.NewDumpsFound
                        .Select(d => LoadNightProcess.dumpLineRegex.Match(d))
                        .ToList()
                        .ForEach(dumpLine =>
                        {
                            string dumpVPARS = dumpLine.Groups["vpars"].Value;
                            string dumpId = dumpLine.Groups["dump_id"].Value;

                            // add rows 
                            html.RenderBeginTag(HtmlTextWriterTag.Tr);

                            html.RenderBeginTag(HtmlTextWriterTag.Td); html.Write(obsNo); html.RenderEndTag();  // Obs no
                            obsNo += 1;

                            html.RenderBeginTag(HtmlTextWriterTag.Td); html.Write(we.WENumber); html.RenderEndTag();  // WE/Switch/Global

                            html.RenderBeginTag(HtmlTextWriterTag.Td); html.Write(RTN); html.RenderEndTag();  // RTN

                            html.RenderBeginTag(HtmlTextWriterTag.Td); html.Write(we.WEState); html.RenderEndTag();  // Install STATE

                            html.RenderBeginTag(HtmlTextWriterTag.Td);
                            html.AddAttribute(HtmlTextWriterAttribute.Href, System.IO.Path.Combine(runSett.CoderunServer, "DUMP" + dumpId + "_" + dumpVPARS + ".txt"));
                            html.RenderBeginTag(HtmlTextWriterTag.A);
                            html.Write(dumpLine.Groups["dump_number"].Value);
                            html.RenderEndTag();
                            html.RenderEndTag();

                            html.RenderBeginTag(HtmlTextWriterTag.Td); html.Write(dumpLine.Groups["program"].Value); html.RenderEndTag();  // Program

                            html.RenderBeginTag(HtmlTextWriterTag.Td); html.Write(dumpVPARS); html.RenderEndTag();  // TSDUMP VPARS

                            tapesHdr.ForEach(tapeType =>
                            {
                                html.RenderBeginTag(HtmlTextWriterTag.Td);
                                try
                                {
                                    html.Write(
                                        we.Tapes[tapeType].Split(',')[runSett.VIPS.IndexOf(runSett.VIPS.First(vip => vip.VPARS == dumpVPARS))]
                                        );
                                }
                                catch
                                {
                                    html.Write("NA");
                                }
                                html.RenderEndTag();
                            });

                            html.RenderEndTag(); // tr

                        });
                });

            html.RenderEndTag();// table
        }

        private void createMMTable(HtmlTextWriter html)
        {

        }
        #endregion
        /// <summary>
        /// Validates the Slims Install script 
        /// </summary>
        /// <returns>true for a valid install script or throws an exception for invalid script </returns>
        public bool ValidateInstallScript()
        {
            return true;
        }
    }
    /// <summary>
    /// Class to store a single mismatch data
    /// </summary>
    public class MismatchData
    {
        // initially all values are empty
        public string Field = String.Empty;
        public string Value1 = String.Empty;
        public string Value2 = String.Empty;
        public string Status = String.Empty;
        public string Type = String.Empty;
        public string TestcaseFile = String.Empty;
        public MismatchData()
        {
        }
    }
}
