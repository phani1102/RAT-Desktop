﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.IO;

namespace LoadNightTesting
{
    public class FTPVIPFile
    {
        private IPAddress VIP_IP;
        string srcFilePath;
        string remoteFilePath;
        public enum FileTypes { Travel_TAG, CDB, CardArtMetadata, RTD, OTHER}
        FileTypes FileType;

        public FTPVIPFile(FileTypes fType, string srcFilePath, IPAddress vic_IP)
        {
            VIP_IP = vic_IP;
            this.srcFilePath = srcFilePath;
            FileType = fType;

            switch (FileType)
            {
                case FileTypes.Travel_TAG:
                    remoteFilePath = Path.Combine("/usr/PFSBTKN/ttag/request/", Path.GetFileName(srcFilePath));
                    break;
                case FileTypes.CDB:
                    remoteFilePath = Path.Combine("/usr/cdb", Path.GetFileName(srcFilePath));
                    break;
                case FileTypes.CardArtMetadata:
                    remoteFilePath = Path.Combine("/usr/PFSBTKN/cart/request", Path.GetFileName(srcFilePath));
                    break;
                case FileTypes.RTD:
                    remoteFilePath = Path.Combine("/usr/realtimed", Path.GetFileName(srcFilePath));
                    break;
            }
        }

        public void FTPfile()
        {
            switch (FileType)
            {
                case FileTypes.Travel_TAG:
                    FTPVIPUpload(srcFilePath, remoteFilePath);
                    break;
                case FileTypes.CDB:
                    FTPVIPUpload(srcFilePath, remoteFilePath);
                    break;
                case FileTypes.CardArtMetadata:
                    FTPVIPUpload(srcFilePath, remoteFilePath);
                    break;
                case FileTypes.RTD:
                    FTPVIPUpload(srcFilePath, remoteFilePath);
                    break;
                default:
                    FTPVIPUpload(srcFilePath, remoteFilePath);
                    break;
            }

        }

        private void FTPcdb()
        {

        }

        private void FTPcart()
        {

        }

        private void FTPttag()
        {

        }

        private void FTPrtd()
        {

        }

        private string getFileMD5(string filename)
        {
            using (var md5 = System.Security.Cryptography.MD5.Create())
            {
                return BitConverter.ToString(md5.ComputeHash(File.ReadAllBytes(filename))).Replace("-", "").ToLower();
            }
        }

        private void FTPVIPUpload(string srcFile, string remoteFilePath, bool usebinary = false, string cmsid = "root", string pwd  = "root")
        {
            UriBuilder remoteUriBuild = new UriBuilder("ftp", VIP_IP.ToString());
            remoteUriBuild.Path = remoteFilePath;
            
            FtpWebRequest request;

            request = (FtpWebRequest)WebRequest.Create(remoteUriBuild.Uri);
            request.Credentials = new NetworkCredential(cmsid, pwd);
            request.Method = WebRequestMethods.Ftp.UploadFile;
            request.UseBinary = usebinary;
            request.KeepAlive = false;

            using (StreamReader sourceStream = new StreamReader(srcFile))
            {
                byte[] fileContents = Encoding.Default.GetBytes(sourceStream.ReadToEnd());
                request.ContentLength = fileContents.Length;
                using (Stream requestStream = request.GetRequestStream())
                {
                    requestStream.Write(fileContents, 0, fileContents.Length);
                }
            }

        }
    }
}
