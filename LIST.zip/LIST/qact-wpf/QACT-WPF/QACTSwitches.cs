﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QACT_WPF;

namespace QACT_WPF
{
    public static class QACTSwitches
    {
        public static bool IsSwitchActive(int swtno)
        {
            if (AllSwitches == null)
            {
                try
                {
                    AllSwitches = CommonClass.LoadFromJSONFile<List<QACTSWITCH>>(App.QACTSwitchesFile);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            var reqswt = AllSwitches.FirstOrDefault(swt => swt.Number == swtno);
            if (reqswt == null)
            {
                return false;
            }
            return reqswt.IsActive;
        }
        class QACTSWITCH
        {
            public int Number { get; set; }
            public string Description { get; set; }
            public bool IsActive { get; set; }
        }
        private static List<QACTSWITCH> AllSwitches;
    }
}
